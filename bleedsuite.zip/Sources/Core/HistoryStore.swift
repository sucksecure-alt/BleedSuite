import Foundation
import os

/// Thread-safe store of captured exchanges plus the currently applied filter.
///
/// Rows are kept in arrival order and trimmed FIFO at `capacity`. `index` holds
/// the row offsets that pass the filter, so UI reads never scan the whole history.
final class HistoryStore: @unchecked Sendable {
    static let shared = HistoryStore()

    struct Filter: Sendable, Equatable {
        var text: String = ""
        var host: String = ""
        var methods: Set<String> = []
        var statusClasses: Set<StatusClass> = []
        var origins: Set<HTTPPair.Origin> = []
        var isActive: Bool = false

        init() {}

        init(text: String = "", host: String = "", methods: Set<String> = [],
             statusClasses: Set<StatusClass> = [], origins: Set<HTTPPair.Origin> = [],
             isActive: Bool = false) {
            self.text = text
            self.host = host
            self.methods = methods
            self.statusClasses = statusClasses
            self.origins = origins
            self.isActive = isActive
        }

        var isEmpty: Bool {
            text.isEmpty && host.isEmpty && methods.isEmpty && statusClasses.isEmpty && origins.isEmpty
        }
    }

    private struct State {
        var rows: [HTTPPair] = []
        var byID: [Int: Int] = [:]
        var index: [Int] = []
        var filter = Filter()
        var generation: Int = 0
        /// Host set and its cached fingerprint; see `hostSignature`.
        var hosts: Set<String> = []
        var signature = ""
    }

    /// Recomputes the fingerprint. Only the *set* of hosts changes when a row is appended, so
    /// this runs at most once per new host rather than once per request.
    private static func refreshSignature(_ s: inout State) {
        s.signature = s.hosts.sorted().joined(separator: "|")
    }

    private let state = OSAllocatedUnfairLock(initialState: State())
    private let filterQueue = DispatchQueue(label: "bleed.history.filter")
    private let capacity: Int

    init(capacity: Int = 60_000) {
        self.capacity = max(1, capacity)
    }

    // MARK: - Mutation

    func add(_ pair: HTTPPair) {
        state.withLock { s in
            appendLocked(pair, to: &s)
            s.generation += 1
        }
    }

    func add(contentsOf pairs: [HTTPPair]) {
        guard !pairs.isEmpty else { return }
        state.withLock { s in
            for pair in pairs { appendLocked(pair, to: &s) }
            s.generation += 1
        }
    }

    func clear() {
        state.withLock { s in
            s.rows.removeAll(keepingCapacity: true)
            s.byID.removeAll(keepingCapacity: true)
            s.index.removeAll(keepingCapacity: true)
            s.hosts.removeAll(keepingCapacity: true)
            s.signature = ""
            s.generation += 1
        }
    }

    /// Point mutation of a stored row. The filter index is repaired in place so a
    /// row edited in the viewer can disappear from (or appear in) the list.
    func update(id: Int, _ mutate: (inout HTTPPair) -> Void) {
        state.withLock { s in
            guard let rowIndex = s.byID[id] else { return }
            var pair = s.rows[rowIndex]
            // `index` is kept in ascending order, so membership is a binary search.
            // This runs on every keystroke the analyst makes in an inspector, so the
            // linear scan it used to do was a real cost at 60k rows.
            let wasVisible = s.index.binarySearch(rowIndex) != nil
            mutate(&pair)
            s.rows[rowIndex] = pair
            let isVisible = Self.matches(pair, filter: s.filter)
            switch (wasVisible, isVisible) {
            case (true, false):
                if let position = s.index.binarySearch(rowIndex) {
                    s.index.remove(at: position)
                }
            case (false, true):
                s.index.insert(rowIndex, at: Self.insertionPoint(for: rowIndex, in: s.index))
            default:
                break
            }
            s.generation += 1
        }
    }

    private func appendLocked(_ pair: HTTPPair, to s: inout State) {
        let rowIndex = s.rows.count
        s.rows.append(pair)
        s.byID[pair.id] = rowIndex
        // Only a genuinely new host invalidates the fingerprint.
        if s.hosts.insert(pair.host).inserted {
            Self.refreshSignature(&s)
        }
        if Self.matches(pair, filter: s.filter) {
            s.index.append(rowIndex)
        }
        if s.rows.count > capacity {
            let overflow = s.rows.count - capacity
            s.rows.removeFirst(overflow)
            s.byID.removeAll(keepingCapacity: true)
            for (offset, row) in s.rows.enumerated() { s.byID[row.id] = offset }
            s.index = s.index.compactMap { offset -> Int? in
                let shifted = offset - overflow
                return shifted >= 0 && shifted < s.rows.count ? shifted : nil
            }
        }
    }

    // MARK: - Reads

    /// Row currently shown at visible position `index`.
    func row(at index: Int) -> HTTPPair? {
        state.withLock { s in
            guard s.index.indices.contains(index) else { return nil }
            return s.rows[s.index[index]]
        }
    }

    var visibleCount: Int { state.withLock { $0.index.count } }
    var totalCount: Int { state.withLock { $0.rows.count } }
    var allRows: [HTTPPair] { state.withLock { $0.rows } }
    var filter: Filter { state.withLock { $0.filter } }
    var generation: Int { state.withLock { $0.generation } }

    /// Visible rows for a UI range; indices are clamped so SwiftUI can ask freely.
    func rows(at range: Range<Int>) -> ArraySlice<HTTPPair> {
        state.withLock { s in
            let lower = max(0, min(range.lowerBound, s.index.count))
            let upper = max(lower, min(range.upperBound, s.index.count))
            let offsets = Array(s.index[lower..<upper])
            return ArraySlice(offsets.map { s.rows[$0] })
        }
    }

    func pair(withID id: Int) -> HTTPPair? {
        state.withLock { s in
            guard let offset = s.byID[id], s.rows.indices.contains(offset) else { return nil }
            return s.rows[offset]
        }
    }

    func pairs(forHost host: String) -> [HTTPPair] {
        let needle = host.lowercased().trimmingCharacters(in: .whitespaces)
        guard !needle.isEmpty else { return [] }
        let bare = needle.hasPrefix(".") ? String(needle.dropFirst()) : needle
        return state.withLock { s in
            s.rows.filter { row in
                let h = row.host.lowercased()
                return h == bare || h.hasSuffix("." + bare) || h.hasSuffix(bare)
            }
        }
    }

    /// Cheap fingerprint of the host set, used to decide when the site map is stale.
    ///
    /// Maintained incrementally rather than recomputed from every row: the UI polls this on every
    /// tick, and walking tens of thousands of rows to build a string each time was the reason the
    /// site map lagged seconds behind the history.
    var hostSignature: String {
        state.withLock { s in s.signature }
    }

    func exportSnapshot() -> [HTTPPair] { allRows }

    // MARK: - Filtering

    /// Re-filters off the caller's thread and publishes atomically. Rows appended
    /// while the scan runs are merged at publish time, so no capture is lost.
    /// `generation` changes only when the publish completes.
    func applyFilter(_ filter: Filter) {
        state.withLock { s in
            guard s.filter != filter else { return }
            s.filter = filter
        }
        filterQueue.async { [weak self] in
            guard let self else { return }
            let snapshot = self.state.withLock { ($0.rows, $0.rows.count) }
            var computed: [Int] = []
            computed.reserveCapacity(snapshot.0.count)
            let active = filter
            for (offset, row) in snapshot.0.enumerated() where Self.matches(row, filter: active) {
                computed.append(offset)
            }
            let baseCount = snapshot.1
            self.state.withLock { s in
                for offset in baseCount..<s.rows.count where Self.matches(s.rows[offset], filter: s.filter) {
                    computed.append(offset)
                }
                s.index = computed
                s.generation += 1
            }
        }
    }

    /// Synchronous rebuild of the index against the current rows and filter.
    func reindex() {
        state.withLock { s in
            var newIndex: [Int] = []
            newIndex.reserveCapacity(s.rows.count)
            for (offset, row) in s.rows.enumerated() where Self.matches(row, filter: s.filter) {
                newIndex.append(offset)
            }
            s.index = newIndex
            s.generation += 1
        }
    }

    private static func insertionPoint(for offset: Int, in index: [Int]) -> Int {
        var low = 0
        var high = index.count
        while low < high {
            let mid = (low + high) / 2
            if index[mid] < offset { low = mid + 1 } else { high = mid }
        }
        return low
    }

    // MARK: - Matching

    private static let maxSearchableBodyBytes = 256 * 1024

    static func matches(_ pair: HTTPPair, filter: Filter) -> Bool {
        if !filter.methods.isEmpty && !filter.methods.contains(pair.request.method) { return false }
        if !filter.statusClasses.isEmpty && !filter.statusClasses.contains(pair.statusClass) { return false }
        if !filter.origins.isEmpty && !filter.origins.contains(pair.origin) { return false }

        let hostFilter = filter.host.trimmingCharacters(in: .whitespaces).lowercased()
        if !hostFilter.isEmpty {
            let host = pair.host.lowercased()
            let bare = hostFilter.hasPrefix(".") ? String(hostFilter.dropFirst()) : hostFilter
            guard host == bare || host.hasSuffix("." + bare) || host.hasSuffix(bare) else { return false }
        }

        let textFilter = filter.text.trimmingCharacters(in: .whitespaces)
        guard !textFilter.isEmpty else { return true }
        return contains(text: textFilter, in: pair)
    }

    private static func contains(text needle: String, in pair: HTTPPair) -> Bool {
        func hit(_ haystack: String) -> Bool {
            haystack.range(of: needle, options: .caseInsensitive) != nil
        }

        if hit(pair.host) || hit(pair.url) || hit(pair.request.path) || hit(pair.request.startLine) { return true }

        for h in pair.request.headers where hit(h.name) || hit(h.value) { return true }
        if !pair.note.isEmpty, hit(pair.note) { return true }

        guard let response = pair.response else { return false }
        if hit(response.startLine) { return true }
        for h in response.headers where hit(h.name) || hit(h.value) { return true }
        if response.body.count < maxSearchableBodyBytes, response.isBodyTextual, hit(response.bodyText) { return true }
        return false
    }
}
extension Array where Element == Int {
    /// Binary search for a value known to be comparable to the elements.
    /// Returns the position, or nil when absent. The filter index is built in
    /// ascending offset order, which is what makes this valid.
    func binarySearch(_ value: Int) -> Int? {
        var low = 0
        var high = count
        while low < high {
            let mid = (low + high) / 2
            if self[mid] < value { low = mid + 1 } else { high = mid }
        }
        return (low < count && self[low] == value) ? low : nil
    }
}
