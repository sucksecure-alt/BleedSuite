
import SwiftUI
import AppKit

// ============================================================================
//  Editable header grid
// ============================================================================

struct HeadersTable: View {
    @Binding var headers: [Header]
    var readOnly = false

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                Text("Enabled").frame(width: 50, alignment: .center)
                Text("Name").frame(maxWidth: .infinity, alignment: .leading)
                Text("Value").frame(maxWidth: .infinity, alignment: .leading)
                Text("").frame(width: 26)
            }
            .font(Theme.ui(10, weight: .semibold))
            .foregroundStyle(Theme.textTertiary)
            .padding(.horizontal, 6)
            .padding(.vertical, 5)
            .background(Theme.surfaceRaised)

            Rectangle().fill(Theme.divider).frame(height: 1)

            ScrollView {
                VStack(spacing: 0) {
                    ForEach(Array(headers.indices), id: \.self) { index in
                        HeaderRow(
                            header: headers[index],
                            readOnly: readOnly,
                            onChange: { newValue in
                                if index < headers.count { headers[index] = newValue }
                            },
                            onDelete: {
                                guard !readOnly, headers.indices.contains(index) else { return }
                                headers.remove(at: index)
                            }
                        )
                        Rectangle().fill(Theme.divider.opacity(0.5)).frame(height: 1)
                    }
                    if !readOnly {
                        Button {
                            headers.append(Header(name: "", value: ""))
                        } label: {
                            HStack(spacing: 5) {
                                Image(systemName: "plus").font(Theme.ui(9, weight: .bold))
                                Text("Add header").font(Theme.ui(11))
                            }
                            .foregroundStyle(Theme.crimson)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 6)
                        }
                        .buttonStyle(.plain)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
        }
        .background(Theme.background)
    }
}

private struct HeaderRow: View {
    var header: Header
    var readOnly: Bool
    var onChange: (Header) -> Void
    var onDelete: () -> Void

    var body: some View {
        HStack(spacing: 0) {
            Toggle("", isOn: Binding(
                get: { header.enabled },
                set: { var h = header; h.enabled = $0; onChange(h) }
            ))
            .labelsHidden()
            .toggleStyle(.checkbox)
            .frame(width: 50)

            if readOnly {
                Text(header.name)
                    .font(Theme.monoSwiftUI(11))
                    .foregroundStyle(Theme.crimson)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(header.value)
                    .font(Theme.monoSwiftUI(11))
                    .foregroundStyle(Theme.info)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                GridField(
                    text: Binding(
                        get: { header.name },
                        set: { var h = header; h.name = $0; onChange(h) }
                    ),
                    color: Theme.crimson
                )
                GridField(
                    text: Binding(
                        get: { header.value },
                        set: { var h = header; h.value = $0; onChange(h) }
                    ),
                    color: Theme.info
                )
            }

            Button(action: onDelete) {
                Image(systemName: "minus.circle")
                    .font(Theme.ui(10))
                    .foregroundStyle(Theme.textTertiary)
            }
            .buttonStyle(.plain)
            .frame(width: 26)
            .opacity(readOnly ? 0 : 1)
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 3)
    }
}

/// Borderless inline text field styled for the grid.
struct GridField: View {
    @Binding var text: String
    var color: Color = Theme.textPrimary

    var body: some View {
        TextField("", text: $text)
            .textFieldStyle(.plain)
            .font(Theme.monoSwiftUI(11))
            .foregroundStyle(color)
            .padding(.horizontal, 3)
            .padding(.vertical, 2)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// ============================================================================
//  Editable parameter grid
// ============================================================================

struct ParamsTable: View {
    @Binding var params: [Param]

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                Text("Enabled").frame(width: 50, alignment: .center)
                Text("Name").frame(maxWidth: .infinity, alignment: .leading)
                Text("Value").frame(maxWidth: .infinity, alignment: .leading)
                Text("").frame(width: 26)
            }
            .font(Theme.ui(10, weight: .semibold))
            .foregroundStyle(Theme.textTertiary)
            .padding(.horizontal, 6)
            .padding(.vertical, 5)
            .background(Theme.surfaceRaised)
            Rectangle().fill(Theme.divider).frame(height: 1)

            ScrollView {
                VStack(spacing: 0) {
                    ForEach(Array(params.indices), id: \.self) { index in
                        HStack(spacing: 0) {
                            Toggle("", isOn: Binding(
                                get: { params.indices.contains(index) ? params[index].enabled : false },
                                set: { if params.indices.contains(index) { params[index].enabled = $0 } }
                            ))
                            .labelsHidden()
                            .toggleStyle(.checkbox)
                            .frame(width: 50)

                            GridField(text: Binding(
                                get: { params.indices.contains(index) ? params[index].name : "" },
                                set: { if params.indices.contains(index) { params[index].name = $0 } }
                            ), color: Theme.crimson)

                            GridField(text: Binding(
                                get: { params.indices.contains(index) ? params[index].value : "" },
                                set: { if params.indices.contains(index) { params[index].value = $0 } }
                            ), color: Theme.success)

                            Button {
                                if params.indices.contains(index) { params.remove(at: index) }
                            } label: {
                                Image(systemName: "minus.circle")
                                    .font(Theme.ui(10))
                                    .foregroundStyle(Theme.textTertiary)
                            }
                            .buttonStyle(.plain)
                            .frame(width: 26)
                        }
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        Rectangle().fill(Theme.divider.opacity(0.5)).frame(height: 1)
                    }
                    Button {
                        params.append(Param(name: "", value: ""))
                    } label: {
                        HStack(spacing: 5) {
                            Image(systemName: "plus").font(Theme.ui(9, weight: .bold))
                            Text("Add parameter").font(Theme.ui(11))
                        }
                        .foregroundStyle(Theme.crimson)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 6)
                    }
                    .buttonStyle(.plain)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .background(Theme.background)
    }
}

// ============================================================================
//  Shared message inspector
// ============================================================================

enum MessageTab: String, CaseIterable, Identifiable {
    case pretty, raw, headers, params
    var id: String { rawValue }
    var title: String {
        switch self {
        case .pretty: return "Pretty"
        case .raw: return "Raw"
        case .headers: return "Headers"
        case .params: return "Params"
        }
    }
    var icon: String {
        switch self {
        case .pretty: return "wand.and.stars"
        case .raw: return "doc.plaintext"
        case .headers: return "list.bullet.rectangle"
        case .params: return "slider.horizontal.3"
        }
    }
}

/// Burp-style inspector for a single HTTP message.
///
/// Used by the history, intercept, repeater, intruder and comparer workspaces, so the
/// editing model (raw ↔ headers ↔ params) behaves identically everywhere.
struct MessageInspector: View {
    @Binding var message: HTTPMessage
    var isEditable: Bool = true
    var tabOverride: MessageTab?
    var onSubmit: (() -> Void)? = nil
    /// Identity of the message the editor was seeded from. Only a change of *this*
    /// re-seeds the raw buffer, so typing never resets the caret.
    var seed: AnyHashable? = nil

    @State private var tab: MessageTab = .raw
    @State private var rawText: String = ""
    @State private var editingRaw = false
    /// Guards the round trip: writing `rawText` back into `message` must not
    /// re-trigger the parse that produced `rawText` in the first place.
    @State private var applying = false

    private var availableTabs: [MessageTab] {
        var tabs: [MessageTab] = [.pretty, .raw, .headers]
        if !message.queryParams.isEmpty || !message.formParams.isEmpty || message.isRequest {
            tabs.append(.params)
        }
        return tabs
    }

    var body: some View {
        VStack(spacing: 0) {
            headerBar
            Rectangle().fill(Theme.divider).frame(height: 1)
            content
        }
        .background(Theme.surface)
        .onAppear { seedEditor() }
        // The store publishes on every edit the analyst makes. Re-seeding from that
        // would reset the caret on each keystroke, so the buffer only follows a
        // change of `seed` — a different transaction, or a different repeater tab.
        .onChange(of: seed) { _, _ in seedEditor() }
        .onReceive(NotificationCenter.default.publisher(for: .bleedFlushPendingEdit)) { _ in
            flushPendingEdit()
        }
    }

    private var headerBar: some View {
        HStack(spacing: 8) {
            SegmentBar(
                selection: $tab,
                options: availableTabs.map { ($0, $0.title, $0.icon) },
                compact: true
            )
            Spacer(minLength: 8)

            if message.isBodyTextual && !message.body.isEmpty {
                Button {
                    copy(message.bodyText)
                } label: {
                    Label("Copy body", systemImage: "doc.on.doc")
                        .font(Theme.ui(11))
                }
                .buttonStyle(GhostButtonStyle(compact: true))
            }

            if !message.body.isEmpty {
                Text(Format.bytes(message.body.count))
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)
            }

            if isEditable && !message.isRequest {
                Button {
                    message.normalizeFraming()
                } label: {
                    Label("Rebuild framing", systemImage: "arrow.triangle.2.circlepath")
                        .font(Theme.ui(11))
                }
                .buttonStyle(GhostButtonStyle(compact: true))
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(Theme.surfaceRaised)
    }

    @ViewBuilder
    private var content: some View {
        switch tabOverride ?? tab {
        case .pretty:
            RawTextView(text: message.body.isEmpty ? "(empty body)" : HexDump.pretty(message.body))
        case .raw:
            CodeEditor(text: $rawText, isEditable: isEditable) {
                commitRaw()
                onSubmit?()
            }
            .onChange(of: rawText) { _, _ in scheduleCommit() }
            .overlay(alignment: .topTrailing) {
                if isEditable {
                    HStack(spacing: 5) {
                        Button {
                            commitRaw()
                        } label: {
                            Label("Apply", systemImage: "checkmark")
                                .font(Theme.ui(10, weight: .semibold))
                        }
                        .buttonStyle(CrimsonButtonStyle(compact: true))

                        Button {
                            rawText = message.prettyRaw
                        } label: {
                            Image(systemName: "arrow.counterclockwise").font(Theme.ui(10))
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))
                        .help("Discard edits")
                    }
                    .padding(6)
                }
            }
        case .headers:
            HeadersTable(headers: $message.headers, readOnly: !isEditable)
        case .params:
            if message.isRequest {
                ParamsTable(params: Binding(
                    get: { message.queryParams },
                    set: { message.setQueryParams($0) }
                ))
                if message.contentType.contains("x-www-form-urlencoded") {
                    ParamsTable(params: Binding(
                        get: { message.formParams },
                        set: { var updated = message; updated.formParams = $0; message = updated }
                    ))
                    .frame(maxHeight: .infinity)
                }
            } else {
                RawTextView(text: "Parameters apply to requests only.")
            }
        }
    }

    /// Edits are written back as they are typed (debounced), the way Burp's raw
    /// editor behaves — otherwise the panel looks frozen until Apply is pressed.
    private func scheduleCommit() {
        guard !applying else { return }
        pendingCommit?.cancel()
        let task = DispatchWorkItem { commitRaw() }
        pendingCommit = task
        pendingFlush = task
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35, execute: task)
    }

    @State private var pendingCommit: DispatchWorkItem?
    @State private var pendingFlush: DispatchWorkItem?
    @State private var seededFor: AnyHashable?

    /// Applies queued keystrokes immediately. Sent before a request goes out so a
    /// debounced edit can never be lost.
    private func flushPendingEdit() {
        guard let task = pendingFlush else { return }
        task.cancel()
        pendingFlush = nil
        pendingCommit = nil
        commitRaw()
    }

    /// Loads the bound message into the raw editor.
    private func seedEditor() {
        seededFor = seed
        rawText = message.prettyRaw
    }

    /// Parses the buffer into the bound message.
    ///
    /// It deliberately does **not** write `parsed.prettyRaw` back into `rawText`. That
    /// normalised rendering is not byte-identical to what the analyst typed, so every debounced
    /// commit snapped the buffer back to the canonical form — the caret jumped and the edit
    /// looked reverted a third of a second after every keystroke. Burp keeps what you typed;
    /// "Discard edits" is the explicit way back to the stored message.
    private func commitRaw() {
        guard !applying else { return }
        applying = true
        message = HTTPMessage.parseEditorText(rawText, isRequest: message.isRequest)
        applying = false
    }

    private func copy(_ text: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
    }
}

// ============================================================================
//  Summary strip shown above an exchange
// ============================================================================

struct ExchangeSummaryBar: View {
    let request: HTTPMessage
    let response: HTTPMessage?
    let host: String
    let isSecure: Bool
    var note: String = ""
    var tags: [String] = []

    var body: some View {
        HStack(spacing: 10) {
            HStack(spacing: 5) {
                Image(systemName: isSecure ? "lock.fill" : "lock.open.fill")
                    .font(Theme.ui(9))
                    .foregroundStyle(isSecure ? Theme.success : Theme.warning)
                Text(host.isEmpty ? (request.header("Host") ?? "—") : host)
                    .font(Theme.monoSwiftUI(11, weight: .semibold))
                    .foregroundStyle(Theme.textPrimary)
                    // Without a line limit this wrapped mid-word — "example.co" / "m" — as soon
                    // as the inspector got narrow. The domain is the one thing here that must
                    // stay readable, so it wins the space and truncates from the front, which
                    // keeps the meaningful tail.
                    .lineLimit(1)
                    .truncationMode(.head)
                    .layoutPriority(2)
            }

            Text(request.method)
                .font(Theme.monoSwiftUI(10, weight: .bold))
                .foregroundStyle(Theme.methodColor(request.method))
                .fixedSize()

            Text(request.path)
                .font(Theme.monoSwiftUI(11))
                .foregroundStyle(Theme.textSecondary)
                .lineLimit(1)
                .truncationMode(.middle)

            if let response {
                StatusChip(status: response.status)
                Text(response.reason)
                    .font(Theme.ui(11))
                    .foregroundStyle(Theme.textSecondary)
                Text(Format.bytes(response.body.count))
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)
            }

            if !note.isEmpty {
                Badge(text: note, color: Theme.crimson)
            }
            ForEach(tags, id: \.self) { Badge(text: $0, color: Theme.warning) }

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(Theme.surfaceRaised)
    }
}