#!/bin/bash
# Proves the TLS record layer no longer costs one thread per session.
#
# Opens a burst of concurrent HTTPS sessions through the proxy and tracks the peak thread
# count. The regression shows up as the count climbing towards dispatch's 512-worker ceiling
# and the process stalling; with the pooled record layer it stays flat no matter the burst.
#
#   ./scripts/threadsoak.sh [parallel] [rounds]
set -uo pipefail
cd "$(dirname "$0")/.." || exit 1

PAR=${1:-240}
ROUNDS=${2:-3}
PORT=8080
BIN=./.build/debug/BleedSuite

pkill -9 -f "\.build/debug/BleedSuite" 2>/dev/null
sleep 1
nohup "$BIN" > /tmp/threadsoak.log 2>&1 < /dev/null &
disown 2>/dev/null || true
sleep 8

PID=$(pgrep -f "\.build/debug/BleedSuite" | head -1)
[ -z "$PID" ] && { echo "app failed to start"; exit 1; }

threads() { ps -M "$PID" 2>/dev/null | wc -l | tr -d ' '; }

base=$(threads)
echo "pid=$PID  baseline_threads=$base  burst=$PAR concurrent TLS sessions x $ROUNDS rounds"
echo

overall_bad=0
peak=$base

for r in $(seq 1 "$ROUNDS"); do
    # Sample in the background so we see the peak, not just the value after the burst drains.
    ( while :; do threads; sleep 0.15; done ) > /tmp/threadsoak.samples 2>/dev/null &
    sampler=$!

    pids=""
    for n in $(seq 1 "$PAR"); do
        ( curl -sk -x "http://127.0.0.1:$PORT" -m 25 -o /dev/null \
              "https://example.com/t/$r/$n" >/dev/null 2>&1 ) &
        pids="$pids $!"
    done
    for p in $pids; do wait "$p" 2>/dev/null; done

    kill "$sampler" 2>/dev/null
    round_peak=$(sort -n /tmp/threadsoak.samples 2>/dev/null | tail -1)
    round_peak=${round_peak:-0}
    [ "$round_peak" -gt "$peak" ] && peak=$round_peak

    alive=$(pgrep -f "\.build/debug/BleedSuite" | head -1)
    if [ -z "$alive" ]; then
        echo "round $r: PROCESS GONE"; overall_bad=1; break
    fi
    code=$(curl -sk -x "http://127.0.0.1:$PORT" -m 15 -o /dev/null -w "%{http_code}" \
           "https://example.com/probe")
    echo "round $r: peak_threads=$round_peak  after_threads=$(threads)  rssMB=$(( $(ps -o rss= -p "$PID") / 1024 ))  proxy_responds=$code"
    [ "$code" = "200" ] || overall_bad=1
done

echo
echo "peak_threads=$peak  (dispatch ceiling is 512)"
if [ "$peak" -ge 512 ]; then
    echo "VERDICT: FAIL — hit the dispatch thread ceiling; the process will stall"
elif [ "$peak" -ge 300 ]; then
    echo "VERDICT: WEAK — below the ceiling but still scaling with session count"
else
    echo "VERDICT: PASS — thread count stays flat under a $PAR-session burst"
fi

pkill -f "\.build/debug/BleedSuite" 2>/dev/null
exit $overall_bad