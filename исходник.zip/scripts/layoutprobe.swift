#!/usr/bin/env swift
// Measures how long the main thread is blocked in Auto Layout, by spinning a run loop and
// timing how far a 10 ms timer can drift.
//
// A SwiftUI layout loop (a view whose layout feeds itself) shows up here as drift growing to
// seconds — exactly the 71 s `layoutIfNeeded` stall the hang reports showed.
//
//   ui layout [seconds]
import CoreFoundation
import Foundation

let seconds = CommandLine.arguments.count > 1 ? (Double(CommandLine.arguments[1]) ?? 6) : 6
let interval = 0.01

var samples: [Double] = []
var next = CFAbsoluteTimeGetCurrent()
let deadline = next + seconds

while CFAbsoluteTimeGetCurrent() < deadline {
    RunLoop.main.run(until: Date().addingTimeInterval(interval))
    let now = CFAbsoluteTimeGetCurrent()
    samples.append((now - next) * 1000)   // milliseconds of drift per 10 ms tick
    next = now
}

samples.sort()
func pct(_ p: Double) -> Double { samples.isEmpty ? 0 : samples[min(samples.count - 1, Int(Double(samples.count) * p))] }
let worst = samples.last ?? 0
print(String(format: "samples=%d  median=%.1fms  p95=%.1fms  worst=%.1fms",
             samples.count, pct(0.5), pct(0.95), worst))
if worst > 250 {
    print("LAYOUT STALL: main thread blocked for \(String(format: "%.0f", worst))ms")
    exit(1)
}
print("main thread responsive")
exit(0)