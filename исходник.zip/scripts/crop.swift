#!/usr/bin/env swift
// Crops a region out of an image, so a screenshot can be inspected at a readable size.
//
//   crop <in.png> <out.png> <x> <y> <w> <h> [scale]
//
// <x> <y> <w> <h> are in pixels of the source image. `scale` multiplies both axes.
import AppKit
import Foundation

let args = CommandLine.arguments
guard args.count >= 7,
      let image = NSImage(contentsOfFile: args[1]),
      let x = Double(args[3]), let y = Double(args[4]),
      let w = Double(args[5]), let h = Double(args[6])
else {
    FileHandle.standardError.write(Data("usage: crop <in> <out> <x> <y> <w> <h> [scale]\n".utf8))
    exit(2)
}

let scale = args.count >= 8 ? (Double(args[7]) ?? 1) : 1

guard let tiff = image.tiffRepresentation,
      let bitmap = NSBitmapImageRep(data: tiff),
      let cg = bitmap.cgImage
else {
    FileHandle.standardError.write(Data("cannot read image\n".utf8))
    exit(2)
}

let rect = CGRect(x: x, y: y, width: w, height: h).integral
guard let cropped = cg.cropping(to: rect) else {
    FileHandle.standardError.write(Data("crop out of bounds\n".utf8))
    exit(2)
}

let outW = Int(rect.width * scale), outH = Int(rect.height * scale)
let final: CGImage
if scale == 1 {
    final = cropped
} else {
    guard let scaled = NSBitmapImageRep(
        bitmapDataPlanes: nil, pixelsWide: outW, pixelsHigh: outH,
        bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false,
        colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0
    ) else { exit(2) }
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: scaled)
    NSColor.black.setFill()
    NSRect(x: 0, y: 0, width: outW, height: outH).fill()
    NSImage(cgImage: cropped, size: NSSize(width: outW, height: outH)).draw(
        in: NSRect(x: 0, y: 0, width: outW, height: outH))
    NSGraphicsContext.restoreGraphicsState()
    guard let s = scaled.cgImage else { exit(2) }
    final = s
}

guard let data = NSBitmapImageRep(cgImage: final).representation(using: .png, properties: [:]) else {
    exit(2)
}
try data.write(to: URL(fileURLWithPath: args[2]))
print("wrote \(args[2]) \(outW)x\(outH)")