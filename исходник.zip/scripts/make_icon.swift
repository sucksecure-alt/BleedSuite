#!/usr/bin/env swift
//
// Renders the Bleed Suite app icon: a crimson geometric "B" monogram cut out of a
// brushed dark plate, with a single hairline accent. Run with
// `swift scripts/make_icon.swift <outdir>`.
//
// The previous mark was a liquid droplet with a gloss highlight. It read as a generic
// "cleaning/utility" app rather than an interception tool, and the soft bloom made it
// look cheap at small sizes. This one is built from straight strokes and one arc so it
// stays crisp from 16 px up.
//
import AppKit
import Foundation

let outDir = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "Resources"
let fm = FileManager.default
try? fm.createDirectory(atPath: outDir, withIntermediateDirectories: true)

func color(_ hex: UInt32, _ a: CGFloat = 1) -> NSColor {
    NSColor(srgbRed: CGFloat((hex >> 16) & 0xFF) / 255,
            green: CGFloat((hex >> 8) & 0xFF) / 255,
            blue: CGFloat(hex & 0xFF) / 255, alpha: a)
}

func drawIcon(size: CGFloat) -> Data {
    let image = NSImage(size: NSSize(width: size, height: size))
    image.lockFocus()

    // ---- plate: rounded rect, near-black with a slight vertical falloff ----
    let inset = size * 0.055
    let rect = NSRect(x: inset, y: inset, width: size - inset * 2, height: size - inset * 2)
    let plate = NSBezierPath(roundedRect: rect, xRadius: size * 0.2237, yRadius: size * 0.2237)

    NSGradient(colors: [color(0x1C1C24), color(0x0E0E13), color(0x060609)])?
        .draw(in: plate, angle: -90)

    // A single restrained diagonal sheen instead of the old crimson bloom: it gives the
    // plate depth without tinting the whole face.
    NSGraphicsContext.saveGraphicsState()
    plate.addClip()
    let sheen = NSGradient(colors: [color(0xFFFFFF, 0.10), color(0xFFFFFF, 0.0)])
    sheen?.draw(in: NSRect(x: rect.minX, y: rect.minY, width: rect.width, height: rect.height * 0.5),
                relativeCenterPosition: NSPoint(x: 0, y: -0.7))
    NSGraphicsContext.restoreGraphicsState()

    // inner hairline, as before — this is what makes it read as a machined plate
    NSGraphicsContext.saveGraphicsState()
    plate.addClip()
    color(0xFFFFFF, 0.09).setStroke()
    let inner = NSBezierPath(roundedRect: rect.insetBy(dx: size * 0.013, dy: size * 0.013),
                              xRadius: size * 0.2107, yRadius: size * 0.2107)
    inner.lineWidth = max(1, size * 0.005)
    inner.stroke()
    NSGraphicsContext.restoreGraphicsState()

    // ---- monogram: a "B" built from two stacked bowls on a single stem ----
    // Everything is derived from the plate rect so the mark stays inside the plate at
    // every size — the first attempt used sizes off the canvas centre and the flourish
    // arc ran off the bottom edge.
    let cx = rect.midX
    let cy = rect.midY + rect.height * 0.03
    let stroke = size * 0.058
    let glyphHeight = rect.height * 0.40
    let glyphWidth = rect.width * 0.28
    let stemLeft = cx - glyphWidth / 2 - stroke / 2
    let glyphBottom = cy - glyphHeight / 2
    let glyphTop = glyphBottom + glyphHeight
    let midY = glyphBottom + glyphHeight / 2
    let bowlRight = stemLeft + stroke + glyphWidth

    // One path for the whole letterform: stem plus two bowls, all the same stroke weight.
    // Building it as a single stroked path is what makes the joins seamless — drawn as
    // separate pieces the caps showed as notches.
    func bowl(from y0: CGFloat, to y1: CGFloat, into path: NSBezierPath) {
        path.move(to: NSPoint(x: stemLeft + stroke / 2, y: y0))
        path.curve(to: NSPoint(x: stemLeft + stroke / 2, y: y1),
                   controlPoint1: NSPoint(x: bowlRight, y: y0),
                   controlPoint2: NSPoint(x: bowlRight, y: y1))
    }

    let letter = NSBezierPath()
    letter.move(to: NSPoint(x: stemLeft + stroke / 2, y: glyphBottom))
    letter.line(to: NSPoint(x: stemLeft + stroke / 2, y: glyphTop))
    bowl(from: glyphTop, to: midY, into: letter)
    bowl(from: midY, to: glyphBottom, into: letter)
    letter.lineWidth = stroke
    letter.lineCapStyle = .round
    letter.lineJoinStyle = .round

    // Flat crimson, no overlay gradient. A gradient composited over a *stroked* path has no
    // fill region to respect, so it painted a visible rectangular haze across the plate —
    // the ink looks cleaner on its own, and it survives downscaling to 16 px better too.
    color(0xE11D48).setStroke()
    letter.stroke()

    image.unlockFocus()

    guard let tiff = image.tiffRepresentation,
          let rep = NSBitmapImageRep(data: tiff),
          let png = rep.representation(using: .png, properties: [:]) else {
        FileHandle.standardError.write(Data("failed to render icon\n".utf8))
        exit(1)
    }
    return png
}

let iconset = "\(outDir)/AppIcon.iconset"
try? fm.removeItem(atPath: iconset)
try! fm.createDirectory(atPath: iconset, withIntermediateDirectories: true)

let variants: [(name: String, size: CGFloat, scale: Int)] = [
    ("icon_16x16", 16, 1), ("icon_16x16@2x", 32, 2),
    ("icon_32x32", 32, 1), ("icon_32x32@2x", 64, 2),
    ("icon_128x128", 128, 1), ("icon_128x128@2x", 256, 2),
    ("icon_256x256", 256, 1), ("icon_256x256@2x", 512, 2),
    ("icon_512x512", 512, 1), ("icon_512x512@2x", 1024, 2),
]

for variant in variants {
    let data = drawIcon(size: variant.size)
    try! data.write(to: URL(fileURLWithPath: "\(iconset)/\(variant.name).png"))
}

let icns = "\(outDir)/AppIcon.icns"
try? fm.removeItem(atPath: icns)
let task = Process()
task.executableURL = URL(fileURLWithPath: "/usr/bin/iconutil")
task.arguments = ["-c", "icns", iconset, "-o", icns]
try? task.run()
task.waitUntilExit()

if fm.fileExists(atPath: icns) {
    try? fm.removeItem(atPath: iconset)
    print("icon written to \(icns)")
} else {
    print("iconutil failed; PNGs left in \(iconset)")
}