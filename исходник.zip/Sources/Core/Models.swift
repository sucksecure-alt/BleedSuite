import Foundation

// ============================================================================
//  HTTP primitives
// ============================================================================

/// A single header field. Burp shows these as an editable grid.
struct Header: Identifiable, Hashable, Codable, Sendable {
    var id: UUID = UUID()
    var name: String
    var value: String
    /// When unchecked in the editor the field is stripped before going on the wire.
    var enabled: Bool = true

    init(name: String, value: String, enabled: Bool = true) {
        self.name = name
        self.value = value
        self.enabled = enabled
    }

    var trimmedName: String { name.trimmingCharacters(in: .whitespaces) }
    var trimmedValue: String { value.trimmingCharacters(in: .whitespaces) }
    var isSeparator: Bool { trimmedName.isEmpty }
}

/// Query / form parameter with an enable checkbox, exactly like Burp's Params tab.
struct Param: Identifiable, Hashable, Sendable {
    var id: UUID = UUID()
    var name: String
    var value: String
    var enabled: Bool = true

    init(name: String, value: String, enabled: Bool = true) {
        self.name = name
        self.value = value
        self.enabled = enabled
    }
}

/// Which half of an exchange a body belongs to.
enum BodySide: String, Codable, Sendable {
    case request
    case response
}

// ============================================================================
//  HTTPMessage — the single representation of both requests and responses
// ============================================================================

/// A parsed HTTP/1.x message. Bodies are always kept as `Data` so that binary
/// payloads survive a round trip through the editors without corruption.
struct HTTPMessage: Identifiable, Sendable {
    var id: UUID = UUID()
    var isRequest: Bool
    /// `GET /x HTTP/1.1` or `HTTP/1.1 200 OK`
    var startLine: String
    var headers: [Header]
    var body: Data
    /// Set when the body was too large to keep in memory and lives in the body store.
    var bodySpilled: Bool = false

    init(isRequest: Bool, startLine: String, headers: [Header] = [], body: Data = Data()) {
        self.isRequest = isRequest
        self.startLine = startLine
        self.headers = headers
        self.body = body
    }

    // MARK: - Header access

    func header(_ name: String) -> String? {
        let lower = name.lowercased()
        for h in headers where h.enabled && h.trimmedName.lowercased() == lower {
            return h.trimmedValue
        }
        return nil
    }

    func headerValues(_ name: String) -> [String] {
        let lower = name.lowercased()
        return headers.filter { $0.enabled && $0.trimmedName.lowercased() == lower }.map(\.trimmedValue)
    }

    mutating func setHeader(_ name: String, _ value: String) {
        let lower = name.lowercased()
        var replaced = false
        for i in headers.indices {
            if headers[i].trimmedName.lowercased() == lower {
                if !replaced { headers[i].value = value; replaced = true }
                else { headers[i].enabled = false }
            }
        }
        if !replaced { headers.append(Header(name: name, value: value)) }
    }

    mutating func removeHeader(_ name: String) {
        let lower = name.lowercased()
        headers.removeAll { $0.trimmedName.lowercased() == lower }
    }

    var contentType: String { header("Content-Type")?.lowercased() ?? "" }
    var isChunkedDeclared: Bool {
        (header("Transfer-Encoding") ?? "").lowercased().contains("chunked")
    }

    // MARK: - Request conveniences

    var method: String {
        get { startLine.split(separator: " ").first.map(String.init)?.uppercased() ?? "GET" }
        set {
            let parts = startLine.split(separator: " ", omittingEmptySubsequences: false).map(String.init)
            startLine = ([newValue.uppercased()] + (parts.count > 1 ? Array(parts.dropFirst()) : ["/", "HTTP/1.1"])).joined(separator: " ")
        }
    }

    /// Request target exactly as it appeared on the wire (may be absolute-form).
    var rawTarget: String {
        let parts = startLine.split(separator: " ", omittingEmptySubsequences: false).map(String.init)
        return parts.count >= 2 ? parts[1] : "/"
    }

    var version: String {
        let parts = startLine.split(separator: " ", omittingEmptySubsequences: false).map(String.init)
        return parts.last.flatMap { $0.hasPrefix("HTTP/") ? $0 : nil } ?? "HTTP/1.1"
    }

    /// Path + query only (absolute-form URLs are reduced).
    var path: String {
        let target = rawTarget
        if let range = target.range(of: "://") {
            if let slash = target[range.upperBound...].firstIndex(of: "/") {
                return String(target[slash...])
            }
            return "/"
        }
        return target.isEmpty ? "/" : target
    }

    var query: String {
        guard let idx = path.firstIndex(of: "?") else { return "" }
        return String(path[path.index(after: idx)...])
    }

    // MARK: - Response conveniences

    var status: Int? {
        guard !isRequest else { return nil }
        let parts = startLine.split(separator: " ", omittingEmptySubsequences: false).map(String.init)
        guard parts.count >= 2, let code = Int(parts[1]) else { return nil }
        return code
    }

    var reason: String {
        guard !isRequest else { return "" }
        let parts = startLine.split(separator: " ").map(String.init)
        return parts.count >= 3 ? parts.dropFirst(2).joined(separator: " ") : ""
    }

    var statusClass: StatusClass { StatusClass(status: status) }

    // MARK: - Body decoding

    /// Human-readable body. Binary payloads are rendered as hex, never corrupted.
    var bodyText: String {
        guard !body.isEmpty else { return "" }
        if let text = String(data: body, encoding: .utf8), !text.unicodeScalars.contains(where: { $0.value == 0xFFFD }) {
            return text
        }
        return HexDump.text(body)
    }

    var isBodyTextual: Bool {
        guard !body.isEmpty else { return true }
        return String(data: body, encoding: .utf8)?.unicodeScalars.allSatisfy { $0.value != 0xFFFD } ?? false
    }

    // MARK: - Query / form parameters

    var queryParams: [Param] {
        get { Params.parseQuery(query) }
        set { setQueryParams(newValue) }
    }

    mutating func setQueryParams(_ params: [Param]) {
        let rebuilt = Params.buildQuery(params)
        let base = path.split(separator: "?", maxSplits: 1).first.map(String.init) ?? "/"
        let parts = startLine.split(separator: " ", omittingEmptySubsequences: false).map(String.init)
        var line = parts
        if line.count >= 2 { line[1] = rebuilt.isEmpty ? base : base + "?" + rebuilt } else { line = [method, base, version] }
        startLine = line.joined(separator: " ")
    }

    var formParams: [Param] {
        get {
            guard contentType.contains("application/x-www-form-urlencoded") else { return [] }
            return Params.parseQuery(String(decoding: body, as: UTF8.self))
        }
        set {
            guard contentType.contains("application/x-www-form-urlencoded") else { return }
            body = Data(Params.buildQuery(newValue).utf8)
            normalizeFraming()
        }
    }

    // MARK: - Wire format

    /// Serializes back to the wire. If `Transfer-Encoding: chunked` is declared the body is
    /// re-chunked, so the peer never sees a truncated stream.
    var rawBytes: Data {
        var head = startLine + "\r\n"
        let declaredChunked = headers.contains {
            $0.enabled && $0.trimmedName.lowercased() == "transfer-encoding" && $0.trimmedValue.lowercased().contains("chunked")
        }
        for h in headers where h.enabled && !h.isSeparator {
            head += "\(h.trimmedName): \(h.trimmedValue)\r\n"
        }
        head += "\r\n"
        var out = Data(head.utf8)
        if !body.isEmpty || declaredChunked {
            if declaredChunked {
                out.append(Data(String(format: "%lx\r\n", body.count).utf8))
                out.append(body)
                out.append(Data("\r\n0\r\n\r\n".utf8))
            } else {
                out.append(body)
            }
        }
        return out
    }

    /// Pretty representation used by the raw editors.
    var prettyRaw: String {
        var text = startLine + "\n"
        for h in headers {
            text += h.isSeparator ? "\n" : "\(h.name): \(h.value)\n"
        }
        text += "\n"
        if bodySpilled {
            text += "« body spilled to disk — use Download »"
        } else if !body.isEmpty {
            text += bodyText
        }
        return text
    }

    /// Drops `Transfer-Encoding` and rewrites `Content-Length` to match the body.
    mutating func normalizeFraming() {
        removeHeader("Transfer-Encoding")
        removeHeader("Content-Length")
        if !body.isEmpty || method != "GET" {
            setHeader("Content-Length", String(body.count))
        }
    }

    /// Describes why editor text cannot become a message, or `nil` when it can.
    ///
    /// `parseEditorText` never fails — it happily turns any blob into a message, which means a
    /// stray keystroke on an empty line silently blanks the request being edited: method, target
    /// and host all disappear and the tab looks like it reset itself. Anything that reaches the
    /// parser from the raw editor goes through this first.
    static func editorTextIssue(_ text: String, isRequest: Bool) -> String? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return "The request is empty." }
        let firstLine = trimmed.components(separatedBy: "\n")[0]
            .trimmingCharacters(in: .whitespaces)
        if isRequest {
            let parts = firstLine.split(separator: " ", omittingEmptySubsequences: true)
            guard parts.count >= 2 else {
                return "The first line should look like «GET /path HTTP/1.1»."
            }
            return nil
        }
        guard firstLine.uppercased().hasPrefix("HTTP/") else {
            return "The first line should look like «HTTP/1.1 200 OK»."
        }
        return nil
    }

    /// Rebuilds a message from editor text (LF or CRLF tolerant).
    static func parseEditorText(_ text: String, isRequest: Bool) -> HTTPMessage {
        let normalized = text.replacingOccurrences(of: "\r\n", with: "\n")
        var lines = normalized.components(separatedBy: "\n")
        var msg = HTTPMessage(isRequest: isRequest, startLine: lines.first ?? "")
        lines.removeFirst()
        var headers: [Header] = []
        var bodyLines: [String] = []
        var inBody = false
        for line in lines {
            if inBody { bodyLines.append(line); continue }
            if line.isEmpty { inBody = true; continue }
            if line.first == " " || line.first == "\t", let last = headers.indices.last {
                headers[last].value += " " + line.trimmingCharacters(in: .whitespaces)
                continue
            }
            if let colon = line.firstIndex(of: ":") {
                headers.append(Header(name: String(line[line.startIndex..<colon]),
                                      value: String(line[line.index(after: colon)...]).trimmingCharacters(in: .whitespaces)))
            }
        }
        msg.headers = headers
        let bodyText = bodyLines.joined(separator: "\n")
        msg.body = Data(bodyText.utf8)
        if msg.body.last == 0x0A { msg.body.removeLast() }
        return msg
    }

    var toEditorText: String { prettyRaw }
}

// ============================================================================
//  Status classes
// ============================================================================

enum StatusClass: String, CaseIterable, Sendable {
    case none, info, redirect, success, clientError, serverError, other

    init(status: Int?) {
        guard let s = status else { self = .none; return }
        switch s {
        case 100..<200: self = .info
        case 200..<300: self = .success
        case 300..<400: self = .redirect
        case 400..<500: self = .clientError
        case 500..<600: self = .serverError
        default: self = .other
        }
    }

    var label: String {
        switch self {
        case .none: return "—"
        case .info: return "INFO"
        case .success: return "OK"
        case .redirect: return "REDR"
        case .clientError: return "CLNT"
        case .serverError: return "SRVR"
        case .other: return "????"
        }
    }

    var fullName: String {
        switch self {
        case .none: return "No status"
        case .info: return "Informational"
        case .success: return "Success"
        case .redirect: return "Redirect"
        case .clientError: return "Client error"
        case .serverError: return "Server error"
        case .other: return "Other"
        }
    }
}

// ============================================================================
//  HTTPPair — one exchange in the history / site map
// ============================================================================

struct HTTPPair: Identifiable, Sendable {
    var id: Int
    var time: Date
    var durationMS: Int
    var host: String
    var port: Int
    var isSecure: Bool
    var request: HTTPMessage
    var response: HTTPMessage?
    var error: String?
    var isIntercepted: Bool = false
    var isModified: Bool = false
    var note: String = ""
    var tags: [String] = []
    /// Set when the transaction came from Repeater / Intruder / Spider rather than the proxy.
    var origin: Origin = .proxy

    enum Origin: String, Sendable, Codable {
        case proxy, repeater, intruder, spider, scanner, comparer

        var label: String {
            switch self {
            case .proxy: return "Proxy"
            case .repeater: return "Repeater"
            case .intruder: return "Intruder"
            case .spider: return "Spider"
            case .scanner: return "Scanner"
            case .comparer: return "Comparer"
            }
        }
    }

    var scheme: String { isSecure ? "https" : "http" }
    var url: String { "\(scheme)://\(host):\(port)\(request.path)" }
    var urlNoPort: String { "\(scheme)://\(host)\(request.path)" }
    var status: Int? { response?.status }
    var statusClass: StatusClass { StatusClass(status: status) }
    var requestLength: Int { request.body.count + headerBytes(request) }
    var responseLength: Int {
        guard let r = response else { return 0 }
        return r.body.count + headerBytes(r)
    }

    private func headerBytes(_ m: HTTPMessage) -> Int {
        m.startLine.utf8.count + m.headers.reduce(4) { $0 + $1.name.utf8.count + $1.value.utf8.count }
    }

    var summary: String { "\(request.method) \(request.path)" }
}

// ============================================================================
//  Parameter helpers
// ============================================================================

enum Params {
    static func percentDecode(_ s: String) -> String { s.replacingOccurrences(of: "+", with: " ").removingPercentEncoding ?? s }

    static func parseQuery(_ query: String) -> [Param] {
        guard !query.isEmpty else { return [] }
        return query.components(separatedBy: "&").map { pair in
            let parts = pair.components(separatedBy: "=")
            let name = percentDecode(parts.first ?? "")
            let value = parts.count > 1 ? percentDecode(parts.dropFirst().joined(separator: "=")) : ""
            return Param(name: name, value: value)
        }
    }

    static func buildQuery(_ params: [Param]) -> String {
        let allowed = params.filter { $0.enabled }
        guard !allowed.isEmpty else { return "" }
        return allowed
            .map { p in
                let n = escape(p.name), v = escape(p.value)
                return v.isEmpty && !p.value.isEmpty ? n : "\(n)=\(v)"
            }
            .joined(separator: "&")
    }

    static func escape(_ s: String) -> String {
        var out = ""
        for byte in Array(s.utf8) {
            let c = Character(UnicodeScalar(byte))
            if (byte >= 0x41 && byte <= 0x5A) || (byte >= 0x61 && byte <= 0x7A) || (byte >= 0x30 && byte <= 0x39)
                || "-._~".contains(c) {
                out.append(c)
            } else {
                out += String(format: "%%%02X", byte)
            }
        }
        return out
    }
}

// ============================================================================
//  Site map node
// ============================================================================

final class TargetNode: Identifiable, Sendable {
    let id: String
    var name: String
    weak var parent: TargetNode?
    var children: [TargetNode] = []
    var pairs: [HTTPPair] = []
    var isLeaf: Bool { children.isEmpty }

    init(name: String, id: String) {
        self.name = name
        self.id = id
    }

    var sorted: TargetNode {
        let copy = TargetNode(name: name, id: id)
        copy.parent = parent
        copy.pairs = pairs
        copy.children = children.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
            .map { $0.sorted }
        return copy
    }

    var requestCount: Int {
        pairs.count + children.reduce(0) { $0 + $1.requestCount }
    }

    var leafPaths: [String] {
        if children.isEmpty { return pairs.map { $0.request.path } }
        return children.flatMap(\.leafPaths)
    }
}

/// Incremental site map. Rebuilt from the history when the host set changes.
struct TargetTreeBuilder {
    static func build(from pairs: [HTTPPair], maxDepth: Int = 5) -> [TargetNode] {
        var roots: [String: TargetNode] = [:]
        for pair in pairs {
            let hostKey = "\(pair.scheme)://\(pair.host):\(pair.port)"
            let root = roots[hostKey] ?? TargetNode(name: hostKey, id: "h:\(hostKey)")
            roots[hostKey] = root

            var node = root
            var path = pair.request.path
            var segments = path.components(separatedBy: "/").filter { !$0.isEmpty }
            if segments.isEmpty { segments = ["(root)"] }

            let folderDepth = min(max(0, maxDepth - 1), segments.count - 1)
            if folderDepth > 0 {
                for i in 0..<folderDepth {
                    let name = segments[i]
                    let childID = node.id + "/" + name
                    let child = node.children.first { $0.id == childID } ?? {
                        let created = TargetNode(name: name, id: childID)
                        created.parent = node
                        return created
                    }()
                    if !node.children.contains(where: { $0.id == childID }) { node.children.append(child) }
                    node = child
                }
            }
            let leafName = segments.suffix(from: folderDepth).joined(separator: "/")
            if !leafName.isEmpty { node.pairs.append(pair) }
        }
        return roots.values.map { $0.sorted }.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }
}

// ============================================================================
//  Scanning
// ============================================================================

struct ScanIssue: Identifiable, Sendable, Equatable {
    var id: UUID = UUID()
    var name: String
    var severity: Severity
    var confidence: Confidence
    var kind: Kind
    var host: String
    var url: String
    var detail: String
    var evidence: String = ""
    var remediation: String = ""
    var transactionID: Int?
    /// True when the finding was confirmed by actually sending a probe.
    var confirmed: Bool = false

    enum Severity: Int, CaseIterable, Comparable, Sendable {
        case info, low, medium, high, critical
        static func < (a: Severity, b: Severity) -> Bool { a.rawValue < b.rawValue }
        var label: String { ["Info", "Low", "Medium", "High", "Critical"][rawValue] }
    }

    enum Confidence: Int, CaseIterable, Comparable, Sendable {
        case certain, firm, tentative
        static func < (a: Confidence, b: Confidence) -> Bool { a.rawValue < b.rawValue }
        var label: String { ["Certain", "Firm", "Tentative"][rawValue] }
    }

    enum Kind: String, CaseIterable, Sendable {
        case passive, active
        var label: String { self == .passive ? "Passive" : "Active" }
    }
}

// ============================================================================
//  Match & Replace rules
// ============================================================================

struct ProxyRule: Identifiable, Codable, Sendable {
    var id: UUID = UUID()
    var enabled: Bool = true
    var comment: String = ""
    var direction: Direction = .request
    var target: Target = .url
    var matchType: MatchType = .regex
    var negateMatch: Bool = false
    var caseSensitive: Bool = false
    var pattern: String = ""
    var replacement: String = ""

    enum Direction: String, CaseIterable, Codable, Sendable {
        case request, response
    }

    enum Target: String, CaseIterable, Codable, Sendable {
        case url, host, path, query, header, body, method, statusCode

        var label: String {
            switch self {
            case .url: return "URL"
            case .host: return "Host header"
            case .path: return "Path"
            case .query: return "Query string"
            case .header: return "Header"
            case .body: return "Body"
            case .method: return "Request method"
            case .statusCode: return "Status code"
            }
        }
    }

    enum MatchType: String, CaseIterable, Codable, Sendable {
        case regex, contains, startsWith, endsWith, equals

        var label: String {
            switch self {
            case .regex: return "Regex"
            case .contains: return "Contains"
            case .startsWith: return "Starts with"
            case .endsWith: return "Ends with"
            case .equals: return "Equals"
            }
        }
    }

    /// Header name for `.header` targets ("Name: value" is also accepted and split).
    var headerName: String {
        guard target == .header, let colon = pattern.firstIndex(of: ":") else { return pattern }
        return String(pattern[pattern.startIndex..<colon]).trimmingCharacters(in: .whitespaces)
    }
}

// ============================================================================
//  Misc utilities
// ============================================================================

enum HexDump {
    static func isPrintable(_ data: Data) -> Bool {
        guard !data.isEmpty else { return true }
        return String(data: data, encoding: .utf8)?.unicodeScalars.allSatisfy { $0.value != 0xFFFD } ?? false
    }

    static func text(_ data: Data, limit: Int = 2 * 1024 * 1024) -> String {
        let slice = data.prefix(limit)
        let bytes = Array(slice)
        var out = ""
        out.reserveCapacity(bytes.count * 4)
        for (i, b) in bytes.enumerated() {
            if i > 0 && i % 16 == 0 { out += "\n" }
            out += String(format: "%02X ", b)
        }
        return out
    }

    static func fromHex(_ text: String) -> Data? {
        let cleaned = text.filter { !$0.isWhitespace && $0 != ":" }
        guard cleaned.count % 2 == 0 else { return nil }
        var data = Data(capacity: cleaned.count / 2)
        var index = cleaned.startIndex
        while index < cleaned.endIndex {
            let next = cleaned.index(index, offsetBy: 2)
            guard let byte = UInt8(cleaned[index..<next], radix: 16) else { return nil }
            data.append(byte)
            index = next
        }
        return data
    }

    static func pretty(_ data: Data, limit: Int = 512 * 1024) -> String {
        guard !data.isEmpty else { return "" }
        if let json = try? JSONSerialization.jsonObject(with: data.prefix(limit), options: [.fragmentsAllowed]),
           let pretty = try? JSONSerialization.data(withJSONObject: json, options: [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]),
           let text = String(data: pretty, encoding: .utf8) {
            return text
        }
        if let text = String(data: data.prefix(limit), encoding: .utf8),
           text.unicodeScalars.allSatisfy({ $0.value != 0xFFFD }) {
            return XMLFormatter.pretty(text)
        }
        return HexDump.text(data, limit: limit)
    }
}

enum XMLFormatter {
    static func pretty(_ text: String) -> String {
        guard text.contains("<") else { return text }
        var out = ""
    var depth = 0
        var scanner = text.startIndex
        while scanner < text.endIndex {
            let nextClose = text[scanner...].firstIndex(of: "<")
            guard let open = nextClose else {
                out += text[scanner...].trimmingCharacters(in: .whitespacesAndNewlines)
                break
            }
            if open > scanner {
                let chunk = text[scanner..<open].trimmingCharacters(in: .whitespacesAndNewlines)
                if !chunk.isEmpty { out += String(repeating: "  ", count: max(depth, 0)) + chunk + "\n" }
            }
            let close = text[open...].firstIndex(of: ">").map { text.index(after: $0) } ?? text.endIndex
            let tag = text[open..<close].trimmingCharacters(in: .whitespaces)
            if tag.hasPrefix("</") {
                depth = max(0, depth - 1)
                out += String(repeating: "  ", count: depth) + tag + "\n"
            } else if tag.hasSuffix("/>") {
                out += String(repeating: "  ", count: max(depth, 0)) + tag + "\n"
            } else {
                out += String(repeating: "  ", count: max(depth, 0)) + tag + "\n"
                depth += 1
            }
            scanner = close
        }
        return out
    }
}

enum Format {
    static func bytes(_ n: Int) -> String {
        let units = ["B", "KB", "MB", "GB"]
        var value = Double(n)
        var i = 0
        while value >= 1024, i < units.count - 1 { value /= 1024; i += 1 }
        return i == 0 ? "\(n) B" : String(format: "%.1f %@", value, units[i])
    }

    static func ms(_ n: Int) -> String { n < 1000 ? "\(n) ms" : String(format: "%.2f s", Double(n) / 1000) }

    static func clock(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        f.locale = Locale(identifier: "en_US_POSIX")
        return f.string(from: date)
    }

    static func stamp(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm:ss"
        f.locale = Locale(identifier: "en_US_POSIX")
        return f.string(from: date)
    }
}