import Foundation

// ============================================================================
//  HTTP/1.x wire parsing and framing
// ============================================================================

extension Data {
    /// Drops the first `n` bytes while keeping the slice base at zero.
    ///
    /// `removeFirst(_:)` re-bases `startIndex`, after which every `data[0..<k]`
    /// access in the parser would trap. Every buffer in the proxy goes through here.
    mutating func consume(_ n: Int) {
        guard n > 0 else { return }
        guard n < count else { self = Data(); return }
        let index = startIndex + n
        self = Data(self[index..<endIndex])
    }
}

enum HTTPParser {

    static let maxHeadSize = 512 * 1024
    static let maxBodySize = 64 * 1024 * 1024

    /// Finds the CRLFCRLF that terminates the head. Returns nil when absent.
    static func headEnd(in data: Data) -> Int? {
        guard data.count >= 4 else { return nil }
        let bytes = [UInt8](data.prefix(min(data.count, 65536)))
        for i in 0...(bytes.count - 4) {
            if bytes[i] == 0x0D, bytes[i + 1] == 0x0A, bytes[i + 2] == 0x0D, bytes[i + 3] == 0x0A {
                return i + 4
            }
        }
        return nil
    }

    // MARK: - Generic message parse

    /// Parses one message starting at the beginning of `data`.
    /// - Returns: the message plus how many bytes were consumed, or nil if incomplete.
    static func parse(_ data: Data, isRequest: Bool) -> (HTTPMessage, Int)? {
        guard let headLength = headEnd(in: data) else { return nil }
        let headData = Data(data[0..<headLength])
        var message: HTTPMessage
        var headers: [Header] = []
        var bodyStart = headLength

        guard let rawLines = splitHead(headData) else { return nil }
        var lines = rawLines

        // Undo obs-fold (RFC 7230 §3.2.4): continuation lines are joined to the previous field.
        var folded: [String] = []
        for line in lines {
            if (line.hasPrefix(" ") || line.hasPrefix("\t")), !folded.isEmpty {
                folded[folded.count - 1] += " " + line.trimmingCharacters(in: .whitespaces)
            } else {
                folded.append(line)
            }
        }
        lines = folded

        guard let startLine = lines.first, !startLine.isEmpty else { return nil }
        message = HTTPMessage(isRequest: isRequest, startLine: startLine.trimmingCharacters(in: .whitespaces))

        for line in lines.dropFirst() {
            if line.isEmpty { continue }
            guard let colon = line.firstIndex(of: ":") else {
                headers.append(Header(name: line, value: ""))
                continue
            }
            let name = String(line[line.startIndex..<colon]).trimmingCharacters(in: .whitespaces)
            let value = String(line[line.index(after: colon)...]).trimmingCharacters(in: .whitespaces)
            headers.append(Header(name: name, value: value))
        }
        message.headers = headers

        // Body framing.
        let lowerHead = String(decoding: headData.prefix(headLength), as: UTF8.self).lowercased()
        let transferEncoding = headers.first {
            $0.trimmedName.lowercased() == "transfer-encoding" && $0.trimmedValue.lowercased().contains("chunked")
        } != nil
        let contentLength = headers.first { $0.trimmedName.lowercased() == "content-length" }
            .flatMap { Int($0.trimmedValue) }
        let statusCode = isRequest ? nil : Int(message.startLine.split(separator: " ").dropFirst().first.map(String.init) ?? "")

        let bodyAllowed: Bool
        if isRequest {
            bodyAllowed = true
        } else if let code = statusCode {
            bodyAllowed = !(code == 204 || code == 304 || (code >= 100 && code < 200))
        } else {
            bodyAllowed = true
        }

        if !bodyAllowed {
            message.body = Data()
            return (message, headLength)
        }

        if transferEncoding {
            let result = dechunk(Data(data[bodyStart...]))
            guard let r = result else { return nil } // incomplete
            message.body = r.body
            return (message, bodyStart + r.consumed)
        }

        if let length = contentLength {
            // `Content-Length` is attacker-controlled: any origin server, or any plaintext hop
            // in a MITM'd connection, can send a negative value. `Int("-1")` parses happily and
            // then passes the size check below, after which `bodyStart..<(bodyStart + length)`
            // is a range whose lower bound exceeds its upper — `Range requires lowerBound <=
            // upperBound`, a trap. That killed the whole process on traffic we never chose to
            // intercept. `dechunk` below already guards its size this way; this path did not.
            guard length >= 0 else { return (message, headLength) }
            guard length <= maxBodySize else { return (message, headLength) }
            guard bodyStart + length >= bodyStart, data.count >= bodyStart + length else { return nil }
            message.body = Data(data[bodyStart..<(bodyStart + length)])
            return (message, bodyStart + length)
        }

        // No framing headers: the message ends where the input ends (caller supplies complete data).
        message.body = Data(data[bodyStart...])
        return (message, data.count)
    }

    /// Splits the head into logical lines, keeping obs-fold continuations attached.
    private static func splitHead(_ head: Data) -> [String]? {
        var text = String(decoding: head, as: UTF8.self)
        while text.hasSuffix("\r\n") { text.removeLast(2) }
        if text.isEmpty { return nil }
        return text.components(separatedBy: "\r\n")
    }

    /// Decodes an ISO-8859-1 / UTF-8 mixture into a displayable header block.
    static func decodeHeaderBlock(_ data: Data) -> String {
        String(data: data, encoding: .utf8)
            ?? String(data: data, encoding: .isoLatin1)
            ?? String(decoding: data, as: UTF8.self)
    }

    // MARK: - Chunked transfer encoding

    struct DechunkResult {
        var body: Data
        var consumed: Int
        var trailers: [Header]
    }

    /// Decodes a chunked stream that may be incomplete. Returns nil if more bytes are needed.
    static func dechunk(_ data: Data) -> DechunkResult? {
        var body = Data()
        var index = data.startIndex
        var trailers: [Header] = []

        while true {
            guard index <= data.endIndex else { return nil }
            guard let lineEnd = findCRLF(from: index, in: data) else { return nil }
            let sizeLine = String(decoding: data[index..<lineEnd.contentEnd], as: UTF8.self)
            let trimmed = sizeLine.trimmingCharacters(in: .whitespaces)
            // Chunk extensions (";name=value") are legal and must be ignored for the size.
            let hexPart = trimmed.split(separator: ";", maxSplits: 1).first.map(String.init) ?? trimmed
            guard let size = Int(hexPart.trimmingCharacters(in: .whitespaces), radix: 16),
                  size >= 0, size <= maxBodySize else { return nil }

            if size == 0 {
                // Trailers until an empty line.
                var trailerIndex = lineEnd.next
                while true {
                    guard let next = findCRLF(from: trailerIndex, in: data) else { return nil }
                    let trailerLine = String(decoding: data[trailerIndex..<next.contentEnd], as: UTF8.self)
                    trailerIndex = next.next
                    if trailerLine.trimmingCharacters(in: .whitespaces).isEmpty { break }
                    if let colon = trailerLine.firstIndex(of: ":") {
                        trailers.append(Header(name: String(trailerLine[trailerLine.startIndex..<colon]).trimmingCharacters(in: .whitespaces),
                                               value: String(trailerLine[trailerLine.index(after: colon)...]).trimmingCharacters(in: .whitespaces)))
                    }
                }
                return DechunkResult(body: body,
                                     consumed: data.distance(from: data.startIndex, to: trailerIndex),
                                     trailers: trailers)
            }

            let chunkStart = lineEnd.next
            // `offsetBy:` traps on a hostile or malformed size line, so the
            // remaining length is checked before the index is formed.
            let available = data.distance(from: chunkStart, to: data.endIndex)
            guard size >= 0, size <= available else { return nil }
            let chunkEnd = data.index(chunkStart, offsetBy: size)
            body.append(data[chunkStart..<chunkEnd])
            guard let terminator = findCRLF(from: chunkEnd, in: data) else { return nil }
            index = terminator.next
        }
    }

    /// Re-encodes a payload as a single chunked segment.
    static func enchunk(_ payload: Data) -> Data {
        var out = Data(String(format: "%lx\r\n", payload.count).utf8)
        out.append(payload)
        out.append(Data("\r\n".utf8))
        return out
    }

    /// Locates the next CRLF at or after `from`.
    /// Returns (index of the content terminator, index just past the LF).
    private static func findCRLF(from index: Data.Index, in data: Data) -> (contentEnd: Data.Index, next: Data.Index)? {
        guard index < data.endIndex else { return nil }
        var i = index
        while i < data.endIndex {
            if data[i] == 0x0A {
                let previous = i > data.startIndex ? data.index(before: i) : i
                let contentEnd = (data[previous] == 0x0D && previous != i) ? previous : i
                return (contentEnd, data.index(after: i))
            }
            i = data.index(after: i)
        }
        return nil
    }

    // MARK: - Request helpers

    static func isConnect(_ message: HTTPMessage) -> Bool {
        message.isRequest && message.method == "CONNECT"
    }

    /// Normalises absolute-form targets back to origin-form before forwarding upstream.
    static func normalizeTarget(_ message: inout HTTPMessage) {
        let target = message.rawTarget
        guard target.contains("://") else { return }
        guard let range = target.range(of: "://") else { return }
        let afterScheme = String(target[range.upperBound...])

        var authority = afterScheme
        var path = "/"
        if let slash = afterScheme.firstIndex(of: "/") {
            authority = String(afterScheme[afterScheme.startIndex..<slash])
            path = String(afterScheme[slash...])
        }
        var parts = message.startLine.split(separator: " ", omittingEmptySubsequences: false).map(String.init)
        if parts.count >= 2 {
            parts[1] = path.isEmpty ? "/" : path
            message.startLine = parts.joined(separator: " ")
        }
        message.setHeader("Host", authority)
    }

    /// Extracts `host:port` from an absolute-form URL.
    static func authority(ofAbsolute target: String) -> String? {
        guard let range = target.range(of: "://") else { return nil }
        let rest = target[range.upperBound...]
        let end = rest.firstIndex(where: { $0 == "/" || $0 == "?" }) ?? rest.endIndex
        return String(rest[rest.startIndex..<end])
    }

    /// Splits a `host[:port]` authority, handling bracketed IPv6 literals.
    static func splitAuthority(_ authority: String) -> (host: String, port: Int?) {
        let trimmed = authority.trimmingCharacters(in: .whitespaces)
        if trimmed.hasPrefix("[") {
            if let close = trimmed.firstIndex(of: "]") {
                let host = String(trimmed[trimmed.index(after: trimmed.startIndex)..<close])
                let rest = trimmed[trimmed.index(after: close)...]
                if rest.hasPrefix(":"), let port = Int(rest.dropFirst()) { return (host, port) }
                return (host, nil)
            }
        }
        if let colon = trimmed.lastIndex(of: ":") {
            let host = String(trimmed[trimmed.startIndex..<colon])
            if let port = Int(trimmed[trimmed.index(after: colon)...]), port > 0, port < 65536 {
                return (host, port)
            }
        }
        return (trimmed, nil)
    }

    /// Determines the upstream host and port for a request.
    static func route(for message: HTTPMessage, connectHost: String?, connectPort: Int?, defaultPort: Int) -> (host: String, port: Int) {
        if let connectHost, !connectHost.isEmpty {
            return (connectHost, connectPort ?? defaultPort)
        }
        let target = message.rawTarget
        if target.contains("://") {
            let authority = authority(ofAbsolute: target)
            if let authority {
                let split = splitAuthority(authority)
                return (split.host, split.port ?? defaultPort)
            }
        }
        if let hostHeader = message.header("Host"), !hostHeader.isEmpty {
            let split = splitAuthority(hostHeader)
            return (split.host, split.port ?? defaultPort)
        }
        return ("", defaultPort)
    }

    /// Removes hop-by-hop headers so that upstream connections are not corrupted.
    static func stripHopByHop(_ message: inout HTTPMessage) {
        var declaredConnectionHeaders: [String] = []
        for h in message.headers where h.trimmedName.lowercased() == "connection" {
            for token in h.trimmedValue.lowercased().components(separatedBy: ",") {
                let t = token.trimmingCharacters(in: .whitespaces)
                if !t.isEmpty { declaredConnectionHeaders.append(t) }
            }
        }
        var hopByHop: Set<String> = [
            "connection", "proxy-connection", "keep-alive", "transfer-encoding",
            "te", "trailer", "upgrade", "proxy-authenticate", "proxy-authorization",
        ]
        for name in declaredConnectionHeaders { hopByHop.insert(name.lowercased()) }

        message.headers.removeAll { $0.enabled && hopByHop.contains($0.trimmedName.lowercased()) }
        message.headers.append(Header(name: "Connection", value: "close"))
    }

    // MARK: - Framing

    /// Result of trying to slice one complete message off the front of a buffer.
    struct Framed: Sendable {
        var message: HTTPMessage
        var length: Int
        var isConnect: Bool
        var connectHost: String?
        var connectPort: Int?
        /// `101` / upgrade responses have no normal body framing.
        var isUpgrade: Bool
    }

    /// Slices one complete message off the front of `buffer`, returning nil if more bytes are needed.
    static func frame(_ buffer: Data) -> Framed? {
        guard let headLength = headEnd(in: buffer) else { return nil }
        let headText = String(decoding: buffer[0..<headLength], as: UTF8.self)
        let lines = headText.components(separatedBy: "\r\n")
        guard let first = lines.first else { return nil }

        // CONNECT?
        let upper = first.uppercased()
        if upper.hasPrefix("CONNECT ") {
            let target = first.split(separator: " ").dropFirst().first.map(String.init) ?? ""
            let split = splitAuthority(target)
            let placeholder = HTTPMessage(isRequest: true, startLine: first, headers: [])
            return Framed(message: placeholder, length: headLength, isConnect: true,
                          connectHost: split.host, connectPort: split.port ?? 443, isUpgrade: false)
        }

        guard let (parsed, _) = parse(buffer, isRequest: true) else { return nil }
        let loweredHead = headText.lowercased()
        let hasCL = loweredHead.contains("\r\ncontent-length:")
        let isChunked = loweredHead.contains("transfer-encoding:") && loweredHead.contains("chunked")

        if isChunked {
            let rest = Data(buffer[headLength...])
            guard let decoded = dechunk(rest) else { return nil }
            var message = parsed
            message.body = decoded.body
            return Framed(message: message, length: headLength + decoded.consumed, isConnect: false,
                          connectHost: nil, connectPort: nil, isUpgrade: false)
        }

        let hasBody = !(parsed.method == "HEAD" || parsed.method == "GET" && hasCL == false && false)
        if let length = parsed.header("Content-Length").flatMap({ Int($0) }) {
            // Same negative-length trap as `parse` above; this path re-reads the header
            // independently, so it needs its own guard.
            guard length >= 0 else { return nil }
            guard headLength + length >= headLength, buffer.count >= headLength + length else { return nil }
            var message = parsed
            message.body = Data(buffer[headLength..<(headLength + length)])
            let isUpgrade = parsed.headerValueContains("upgrade: websocket")
            return Framed(message: message, length: headLength + length, isConnect: false,
                          connectHost: nil, connectPort: nil, isUpgrade: isUpgrade)
        }

        if parsed.method == "GET" || parsed.method == "HEAD" || parsed.method == "DELETE" || parsed.method == "OPTIONS" {
            var message = parsed
            message.body = Data()
            let isUpgrade = parsed.headerValueContains("upgrade: websocket")
            return Framed(message: message, length: headLength, isConnect: false,
                          connectHost: nil, connectPort: nil, isUpgrade: isUpgrade)
        }

        // No framing on a bodied request: wait for more bytes; the caller enforces a cap.
        _ = hasBody
        return nil
    }

    /// Whether a response with these bytes is complete (does not wait for EOF).
    static func responseIsComplete(_ buffer: Data, method: String) -> Bool {
        guard let headLength = headEnd(in: buffer) else { return false }
        let headText = String(decoding: buffer[0..<headLength], as: UTF8.self)
        guard let (parsed, _) = parse(buffer, isRequest: false) else { return false }
        let status = parsed.status ?? 0

        if method == "HEAD" || status == 204 || status == 304 || (status >= 100 && status < 200) || status == 101 {
            return true
        }
        let lowered = headText.lowercased()
        if lowered.contains("transfer-encoding:") && lowered.contains("chunked") {
            return dechunk(Data(buffer[headLength...])) != nil
        }
        if let length = parsed.header("Content-Length").flatMap({ Int($0) }) {
            // A negative length must not read as "already complete": that declared a truncated
            // body finished and handed a bad range to the parser.
            guard length >= 0 else { return false }
            return buffer.count >= headLength + length
        }
        return false // body-until-close; the caller waits for EOF
    }
}

private extension HTTPMessage {
    func headerValueContains(_ needle: String) -> Bool {
        header("Connection")?.lowercased().contains(needle) == true
            || header("Upgrade")?.lowercased().contains(needle) == true
    }
}

// ============================================================================
//  Header block rendering helpers
// ============================================================================

enum HeaderBlock {
    /// Splits a header block back into editable rows, keeping blank separator lines as disabled rows.
    static func rows(from message: HTTPMessage) -> [Header] {
        var rows: [Header] = []
        for h in message.headers {
            rows.append(Header(name: h.name, value: h.value, enabled: h.enabled))
        }
        rows.append(Header(name: "", value: ""))
        return rows
    }

    /// Reapplies the editable header grid onto a message (enabled rows only, blank line terminates).
    static func apply(_ rows: [Header], to message: inout HTTPMessage) {
        var result: [Header] = []
        for row in rows {
            if row.isSeparator { continue }
            result.append(row)
        }
        message.headers = result
    }
}