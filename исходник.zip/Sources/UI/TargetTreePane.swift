import SwiftUI

/// The full Target workspace's site map, drawn entirely in SwiftUI.
///
/// This replaces `TargetTreeView`, an `NSOutlineView`. AppKit's answer to "why does the site
/// map look garbled?" is already written down in `SidebarTargetTree`: an AppKit view hosted
/// inside SwiftUI is composited as its own layer group, so the opaque filter bar above it
/// paints over the top of it and slices the first host row in half. The sidebar was redrawn in
/// SwiftUI to escape that; the main workspace was left on the AppKit view and kept the bug.
///
/// Every attempt to fix it by hand — resetting the clip origin, forcing the document frame,
/// resizing masks, `frame(maxHeight: .infinity)` — left it in place, because none of them touch
/// the compositing that causes it. Rendering in SwiftUI removes the layer group, and with it the
/// artefact. It is also lazy, so a crawl with tens of thousands of endpoints costs the same as
/// the sidebar's tree.
struct TargetTreePane: View {
    let nodes: [TargetNode]
    let onSelectLeaf: (HTTPPair) -> Void
    let onSelectHost: (TargetNode) -> Void

    /// Roots start open so the host list is visible straight away.
    @State private var collapsed: Set<String> = []
    @State private var seeded = false

    // The workspace pane has room for full-size type; the sidebar's 9 pt is for a 250 pt strip.
    private let rowHeight: CGFloat = 24
    private let fontSize: CGFloat = 11
    private let indent: CGFloat = 14

    var body: some View {
        ScrollView(.vertical, showsIndicators: true) {
            LazyVStack(alignment: .leading, spacing: 0) {
                ForEach(visibleRows, id: \.id) { row in
                    rowView(row)
                }
            }
            .padding(.bottom, 8)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .background(Theme.background)
        .onAppear { seedIfNeeded() }
        .onChange(of: nodes.map(\.id)) { seedIfNeeded() }
    }

    // MARK: - Rows

    private struct Row: Identifiable {
        let node: TargetNode
        let depth: Int
        var id: String { node.id }
    }

    /// Flattens the visible part of the tree. Doing it here keeps the body free of recursion and
    /// lets `LazyVStack` stay lazy.
    private var visibleRows: [Row] {
        guard seeded else { return [] }
        var out: [Row] = []
        for root in nodes {
            append(root, depth: 0, into: &out)
        }
        return out
    }

    private func append(_ node: TargetNode, depth: Int, into out: inout [Row]) {
        out.append(Row(node: node, depth: depth))
        guard !node.isLeaf, !collapsed.contains(node.id) else { return }
        for child in node.children.sorted(by: { $0.name.localizedStandardCompare($1.name) == .orderedAscending }) {
            append(child, depth: depth + 1, into: &out)
        }
    }

    private func seedIfNeeded() {
        guard !seeded, !nodes.isEmpty else { return }
        seeded = true
    }

    @ViewBuilder
    private func rowView(_ row: Row) -> some View {
        if row.node.isLeaf { leafRow(row) } else { folderRow(row) }
    }

    private func folderRow(_ row: Row) -> some View {
        let isOpen = !collapsed.contains(row.node.id)
        return HStack(spacing: 5) {
            disclosure(isOpen: isOpen, node: row.node)
            Image(systemName: isOpen ? "folder.fill" : "folder")
                .font(Theme.ui(fontSize))
                .foregroundStyle(Theme.crimson)
                .frame(width: 13)
            Text(row.node.name)
                .font(Theme.monoSwiftUI(fontSize, weight: .semibold))
                .foregroundStyle(Theme.textPrimary)
                .lineLimit(1)
                .truncationMode(.head)
            Spacer(minLength: 6)
            if row.node.requestCount > 0 {
                Text(row.node.requestCount.compactString)
                    .font(Theme.monoSwiftUI(fontSize - 1, weight: .bold))
                    .foregroundStyle(Theme.textTertiary)
                    .lineLimit(1)
            }
        }
        .padding(.leading, 8 + CGFloat(row.depth) * indent)
        .padding(.trailing, 10)
        .frame(height: rowHeight)
        .contentShape(Rectangle())
        .onTapGesture { onSelectHost(row.node) }
    }

    private func leafRow(_ row: Row) -> some View {
        let last = row.node.pairs.last
        return HStack(spacing: 6) {
            Circle()
                .fill(Theme.statusColor(last?.status))
                .frame(width: 5, height: 5)
            Text(row.node.name)
                .font(Theme.monoSwiftUI(fontSize))
                .foregroundStyle(Theme.textSecondary)
                .lineLimit(1)
                .truncationMode(.middle)
            Spacer(minLength: 6)
            if let last {
                Text(row.node.pairs.count > 1
                     ? "\(row.node.pairs.count)x  \(Format.bytes(last.responseLength))"
                     : Format.bytes(last.responseLength))
                    .font(Theme.monoSwiftUI(fontSize - 1))
                    .foregroundStyle(Theme.textTertiary)
                    .lineLimit(1)
                    .fixedSize()
            }
        }
        .padding(.leading, 10 + CGFloat(row.depth) * indent)
        .padding(.trailing, 10)
        .frame(height: rowHeight)
        .contentShape(Rectangle())
        .onTapGesture { if let pair = last { onSelectLeaf(pair) } }
    }

    private func disclosure(isOpen: Bool, node: TargetNode) -> some View {
        Button {
            if isOpen { collapsed.insert(node.id) } else { collapsed.remove(node.id) }
        } label: {
            Image(systemName: "triangle.fill")
                .font(Theme.ui(7))
                .foregroundStyle(Theme.textTertiary)
                // Keeps the arrow upright when collapsed instead of mirrored.
                .rotationEffect(.degrees(isOpen ? 90 : 0))
                .frame(width: 11, height: 11)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(isOpen ? "Collapse \(node.name)" : "Expand \(node.name)")
    }
}