import Foundation

/// Watches for main-thread stalls.
///
/// A layout loop inside SwiftUI shows up as the run loop simply not getting a turn: the window
/// stops drawing, buttons stop responding and — because the proxy's relay callbacks hop to the
/// main actor — traffic appears to "go out but never loads". The user sees an app that hangs
/// with no explanation, which is exactly how this was reported.
///
/// A timer on the main run loop that is consistently late means the main thread was busy for
/// longer than the interval. When that happens the app says so, and names the screen it was on.
@MainActor
final class StallWatchdog {

    private static let interval: TimeInterval = 1.0
    /// Comfortably below a visible freeze; a frame budget is 16ms, a second is already broken.
    private static let threshold: TimeInterval = 0.6

    private var timer: Timer?
    private var lastTick = Date()
    private var worstStall: TimeInterval = 0
    private var reportedFor = Date.distantPast

    func start() {
        stop()
        lastTick = Date()
        let t = Timer(timeInterval: Self.interval, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.tick() }
        }
        // Common modes so the watchdog keeps firing while a menu is tracking.
        RunLoop.main.add(t, forMode: .common)
        timer = t
        FileHandle.standardError.write(Data("[stall] watchdog armed, \(Self.interval)s interval\n".utf8))
    }

    func stop() {
        timer?.invalidate()
        timer = nil
    }

    private func tick() {
        let now = Date()
        let drift = now.timeIntervalSince(lastTick) - Self.interval
        // A run loop that was blocked catches up by firing the timer again straight away, so
        // advancing the baseline by whole intervals keeps one long stall from being reported as a
        // flurry of short ones — and keeps it from being swallowed entirely.
        let missed = Int(drift / Self.interval) + 1
        lastTick = lastTick.addingTimeInterval(Self.interval * Double(missed))
        guard drift > Self.threshold else { return }

        let stall = drift
        if stall > worstStall { worstStall = stall }
        // One line per stall burst; a persistent loop should not fill the log.
        guard now.timeIntervalSince(reportedFor) > 5 else { return }
        reportedFor = now
        let message = "UI stalled for \(String(format: "%.1f", stall))s on \(AppModel.shared.workspace.rawValue)"
        AppModel.shared.appendLog(message, .bad)
        // Also to stderr: `appendLog` only feeds the in-app event log, which is exactly what a
        // frozen app cannot show you.
        FileHandle.standardError.write(Data("[stall] \(message)\n".utf8))
    }
}