
import SwiftUI
import AppKit

// ============================================================================
//  Design tokens
// ============================================================================

/// The single source of truth for colour, type and spacing across the app.
///
/// The palette is a dark "cyberpunk crimson" scheme: near-black neutrals with a single
/// saturated accent, so traffic colour-coding (method + status) stays the loudest thing
/// on screen.
enum Theme {

    // MARK: Surfaces

    // MARK: Surfaces
    //
    // Warm near-blacks rather than pure grey: a hint of red in the neutrals keeps
    // the palette cohesive without any saturated colour competing for attention.

    static let background = Color(hex: 0x0C0B0D)
    static let surface = Color(hex: 0x131215)
    static let surfaceRaised = Color(hex: 0x1A181C)
    static let surfaceOverlay = Color(hex: 0x211F24)
    static let sidebar = Color(hex: 0x100F12)

    // MARK: Accent
    //
    // A deep oxblood rather than a saturated red. It still reads unmistakably as red,
    // but sits quietly against near-black instead of glowing, so the interface stays
    // calm and the few places that need attention stand out for the right reason.

    // Nudged slightly redder than the previous 0x9E3B44. The palette is deliberately restrained
    // — these read as muted oxblood rather than fire-engine red — so the shift is a couple of
    // points of hue, not a saturation jump.
    static let crimson = Color(hex: 0xA33A40)
    static let crimsonBright = Color(hex: 0xBE464E)
    static let crimsonDim = Color(hex: 0x5C2126)
    static let accentGradient = LinearGradient(
        colors: [crimsonBright, crimson], startPoint: .topLeading, endPoint: .bottomTrailing
    )

    // MARK: Text

    static let textPrimary = Color(hex: 0xE8E6E9)
    static let textSecondary = Color(hex: 0xA5A1A9)
    static let textTertiary = Color(hex: 0x77737C)
    static let textOnAccent = Color(hex: 0x120E10)

    // MARK: Lines

    static let divider = Color(hex: 0x242227)
    static let dividerBright = Color(hex: 0x322F37)

    // MARK: Semantic
    //
    // Pulled almost onto the neutral axis on purpose. The interface has exactly one
    // chromatic colour — the oxblood accent — and status hues stay close enough to
    // grey that the screen reads calm, while still being distinguishable when a
    // status actually matters. Only `danger` leans toward the accent.

    static let success = Color(hex: 0x8C9E8E)
    static let info = Color(hex: 0x8A94A3)
    static let warning = Color(hex: 0xA8987E)
    static let danger = Color(hex: 0xA96B6E)
    static let redirect = Color(hex: 0x938C9E)

    // MARK: Method colours

    static func methodColor(_ method: String) -> Color {
        Color(hex: Palette.method(method))
    }

    static func statusColor(_ status: Int?) -> Color {
        guard status != nil else { return textTertiary }
        return Color(hex: Palette.status(status))
    }

    static func statusBackground(_ status: Int?) -> Color {
        guard let status else { return Color.clear }
        switch status {
        case 200..<300: return success.opacity(0.10)
        case 300..<400: return info.opacity(0.10)
        case 400..<500: return warning.opacity(0.10)
        case 500..<600: return danger.opacity(0.12)
        default: return Color.clear
        }
    }

    /// Severity ramps from slate to the app's own oxblood, so the worst findings
    /// share the accent hue instead of introducing a second alarm colour.
    static func severityColor(_ severity: ScanIssue.Severity) -> Color {
        switch severity {
        case .info: return Color(hex: 0x7F8794)
        case .low: return Color(hex: 0x859189)
        case .medium: return Color(hex: 0x9A8A78)
        case .high: return Color(hex: 0xA96B6E)
        case .critical: return Color(hex: 0xB54752)
        }
    }

    static func severityBackground(_ severity: ScanIssue.Severity) -> Color {
        severityColor(severity).opacity(0.11)
    }

    static func logColor(_ level: LogLevel) -> Color {
        switch level {
        case .info: return textSecondary
        case .good: return success
        case .warn: return warning
        case .bad: return danger
        }
    }

    static func directionColor(_ direction: InterceptDirection) -> Color {
        direction == .request ? info : success
    }

    // MARK: Typography

    static let monoFontName = "SF Mono"
    static let uiFont = "SF Pro Text"

    /// Global type scale, in points.
    ///
    /// The app read as too small, so every font — UI, monospaced SwiftUI and the AppKit mirror
    /// alike — is bumped through this one constant. Set it to `0` to get the nominal sizes back;
    /// no call site carries a magic offset.
    static let typeScale: CGFloat = 2

    static func mono(_ size: CGFloat = 12, weight: Font.Weight = .regular) -> NSFont {
        .monospacedSystemFont(ofSize: size + typeScale, weight: nsWeight(weight))
    }

    private static func nsWeight(_ weight: Font.Weight) -> NSFont.Weight {
        switch weight {
        case .ultraLight: return .ultraLight
        case .thin: return .thin
        case .light: return .light
        case .medium: return .medium
        case .semibold: return .semibold
        case .bold: return .bold
        case .heavy: return .heavy
        case .black: return .black
        default: return .regular
        }
    }

    static func ui(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size + typeScale, weight: weight, design: .default)
    }

    static func monoSwiftUI(_ size: CGFloat = 12, weight: Font.Weight = .regular) -> Font {
        .system(size: size + typeScale, weight: weight, design: .monospaced)
    }

    // MARK: AppKit mirror
    //
    // `NSColor(_ someColor: Color)` segfaults outside a SwiftUI render pass, which is
    // exactly where the AppKit-backed components update. The tokens used there are
    // mirrored as plain hex constants so the conversion never happens at all.

    enum NS {
        static let sidebar = NSColor(hex: 0x100F12)
        static let surface = NSColor(hex: 0x131215)
        static let surfaceRaised = NSColor(hex: 0x1A181C)
        static let background = NSColor(hex: 0x0C0B0D)
        static let divider = NSColor(hex: 0x242227)
        static let surfaceOverlay = NSColor(hex: 0x211F24)
        static let textPrimary = NSColor(hex: 0xE8E6E9)
        static let textSecondary = NSColor(hex: 0xA5A1A9)
        static let textTertiary = NSColor(hex: 0x77737C)
        static let crimson = NSColor(hex: 0xA33A40)
        static let success = NSColor(hex: 0x8C9E8E)
        static let warning = NSColor(hex: 0xA8987E)
        static let danger = NSColor(hex: 0xA96B6E)
        static let info = NSColor(hex: 0x8A94A3)

        static func status(_ code: Int?) -> NSColor { NSColor(hex: Palette.status(code)) }
        static func method(_ name: String) -> NSColor { NSColor(hex: Palette.method(name)) }
    }

    // MARK: Metrics

    static let corner: CGFloat = 7
    static let smallCorner: CGFloat = 5
    static let rowHeight: CGFloat = 22
    static let sidebarWidth: CGFloat = 288
    static let toolbarHeight: CGFloat = 50
    static let tabBarHeight: CGFloat = 36
}

// ============================================================================
//  Colour bridge
// ============================================================================

// ============================================================================
//  Shared colour ramp
//
//  The AppKit-backed components cannot convert a SwiftUI `Color` outside a render
//  pass, so both halves read from this single table of hex values.
// ============================================================================

enum Palette {
    // Muted slate-greens and ambers for methods. Only DELETE and the error
    // statuses carry any red, so the accent colour keeps its meaning.
    static let methodGET = UInt32(0x94A0B4)
    static let methodPOST = UInt32(0x94A79B)
    static let methodWrite = UInt32(0xA79B84)
    static let methodDELETE = UInt32(0xA98080)
    static let methodHEAD = UInt32(0x95A0A8)
    static let methodOPTIONS = UInt32(0x9C99A6)
    static let methodCONNECT = UInt32(0x9E97A6)

    static let status1xx = UInt32(0x9A95A6)
    static let status2xx = UInt32(0x86A08C)
    static let status3xx = UInt32(0x879AB0)
    static let status4xx = UInt32(0xA8987E)
    static let status5xx = UInt32(0xA96B6E)

    static let originRepeater = UInt32(0x879AB0)
    static let originIntruder = UInt32(0xA8987E)
    static let originSpider = UInt32(0x86A08C)
    static let originScanner = UInt32(0xA96B6E)
    static let originComparer = UInt32(0x9A95A6)

    static func method(_ name: String) -> UInt32 {
        switch name.uppercased() {
        case "GET": return methodGET
        case "POST": return methodPOST
        case "PUT", "PATCH": return methodWrite
        case "DELETE": return methodDELETE
        case "HEAD": return methodHEAD
        case "OPTIONS": return methodOPTIONS
        case "CONNECT": return methodCONNECT
        default: return UInt32(0xA5A1A9)
        }
    }

    static func status(_ code: Int?) -> UInt32 {
        guard let code else { return 0x77737C }
        switch code {
        case 100..<200: return status1xx
        case 200..<300: return status2xx
        case 300..<400: return status3xx
        case 400..<500: return status4xx
        case 500..<600: return status5xx
        default: return UInt32(0xA5A1A9)
        }
    }

    /// Colour that marks where an exchange came from.
    static func origin(_ origin: HTTPPair.Origin) -> UInt32 {
        switch origin {
        case .proxy: return UInt32(0x3A3A44)
        case .repeater: return originRepeater
        case .intruder: return originIntruder
        case .spider: return originSpider
        case .scanner: return originScanner
        case .comparer: return originComparer
        }
    }
}

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: opacity
        )
    }

    init(hex: UInt32) {
        self.init(hex: hex, opacity: 1)
    }
}

extension NSColor {
    convenience init(hex: UInt32, alpha: CGFloat = 1) {
        self.init(
            srgbRed: CGFloat((hex >> 16) & 0xFF) / 255,
            green: CGFloat((hex >> 8) & 0xFF) / 255,
            blue: CGFloat(hex & 0xFF) / 255,
            alpha: alpha
        )
    }

    }

// ============================================================================
//  Reusable components
// ============================================================================

/// Thin crimson rule separating major regions.
struct CrimsonRule: View {
    var axis: Axis = .horizontal
    var body: some View {
        Rectangle()
            .fill(
                LinearGradient(
                    colors: [Theme.crimson.opacity(0), Theme.crimson.opacity(0.35), Theme.crimson.opacity(0)],
                    startPoint: axis == .horizontal ? .leading : .top,
                    endPoint: axis == .horizontal ? .trailing : .bottom
                )
            )
            .frame(
                width: axis == .vertical ? 1 : nil,
                height: axis == .horizontal ? 1 : nil
            )
    }
}

/// Uppercase section caption.
struct SectionLabel: View {
    let text: String
    var trailing: String? = nil

    var body: some View {
        HStack(spacing: 6) {
            Text(text.uppercased())
                .font(Theme.ui(10, weight: .semibold))
                .tracking(1.1)
                .lineLimit(1)
                .fixedSize(horizontal: true, vertical: false)
                .foregroundStyle(Theme.textTertiary)
            if let trailing {
                Text(trailing)
                    .font(Theme.ui(10, weight: .medium))
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .foregroundStyle(Theme.textTertiary.opacity(0.75))
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
    }
}

/// Pill-shaped container used by inspectors and sidebars.
struct Panel<Content: View>: View {
    var title: String? = nil
    var padding: CGFloat = 10
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if let title {
                SectionLabel(text: title)
                Rectangle().fill(Theme.divider).frame(height: 1)
            }
            content.padding(padding)
        }
        .background(
                RoundedRectangle(cornerRadius: Theme.corner, style: .continuous)
                    .fill(Theme.surface)
            )
        .clipShape(RoundedRectangle(cornerRadius: Theme.corner, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: Theme.corner, style: .continuous)
                .strokeBorder(Theme.divider, lineWidth: 1)
        )
    }
}

// MARK: - Buttons

struct CrimsonButtonStyle: ButtonStyle {
    var prominent = true
    var compact = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(Theme.ui(compact ? 11 : 12, weight: .semibold))
            .lineLimit(1)
            .foregroundStyle(prominent ? Theme.textOnAccent : Theme.textPrimary)
            .padding(.horizontal, compact ? 10 : 14)
            .padding(.vertical, compact ? 4 : 6)
            .background(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                    .fill(prominent ? AnyShapeStyle(Theme.accentGradient) : AnyShapeStyle(Theme.surfaceOverlay))
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                    .strokeBorder(prominent ? Color.clear : Theme.dividerBright, lineWidth: 1)
            )
            .opacity(configuration.isPressed ? 0.7 : 1)
            .shadow(color: prominent ? Theme.crimson.opacity(configuration.isPressed ? 0.08 : 0.22) : .clear, radius: 5, y: 2)
    }
}

struct GhostButtonStyle: ButtonStyle {
    var tint: Color = Theme.textSecondary
    var compact = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(Theme.ui(compact ? 11 : 12, weight: .medium))
            .lineLimit(1)
            .foregroundStyle(tint)
            .padding(.horizontal, compact ? 8 : 11)
            .padding(.vertical, compact ? 4 : 6)
            .background(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                    .fill(Theme.surfaceOverlay.opacity(configuration.isPressed ? 0.9 : 0.45))
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                    .strokeBorder(Theme.divider, lineWidth: 1)
            )
    }
}

/// Transport-style play/stop button for the proxy listener.
struct TransportButton: View {
    let isRunning: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 7) {
                ZStack {
                    Circle()
                        .fill(isRunning ? Theme.success.opacity(0.10) : Theme.crimson.opacity(0.10))
                        .frame(width: 22, height: 22)
                    Image(systemName: isRunning ? "stop.fill" : "play.fill")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(isRunning ? Theme.success : Theme.crimsonBright)
                }
                Text(isRunning ? "Listening" : "Start proxy")
                    .font(Theme.ui(12, weight: .semibold))
                    .foregroundStyle(Theme.textPrimary)
                if isRunning {
                    Circle()
                        .fill(Theme.success)
                        .frame(width: 6, height: 6)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                    .fill(Theme.surfaceOverlay)
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                    .strokeBorder(isRunning ? Theme.success.opacity(0.28) : Theme.divider, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Badges

struct Badge: View {
    let text: String
    var color: Color = Theme.textSecondary
    var filled = false

    var body: some View {
        Text(text)
            .font(Theme.ui(10, weight: .bold))
            .tracking(0.4)
            .lineLimit(1)
            .fixedSize(horizontal: true, vertical: false)
            .foregroundStyle(filled ? Theme.background : color)
            .padding(.horizontal, 6)
            .padding(.vertical, 2)
            .background(
                Capsule().fill(filled ? color : color.opacity(0.15))
            )
            .overlay(
                Capsule().strokeBorder(filled ? Color.clear : color.opacity(0.35), lineWidth: 1)
            )
    }
}

struct StatusChip: View {
    let status: Int?

    var body: some View {
        Text(status.map(String.init) ?? "—")
            .font(Theme.monoSwiftUI(11, weight: .bold))
            .lineLimit(1)
            .fixedSize(horizontal: true, vertical: false)
            .foregroundStyle(Theme.statusColor(status))
            .padding(.horizontal, 5)
            .padding(.vertical, 1)
            .background(
                RoundedRectangle(cornerRadius: 3, style: .continuous)
                    .fill(Theme.statusBackground(status))
            )
            .frame(minWidth: 34)
    }
}

// MARK: - Form controls

struct LabelledField: View {
    let label: String
    @Binding var text: String
    var placeholder: String = ""
    var mono = false
    var width: CGFloat? = nil

    var body: some View {
        HStack(spacing: 6) {
            Text(label)
                .font(Theme.ui(11))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 88, alignment: .trailing)
            TextField(placeholder, text: $text)
                .textFieldStyle(.plain)
                .font(mono ? Theme.monoSwiftUI(12) : Theme.ui(12))
                .foregroundStyle(Theme.textPrimary)
                .padding(.horizontal, 7)
                .padding(.vertical, 4)
                .background(
                    RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                        .fill(Theme.background)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                        .strokeBorder(Theme.divider, lineWidth: 1)
                )
                .frame(width: width)
        }
    }
}

struct DarkPicker<T: Hashable>: View {
    let title: String
    @Binding var selection: T
    let options: [(T, String)]
    var width: CGFloat = 132

    var body: some View {
        HStack(spacing: 6) {
            Text(title)
                .font(Theme.ui(11))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 88, alignment: .trailing)
            Picker("", selection: $selection) {
                ForEach(options, id: \.0) { option in
                    Text(option.1).tag(option.0)
                }
            }
            .labelsHidden()
            .pickerStyle(.menu)
            .font(Theme.ui(12))
            .frame(width: width)
        }
    }
}

/// Compact toggle with the crimson accent applied.
struct CrimsonToggle: View {
    @Binding var isOn: Bool
    var label: String = ""

    var body: some View {
        Button {
            isOn.toggle()
        } label: {
            HStack(spacing: 7) {
                ZStack(alignment: isOn ? .trailing : .leading) {
                    Capsule()
                        .fill(isOn ? Theme.crimson.opacity(0.85) : Theme.dividerBright)
                        .frame(width: 30, height: 17)
                    Circle()
                        .fill(Color.white)
                        .frame(width: 13, height: 13)
                        .padding(.horizontal, 2)
                        .shadow(color: .black.opacity(0.35), radius: 1, y: 0.5)
                }
                if !label.isEmpty {
                    Text(label)
                        .font(Theme.ui(12))
                        .foregroundStyle(isOn ? Theme.textPrimary : Theme.textSecondary)
                }
            }
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Layout helpers

/// Draggable split container used across the workspaces.
/// Accepts two trailing view-builder closures: `SplitLayout(axis: .vertical) { top } { bottom }`.
struct SplitLayout<First: View, Second: View>: View {
    var axis: Axis = .horizontal
    var minFirst: CGFloat = 140
    var minSecond: CGFloat = 140
    private let first: First
    private let second: Second
    @State private var fraction: CGFloat = 0.5

    init(
        axis: Axis = .horizontal,
        minFirst: CGFloat = 140,
        minSecond: CGFloat = 140,
        initialFraction: CGFloat = 0.5,
        @ViewBuilder first: () -> First,
        @ViewBuilder second: () -> Second
    ) {
        self.axis = axis
        self.minFirst = minFirst
        self.minSecond = minSecond
        self.first = first()
        self.second = second()
        _fraction = State(initialValue: initialFraction)
    }

    var body: some View {
        GeometryReader { geo in
            let isH = axis == .horizontal
            let total = isH ? geo.size.width : geo.size.height
            let firstSize = max(minFirst, min(total - minSecond, total * fraction))
            let secondSize = max(0, total - firstSize - 6)
            Group {
                if isH {
                    HStack(spacing: 0) {
                        first.frame(width: firstSize)
                        Splitter(axis: axis, total: total, base: firstSize, fraction: $fraction)
                            .frame(width: 6)
                        second.frame(width: secondSize)
                    }
                    .frame(width: geo.size.width, alignment: .leading)
                } else {
                    VStack(spacing: 0) {
                        first.frame(height: firstSize)
                        Splitter(axis: axis, total: total, base: firstSize, fraction: $fraction)
                            .frame(height: 6)
                        second.frame(height: secondSize)
                    }
                    .frame(height: geo.size.height, alignment: .top)
                }
            }
            // Neither pane may paint outside its slot. Without this, a wide child — a long URL in
            // the summary bar, a wide action row — drew straight past the window edge.
            .clipped()
        }
    }
}

/// The draggable part of a `SplitLayout`.
///
/// The drag gesture belongs on this handle alone. Attached to the group that holds both panes,
/// it swallows clicks anywhere in the layout and buttons inside either pane stop reacting.
private struct Splitter: View {
    let axis: Axis
    let total: CGFloat
    let base: CGFloat
    @Binding var fraction: CGFloat

    init(axis: Axis, total: CGFloat, base: CGFloat, fraction: Binding<CGFloat>) {
        self.axis = axis
        self.total = total
        self.base = base
        self._fraction = fraction
    }

    var body: some View {
        SplitHandle(axis: axis)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 1)
                    .onChanged { value in
                        let delta = axis == .horizontal ? value.translation.width : value.translation.height
                        fraction = (base + delta) / max(total, 1)
                    }
            )
    }
}

/// Thin resizable divider.
struct SplitHandle: View {
    var axis: Axis

    var body: some View {
        ZStack {
            Rectangle()
                .fill(Theme.divider)
                .frame(width: axis == .horizontal ? 1 : nil, height: axis == .vertical ? 1 : nil)
        }
        .frame(width: axis == .horizontal ? 6 : nil, height: axis == .vertical ? 6 : nil)
        .contentShape(Rectangle())
        .onHover { inside in
            if inside {
                if axis == .horizontal { NSCursor.resizeLeftRight.push() } else { NSCursor.resizeUpDown.push() }
            } else {
                NSCursor.pop()
            }
        }
    }
}

/// Selectable segmented control used for Raw / Pretty / Headers / Params tabs.
struct SegmentBar<T: Hashable>: View {
    @Binding var selection: T
    let options: [(T, String, String)]
    var compact = false

    var body: some View {
        HStack(spacing: 2) {
            ForEach(options, id: \.0) { option in
                let active = option.0 == selection
                Button {
                    selection = option.0
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: option.2)
                            .font(.system(size: compact ? 9 : 10, weight: .semibold))
                        Text(option.1)
                            .font(Theme.ui(compact ? 10 : 11, weight: active ? .semibold : .regular))
                    }
                    .foregroundStyle(active ? Theme.textOnAccent : Theme.textSecondary)
                    // Without this the label wrapped one character per line as soon as the
                    // inspector got narrow — the "letters running top to bottom" look.
                    // `fixedSize` is safe here: this bar sits in a header row, never inside a
                    // horizontal `ScrollView`, so there is no width feedback loop.
                    .lineLimit(1)
                    .fixedSize(horizontal: true, vertical: false)
                    .padding(.horizontal, compact ? 7 : 9)
                    .padding(.vertical, compact ? 3 : 4)
                    .background(
                        RoundedRectangle(cornerRadius: 4, style: .continuous)
                            .fill(active ? Theme.crimson : Color.clear)
                    )
                }
                .buttonStyle(.plain)
            }
        }
        .padding(2)
        .background(
            RoundedRectangle(cornerRadius: 6, style: .continuous).fill(Theme.background)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 6, style: .continuous).strokeBorder(Theme.divider, lineWidth: 1)
        )
    }
}

/// Empty-state placeholder.
struct EmptyHint: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        VStack(spacing: 9) {
            Image(systemName: icon)
                .font(.system(size: 26, weight: .light))
                .foregroundStyle(Theme.dividerBright)
            Text(title)
                .font(Theme.ui(13, weight: .medium))
                .foregroundStyle(Theme.textSecondary)
            Text(subtitle)
                .font(Theme.ui(11))
                .foregroundStyle(Theme.textTertiary)
                .multilineTextAlignment(.center)
                .frame(maxWidth: 340)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

/// Search field with a leading glyph.
struct SearchField: View {
    @Binding var text: String
    var placeholder: String = "Search"
    var width: CGFloat? = nil

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(Theme.textTertiary)
            TextField(placeholder, text: $text)
                .textFieldStyle(.plain)
                .font(Theme.ui(12))
                .foregroundStyle(Theme.textPrimary)
            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 10))
                        .foregroundStyle(Theme.textTertiary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(
            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous).fill(Theme.background)
        )
        .overlay(
            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                .strokeBorder(Theme.divider, lineWidth: 1)
        )
        .frame(width: width)
    }
}