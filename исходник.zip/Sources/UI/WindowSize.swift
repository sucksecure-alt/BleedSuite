import CoreGraphics
import Foundation

/// Window sizing, in one place.
///
/// The minimum is deliberately below the comfortable width. A proxy has to stay usable in a
/// narrow pane — the splitter can already squeeze the inspector down to a few hundred points —
/// so the layout is required to hold together there rather than being protected by a floor that
/// only hides the problem on someone else's screen.
enum WindowSize {

    /// Below this the sidebar and the workspace genuinely stop being usable.
    static let minimum = CGSize(width: 940, height: 600)

    /// What a fresh launch opens at.
    static let defaultSize = CGSize(width: 1320, height: 860)

    /// Requested window size, if `--window <w>x<h>` was passed.
    static var requested: CGSize? {
        guard let index = CommandLine.arguments.firstIndex(of: "--window"),
              CommandLine.arguments.count > index + 1
        else { return nil }
        let parts = CommandLine.arguments[index + 1].split(separator: "x", maxSplits: 1)
        guard parts.count == 2,
              let width = Double(parts[0]),
              let height = Double(parts[1]),
              width > 0, height > 0
        else { return nil }
        return CGSize(
            width: max(width, minimum.width),
            height: max(height, minimum.height)
        )
    }

    /// The size a new window should open at.
    static var launch: CGSize { requested ?? defaultSize }
}