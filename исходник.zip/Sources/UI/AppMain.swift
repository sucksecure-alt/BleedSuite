
import SwiftUI
import AppKit
import Security

/// Mutable box so a detached task can hand a result back to the parked main thread.
final class ExitCode: @unchecked Sendable {
    private let lock = NSLock()
    private var storage: Int32 = 1
    var value: Int32 {
        get { lock.lock(); defer { lock.unlock() }; return storage }
        set { lock.lock(); storage = newValue; lock.unlock() }
    }
}

/// Entry point. `--selftest` runs the engine suite and exits without launching the UI.
@main
struct BleedSuiteEntry {
    static func main() {
        if let index = CommandLine.arguments.firstIndex(of: "--dump-cert"),
           CommandLine.arguments.count > index + 1 {
            let host = CommandLine.arguments[index + 1]
            var exported = ""
            do {
                let ca = CertificateAuthority.shared
                let der = (try? ca.leafDER(for: host)) ?? Data()
                if der.isEmpty {
                    exported = "error: could not mint a certificate for \(host)\n"
                } else {
                    let b64 = der.base64EncodedString(options: [.lineLength64Characters, .endLineWithLineFeed])
                    exported = "-----BEGIN CERTIFICATE-----\n\(b64)\n-----END CERTIFICATE-----\n"
                }
            } catch {
                exported = "error: \(error.localizedDescription)\n"
            }
            FileHandle.standardOutput.write(Data(exported.utf8))
            return
        }
        // Diagnostics used during setup and support. These run entirely off the main
        // actor — `main` has no run loop here, so anything touching @MainActor would
        // deadlock against the semaphore wait below.
        if CommandLine.arguments.contains("--proxy-on") {
            let done = DispatchSemaphore(value: 0)
            let resultBox = ExitCode()
            Task.detached(priority: .userInitiated) {
                resultBox.value = await SystemProxyToggle.apply(port: 8080) ? 0 : 1
                done.signal()
            }
            _ = done.wait(timeout: .now() + 60)
            exit(resultBox.value)
        }
        if CommandLine.arguments.contains("--proxy-off") {
            let done = DispatchSemaphore(value: 0)
            Task.detached(priority: .userInitiated) {
                await SystemProxyToggle.restore()
                done.signal()
            }
            _ = done.wait(timeout: .now() + 60)
            exit(0)
        }
        // `--stall-test` deliberately blocks the main thread for 3s so the watchdog can be shown to
        // actually fire. Used to validate the watchdog itself.
        if let index = CommandLine.arguments.firstIndex(of: "--stall-test") {
            let seconds = CommandLine.arguments.count > index + 1
                ? (Double(CommandLine.arguments[index + 1]) ?? 3) : 3
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 4_000_000_000)
                FileHandle.standardError.write(Data("[stall] blocking the main thread for \(seconds)s\n".utf8))
                Thread.sleep(forTimeInterval: seconds)
                FileHandle.standardError.write(Data("[stall] main thread released\n".utf8))
            }
        }
        if CommandLine.arguments.contains("--uitest") {
            // The main run loop has to keep turning while the @MainActor task runs — blocking
            // this thread on a semaphore stops the main queue from ever draining, so the task
            // would never start.
            let finished = DispatchSemaphore(value: 0)
            Task { @MainActor in
                let code = await UITest.run()
                finished.signal()
                exit(code)
            }
            while finished.wait(timeout: .now()) == .timedOut {
                RunLoop.main.run(until: Date().addingTimeInterval(0.05))
            }
            exit(1)
        }
        if CommandLine.arguments.contains("--selftest") {
            // The main run loop has to keep turning for the same reason `--record` needs it:
            // parts of the suite are main-actor isolated (the repeater round trip, the
            // intercept queue), and parking this thread on a semaphore means no main-actor
            // work can ever run. That deadlocked until the 300 s wait expired and this thread
            // resumed — the suite passed, but every run cost five minutes.
            Task.detached(priority: .userInitiated) {
                let code = await SelfTest.run()
                exit(code)
            }
            while true {
                RunLoop.main.run(mode: .default, before: Date().addingTimeInterval(0.05))
            }
        }
        // `--record <seconds>` runs the proxy headless for a while and prints what it captured, then
        // exits. The history store lives in memory, so there is no other way to inspect what a
        // run actually recorded — and a blank Host in the history table cannot be diagnosed from
        // the UI.
        if let index = CommandLine.arguments.firstIndex(of: "--record") {
            let seconds = CommandLine.arguments.count > index + 1
                ? (Int(CommandLine.arguments[index + 1]) ?? 20) : 20

            // The main run loop has to keep turning: proxy sessions are main-actor isolated, and
            // parking this thread on a semaphore stops them from ever running — every request
            // then hangs and nothing is recorded, which looks exactly like a broken recorder.
            Task { @MainActor in
                _ = try? await ProxyEngine.shared.start()
            }

            RunLoop.main.run(until: Date().addingTimeInterval(TimeInterval(seconds)))

            let all = HistoryStore.shared.allRows
            var out = "recorded=\(HistoryStore.shared.totalCount)\n"
            for pair in all.suffix(50) {
                let host = pair.host.isEmpty ? "<EMPTY>" : pair.host
                out += "#\(pair.id) \(pair.request.method) \(pair.request.rawTarget) "
                out += "host=\(host) port=\(pair.port) secure=\(pair.isSecure) "
                out += "status=\(pair.status.map(String.init) ?? "-")\n"
                out += "   hdr: \(pair.request.headers.map { "\($0.name)=\($0.value)" }.joined(separator: " | "))\n"
            }
            FileHandle.standardOutput.write(Data(out.utf8))
            exit(0)
        }
        // `--open <workspace>` lands straight on a given screen. Used to smoke-test every tab
        // without a human clicking through the sidebar.
        if let index = CommandLine.arguments.firstIndex(of: "--open"),
           CommandLine.arguments.count > index + 1,
           let requested = Workspace(rawValue: CommandLine.arguments[index + 1].lowercased()) {
            AppModel.shared.workspace = requested
        }
        BleedSuiteApp.main()
    }
}

struct BleedSuiteApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var model = AppModel.shared

    var body: some Scene {
        WindowGroup("Bleed Suite") {
            RootView()
                .frame(
                    minWidth: WindowSize.minimum.width,
                    minHeight: WindowSize.minimum.height
                )
                .preferredColorScheme(.dark)
                .onAppear { model.bootstrap() }
                .environmentObject(model)
        }
        .windowStyle(.hiddenTitleBar)
        .commands { BleedCommands(model: model) }
    }
}

struct BleedCommands: Commands {
    @ObservedObject var model: AppModel

    var body: some Commands {
        CommandGroup(replacing: .newItem) {
            Button("New Repeater Tab") { model.repeater.newTab() }
                .keyboardShortcut("t", modifiers: [.command, .shift])
        }

        CommandMenu("Proxy") {
            Button(model.proxyRunning ? "Stop Proxy" : "Start Proxy") { model.toggleProxy() }
                .keyboardShortcut("p", modifiers: [.command, .shift])

            Button(model.interceptEnabled ? "Turn Interception Off" : "Turn Interception On") {
                model.toggleIntercept()
            }
            .keyboardShortcut("i", modifiers: [.command, .shift])

            Divider()

            Button("Open Browser") { model.openBrowser() }
                .keyboardShortcut("b", modifiers: [.command, .shift])

            Button(model.systemProxyEnabled ? "Disable System Proxy" : "Enable System Proxy") {
                model.setSystemProxy(!model.systemProxyEnabled)
            }

            Divider()

            Button("Clear History") { model.clearHistory() }
                .keyboardShortcut("k", modifiers: [.command, .shift])

            Button("Export History…") { model.exportHistory(as: .har) }
                .keyboardShortcut("e", modifiers: [.command, .shift])
        }

        CommandMenu("Tools") {
            ForEach(Workspace.allCases) { workspace in
                Button(workspace.title) { model.workspace = workspace }
                    .keyboardShortcut(workspaceShortcut(workspace), modifiers: [.command, .option])
            }
        }

        CommandMenu("Project") {
            Button("Save Project") { model.saveProject() }
                .keyboardShortcut("s", modifiers: [.command])
            Button("Save Project As…") { model.saveProject() }
                .keyboardShortcut("s", modifiers: [.command, .shift])
        }
    }

    private func workspaceShortcut(_ workspace: Workspace) -> KeyEquivalent {
        switch workspace {
        case .dashboard: return "1"
        case .intercept: return "2"
        case .history: return "3"
        case .target: return "4"
        case .repeater: return "5"
        case .comparer: return "6"
        case .intruder: return "7"
        case .scanner: return "8"
        case .rules: return "9"
        case .settings: return "0"
        }
    }
}

/// Releases the system proxy on the signals a normal quit delivers.
///
/// `applicationWillTerminate` only runs when AppKit gets to unwind, which a `kill -9` prevents
/// outright and a hang can prevent by never returning to the run loop. Either way the machine
/// is left routed at a dead port and has no internet. SIGTERM and SIGINT are the paths a quit
/// script or a `kill` actually take, so the cleanup runs there too.
///
/// The handler does the minimum: a synchronous `networksetup` call to turn the proxy off, then
/// re-raises the signal with the default disposition so the exit status still looks like a
/// signal death to the parent process.
enum AppTermination {
    static func install() {
        for sig in [SIGTERM, SIGINT, SIGHUP] {
            signal(sig, handler)
            // A second signal must kill immediately; the user asked twice.
            signal(sig, SIG_IGN)
        }
    }

    private static let handler: @convention(c) (Int32) -> Void = { sig in
        SystemProxyRelease.restoreSynchronously()
        signal(sig, SIG_DFL)
        raise(sig)
    }
}

/// The synchronous, no-Swift-concurrency proxy release used from a signal handler.
///
/// `networksetup` is spawned directly rather than through `Shell`, because a signal handler runs
/// on a thread that must not allocate async work or wait on a queue that may itself be wedged.
enum SystemProxyRelease {
    private static let listenHost = "127.0.0.1"

    /// Services are probed rather than assumed, so this is safe to run when nothing was changed.
    static func restoreSynchronously() {
        let services = activeServices()
        guard !services.isEmpty else { return }
        for service in services {
            guard let settings = proxySettings(service) else { continue }
            guard settings.webEnabled || settings.secureEnabled else { continue }
            // Never touch a third-party proxy.
            guard settings.webServer == listenHost || settings.secureServer == listenHost else { continue }
            run(["-setwebproxystate", service, "off"])
            run(["-setsecurewebproxystate", service, "off"])
        }
    }

    private static func activeServices() -> [String] {
        let list = capture("/usr/sbin/networksetup", ["-listallnetworkservices"]) ?? ""
        return list.split(separator: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.hasPrefix("*") && !$0.isEmpty }
    }

    private struct Settings {
        var webEnabled = false, secureEnabled = false
        var webServer = "", secureServer = ""
    }

    private static func proxySettings(_ service: String) -> Settings? {
        var result = Settings()
        let web = capture("/usr/sbin/networksetup", ["-getwebproxy", service]) ?? ""
        let secure = capture("/usr/sbin/networksetup", ["-getsecurewebproxy", service]) ?? ""
        guard !web.isEmpty, !secure.isEmpty else { return nil }
        result.webEnabled = isOn(web)
        result.secureEnabled = isOn(secure)
        result.webServer = field(web, "Server")
        result.secureServer = field(secure, "Server")
        return result
    }

    private static func isOn(_ text: String) -> Bool {
        text.split(separator: "\n").contains { line in
            let parts = line.split(separator: ":", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            return parts.count == 2 && parts[0] == "Enabled" && parts[1] == "Yes"
        }
    }

    private static func field(_ text: String, _ key: String) -> String {
        for line in text.split(separator: "\n") {
            let parts = line.split(separator: ":", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            if parts.count == 2, parts[0] == key { return String(parts[1]) }
        }
        return ""
    }

    private static func run(_ args: [String]) {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/sbin/networksetup")
        process.arguments = args
        // A dead-end pipe must not kill the app on the way out.
        process.standardOutput = FileHandle.nullDevice
        process.standardError = FileHandle.nullDevice
        try? process.run()
        process.waitUntilExit()
    }

    private static func capture(_ path: String, _ args: [String]) -> String? {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: path)
        process.arguments = args
        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = FileHandle.nullDevice
        do {
            try process.run()
        } catch {
            return nil
        }
        // Bounded: a wedged `networksetup` must not hang the handler forever.
        let deadline = Date().addingTimeInterval(3)
        var data = Data()
        while Date() < deadline {
            let chunk = pipe.fileHandleForReading.availableData
            if chunk.isEmpty { break }
            data.append(chunk)
            if process.isRunning == false { break }
        }
        process.terminate()
        return String(data: data, encoding: .utf8)
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.appearance = NSAppearance(named: .darkAqua)
        signal(SIGPIPE, SIG_IGN)
        AppTermination.install()
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }

    /// Sizes the first window. Without this a launch inherits whatever size the window had
    /// before, which is how a cramped layout survives a restart nobody remembers.
    func applicationDidBecomeActive(_ notification: Notification) {
        guard !AppModel.shared.hasSizedWindow else { return }
        AppModel.shared.hasSizedWindow = true
        MainActor.assumeIsolated {
            guard let window = NSApp.windows.first else { return }
            let size = WindowSize.launch
            window.setContentSize(size)
            window.center()
        }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    func applicationWillTerminate(_ notification: Notification) {
        MainActor.assumeIsolated {
            AppModel.shared.shutdown()
        }
    }
}