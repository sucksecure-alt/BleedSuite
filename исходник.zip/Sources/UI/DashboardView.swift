
import SwiftUI
import AppKit

// ============================================================================
//  Dashboard workspace
// ============================================================================

/// Landing screen: listener state, headline counters, a jump-off point into the
/// other workspaces and a live tail of the event log.
struct DashboardView: View {
    @ObservedObject var model = AppModel.shared

    private var version: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
    }

    private var highIssues: Int {
        model.scanIssues.filter { $0.severity >= .high }.count
    }

    private var criticalIssues: Int {
        model.scanIssues.filter { $0.severity == .critical }.count
    }

    private var recentLog: [LogEntry] {
        Array(model.filteredLog.prefix(12))
    }

    var body: some View {
        VStack(spacing: 0) {
            WorkspaceToolbar(title: "Dashboard", subtitle: "Bleed Suite — intercepting proxy") {
                HStack(spacing: 8) {
                    if model.interceptItems.isEmpty {
                        Text(verbatim: "\(model.totalHistoryCount) requests")
                            .font(Theme.monoSwiftUI(11))
                            .foregroundStyle(Theme.textSecondary)
                    } else {
                        Badge(text: "\(model.interceptItems.count) held", color: Theme.crimson)
                    }
                    if model.caTrusted {
                        Badge(text: "CA trusted", color: Theme.crimson)
                    } else {
                        Badge(text: "CA not trusted", color: Theme.textSecondary)
                    }
                }
            }

            Rectangle().fill(Theme.divider).frame(height: 1)

            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    hero
                    kpiRow
                    quickActions
                    logPanel
                }
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(Theme.background)
        }
        .background(Theme.background)
    }

    // MARK: - Hero

    private var hero: some View {
        DashboardCard(accent: Theme.crimson, padding: 0, showsAccent: true) {
            VStack(alignment: .leading, spacing: 0) {
                // No logo and no wordmark here. The hero states what the app is doing; the
                // window title and sidebar already carry the identity, and a 62 pt badge was
                // pure decoration occupying the widest, brightest slot on the page.
                HStack(alignment: .center, spacing: 16) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(verbatim: "HTTP / HTTPS interception proxy")
                            .font(Theme.ui(13))
                            .foregroundStyle(Theme.textSecondary)
                            .fixedSize(horizontal: true, vertical: false)
                    }

                    Spacer(minLength: 12)

                    Button {
                        model.workspace = .settings
                    } label: {
                        Label("Settings", systemImage: "gearshape.fill")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                }
                .padding(.horizontal, 16)
                .padding(.top, 16)

                Rectangle()
                    .fill(
                        LinearGradient(
                            colors: [Theme.crimson.opacity(0), Theme.crimson.opacity(0.6), Theme.crimson.opacity(0)],
                            startPoint: .leading, endPoint: .trailing
                        )
                    )
                    .frame(height: 1)
                    .padding(.vertical, 14)

                HStack(alignment: .center, spacing: 12) {
                    PulseDot(color: model.proxyRunning ? Theme.crimson : Theme.textTertiary)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(verbatim: model.proxyRunning
                             ? "Listening on 127.0.0.1:\(model.proxyPort)"
                             : "Stopped")
                            .font(Theme.monoSwiftUI(20, weight: .bold))
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                            .foregroundStyle(model.proxyRunning ? Theme.textPrimary : Theme.crimsonBright)
                        Text(verbatim: model.proxyRunning
                             ? "\(model.connectionCount) connection\(model.connectionCount == 1 ? "" : "s")"
                             : "Start the listener to capture traffic")
                            .font(Theme.monoSwiftUI(10))
                            .foregroundStyle(Theme.textTertiary)
                    }

                    Spacer(minLength: 12)

                    HStack(spacing: 8) {
                        // The hero row is already crowded; without a fixed width the labels
                        // wrapped ("Stop" over "proxy") as soon as the type scale grew.
                        Button {
                            model.toggleProxy()
                        } label: {
                            Label(model.proxyRunning ? "Stop proxy" : "Start proxy",
                                  systemImage: model.proxyRunning ? "stop.fill" : "play.fill")
                                .lineLimit(1)
                                .fixedSize(horizontal: true, vertical: false)
                        }
                        .buttonStyle(CrimsonButtonStyle())

                        Button {
                            model.openBrowser()
                        } label: {
                            Label("Open browser", systemImage: "safari")
                                .lineLimit(1)
                                .fixedSize(horizontal: true, vertical: false)
                        }
                        .buttonStyle(GhostButtonStyle())

                        Button {
                            model.installCA()
                        } label: {
                            Label(model.caTrusted ? "CA installed" : "Install CA",
                                  systemImage: model.caTrusted ? "checkmark.shield.fill" : "checkmark.shield")
                                .lineLimit(1)
                                .fixedSize(horizontal: true, vertical: false)
                        }
                        .buttonStyle(GhostButtonStyle(tint: Theme.textSecondary))
                    }
                    .fixedSize(horizontal: true, vertical: false)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 16)
            }
        }
    }

    // MARK: - KPIs

    private var kpiRow: some View {
        HStack(alignment: .top, spacing: 12) {
            KpiCard(
                title: "Total requests",
                value: model.totalHistoryCount.compactString,
                caption: "\(model.visibleHistoryCount) shown",
                tint: Theme.textSecondary,
                icon: "list.bullet.rectangle"
            )
            KpiCard(
                title: "Hosts",
                value: "\(model.targetTree.count)",
                caption: model.targetTree.isEmpty ? "no targets captured" : "in the site map",
                tint: Theme.textSecondary,
                icon: "point.3.connected.trianglepath.dotted"
            )
            KpiCard(
                title: "Issues",
                value: "\(model.scanIssues.count)",
                caption: "\(criticalIssues) critical · \(highIssues) high",
                tint: model.scanIssues.isEmpty ? Theme.textSecondary : Theme.crimson,
                icon: "shield.lefthalf.filled.badge.checkmark",
                badge: model.scannerRunning ? "scanning" : nil,
                badgeColor: Theme.textSecondary
            )
            KpiCard(
                title: "Intercept held",
                value: "\(model.interceptItems.count)",
                caption: model.interceptEnabled ? "interception on" : "interception off",
                tint: model.interceptItems.isEmpty ? Theme.textSecondary : Theme.crimson,
                icon: "hand.raised.fill"
            )
        }
        .fixedSize(horizontal: false, vertical: true)
    }

    // MARK: - Quick actions

    private var quickActions: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionLabel(text: "Quick actions")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10),
                                GridItem(.flexible(), spacing: 10),
                                GridItem(.flexible(), spacing: 10)],
                      spacing: 10) {
                ForEach(actionCards, id: \.workspace) { card in
                    Button {
                        model.workspace = card.workspace
                    } label: {
                        DashboardCard(padding: 11) {
                            VStack(alignment: .leading, spacing: 7) {
                                HStack(spacing: 6) {
                                    Image(systemName: card.workspace.icon)
                                        .font(Theme.ui(11, weight: .semibold))
                                        .foregroundStyle(card.tint)
                                    Spacer(minLength: 4)
                                    if let badge = card.badge {
                                        Badge(text: badge, color: card.tint)
                                    }
                                }
                                Text(card.workspace.title)
                                    .font(Theme.ui(12, weight: .semibold))
                                    .foregroundStyle(Theme.textPrimary)
                                Text(card.detail)
                                    .font(Theme.ui(10))
                                    .foregroundStyle(Theme.textTertiary)
                                    .lineLimit(2)
                                    .multilineTextAlignment(.leading)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 10)
        }
        .background(
            RoundedRectangle(cornerRadius: Theme.corner, style: .continuous).fill(Theme.surface)
        )
        .clipShape(RoundedRectangle(cornerRadius: Theme.corner, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: Theme.corner, style: .continuous)
                .strokeBorder(Theme.divider, lineWidth: 1)
        )
    }

    /// Every card shares one tint. Only the badge and the icon colour vary, so the
    /// grid reads as a single surface instead of a colour chart.
    private var actionCards: [(workspace: Workspace, detail: String, tint: Color, badge: String?)] {
        let neutral = Theme.textSecondary
        return [
            (.intercept, "Hold requests and responses, edit before forwarding.",
             Theme.crimson, model.interceptItems.isEmpty ? nil : "\(model.interceptItems.count)"),
            (.repeater, "Resend a request with manual parameter changes.", neutral, nil),
            (.intruder, "Fuzz positions across a batch of payloads.", neutral, nil),
            (.scanner, "Passive and active checks over the captured traffic.", neutral,
             model.scanIssues.isEmpty ? nil : "\(model.scanIssues.count)"),
            (.rules, "Match and replace on any part of a message.", neutral, nil),
            (.target, "Site map of every host seen by the proxy.", neutral, nil),
        ]
    }

    // MARK: - Log

    private var logPanel: some View {
        Panel(title: "Event log", padding: 0) {
            VStack(spacing: 0) {
                HStack(spacing: 8) {
                    SearchField(text: $model.logFilter, placeholder: "Filter log", width: 240)
                    Text(verbatim: "\(recentLog.count) of \(model.filteredLog.count)")
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textTertiary)
                    Spacer(minLength: 8)
                    Button {
                        model.copyLog()
                    } label: {
                        Label("Copy", systemImage: "doc.on.doc")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))

                    Button {
                        model.clearLog()
                    } label: {
                        Label("Clear log", systemImage: "trash")
                    }
                    .buttonStyle(GhostButtonStyle(tint: Theme.crimsonBright, compact: true))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 7)

                Rectangle().fill(Theme.divider).frame(height: 1)

                if recentLog.isEmpty {
                    EmptyHint(
                        icon: "text.alignleft",
                        title: model.logFilter.isEmpty ? "No events yet" : "Nothing matches the filter",
                        subtitle: model.logFilter.isEmpty
                            ? "Proxy activity, interception and CA events show up here as they happen."
                            : "Clear the filter to see the full log."
                    )
                    .frame(height: 150)
                } else {
                    VStack(spacing: 0) {
                        ForEach(Array(recentLog.enumerated()), id: \.element.id) { index, entry in
                            HStack(alignment: .top, spacing: 8) {
                                Text(Format.clock(entry.time))
                                    .font(Theme.monoSwiftUI(10))
                                    .foregroundStyle(Theme.textTertiary)
                                Badge(text: entry.level.label, color: Theme.logColor(entry.level))
                                    .frame(width: 54, alignment: .leading)
                                Text(entry.text)
                                    .font(Theme.monoSwiftUI(11))
                                    .foregroundStyle(Theme.textSecondary)
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                                Spacer(minLength: 0)
                            }
                            .padding(.horizontal, 10)
                            .padding(.vertical, 3)
                            if index < recentLog.count - 1 {
                                Rectangle().fill(Theme.divider.opacity(0.45)).frame(height: 1)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
//  Dashboard building blocks
// ============================================================================

/// Surface with a thin accent line along its top edge.
private struct DashboardCard<Content: View>: View {
    var accent: Color = Theme.crimson
    var padding: CGFloat = 12
    /// Only the primary card carries the hairline rule; the rest are plain panels.
    var showsAccent: Bool = false
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            content
                .padding(padding)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: Theme.corner, style: .continuous).fill(Theme.surface)
        )
        .clipShape(RoundedRectangle(cornerRadius: Theme.corner, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: Theme.corner, style: .continuous)
                .strokeBorder(Theme.divider, lineWidth: 1)
        )
        .overlay(alignment: .top) {
            Rectangle()
                .fill(showsAccent ? accent : Color.clear)
                .frame(height: 2)
                .clipShape(
                    UnevenRoundedRectangle(
                        topLeadingRadius: Theme.corner,
                        bottomLeadingRadius: 0,
                        bottomTrailingRadius: 0,
                        topTrailingRadius: Theme.corner,
                        style: .continuous
                    )
                )
        }
    }
}

/// One headline number.
private struct KpiCard: View {
    let title: String
    let value: String
    let caption: String
    let tint: Color
    let icon: String
    var badge: String? = nil
    var badgeColor: Color = Theme.textSecondary

    var body: some View {
        DashboardCard(padding: 12) {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 6) {
                    Image(systemName: icon)
                        .font(Theme.ui(10, weight: .semibold))
                        .foregroundStyle(tint)
                    Text(title.uppercased())
                        .font(Theme.ui(9, weight: .semibold))
                        .tracking(0.9)
                        .foregroundStyle(Theme.textTertiary)
                    Spacer(minLength: 4)
                    if let badge {
                        Badge(text: badge, color: badgeColor)
                    }
                }
                Text(value)
                    .font(Theme.monoSwiftUI(30, weight: .bold))
                    .foregroundStyle(Theme.textPrimary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                Text(caption)
                    .font(Theme.ui(10))
                    .foregroundStyle(Theme.textTertiary)
                    .lineLimit(1)
                    .truncationMode(.tail)
            }
        }
    }
}

/// Breathing status light used in the hero header.
private struct PulseDot: View {
    let color: Color
    @State private var on = false

    var body: some View {
        ZStack {
            // A single breathing halo rather than a neon glow.
            Circle()
                .fill(color.opacity(0.10))
                .frame(width: 26, height: 26)
                .scaleEffect(on ? 1.15 : 0.9)
                .opacity(on ? 0.5 : 0.25)
            Circle()
                .fill(color)
                .frame(width: 9, height: 9)
        }
        .frame(width: 30, height: 30)
        .onAppear {
            withAnimation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true)) {
                on = true
            }
        }
    }
}
