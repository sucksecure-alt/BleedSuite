
import SwiftUI
import AppKit

// ============================================================================
//  Raw message editor with HTTP syntax highlighting
// ============================================================================

/// AppKit-backed editor. SwiftUI `TextEditor` cannot colour individual tokens, so the
/// whole app uses this one view for every raw request/response surface.
struct CodeEditor: NSViewRepresentable {
    @Binding var text: String
    var isEditable: Bool = true
    var fontSize: CGFloat = 12
    var onSubmit: (() -> Void)? = nil

    func makeNSView(context: Context) -> NSScrollView {
        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.drawsBackground = false
        scroll.borderType = .noBorder

        let textView = Coordinator.makeTextView()
        textView.isEditable = isEditable
        textView.isSelectable = true
        textView.isRichText = false
        textView.isAutomaticQuoteSubstitutionEnabled = false
        textView.isAutomaticDashSubstitutionEnabled = false
        textView.isAutomaticTextReplacementEnabled = false
        textView.isAutomaticSpellingCorrectionEnabled = false
        textView.isContinuousSpellCheckingEnabled = false
        textView.allowsUndo = true
        textView.backgroundColor = Theme.NS.background
        textView.textContainerInset = NSSize(width: 8, height: 8)
        textView.font = Theme.mono(fontSize)
        textView.textColor = Theme.NS.textPrimary
        textView.insertionPointColor = NSColor(hex: 0x9E3B44)
        textView.selectedTextAttributes = [
            .backgroundColor: NSColor(hex: 0x2A2024),
            .foregroundColor: NSColor.white,
        ]
        textView.minSize = NSSize(width: 0, height: 0)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]

        // Colour once, after the text is in place — highlighting before the string is set does
        // nothing and colouring twice doubles the cost of the editor appearing.
        textView.string = text

        scroll.documentView = textView
        context.coordinator.textView = textView
        context.coordinator.highlight(in: textView)
        return scroll
    }

    func updateNSView(_ scroll: NSScrollView, context: Context) {
        guard let textView = context.coordinator.textView else { return }
        context.coordinator.parent = self
        textView.isEditable = isEditable
        textView.font = Theme.mono(fontSize)
        guard textView.string != text else { return }
        let selection = textView.selectedRange()
        context.coordinator.isApplyingExternalText = true
        textView.string = text
        if selection.location <= textView.string.utf16.count {
            textView.setSelectedRange(selection)
        }
        context.coordinator.highlight(in: textView)
        context.coordinator.isApplyingExternalText = false
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, NSTextViewDelegate {
        /// Refreshed on every `updateNSView`. Held by value, so without this it kept the text the
        /// editor was born with, and the "did the user actually change anything" check below
        /// compared against a stale snapshot.
        fileprivate var parent: CodeEditor
        weak var textView: NSTextView?
        private var pendingHighlight: DispatchWorkItem?

        /// Set while the editor's text is being replaced from the model. `textDidChange` fires
        /// for that too, and publishing it straight back made the model → view → model round trip
        /// never fully settle: every pass re-published the same string, which re-rendered the
        /// whole workspace. Under live traffic that loop ran continuously and pinned a core.
        var isApplyingExternalText = false

        init(_ parent: CodeEditor) {
            self.parent = parent
            super.init()
        }

        static func makeTextView() -> NSTextView {
            let textView = NSTextView()
            textView.isVerticallyResizable = true
            textView.isHorizontallyResizable = false
            return textView
        }

        func textDidChange(_ notification: Notification) {
            guard let textView else { return }
            // A programmatic replacement is not a user edit; re-publishing it re-renders the
            // workspace for nothing.
            guard !isApplyingExternalText else { return }
            let updated = textView.string
            guard updated != parent.text else { return }
            parent.text = updated
            scheduleHighlight(textView)
        }

        /// `⌘↩` is the global "send" shortcut inside editors.
        func textView(_ textView: NSTextView, doCommandBy selector: Selector) -> Bool {
            let command = NSEvent.modifierFlags.contains(.command)
            if command, selector == #selector(NSTextView.insertNewline(_:)) {
                parent.onSubmit?()
                return true
            }
            return false
        }

        private func scheduleHighlight(_ textView: NSTextView) {
            pendingHighlight?.cancel()
            let item = DispatchWorkItem { [weak self, weak textView] in
                guard let self, let textView else { return }
                self.highlight(in: textView)
            }
            pendingHighlight = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.12, execute: item)
        }

        /// Above this, colouring is skipped entirely.
        ///
        /// A captured HTML page runs to a quarter of a megabyte and tens of thousands of lines.
        /// Walking every one of them on each edit pegged a core — the app's CPU report showed
        /// `makeNSView` at 89% — and a page you are trying to read does not benefit from the
        /// body being tinted. Headers and the start line are what matter, and they live at the
        /// top, so the cap keeps those.
        private static let colourBudget = 400_000

        /// Single-pass colouring: request/response start line, header names, values and body.
        func highlight(in textView: NSTextView) {
            guard let storage = textView.textStorage else { return }
            let full = storage.string as NSString
            storage.beginEditing()
            storage.setAttributes(
                [
                    .font: Theme.mono(12),
                    .foregroundColor: NSColor(hex: 0xB4B0B8),
                ],
                range: NSRange(location: 0, length: full.length)
            )

            guard full.length <= Self.colourBudget else {
                storage.endEditing()
                return
            }

            var inBody = false
            var lineStart = 0
            var index = 0
            // Walk the lines through `NSString` rather than `components(separatedBy: "\n")`,
            // which allocated an array holding every line — a second full copy of the document
            // on each keystroke.
            while lineStart < full.length {
                let lineRange = full.lineRange(for: NSRange(location: lineStart, length: 0))
                let line = full.substring(with: lineRange)
                let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
                let cleanRange = NSRange(location: lineRange.location, length: max(0, line.utf16.count))

                if !inBody && trimmed.isEmpty && lineStart > 0 {
                    inBody = true
                } else if !inBody {
                    if index == 0 {
                        colorStartLine(line, range: cleanRange, storage: storage)
                    } else if let colon = line.firstIndex(of: ":") {
                        let nameLength = line.distance(from: line.startIndex, to: colon)
                        storage.addAttribute(
                            .foregroundColor, value: NSColor(hex: Palette.methodPOST), range: NSRange(location: lineRange.location, length: nameLength)
                        )
                        let valueStart = nameLength + 1
                        if valueStart < line.utf16.count {
                            storage.addAttribute(
                                .foregroundColor,
                                value: NSColor(hex: Palette.status3xx),
                                range: NSRange(location: lineRange.location + valueStart, length: line.utf16.count - valueStart)
                            )
                        }
                    }
                } else if trimmed.hasPrefix("#") || trimmed.hasPrefix("//") {
                    storage.addAttribute(.foregroundColor, value: NSColor(hex: 0x65616B), range: cleanRange)
                }
                lineStart = NSMaxRange(lineRange)
                index += 1
                if index > 200_000 { break }
            }
            storage.endEditing()
        }

        private func colorStartLine(_ line: String, range: NSRange, storage: NSTextStorage) {
            let parts = line.split(separator: " ", maxSplits: 3, omittingEmptySubsequences: false)
            guard parts.count >= 2 else { return }
            if parts[0].uppercased().hasPrefix("HTTP/") {
                // Status line.
                storage.addAttribute(.foregroundColor, value: NSColor(hex: Palette.status3xx), range: range)
                if parts.count >= 2, let code = Int(parts[1]) {
                    storage.addAttribute(
                        .font, value: Theme.mono(12, weight: .bold),
                        range: NSRange(location: range.location + 5, length: parts[1].utf16.count)
                    )
                    storage.addAttribute(
                        .foregroundColor, value: NSColor(hex: statusHex(code)), range: range
                    )
                }
            } else {
                let method = parts[0].uppercased()
                storage.addAttribute(
                    .font, value: Theme.mono(12, weight: .bold),
                    range: NSRange(location: range.location, length: parts[0].utf16.count)
                )
                storage.addAttribute(.foregroundColor, value: NSColor(hex: methodHex(method)), range: range)
                let restStart = range.location + parts[0].utf16.count
                let restLength = max(0, line.utf16.count - parts[0].utf16.count)
                storage.addAttribute(.foregroundColor, value: NSColor(hex: 0xB4B0B8), range: NSRange(location: restStart, length: restLength))
                // Colour the protocol token at the end.
                if let last = parts.last, last.uppercased().hasPrefix("HTTP/") {
                    storage.addAttribute(
                        .foregroundColor, value: NSColor(hex: Palette.status2xx),
                        range: NSRange(location: range.location + line.utf16.count - last.utf16.count, length: last.utf16.count)
                    )
                }
            }
        }

        private func statusHex(_ code: Int) -> UInt32 { Palette.status(code) }
        private func methodHex(_ method: String) -> UInt32 { Palette.method(method) }
    }
}

// ============================================================================
//  Read-only body viewer
// ============================================================================

struct RawTextView: View {
    let text: String

    var body: some View {
        ScrollView([.vertical, .horizontal]) {
            Text(text.isEmpty ? "—" : text)
                .font(Theme.monoSwiftUI(11))
                .foregroundStyle(Theme.textSecondary)
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(8)
        }
        .background(Theme.background)
    }
}