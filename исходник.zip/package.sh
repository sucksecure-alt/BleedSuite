#!/bin/bash
#
# Builds Bleed Suite and packages it as a signed .app plus a styled .dmg.
#
#   ./package.sh            build (release), bundle, sign, make the DMG
#   ./package.sh --test     run the engine self test instead of packaging
#   ./package.sh --run      launch the packaged app
#
set -euo pipefail
cd "$(dirname "$0")"

APP_NAME="Bleed Suite"
BUNDLE_ID="ru.heartbleed.bleedsuite"
VERSION="1.0.0"
DIST="dist"
APP="$DIST/$APP_NAME.app"
DMG="$DIST/BleedSuite.dmg"

# ---------------------------------------------------------------------------
# SDK selection
#
# The Command Line Tools install ships no SwiftUIMacros plugin, which every
# `@State` in SwiftUI needs. The macOS 26.x SDK declares the macros, so prefer it.
# ---------------------------------------------------------------------------
pick_sdk() {
    for candidate in \
        "/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk" \
        "/Library/Developer/CommandLineTools/SDKs/MacOSX26.sdk" \
        "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk" \
        "$(xcrun --show-sdk-path 2>/dev/null || true)"
    do
        [ -d "$candidate" ] && { echo "$candidate"; return 0; }
    done
    echo ""
}

SDK="$(pick_sdk)"
if [ -z "$SDK" ]; then
    echo "error: no macOS SDK found" >&2
    exit 1
fi
export SDKROOT="$SDK"
echo "▸ SDK: $SDK"

# ---------------------------------------------------------------------------
# Modes
# ---------------------------------------------------------------------------
case "${1:-}" in
    --test)
        swift build -c release
        BIN="$(swift build -c release --show-bin-path)/BleedSuite"
        "$BIN" --selftest
        exit $?
        ;;
    --run)
        open "$APP"
        exit 0
        ;;
esac

# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------
echo "▸ Compiling (release)…"
swift build -c release --arch arm64 --arch x86_64 2>&1 | grep -E "error:|warning: (unused|never)" || true
BIN_PATH="$(swift build -c release --arch arm64 --arch x86_64 --show-bin-path 2>/dev/null)"
BIN="$BIN_PATH/BleedSuite"
[ -f "$BIN" ] || { echo "error: binary not found at $BIN" >&2; exit 1; }
echo "  ✓ $(lipo -archs "$BIN")"

# ---------------------------------------------------------------------------
# Bundle
# ---------------------------------------------------------------------------
echo "▸ Assembling $APP"
rm -rf "$DIST"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN" "$APP/Contents/MacOS/BleedSuite"
cp Resources/Info.plist "$APP/Contents/Info.plist"
printf 'APPL????' > "$APP/Contents/PkgInfo"

if [ -f Resources/AppIcon.icns ]; then
    cp Resources/AppIcon.icns "$APP/Contents/Resources/AppIcon.icns"
fi

# ---------------------------------------------------------------------------
# Entitlements — the proxy needs to bind a socket, spawn networksetup/security
# and write to the keychain, so the app is deliberately not sandboxed.
# ---------------------------------------------------------------------------
ENTITLEMENTS="$DIST/entitlements.plist"
cat > "$ENTITLEMENTS" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>com.apple.security.app-sandbox</key>
	<false/>
	<key>com.apple.security.network.server</key>
	<true/>
	<key>com.apple.security.network.client</key>
	<true/>
	<key>com.apple.security.cs.allow-jit</key>
	<true/>
	<key>com.apple.security.cs.disable-library-validation</key>
	<true/>
</dict>
</plist>
PLIST

echo "▸ Signing (ad-hoc)…"
codesign --force --sign - --timestamp=none --entitlements "$ENTITLEMENTS" "$APP" 2>&1 | sed 's/^/  /'
codesign --verify --deep --strict "$APP" 2>&1 | sed 's/^/  /' || true
xattr -cr "$APP" 2>/dev/null || true

# ---------------------------------------------------------------------------
# DMG
# ---------------------------------------------------------------------------
echo "▸ Building DMG"
STAGE="$DIST/dmg"
mkdir -p "$STAGE"
cp -R "$APP" "$STAGE/"
ln -s /Applications "$STAGE/Applications"

VOLUME="Bleed Suite"
rm -f "$DMG"
UDZO="/usr/bin/hdiutil"
if $UDZO create -srcfolder "$STAGE" -volname "$VOLUME" -fs HFS+ -format UDRW -ov "$DIST/tmp.dmg" >/dev/null 2>&1; then
    # Style the window: icon size, positions, background.
    MOUNT="$DIST/mnt"
    $UDZO attach "$DIST/tmp.dmg" -mountpoint "$MOUNT" -nobrowse >/dev/null
    osascript <<OSA >/dev/null 2>&1 || echo "  (finder styling skipped — automation permission unavailable)"
tell application "Finder"
    tell disk "$VOLUME"
        open
        set current view of container window to icon view
        set toolbar visible of container window to false
        set statusbar visible of container window to false
        set the bounds of container window to {200, 180, 820, 580}
        set theViewOptions to the icon view options of container window
        set arrangement of theViewOptions to not arranged
        set icon size of theViewOptions to 96
        set position of item "$APP_NAME.app" of container window to {150, 220}
        set position of item "Applications" of container window to {470, 220}
        close
        open
        update without registering applications
        delay 1
        close
    end tell
end tell
OSA
    sync
    $UDZO detach "$MOUNT" >/dev/null
    $UDZO convert "$DIST/tmp.dmg" -format UDZO -imagekey zlib-level=9 -o "$DMG" >/dev/null
    rm -f "$DIST/tmp.dmg"
else
    $UDZO create -srcfolder "$STAGE" -volname "$VOLUME" -fs HFS+ -format UDZO -ov "$DMG" >/dev/null
fi

rm -rf "$STAGE"

SIZE=$(du -h "$DMG" | cut -f1)
echo ""
echo "────────────────────────────────────────────"
echo "  $APP_NAME $VERSION"
echo "  app : $APP"
echo "  dmg : $DMG  ($SIZE)"
echo "────────────────────────────────────────────"
echo ""
echo "  open the DMG, drag to Applications, launch."
echo "  first run installs and trusts the Root CA automatically."
echo ""