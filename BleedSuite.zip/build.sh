#!/bin/bash
#
# Build Bleed Suite.
#
#   ./build.sh                   debug build
#   CONFIG=release ./build.sh    release build
#   VERBOSE=1 ./build.sh         show warnings as well as errors
#
# The Command Line Tools install ships no SwiftUIMacros plugin, which every
# `@State` in SwiftUI needs. The macOS 26.x SDK declares the macros, so prefer it
# when one is present; fall back to whatever `xcrun` reports.
#
set -uo pipefail

cd "$(dirname "$0")" || exit 1

pick_sdk() {
    local candidate
    for candidate in \
        "/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk" \
        "/Library/Developer/CommandLineTools/SDKs/MacOSX26.sdk" \
        "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk" \
        "$(xcrun --show-sdk-path 2>/dev/null || true)"
    do
        if [ -n "$candidate" ] && [ -d "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done
    return 1
}

if ! SDK="$(pick_sdk)"; then
    echo "error: no macOS SDK found" >&2
    exit 1
fi
export SDKROOT="$SDK"

# Diagnostics are colourised; strip the escapes before filtering.
strip_colour() { sed -e 's/\x1b\[[0-9;]*m//g'; }

# Print only the real diagnostics, not the source-snippet context lines.
filter() {
    if [ "${VERBOSE:-0}" = "1" ]; then
        grep -E "error:|warning:"
    else
        grep -E "error:"
    fi | grep -vE '^ +[0-9]+ \||^ +\||^ +`-|^ +\.\.\.'
}

case "${CONFIG:-debug}" in
    release) swift build -c release 2>&1 | strip_colour | filter ;;
    *)       swift build            2>&1 | strip_colour | filter ;;
esac

status=${PIPESTATUS[0]}
if [ "$status" -ne 0 ]; then
    echo "build failed (exit $status)" >&2
fi
exit "$status"