import Foundation
import Network

// ============================================================================
//  Self test
//
//  `./BleedSuite --selftest` runs the whole suite without launching the UI, so the
//  engine can be verified on a build machine and in CI.
// ============================================================================

enum SelfTest {

    /// Unbuffered output so a hung run still shows how far it got.
    private static func say(_ text: String) {
        FileHandle.standardOutput.write(Data((text + "\n").utf8))
    }

    private(set) static var failures: [String] = []
    private(set) static var checks = 0

    static func run() async -> Int32 {
        failures.removeAll()
        checks = 0

        say("\nBleed Suite self test")
        say(String(repeating: "─", count: 62))

        wireFormat()
        messageModel()
        storage()
        rules()
        scopeAndTargets()
        export()
        certificates()
        await scannerAndSpider()
        intruderAndSequencer()
        editors()
        await repeater()
        await liveProxy()
        await interception()

        say(String(repeating: "─", count: 62))
        if failures.isEmpty {
            say("PASS  — \(checks) checks\n")
            return 0
        }
        say("FAIL  — \(failures.count) of \(checks) checks failed:\n")
        for failure in failures { say("  ✗ \(failure)") }
        say("")
        return 1
    }

    // MARK: - Assertions

    /// Progress marker — printed before each group so a hang is always locatable.
    private static func step(_ label: String) {
        FileHandle.standardError.write(Data("    · \(label)\n".utf8))
    }

    private static func check(_ condition: Bool, _ label: String) {
        checks += 1
        if !condition {
            failures.append(label)
            say("  ✗ \(label)")
        }
    }

    private static func equal<T: Equatable>(_ actual: T, _ expected: T, _ label: String) {
        check(actual == expected, "\(label) — expected \(expected), got \(actual)")
    }

    /// The history index is rebuilt on a background queue; give it a moment.
    /// The history index is rebuilt on a background queue; wait until it settles.
    private static func settle(_ store: HistoryStore, milliseconds: Int = 3000) {
        var previous = -1
        var stable = 0
        let deadline = Date().addingTimeInterval(Double(milliseconds) / 1000)
        while Date() < deadline, stable < 5 {
            usleep(20_000)
            let current = store.visibleCount
            if current == previous { stable += 1 } else { stable = 0 }
            previous = current
        }
    }

    private static func section(_ name: String) {
        say("\n▸ \(name)")
    }

    // MARK: - Suites

    private static func wireFormat() {
        section("HTTP/1.1 wire format")

        let simple = Data("GET /api/v1/users?id=42 HTTP/1.1\r\nHost: example.com\r\nAccept: */*\r\n\r\n".utf8)
        let framed = HTTPParser.frame(simple)
        check(framed != nil, "simple request frames")
        equal(framed?.message.method, "GET", "method")
        equal(framed?.message.path, "/api/v1/users?id=42", "path with query")
        equal(framed?.message.header("host"), "example.com", "case-insensitive header lookup")
        equal(framed?.length, simple.count, "consumed exactly the message")

        let chunked = Data("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n5\r\nhello\r\n6\r\n world\r\n0\r\nX-Sum: 11\r\n\r\n".utf8)
        let parsedChunked = HTTPParser.parse(chunked, isRequest: false)
        equal(parsedChunked?.0.body, Data("hello world".utf8), "chunked body with trailer")
        equal(parsedChunked?.1, chunked.count, "chunked consumed length")

        let partial = Data("POST /x HTTP/1.1\r\nHost: h\r\nContent-Length: 10\r\n\r\nabc".utf8)
        check(HTTPParser.frame(partial) == nil, "incomplete body is not framed")

        let noContent = Data("HTTP/1.1 204 No Content\r\n\r\n".utf8)
        equal(HTTPParser.parse(noContent, isRequest: false)?.0.body, Data(), "204 carries no body")

        var pipeline = Data()
        pipeline.append(Data("GET /a HTTP/1.1\r\nHost: h\r\n\r\nGET /b HTTP/1.1\r\nHost: h\r\n\r\n".utf8))
        let first = HTTPParser.frame(pipeline)
        pipeline.consume(first!.length)
        equal(HTTPParser.frame(pipeline)?.message.path, "/b", "pipelined second message")

        let connect = Data("CONNECT example.com:443 HTTP/1.1\r\nHost: example.com:443\r\n\r\n".utf8)
        check(HTTPParser.frame(connect)?.isConnect == true, "CONNECT is detected")
        equal(HTTPParser.frame(connect)?.connectPort, 443, "CONNECT port")

        equal(HTTPParser.splitAuthority("a.com:8443").port, 8443, "authority with port")
        equal(HTTPParser.splitAuthority("a.com").port, nil, "authority without port")
        equal(HTTPParser.splitAuthority("[::1]:9000").host, "::1", "IPv6 literal host")
        equal(HTTPParser.splitAuthority("[::1]:9000").port, 9000, "IPv6 literal port")

        var absolute = HTTPMessage(isRequest: true, startLine: "GET http://example.com/a/b?c=1 HTTP/1.1",
                                   headers: [Header(name: "Host", value: "old")])
        HTTPParser.normalizeTarget(&absolute)
        equal(absolute.path, "/a/b?c=1", "absolute-form normalised to origin-form")
        equal(absolute.header("Host"), "example.com", "Host rewritten from the URL")

        var hopByHop = HTTPMessage(isRequest: true, startLine: "GET / HTTP/1.1", headers: [
            Header(name: "Host", value: "h"),
            Header(name: "Connection", value: "X-Custom, close"),
            Header(name: "X-Custom", value: "keep"),
            Header(name: "Proxy-Connection", value: "keep-alive"),
        ])
        HTTPParser.stripHopByHop(&hopByHop)
        check(hopByHop.header("X-Custom") == nil, "connection-token header stripped")
        check(hopByHop.header("Proxy-Connection") == nil, "proxy-connection stripped")
        equal(hopByHop.header("Connection"), "close", "connection reset for the upstream hop")

        check(HTTPParser.responseIsComplete(
            Data("HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello".utf8), method: "GET"),
              "complete Content-Length response detected")
        check(!HTTPParser.responseIsComplete(
            Data("HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhe".utf8), method: "GET"),
              "partial response is not complete")
        check(HTTPParser.responseIsComplete(
            Data("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\n".utf8), method: "GET"),
              "terminated chunked response detected")
        check(HTTPParser.responseIsComplete(
            Data("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\n\r\n".utf8), method: "GET"),
              "101 upgrade completes immediately")
    }

    private static func messageModel() {
        section("Message model")

        let payload = Data((0...255).map { UInt8($0) })
        var binary = HTTPMessage(isRequest: true, startLine: "POST /b HTTP/1.1",
                                 headers: [Header(name: "Host", value: "h")], body: payload)
        binary.normalizeFraming()
        equal(HTTPParser.frame(binary.rawBytes)?.message.body, payload,
              "binary body survives the wire round trip")

        let original = HTTPMessage(isRequest: true, startLine: "POST /submit HTTP/1.1", headers: [
            Header(name: "Host", value: "example.com"),
            Header(name: "Content-Type", value: "application/json"),
        ], body: Data(#"{"a":1}"#.utf8))
        let restored = HTTPMessage.parseEditorText(original.prettyRaw, isRequest: true)
        equal(restored.method, "POST", "editor round trip keeps the method")
        equal(restored.header("Content-Type"), "application/json", "editor round trip keeps headers")
        equal(restored.body, original.body, "editor round trip keeps the body")

        let chunkedMessage = HTTPMessage(isRequest: false, startLine: "HTTP/1.1 200 OK", headers: [
            Header(name: "Transfer-Encoding", value: "chunked"),
        ], body: Data("payload".utf8))
        equal(HTTPParser.parse(chunkedMessage.rawBytes, isRequest: false)?.0.body, Data("payload".utf8),
              "chunked body is re-chunked on serialisation")

        var framedBody = HTTPMessage(isRequest: false, startLine: "HTTP/1.1 200 OK", headers: [], body: Data("abcd".utf8))
        framedBody.setHeader("Content-Length", "1")
        framedBody.normalizeFraming()
        equal(framedBody.header("Content-Length"), "4", "normalizeFraming recomputes Content-Length")
        check(framedBody.header("Transfer-Encoding") == nil, "normalizeFraming drops Transfer-Encoding")

        var withParams = HTTPMessage(isRequest: true, startLine: "GET /s?a=1&b=2 HTTP/1.1")
        equal(withParams.queryParams.map(\.name), ["a", "b"], "query parameters parsed")
        withParams.setQueryParams([Param(name: "a", value: "9", enabled: true), Param(name: "b", value: "2", enabled: false)])
        equal(withParams.path, "/s?a=9", "disabled parameters are dropped on rebuild")

        let params = HTTPMessage(isRequest: false, startLine: "HTTP/1.1 500 Internal Server Error")
        equal(params.statusClass, .serverError, "status class 5xx")
        equal(StatusClass(status: 302).label, "REDR", "status class label")
    }

    private static func storage() {
        section("Storage")

        let store = HistoryStore()
        let rows = (1...200).map {
            SelfTest.pair(id: $0,
                          path: $0 % 3 == 0 ? "/admin" : "/public",
                          status: $0 % 2 == 0 ? 200 : 500)
        }
        store.add(contentsOf: rows)
        equal(store.totalCount, 200, "history accepts rows")
        equal(store.row(at: 0)?.id, 1, "row lookup by index")
        check(store.pair(withID: 150) != nil, "lookup by id")

        // 66 of the 200 rows sit under /admin; 100 of them answer 500.
        var textFilter = HistoryStore.Filter()
        textFilter.text = "admin"
        store.applyFilter(textFilter)
        settle(store)
        equal(store.visibleCount, 66, "text filter narrows the index")

        var hostFilter = HistoryStore.Filter()
        hostFilter.host = "example.com"
        store.applyFilter(hostFilter)
        settle(store)
        equal(store.visibleCount, 200, "host filter keeps matching hosts")

        var statusFilter = HistoryStore.Filter()
        statusFilter.statusClasses = [.serverError]
        store.applyFilter(statusFilter)
        settle(store)
        equal(store.visibleCount, 100, "status-class filter")

        var combined = HistoryStore.Filter()
        combined.text = "admin"
        combined.statusClasses = [.success]
        store.applyFilter(combined)
        settle(store)
        equal(store.visibleCount, 33, "filters combine with AND")

        store.applyFilter(HistoryStore.Filter())
        settle(store)
        equal(store.visibleCount, 200, "empty filter restores every row")

        let bodyStore = BodyStore.shared
        let payload = Data(repeating: 0x41, count: 8192)
        bodyStore.saveBody(id: 900_001, side: .response, data: payload)
        check(bodyStore.hasBody(id: 900_001, side: .response), "body spilled to SQLite")
        equal(bodyStore.loadBody(id: 900_001, side: .response), payload, "body reads back byte-identical")
        bodyStore.deleteBody(id: 900_001, side: .response)
        check(bodyStore.loadBody(id: 900_001, side: .response) == nil, "body deleted")
    }

    private static func rules() {
        section("Match & Replace")

        let engine = RulesEngine(rules: [])

        var headerRule = ProxyRule()
        headerRule.direction = .request
        headerRule.target = .header
        headerRule.matchType = .regex
        headerRule.pattern = "User-Agent: .*"
        headerRule.replacement = "User-Agent: BleedSuite"
        engine.replaceAll([headerRule])

        var message = HTTPMessage(isRequest: true, startLine: "GET / HTTP/1.1", headers: [
            Header(name: "User-Agent", value: "curl/8.0"),
            Header(name: "Host", value: "h"),
        ])
        var edit = engine.applyToRequest(message, pair: nil)
        equal(edit.applied, 1, "header rule fired once")
        equal(edit.message.header("User-Agent"), "BleedSuite", "header rule rewrote the value")

        var groupRule = ProxyRule()
        groupRule.direction = .request
        groupRule.target = .path
        groupRule.matchType = .regex
        groupRule.pattern = "/users/(\\d+)"
        groupRule.replacement = "/accounts/$1"
        engine.replaceAll([groupRule])

        var grouped = HTTPMessage(isRequest: true, startLine: "GET /users/42 HTTP/1.1", headers: [Header(name: "Host", value: "h")])
        edit = engine.applyToRequest(grouped, pair: nil)
        equal(edit.applied, 1, "capture-group rule fired")
        equal(edit.message.path, "/accounts/42", "capture group substituted")

        var disabled = groupRule
        disabled.enabled = false
        engine.replaceAll([disabled])
        equal(engine.applyToRequest(grouped, pair: nil).applied, 0, "disabled rules do not fire")

        var badRegex = ProxyRule()
        badRegex.target = .path
        badRegex.matchType = .regex
        badRegex.pattern = "([unclosed"
        badRegex.replacement = "/x"
        engine.replaceAll([badRegex])
        let brokenEdit = engine.applyToRequest(grouped, pair: nil)
        check(brokenEdit.error != nil, "invalid regex is reported instead of crashing")

        engine.replaceAll([headerRule])
        check(!engine.exportJSON().isEmpty, "rules export to JSON")
        let roundTripped = Exporter.rulesFromJSON(engine.exportJSON())
        equal(roundTripped.count, 1, "rules round trip through JSON")
        equal(roundTripped.first?.pattern, headerRule.pattern, "rule pattern preserved")
    }

    private static func scopeAndTargets() {
        section("Scope & site map")

        var scope = ScopeFilter()
        check(scope.isInScope(host: "anything.dev", isSecure: false), "empty scope includes everything")
        scope.includedHosts = ["*.example.com", "api.test"]
        check(scope.isInScope(host: "a.example.com", isSecure: true), "wildcard include matches")
        check(!scope.isInScope(host: "example.org", isSecure: true), "unrelated host excluded")
        scope.excludedHosts = ["a.example.com"]
        check(!scope.isInScope(host: "a.example.com", isSecure: true), "exclude beats include")

        let pairs = [
            SelfTest.pair(id: 1, path: "/api/v1/users"),
            SelfTest.pair(id: 2, path: "/api/v1/orders"),
            SelfTest.pair(id: 3, path: "/health"),
        ]
        let tree = TargetTreeBuilder.build(from: pairs)
        equal(tree.count, 1, "one scheme/host root")
        equal(tree[0].name, "https://example.com:443", "root node label")
        let names = tree[0].children.map(\.name)
        check(names.contains("api"), "nested folder created")
        check(tree[0].pairs.map { $0.request.path }.contains("/health"),
              "single-segment path lands directly on the host node")
    }

    private static func export() {
        section("Export & import")

        let pairs = [SelfTest.pair(id: 1, body: "hello")]
        let har = Exporter.har(pairs: pairs)
        check((try? JSONSerialization.jsonObject(with: Data(har.utf8)) as? [String: Any])??["log"] != nil,
              "HAR is a valid log document")
        let restored = Importer.parseHAR(har)
        equal(restored.count, 1, "HAR imports one entry")
        equal(restored.first?.request.method, "GET", "HAR import restores the method")
        equal(restored.first?.response?.body, Data("hello".utf8), "HAR import restores the body")

        let csv = Exporter.csv(pairs: [SelfTest.pair(id: 1, path: "/a,b\"c")])
        check(csv.contains("\"\"") || csv.contains("\"/a,b"), "CSV quotes and escapes the path")

        let sitemap = Exporter.sitemapXML(nodes: TargetTreeBuilder.build(from: pairs))
        check((try? XMLDocument(xmlString: sitemap, options: [])) != nil, "sitemap XML is well formed")
        check(sitemap.contains("https://example.com:443"), "sitemap contains the origin")

        let issues = [SelfTest.issue(host: "x.test")]
        let issuesXML = Exporter.scanIssuesXML(issues: issues)
        check((try? XMLDocument(xmlString: issuesXML, options: [])) != nil, "issues XML is well formed")

        let project = Exporter.projectJSON(pairs: pairs, extra: ["port": "8080"])
        check(project.contains("\"version\""), "project JSON carries a version")
        check(project.contains("port"), "project JSON keeps metadata")
    }

    private static func certificates() {
        section("Certificate authority")

        let ca = CertificateAuthority.shared
        check(!ca.caCertificateDER.isEmpty, "root CA material present")
        check(ca.caCertificatePEM.contains("BEGIN CERTIFICATE"), "root CA exports as PEM")
        check(ca.fingerprintSHA256.contains(":"), "fingerprint is colon separated")

        do {
            let identity = try ca.identity(for: "example.com")
            check(identity != nil, "leaf identity minted for example.com")
            let cached = try ca.identity(for: "example.com")
            check(cached === identity, "leaf identity is cached")
            let ipv4 = try ca.identity(for: "127.0.0.1")
            check(ipv4 != nil, "leaf identity minted for an IP literal")
        } catch {
            failures.append("leaf identity minting failed: \(error.localizedDescription)")
            say("  ✗ leaf identity minting failed: \(error.localizedDescription)")
        }
    }

    private static func scannerAndSpider() async {
        section("Scanner & spider")

        let request = HTTPMessage(isRequest: true,
                                  startLine: "GET /login?token=abcdefghijklmnopqrstuvwx HTTP/1.1",
                                  headers: [Header(name: "Host", value: "shop.test")])
        let response = HTTPMessage(isRequest: false, startLine: "HTTP/1.1 200 OK", headers: [
            Header(name: "Server", value: "nginx/1.18.0"),
            Header(name: "Set-Cookie", value: "sid=1; Path=/"),
        ], body: Data("<html><!-- TODO: remove debug --></html>".utf8))
        let target = HTTPPair(id: 950_001, time: Date(), durationMS: 7, host: "shop.test", port: 80,
                              isSecure: false, request: request, response: response)

        Scanner.shared.clear()
        await Scanner.shared.scanNow(pair: target)
        let issues = Scanner.shared.issues()
        check(issues.contains { $0.name.lowercased().contains("cookie") }, "passive check flags insecure cookies")
        check(issues.contains { $0.name.lowercased().contains("security header") }, "passive check flags missing security headers")
        check(issues.contains { $0.name.lowercased().contains("version") }, "passive check flags version disclosure")
        check(issues.contains { $0.name.lowercased().contains("debug") }, "passive check flags debug leftovers")
        check(issues.contains { $0.detail.lowercased().contains("token") || $0.evidence.lowercased().contains("abcdefghijklmnopqrstuvwx") },
              "passive check flags tokens in the URL")
        Scanner.shared.clear()

        let html = #"<html><body><a href="/a">A</a><a href="https://cdn.test/b">B</a><script>fetch("/c")</script></body></html>"#
        let page = HTTPMessage(isRequest: false, startLine: "HTTP/1.1 200 OK",
                               headers: [Header(name: "Content-Type", value: "text/html")],
                               body: Data(html.utf8))
        let links = await Spider.shared.extractLinks(from: page, base: URL(string: "https://site.test/start")!)
        let paths = Set(links.compactMap { $0.path })
        check(paths.contains("/a"), "spider extracts an HTML link")
        check(paths.contains("/b"), "spider resolves an absolute link")
        check(paths.contains("/c"), "spider extracts a JavaScript endpoint")
    }

    private static func intruderAndSequencer() {
        section("Intruder & sequencer")

        let message = HTTPMessage(isRequest: true, startLine: "GET /api/v1/users?id=42&name=admin HTTP/1.1", headers: [
            Header(name: "Host", value: "h"),
        ])
        let positions = PositionExtractor.positions(in: message)
        check(!positions.isEmpty, "payload positions discovered")
        check(positions.contains { $0.kind.label.lowercased().contains("query") }, "query positions discovered")

        let template = PositionExtractor.previewText(for: message)
        let replaced = PositionExtractor.applyReplacements(template, positions: positions, values: ["777"])
        check(replaced.contains("777"), "payload value substituted into the template")

        let numbers = SequencerEngine.generate(SequencerConfig(type: .numbers, startValue: 1, endValue: 5, step: 1))
        equal(numbers, ["1", "2", "3", "4", "5"], "sequencer generates ascending numbers")
        let counter = SequencerEngine.generate(SequencerConfig(type: .counter, startValue: 1, endValue: 3, step: 1), count: 3)
        equal(counter, ["000001", "000002", "000003"], "sequencer counter is zero padded")
        equal(SequencerEngine.generate(SequencerConfig(type: .numbers, startValue: 9, endValue: 1, step: 1)), [],
              "sequencer respects direction")

        check(!Wordlists.builtIn("sqli").isEmpty, "built-in SQLi wordlist present")
        check(!Wordlists.builtIn("xss").isEmpty, "built-in XSS wordlist present")
    }

    /// The raw-editor plumbing that made "I cannot edit or send" happen: parsing
    /// editor text, and the header/param grids that edit the same message.
    private static func editors() {
        section("Editors")

        var original = HTTPMessage(isRequest: true, startLine: "POST /x HTTP/1.1", headers: [
            Header(name: "Host", value: "example.com"),
            Header(name: "Content-Type", value: "application/json"),
        ], body: Data(#"{"a":1}"#.utf8))
        original.normalizeFraming()

        // Typing into the raw editor and committing must reach the message.
        let typed = "POST /edited HTTP/1.1\nHost: example.com\nContent-Type: application/json\n\n{\"b\":2}"
        var edited = HTTPMessage.parseEditorText(typed, isRequest: true)
        check(edited.path == "/edited", "raw edit changes the path")
        check(edited.body == Data(#"{"b":2}"#.utf8), "raw edit changes the body")
        check(edited.header("Host") == "example.com", "raw edit keeps headers")

        // Re-serialising what the editor produced must parse back identically.
        let reparsed = HTTPParser.parse(edited.rawBytes, isRequest: true)
        check(reparsed?.0.path == "/edited", "edited request survives serialisation")
        check(reparsed?.0.body == Data(#"{"b":2}"#.utf8), "edited body survives serialisation")

        // obs-fold continuation lines must be joined, not treated as new fields.
        let folded = HTTPMessage.parseEditorText(
            "GET /f HTTP/1.1\nHost: h\nX-Long: a\n  b\n\n", isRequest: true)
        check(folded.header("X-Long") == "a b", "obs-fold headers are joined")

        // Header grid toggles a field off, which strips it from the wire.
        var grid = original
        var rows = HeaderBlock.rows(from: grid)
        if let idx = rows.firstIndex(where: { $0.name == "Host" }) { rows[idx].enabled = false }
        HeaderBlock.apply(rows, to: &grid)
        check(grid.header("Host") == nil, "disabled header row is stripped")
        check(HTTPParser.parse(grid.rawBytes, isRequest: true)?.0.header("Host") == nil,
              "stripped header is absent on the wire")

        // Parameter grid rebuilds the query string.
        var query = HTTPMessage(isRequest: true, startLine: "GET /s?a=1&b=2 HTTP/1.1")
        query.setQueryParams([Param(name: "a", value: "9"), Param(name: "b", value: "2", enabled: false)])
        check(query.path == "/s?a=9", "parameter grid rebuilds the query string")

        // Pretty rendering must never corrupt a binary body.
        let binary = Data((0...255).map { UInt8($0) })
        check(binary.isEmpty == false && !HexDump.pretty(binary).isEmpty, "binary body renders as hex")
    }

    /// Repeater round trip against a real origin, plus the tab/selection plumbing
    /// that broke repeatedly: host derivation and body preservation.
    private static func repeater() async {
        section("Repeater")

        let originPort = UInt16(SelfTest.freePort())
        let origin = LocalOriginServer(port: originPort)
        origin.start()
        defer { origin.stop() }
        try? await Task.sleep(nanoseconds: 300_000_000)

        var pair = HTTPPair(
            id: 960_001, time: Date(), durationMS: 4, host: "127.0.0.1", port: Int(originPort),
            isSecure: false,
            request: HTTPMessage(isRequest: true, startLine: "POST /echo HTTP/1.1", headers: [
                Header(name: "Host", value: "127.0.0.1:\(originPort)"),
                Header(name: "Content-Type", value: "application/json"),
            ], body: Data(#"{"ping":1}"#.utf8)),
            response: nil
        )
        pair.request.normalizeFraming()

        @MainActor func roundTrip() async {
            let store = RepeaterStore.shared
            store.tabs = [RepeaterTab.blank()]
            store.selectedID = store.tabs.first?.id
            store.newTab(from: pair)
            guard let id = store.selectedID else {
                check(false, "repeater tab created")
                return
            }
            let tab = store.tabs.first(where: { $0.id == id })
            check(tab != nil, "repeater tab created")
            check(tab?.request.body == pair.request.body,
                  "repeater preserved the request body (got \(tab?.request.body.count ?? -1) bytes)")
            check(tab?.host == "127.0.0.1", "repeater kept the host")

            await store.send(id)
            let after = store.tabs.first(where: { $0.id == id })
            check(after?.error == nil, "repeater send succeeded (\(after?.error ?? "no error"))")
            check(after?.statusCode == 200, "repeater got a 200 (got \(String(describing: after?.statusCode)))")
            check(after?.response?.body == Data("origin-hello".utf8), "repeater body relayed")
            check(after?.isModified == false, "isModified cleared after a successful send")
        }
        await roundTrip()

        // Host/port/scheme derivation from the raw text.
        let absolute = HTTPMessage(isRequest: true,
                                   startLine: "GET https://example.com/a?b=1 HTTP/1.1",
                                   headers: [Header(name: "Host", value: "example.com")])
        let derived = await MainActor.run { () -> (String?, Bool?) in
            let store = RepeaterStore.shared
            var tab = RepeaterTab.blank()
            tab.request = absolute
            store.addTab(tab)
            store.syncFromEditor(tab.id)
            let host = store.tabs.first(where: { $0.id == tab.id })?.host
            let secure = store.tabs.first(where: { $0.id == tab.id })?.isSecure
            store.close(tab.id)
            return (host, secure)
        }
        check(derived.0 == "example.com", "absolute URL sets the host (got \(derived.0 ?? "nil"))")
        check(derived.1 == true, "https absolute URL selects HTTPS (got \(derived.1))")
    }

    /// Interception hold/edit/release through the real queue.
    private static func interception() async {
        section("Interception")

        await InterceptQueue.shared.setEnabled(true)
        let original = HTTPMessage(isRequest: true, startLine: "GET /held HTTP/1.1",
                                   headers: [Header(name: "Host", value: "h")])

        async let decision = InterceptQueue.shared.hold(
            direction: .request, transactionID: 1, host: "h", summary: "GET /held", message: original
        )
        // Give the queue a moment to register the item, then resolve it edited.
        try? await Task.sleep(nanoseconds: 250_000_000)
        let snapshot = await InterceptQueue.shared.snapshot()
        check(snapshot.count == 1, "held item appears in the queue")
        check(snapshot.first?.direction == .request, "held item keeps its direction")

        if let item = snapshot.first {
            var edited = item.message
            edited.startLine = "GET /edited HTTP/1.1"
            await InterceptQueue.shared.update(item.id, message: edited, modified: true)
            await InterceptQueue.shared.forward(item.id, edited: edited)
        }
        let result = await decision
        if case .edited(let message) = result {
            check(message.path == "/edited", "edited request was released")
        } else {
            check(false, "edited request was released")
        }
        let empty = await InterceptQueue.shared.snapshot()
        check(empty.isEmpty, "queue drained after release")

        // Turning interception off must release anything still held.
        async let dropped = InterceptQueue.shared.hold(
            direction: .response, transactionID: 2, host: "h", summary: "200 OK", message: original
        )
        try? await Task.sleep(nanoseconds: 200_000_000)
        await InterceptQueue.shared.setEnabled(false)
        let droppedResult = await dropped
        if case .drop = droppedResult {} else {
            check(false, "disabling interception releases held items")
        }
        await InterceptQueue.shared.setEnabled(false)
    }

    // MARK: - Live proxy

    /// Boots the real listener on an ephemeral port and drives a real HTTP exchange
    /// through it with a raw socket client.
    private static func liveProxy() async {
        section("Live proxy")

        let port = UInt16(SelfTest.freePort())
        let engine = ProxyEngine(configuration: ProxyConfiguration(port: port), relay: EventRelay(), gate: InterceptQueue())
        do {
            try await engine.start()
        } catch {
            failures.append("listener failed to start: \(error.localizedDescription)")
            say("  ✗ listener failed to start: \(error.localizedDescription)")
            return
        }
        defer { Task { await engine.stop() } }

        // Give the listener a moment to bind.
        try? await Task.sleep(nanoseconds: 300_000_000)

        // Start a tiny origin server for the proxy to forward to.
        let originPort = UInt16(SelfTest.freePort())
        let origin = LocalOriginServer(port: originPort)
        origin.start()
        defer { origin.stop() }
        try? await Task.sleep(nanoseconds: 200_000_000)

        // 0. Sanity: is the origin reachable at all?
        let direct = await SelfTest.sendThroughProxy(
            port: originPort,
            raw: "GET /direct HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n"
        )
        check(direct.contains("200 OK"), "origin server reachable directly")
        if !direct.contains("200 OK") { step("direct probe returned: \(direct.prefix(120))") }

        // 1. Plain HTTP through the proxy.
        let plainResponse = await SelfTest.sendThroughProxy(
            port: port,
            raw: "GET /hello?q=1 HTTP/1.1\r\nHost: 127.0.0.1:\(originPort)\r\nConnection: close\r\n\r\n"
        )
        check(plainResponse.contains("200 OK"), "plain HTTP exchange completed")
        check(plainResponse.contains("origin-hello"), "origin body relayed back")

        // 2. The exchange must be recorded in the history with both halves.
        HistoryStore.shared.clear()
        await SelfTest.sendThroughProxy(
            port: port,
            raw: "GET /recorded HTTP/1.1\r\nHost: 127.0.0.1:\(originPort)\r\nConnection: close\r\n\r\n"
        )
        try? await Task.sleep(nanoseconds: 400_000_000)
        check(HistoryStore.shared.totalCount >= 1, "exchange recorded in the history")
        let recorded = HistoryStore.shared.exportSnapshot()
        equal(recorded.first?.request.path, "/recorded", "history keeps the request path")
        equal(recorded.first?.status, 200, "history keeps the status")
        check(recorded.first?.response?.body == Data("origin-hello".utf8), "history keeps the response body")

        // 3. Match & Replace must rewrite traffic on the wire.
        let rewriteEngine = RulesEngine(rules: [])
        var rule = ProxyRule()
        rule.direction = .request
        rule.target = .header
        rule.matchType = .regex
        rule.pattern = "User-Agent: .*"
        rule.replacement = "User-Agent: Selftest"
        rewriteEngine.replaceAll([rule])
        RulesEngine.shared.replaceAll([rule])

        await SelfTest.sendThroughProxy(
            port: port,
            raw: "GET /rewritten HTTP/1.1\r\nHost: 127.0.0.1:\(originPort)\r\nUser-Agent: original\r\nConnection: close\r\n\r\n"
        )
        try? await Task.sleep(nanoseconds: 300_000_000)
        let seen = origin.lastUserAgent
        equal(seen, "Selftest", "rule rewrite reached the origin")

        RulesEngine.shared.removeAll()

        // 4. Keep-alive: two requests on one connection.
        let origin2 = LocalOriginServer(port: UInt16(SelfTest.freePort()))
        origin2.start()
        defer { origin2.stop() }
        try? await Task.sleep(nanoseconds: 200_000_000)

        let baseline = origin2.acceptedConnections
        let keepAliveResponses = await SelfTest.sendPipelined(
            proxyPort: port,
            originPort: origin2.port,
            count: 2
        )
        equal(keepAliveResponses, 2, "both keep-alive requests answered")
        equal(origin2.acceptedConnections - baseline, 1,
              "two pipelined requests reused a single upstream connection")
    }

    // MARK: - Live helpers

    private static func sendThroughProxy(port: UInt16, raw: String) async -> String {
        let connection = NWConnection(host: "127.0.0.1", port: NWEndpoint.Port(rawValue: port)!, using: .tcp)
        let box = ResponseBox()
        connection.stateUpdateHandler = { state in
            if case .ready = state { box.resumeReady() }
        }
        connection.start(queue: DispatchQueue(label: "selftest.client"))
        await box.waitReady()
        connection.send(content: Data(raw.utf8), completion: .contentProcessed { _ in })

        var collected = Data()
        let deadline = Date().addingTimeInterval(10)
        while Date() < deadline {
            if let chunk = try? await SelfTest.receive(connection: connection, timeout: 2), !chunk.isEmpty {
                collected.append(chunk)
                if SelfTest.isComplete(collected) { break }
            }
        }
        connection.cancel()
        return String(decoding: collected, as: UTF8.self)
    }

    private static func sendPipelined(proxyPort: UInt16, originPort: UInt16, count: Int) async -> Int {
        let connection = NWConnection(host: "127.0.0.1", port: NWEndpoint.Port(rawValue: proxyPort)!, using: .tcp)
        let box = ResponseBox()
        connection.stateUpdateHandler = { state in
            if case .ready = state { box.resumeReady() }
        }
        connection.start(queue: DispatchQueue(label: "selftest.keepalive"))
        await box.waitReady()

        var request = ""
        for index in 0..<count {
            request += "GET /keep\(index) HTTP/1.1\r\nHost: 127.0.0.1:\(originPort)\r\n\r\n"
        }
        connection.send(content: Data(request.utf8), completion: .contentProcessed { _ in })

        var collected = Data()
        let deadline = Date().addingTimeInterval(10)
        while Date() < deadline {
            guard let chunk = try? await SelfTest.receive(connection: connection, timeout: 2), !chunk.isEmpty else { break }
            collected.append(chunk)
            let text = String(decoding: collected, as: UTF8.self)
            let seen = text.components(separatedBy: "HTTP/1.1 200").count - 1
            if seen >= count { break }
        }
        connection.cancel()
        return String(decoding: collected, as: UTF8.self).components(separatedBy: "HTTP/1.1 200").count - 1
    }

    private static func receive(connection: NWConnection, timeout: TimeInterval) async throws -> Data? {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Data?, Error>) in
            let gate = OneShot()
            let work = DispatchWorkItem { gate.runOnce { cont.resume(returning: nil) } }
            DispatchQueue.global().asyncAfter(deadline: .now() + timeout, execute: work)
            connection.receive(minimumIncompleteLength: 1, maximumLength: 65536) { data, _, _, _ in
                gate.runOnce { cont.resume(returning: data) }
            }
        }
    }

    private static func isComplete(_ data: Data) -> Bool {
        guard let head = HTTPParser.headEnd(in: data) else { return false }
        let headText = String(decoding: data[0..<head], as: UTF8.self).lowercased()
        if headText.contains("connection: close") { return true }
        return HTTPParser.responseIsComplete(data, method: "GET")
    }

    private static func freePort() -> Int {
        let socket = socket(AF_INET, SOCK_STREAM, 0)
        var address = sockaddr_in()
        address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        address.sin_family = sa_family_t(AF_INET)
        address.sin_port = 0
        address.sin_addr.s_addr = INADDR_ANY.bigEndian
        var port = 0
        var length = socklen_t(MemoryLayout<sockaddr_in>.size)
        withUnsafeMutablePointer(to: &address) { pointer in
            pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) { sockaddrPointer in
                if bind(socket, sockaddrPointer, length) == 0 {
                    var assigned = sockaddr_in()
                    var length2 = socklen_t(MemoryLayout<sockaddr_in>.size)
                    withUnsafeMutablePointer(to: &assigned) { assignedPointer in
                        assignedPointer.withMemoryRebound(to: sockaddr.self, capacity: 1) { rebound in
                            _ = getsockname(socket, rebound, &length2)
                        }
                    }
                    port = Int(UInt16(bigEndian: assigned.sin_port))
                }
            }
        }
        close(socket)
        return port > 0 ? port : 18080
    }

    // MARK: - Fixtures

    static func pair(
        id: Int,
        method: String = "GET",
        host: String = "example.com",
        path: String = "/",
        status: Int = 200,
        body: String = "ok",
        origin: HTTPPair.Origin = .proxy
    ) -> HTTPPair {
        HTTPPair(
            id: id, time: Date(), durationMS: 12, host: host, port: 443, isSecure: true,
            request: HTTPMessage(isRequest: true, startLine: "\(method) \(path) HTTP/1.1",
                                 headers: [Header(name: "Host", value: host)]),
            response: HTTPMessage(isRequest: false, startLine: "HTTP/1.1 \(status) OK",
                                  headers: [Header(name: "Content-Type", value: "text/html")],
                                  body: Data(body.utf8)),
            origin: origin
        )
    }

    static func issue(host: String) -> ScanIssue {
        ScanIssue(name: "Missing security headers", severity: .low, confidence: .certain,
                  kind: .passive, host: host, url: "https://\(host)/", detail: "CSP is absent",
                  remediation: "Add a Content-Security-Policy header")
    }
}

/// Small one-shot readiness gate for the live socket client.
private final class ResponseBox: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Void, Never>?
    private var ready = false

    func resumeReady() {
        lock.lock()
        if ready { lock.unlock(); return }
        ready = true
        let cont = continuation
        continuation = nil
        lock.unlock()
        cont?.resume()
    }

    func waitReady() async {
        if ready { return }
        await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
            lock.lock()
            if ready { lock.unlock(); cont.resume(); return }
            continuation = cont
            lock.unlock()
        }
    }
}

// ============================================================================
//  Minimal origin server used by the live proxy test
// ============================================================================

/// Serves `origin-hello` for every GET and counts how many TCP connections it accepted,
/// which is how the keep-alive test proves connection reuse.
final class LocalOriginServer: @unchecked Sendable {
    let port: UInt16
    private var listener: NWListener?
    private let lock = NSLock()
    private(set) var lastUserAgent: String = ""
    private var connections = 0

    init(port: UInt16) { self.port = port }

    func start() {
        guard let listener = try? NWListener(using: .tcp, on: NWEndpoint.Port(rawValue: port)!) else { return }
        self.listener = listener
        listener.newConnectionHandler = { [weak self] (connection: NWConnection) in
            self?.lock.lock()
            self?.connections += 1
            self?.lock.unlock()
            self?.serve(connection)
        }
        listener.start(queue: DispatchQueue(label: "selftest.origin"))
    }

    var acceptedConnections: Int {
        lock.lock(); defer { lock.unlock() }
        return connections
    }

    private func serve(_ connection: NWConnection) {
        connection.start(queue: DispatchQueue(label: "selftest.origin.conn"))
        receiveNext(on: connection)
    }

    /// Re-arms after every reply so one socket can serve several requests —
    /// that is what proves the proxy reuses its upstream connection.
    private func receiveNext(on connection: NWConnection) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, isComplete, _ in
            guard let self else { return }
            guard let data, !data.isEmpty else {
                if isComplete { connection.cancel() }
                return
            }
            let text = String(decoding: data, as: UTF8.self)
            self.lock.lock()
            for line in text.components(separatedBy: "\r\n") {
                if line.lowercased().hasPrefix("user-agent:") {
                    self.lastUserAgent = line.dropFirst("user-agent:".count).trimmingCharacters(in: .whitespaces)
                }
            }
            self.lock.unlock()

            let path = text.components(separatedBy: " ").dropFirst().first.map(String.init) ?? "/"
            let body = Data("origin-hello".utf8)
            let head = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: \(body.count)\r\nX-Path: \(path)\r\n\r\n"
            connection.send(content: Data(head.utf8) + body, completion: .contentProcessed { _ in
                if isComplete { connection.cancel() } else { self.receiveNext(on: connection) }
            })
        }
    }

    func stop() {
        listener?.cancel()
        listener = nil
    }
}
