import Foundation
import Network
import Security

// ============================================================================
//  Byte stream abstraction
// ============================================================================

/// Bidirectional byte stream used by the proxy pipeline.
/// Implemented by `NWByteStream` (network sockets) and `TLSTerminationBridge` (decrypted TLS).
protocol ByteStream: AnyObject, Sendable {
    func readSome() async throws -> Data
    func write(_ data: Data) async throws
    func close()
}

enum StreamError: Error, LocalizedError {
    case eof
    case closed
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .eof: return "Connection closed by peer"
        case .closed: return "Stream closed"
        case .failed(let m): return m
        }
    }
}

/// Resumes a continuation exactly once from concurrent Network.framework callbacks.
final class OneShot: @unchecked Sendable {
    private let lock = NSLock()
    private var done = false

    func runOnce(_ body: () -> Void) {
        lock.lock()
        let already = done
        done = true
        lock.unlock()
        if !already { body() }
    }
}

/// `NWConnection` wrapped as an async byte stream with a receive buffer.
final class NWByteStream: ByteStream, @unchecked Sendable {
    private let connection: NWConnection
    private let queue: DispatchQueue
    private let lock = NSLock()
    private var chunks: [Data] = []
    private var waiter: CheckedContinuation<Data, Error>?
    private var endError: Error?
    private var isClosed = false

    init(connection: NWConnection, queue: DispatchQueue) {
        self.connection = connection
        self.queue = queue
    }

    // MARK: - Connecting upstream

    /// Opens a connection to `host:port`, optionally performing a TLS handshake.
    static func connect(host: String, port: Int, tls: Bool, ignoreTLSErrors: Bool, timeout: TimeInterval = 30) async throws -> NWByteStream {
        guard let nwPort = NWEndpoint.Port(rawValue: UInt16(truncatingIfNeeded: port)) else {
            throw StreamError.failed("Invalid port \(port)")
        }
        let parameters: NWParameters
        if tls {
            let tlsOptions = NWProtocolTLS.Options()
            let secOptions = tlsOptions.securityProtocolOptions
            // An intercepting proxy must talk to origins whose certificate it does not validate.
            if ignoreTLSErrors {
                sec_protocol_options_set_verify_block(secOptions, { _, _, complete in complete(true) }, .main)
            } else {
                sec_protocol_options_set_tls_server_name(secOptions, host)
            }
            sec_protocol_options_add_tls_application_protocol(secOptions, "http/1.1")
            parameters = NWParameters(tls: tlsOptions, tcp: NWProtocolTCP.Options())
        } else {
            parameters = .tcp
        }
        parameters.serviceClass = .responsiveData
        parameters.allowLocalEndpointReuse = true

        let connection = NWConnection(host: NWEndpoint.Host(host), port: nwPort, using: parameters)
        let stream = NWByteStream(connection: connection, queue: DispatchQueue(label: "bleedsuite.upstream.\(UUID().uuidString.prefix(8))"))
        let oneShot = OneShot()

        // Without a deadline a silently black-holed origin (or an unreachable IPv6
        // route) would hold the exchange open until the client gave up.
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            let watchdog = DispatchWorkItem {
                oneShot.runOnce {
                    cont.resume(throwing: StreamError.failed("Timed out connecting to \(host):\(port)"))
                }
                connection.cancel()
            }
            connection.stateUpdateHandler = { state in
                switch state {
                case .ready:
                    watchdog.cancel()
                    oneShot.runOnce { cont.resume() }
                case .failed(let error):
                    watchdog.cancel()
                    oneShot.runOnce { cont.resume(throwing: error) }
                    stream.handleEnd(error)
                case .cancelled:
                    watchdog.cancel()
                    oneShot.runOnce { cont.resume(throwing: StreamError.closed) }
                    stream.handleEnd(StreamError.closed)
                default:
                    break
                }
            }
            connection.start(queue: stream.queue)
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + max(timeout, 1), execute: watchdog)
        }
        connection.stateUpdateHandler = { [stream] state in
            if case .failed(let error) = state { stream.handleEnd(error) }
            if case .cancelled = state { stream.handleEnd(StreamError.closed) }
        }
        stream.startReceiving()
        return stream
    }

    /// Wraps an already-accepted server-side connection.
    static func accepted(_ connection: NWConnection, label: String = "bleedsuite.client") -> NWByteStream {
        let stream = NWByteStream(connection: connection, queue: DispatchQueue(label: "\(label).\(UUID().uuidString.prefix(8))"))
        connection.stateUpdateHandler = { [stream] state in
            switch state {
            case .failed(let error): stream.handleEnd(error)
            case .cancelled: stream.handleEnd(StreamError.closed)
            default: break
            }
        }
        connection.start(queue: stream.queue)
        stream.startReceiving()
        return stream
    }

    // MARK: - Receiving

    private func startReceiving() {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 256 * 1024) { [weak self] data, _, isComplete, error in
            guard let self else { return }
            if let data, !data.isEmpty { self.push(data) }
            if isComplete {
                self.handleEnd(error.map { StreamError.failed($0.localizedDescription) } ?? StreamError.eof)
                return
            }
            if let error {
                self.handleEnd(StreamError.failed(error.localizedDescription))
                return
            }
            self.startReceiving()
        }
    }

    private func push(_ data: Data) {
        lock.lock()
        if let waiter {
            self.waiter = nil
            lock.unlock()
            waiter.resume(returning: data)
        } else {
            chunks.append(data)
            lock.unlock()
        }
    }

    private func handleEnd(_ error: Error) {
        lock.lock()
        if endError != nil { lock.unlock(); return }
        endError = error
        let waiter = self.waiter
        self.waiter = nil
        lock.unlock()
        waiter?.resume(throwing: error)
    }

    func readSome() async throws -> Data {
        try await withCheckedThrowingContinuation { cont in
            lock.lock()
            if !chunks.isEmpty {
                let data = chunks.removeFirst()
                lock.unlock()
                cont.resume(returning: data)
                return
            }
            if let endError {
                lock.unlock()
                cont.resume(throwing: endError)
                return
            }
            waiter = cont
            lock.unlock()
        }
    }

    /// Non-blocking read used by the pipelined message pump.
    func takeBuffered() -> Data? {
        lock.lock(); defer { lock.unlock() }
        return chunks.isEmpty ? nil : chunks.removeFirst()
    }

    var hasBuffered: Bool {
        lock.lock(); defer { lock.unlock() }
        return !chunks.isEmpty
    }

    // MARK: - Sending

    func write(_ data: Data) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            connection.send(content: data, completion: .contentProcessed { error in
                if let error { cont.resume(throwing: StreamError.failed(error.localizedDescription)) }
                else { cont.resume() }
            })
        }
    }

    /// Fire-and-forget ordered send for byte pumps (NWConnection preserves call order).
    func sendSync(_ data: Data) {
        connection.send(content: data, completion: .contentProcessed { _ in })
    }

    /// Half-closes the sending side while keeping the read side alive.
    func shutdownWrite() {
        connection.send(content: nil, isComplete: true, completion: .contentProcessed { _ in })
    }

    func close() {
        lock.lock()
        let wasClosed = isClosed
        isClosed = true
        lock.unlock()
        if !wasClosed { connection.cancel() }
    }
}

// ============================================================================
//  Framing helpers on top of ByteStream
// ============================================================================

enum StreamIO {

    /// Reads until at least one complete request sits at the front of `buffer`.
    static func readRequest(from stream: ByteStream, buffer: inout Data, isUpgrade: Bool = false) async throws -> HTTPMessage? {
        while true {
            if !isUpgrade, let framed = HTTPParser.frame(buffer) {
                buffer.consume(framed.length)
                return framed.message
            }
            if buffer.count > HTTPParser.maxBodySize { throw StreamError.failed("Request too large") }
            if buffer.count > HTTPParser.maxHeadSize, HTTPParser.headEnd(in: buffer) == nil {
                throw StreamError.failed("Request head too large")
            }
            let chunk = try await stream.readSome()
            buffer.append(chunk)
        }
    }

    /// Reads one complete response for `method`. Handles body-until-close and 101 upgrades.
    static func readResponse(from stream: ByteStream, buffer: inout Data, method: String) async throws -> (HTTPMessage, isUpgrade: Bool) {
        while true {
            if let headLength = HTTPParser.headEnd(in: buffer) {
                let headText = String(decoding: buffer[0..<headLength], as: UTF8.self)
                let lowered = headText.lowercased()
                let statusCode = Int(headText.components(separatedBy: " ").dropFirst().first.map(String.init) ?? "") ?? 0

                if statusCode == 101 {
                    if let (parsed, consumed) = HTTPParser.parse(buffer, isRequest: false) {
                        var response = parsed
                        // Anything buffered past the head belongs to the tunnel.
                        buffer.consume(consumed)
                        response.body = Data()
                        return (response, true)
                    }
                }

                let hasContentLength = lowered.contains("\r\ncontent-length:")
                let isChunked = lowered.contains("transfer-encoding:") && lowered.contains("chunked")
                let bodyAllowed = method != "HEAD" && statusCode != 204 && statusCode != 304
                    && !(statusCode >= 100 && statusCode < 200)

                if bodyAllowed && !hasContentLength && !isChunked {
                    // Body-until-close: drain until EOF, then split head from body.
                    while true {
                        do {
                            buffer.append(try await stream.readSome())
                        } catch {
                            break
                        }
                    }
                    if let (parsed, consumed) = HTTPParser.parse(buffer, isRequest: false) {
                        var response = parsed
                        response.body = Data(buffer[consumed..<buffer.endIndex])
                        buffer = Data()
                        return (response, false)
                    }
                    throw StreamError.failed("Malformed response head")
                }

                // Content-Length / chunked / bodiless: return as soon as the whole message is buffered.
                if HTTPParser.responseIsComplete(buffer, method: method),
                   let (parsed, consumed) = HTTPParser.parse(buffer, isRequest: false) {
                    buffer.consume(consumed)
                    return (parsed, false)
                }
            }

            if buffer.count > HTTPParser.maxBodySize { throw StreamError.failed("Response too large") }
            buffer.append(try await stream.readSome())
        }
    }

    /// Opaque bidirectional tunnel (CONNECT passthrough and upgrade tunnels).
    static func tunnel(_ a: ByteStream, _ b: ByteStream) async {
        async let up: Void = pump(from: a, to: b)
        async let down: Void = pump(from: b, to: a)
        _ = await (up, down)
        a.close()
        b.close()
    }

    private static func pump(from source: ByteStream, to destination: ByteStream) async {
        do {
            while true {
                let chunk = try await source.readSome()
                try await destination.write(chunk)
            }
        } catch {
            destination.close()
        }
    }
}