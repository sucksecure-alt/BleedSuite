import Foundation
import Security

/// TLS server termination for intercepted HTTPS sessions.
///
/// Network.framework cannot upgrade an already-accepted connection to TLS, so the browser's
/// encrypted byte stream is spliced into one end of a `socketpair` (`relayFD`) while Secure
/// Transport runs a complete TLS server handshake and record layer on the other end (`tlsFD`).
///
/// I/O model: `tlsFD` is blocking and every Secure Transport call is serialised on `tlsQueue`.
/// Encrypted bytes travel between `relayFD` and the network side on two dedicated queues.
final class TLSTerminationBridge: ByteStream, @unchecked Sendable {
    private var relayFD: Int32 = -1
    private var tlsFD: Int32 = -1
    private var ctx: SSLContext?

    /// Shared, not per-session: a page load opens many TLS sessions, and a private
    /// queue per session meant a private thread per session.
    private let tlsQueue = DispatchQueue(label: "bleedsuite.tls")
    private let relayWriteQueue = DispatchQueue(label: "bleedsuite.tls.relay.write")
    private let relayReadQueue = DispatchQueue(label: "bleedsuite.tls.relay.read")

    private let onEncryptedOut: @Sendable (Data) -> Void
    private let onClose: @Sendable () -> Void

    private let stateLock = NSLock()
    private var closed = false

    init(onEncryptedOut: @escaping @Sendable (Data) -> Void, onClose: @escaping @Sendable () -> Void) {
        self.onEncryptedOut = onEncryptedOut
        self.onClose = onClose

        var fds: [Int32] = [0, 0]
        guard socketpair(AF_UNIX, SOCK_STREAM, 0, &fds) == 0 else { return }
        relayFD = fds[0]
        tlsFD = fds[1]

        // A write to a closed socket must never kill the process.
        var on: Int32 = 1
        setsockopt(relayFD, SOL_SOCKET, SO_NOSIGPIPE, &on, socklen_t(MemoryLayout<Int32>.size))
        setsockopt(tlsFD, SOL_SOCKET, SO_NOSIGPIPE, &on, socklen_t(MemoryLayout<Int32>.size))

        // Large kernel buffers keep SSLRead/SSLWrite from blocking on full sockets.
        var bufferSize: Int32 = 1024 * 1024
        for fd in [relayFD, tlsFD] {
            setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &bufferSize, socklen_t(MemoryLayout<Int32>.size))
            setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &bufferSize, socklen_t(MemoryLayout<Int32>.size))
        }
    }

    var isReady: Bool { tlsFD >= 0 && relayFD >= 0 }

    // MARK: - Lifecycle

    func handshake(identity: SecIdentity, extraChain: [SecCertificate] = []) async throws {
        guard tlsFD >= 0, relayFD >= 0 else { throw StreamError.closed }
        guard let context = SSLCreateContext(kCFAllocatorDefault, .serverSide, .streamType) else {
            throw StreamError.failed("SSLCreateContext failed")
        }
        ctx = context

        var status = SSLSetIOFuncs(context, Self.tlsRead, Self.tlsWrite)
        guard status == noErr else { throw StreamError.failed("SSLSetIOFuncs: \(status)") }
        status = SSLSetConnection(context, Unmanaged.passUnretained(self).toOpaque())
        guard status == noErr else { throw StreamError.failed("SSLSetConnection: \(status)") }

        var chain: [AnyObject] = [identity]
        chain.append(contentsOf: extraChain)
        status = SSLSetCertificate(context, chain as CFArray)
        guard status == noErr else { throw StreamError.failed("SSLSetCertificate: \(status)") }

        // TLS 1.2 is the ceiling of the legacy Secure Transport stack; browsers accept it.
        SSLSetProtocolVersionMin(context, .tlsProtocol12)

        let result = await withCheckedContinuation { (cont: CheckedContinuation<OSStatus, Never>) in
            tlsQueue.async {
                var outcome = errSSLWouldBlock
                repeat { outcome = SSLHandshake(context) } while outcome == errSSLWouldBlock
                cont.resume(returning: outcome)
            }
        }
        guard result == noErr else { throw StreamError.failed("TLS handshake failed: \(result)") }
    }

    /// Feeds encrypted bytes received from the browser into the TLS record layer.
    func deliverEncrypted(_ data: Data) {
        relayWriteQueue.async { [self] in
            data.withUnsafeBytes { raw in
                guard let base = raw.baseAddress else { return }
                var written = 0
                while written < raw.count {
                    let n = Darwin.write(relayFD, base.advanced(by: written), raw.count - written)
                    if n > 0 { written += n; continue }
                    if errno == EINTR { continue }
                    self.close()
                    return
                }
            }
        }
    }

    // MARK: - ByteStream (decrypted side)

    func readSome() async throws -> Data {
        try await withCheckedThrowingContinuation { cont in
            tlsQueue.async { [self] in
                guard self.tlsFD >= 0, let context = self.ctx else {
                    cont.resume(throwing: StreamError.closed)
                    return
                }
                var buffer = [UInt8](repeating: 0, count: 256 * 1024)
                while true {
                    var processed = 0
                    let status = buffer.withUnsafeMutableBytes { raw -> OSStatus in
                        SSLRead(context, raw.baseAddress!, raw.count, &processed)
                    }
                    if processed > 0 {
                        cont.resume(returning: Data(buffer[0..<processed]))
                        return
                    }
                    switch status {
                    case noErr, errSSLWouldBlock:
                        continue
                    case errSSLClosedGraceful, errSSLClosedAbort, errSSLClosedNoNotify:
                        cont.resume(throwing: StreamError.eof)
                        self.close()
                        return
                    default:
                        cont.resume(throwing: StreamError.failed("SSLRead: \(status)"))
                        self.close()
                        return
                    }
                }
            }
        }
    }

    func write(_ data: Data) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            tlsQueue.async { [self] in
                guard self.tlsFD >= 0, let context = self.ctx else {
                    cont.resume(throwing: StreamError.closed)
                    return
                }
                let result: OSStatus = data.withUnsafeBytes { raw -> OSStatus in
                    guard let base = raw.baseAddress else { return errSecParam }
                    var total = 0
                    while total < raw.count {
                        var written = 0
                        let status = SSLWrite(context, base.advanced(by: total), raw.count - total, &written)
                        if status != noErr && status != errSSLWouldBlock { return status }
                        total += written
                        if written == 0 && status == errSSLWouldBlock { return errSecIO }
                    }
                    return noErr
                }
                if result == noErr {
                    cont.resume()
                } else {
                    cont.resume(throwing: StreamError.failed("SSLWrite: \(result)"))
                    self.close()
                }
            }
        }
    }

    func close() {
        stateLock.lock()
        let already = closed
        closed = true
        stateLock.unlock()
        guard !already else { return }
        tlsQueue.async { [self] in
            if let context = self.ctx { SSLClose(context) }
            self.ctx = nil
            if self.tlsFD >= 0 { Darwin.close(self.tlsFD); self.tlsFD = -1 }
            if self.relayFD >= 0 { Darwin.close(self.relayFD); self.relayFD = -1 }
        }
        onClose()
    }

    /// Starts pumping encrypted bytes from the TLS record layer toward the browser.
    func startPump() {
        relayReadQueue.async { [self] in
            var buffer = [UInt8](repeating: 0, count: 256 * 1024)
            while true {
                let n = Darwin.read(self.relayFD, &buffer, buffer.count)
                if n > 0 {
                    self.onEncryptedOut(Data(buffer[0..<n]))
                } else if n == 0 {
                    self.close()
                    return
                } else {
                    if errno == EINTR { continue }
                    self.close()
                    return
                }
            }
        }
    }

    // MARK: - Secure Transport I/O callbacks

    private static let tlsRead: SSLReadFunc = { connection, data, dataLength in
        let bridge = Unmanaged<TLSTerminationBridge>.fromOpaque(connection).takeUnretainedValue()
        while true {
            let n = Darwin.read(bridge.tlsFD, data, dataLength.pointee)
            if n > 0 {
                dataLength.pointee = n
                return noErr
            }
            if n == 0 {
                dataLength.pointee = 0
                return errSSLClosedGraceful
            }
            if errno == EINTR { continue }
            if errno == EAGAIN || errno == EWOULDBLOCK { return errSSLWouldBlock }
            return errSecIO
        }
    }

    private static let tlsWrite: SSLWriteFunc = { connection, data, dataLength in
        let bridge = Unmanaged<TLSTerminationBridge>.fromOpaque(connection).takeUnretainedValue()
        let rawPointer = UnsafeRawPointer(data)
        var total = 0
        while total < dataLength.pointee {
            let n = Darwin.write(bridge.tlsFD, rawPointer.advanced(by: total), dataLength.pointee - total)
            if n > 0 { total += n; continue }
            if n == 0 { return errSecIO }
            if errno == EINTR { continue }
            return errSecIO
        }
        dataLength.pointee = total
        return noErr
    }
}