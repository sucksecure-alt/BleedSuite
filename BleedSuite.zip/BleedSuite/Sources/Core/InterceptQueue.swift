import Foundation

// ============================================================================
//  Interception
// ============================================================================

enum InterceptDirection: String, Sendable {
    case request, response
    var label: String { self == .request ? "Request" : "Response" }
}

enum InterceptDecision: Sendable {
    case forward
    case edited(HTTPMessage)
    case drop

    var wasHeld: Bool {
        if case .forward = self { return false }
        return true
    }
}

struct InterceptItem: Identifiable, Sendable {
    var id: UUID = UUID()
    var direction: InterceptDirection
    var transactionID: Int
    var host: String
    var summary: String
    var message: HTTPMessage
    var receivedAt: Date = Date()
    /// Set by the UI when the analyst changed something before forwarding.
    var wasModified: Bool = false
}

/// Holds traffic while the analyst inspects and edits it.
///
/// Every held item keeps a continuation alive, so an item that is never resolved would pin a
/// client connection. `releaseAll` is therefore always called on shutdown and whenever
/// interception is turned off.
actor InterceptQueue {
    static let shared = InterceptQueue()

    private var items: [UUID: InterceptItem] = [:]
    private var order: [UUID] = []
    private var waiters: [UUID: CheckedContinuation<InterceptDecision, Never>] = [:]
    private var _enabled = false
    private var repeating = false

    var enabled: Bool { _enabled }

    func setEnabled(_ value: Bool) {
        _enabled = value
        if !value { releaseAll(reason: "Interception disabled") }
    }

    func isRepeating() -> Bool { repeating }
    func setRepeating(_ value: Bool) { repeating = value }

    /// Suspends the exchange until the analyst resolves the item.
    func hold(
        direction: InterceptDirection,
        transactionID: Int,
        host: String,
        summary: String,
        message: HTTPMessage
    ) async -> InterceptDecision {
        guard _enabled else { return .forward }

        let item = InterceptItem(
            direction: direction, transactionID: transactionID,
            host: host, summary: summary, message: message
        )
        items[item.id] = item
        order.append(item.id)

        if Task.isCancelled {
            items[item.id] = nil
            order.removeAll { $0 == item.id }
            return .drop
        }

        return await withCheckedContinuation { continuation in
            waiters[item.id] = continuation
        }
    }

    /// Resolves one held item. Returns false when the item was already gone.
    @discardableResult
    func resolve(_ id: UUID, with decision: InterceptDecision) -> Bool {
        guard let continuation = waiters.removeValue(forKey: id) else {
            items.removeValue(forKey: id)
            order.removeAll { $0 == id }
            return false
        }
        items.removeValue(forKey: id)
        order.removeAll { $0 == id }
        continuation.resume(returning: decision)
        return true
    }

    /// Resolves a single item forward, optionally with an edited message.
    @discardableResult
    func forward(_ id: UUID, edited: HTTPMessage?) -> Bool {
        resolve(id, with: edited.map { .edited($0) } ?? .forward)
    }

    @discardableResult
    func drop(_ id: UUID) -> Bool { resolve(id, with: .drop) }

    /// Forwards everything currently queued, optionally applying `transform` to each message.
    func forwardAll(transform: (@Sendable (HTTPMessage) -> HTTPMessage)? = nil) {
        let ids = order.reversed()
        for id in ids {
            guard let item = items[id] else { continue }
            if let transform {
                let editedMessage = transform(item.message)
                _ = resolve(id, with: InterceptDecision.edited(editedMessage))
            } else {
                _ = resolve(id, with: InterceptDecision.forward)
            }
        }
    }

    func dropAll() {
        for id in order.reversed() { resolve(id, with: .drop) }
    }

    func releaseAll(reason: String) {
        dropAll()
    }

    /// Non-blocking view for the UI.
    func snapshot() -> [InterceptItem] {
        order.compactMap { items[$0] }
    }

    func pendingCount() -> Int { order.count }

    func item(id: UUID) -> InterceptItem? { items[id] }

    /// Refreshes the stored message when the analyst edits in place without forwarding yet.
    func update(_ id: UUID, message: HTTPMessage, modified: Bool) {
        guard var item = items[id] else { return }
        item.message = message
        item.wasModified = modified
        items[id] = item
    }

    func clear() {
        dropAll()
        items.removeAll()
        order.removeAll()
        waiters.removeAll()
    }
}