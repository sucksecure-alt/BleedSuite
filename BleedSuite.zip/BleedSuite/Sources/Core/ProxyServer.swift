import Foundation
import Network
import Security

// ============================================================================
//  Logging
// ============================================================================

enum LogLevel: Int, Sendable {
    case info, good, warn, bad

    var label: String {
        switch self {
        case .info: return "info"
        case .good: return "good"
        case .warn: return "warn"
        case .bad: return "error"
        }
    }
}

/// Engine-wide log fan-out. The UI installs a handler; everything also goes to stderr
/// so that headless runs are diagnosable from a terminal.
enum EngineLog {
    private static let lock = NSLock()
    nonisolated(unsafe) private static var _handler: (@Sendable (String, LogLevel) -> Void)?

    static var handler: (@Sendable (String, LogLevel) -> Void)? {
        get { lock.lock(); defer { lock.unlock() }; return _handler }
        set { lock.lock(); _handler = newValue; lock.unlock() }
    }

    static func write(_ text: String, _ level: LogLevel = .info) {
        handler?(text, level)
        FileHandle.standardError.write(Data("[\(level.label)] \(text)\n".utf8))
    }
}

// ============================================================================
//  Engine configuration
// ============================================================================

struct ProxyConfiguration: Sendable {
    var port: UInt16 = 8080
    var listenAddress: String = "127.0.0.1"
    var mitmEnabled = true
    var acceptInvalidUpstreamTLS = true
    var followRedirectsInRepeater = false
    var upstreamProxyHost: String?
    var upstreamProxyPort: Int?
    var throttleBytesPerSecond: Int = 0
    var requestTimeoutSeconds: Int = 60
    var maxConnections = 200
    var responseBodyLimit: Int = 64 * 1024 * 1024

    static let `default` = ProxyConfiguration()
}

// ============================================================================
//  Event sink implemented by the UI layer
// ============================================================================

protocol ProxyEventSink: AnyObject, Sendable {
    func transactionCompleted(_ pair: HTTPPair)
    func log(_ text: String, _ level: LogLevel)
    func connectionCountChanged(_ count: Int)
    func proxyStateChanged(_ running: Bool, port: UInt16)
    func interceptQueueChanged()
}

/// Safe bridge that tolerates the sink being installed late or torn down.
final class EventRelay: @unchecked Sendable {
    private let lock = NSLock()
    private var sink: ProxyEventSink?

    init(_ sink: ProxyEventSink? = nil) { self.sink = sink }

    func install(_ sink: ProxyEventSink?) {
        lock.lock(); self.sink = sink; lock.unlock()
    }

    private var current: ProxyEventSink? {
        lock.lock(); defer { lock.unlock() }; return sink
    }

    func transaction(_ pair: HTTPPair) { current?.transactionCompleted(pair) }
    func log(_ text: String, _ level: LogLevel) {
        EngineLog.write(text, level)
        current?.log(text, level)
    }
    func connections(_ n: Int) { current?.connectionCountChanged(n) }
    func state(_ running: Bool, _ port: UInt16) { current?.proxyStateChanged(running, port: port) }
    func intercepts() { current?.interceptQueueChanged() }
}

// ============================================================================
//  Upstream connection pool
// ============================================================================

/// Keeps idle upstream connections around so that keep-alive traffic is not forced onto a
/// fresh TCP+TLS handshake for every single request.
final class UpstreamPool: @unchecked Sendable {
    static let shared = UpstreamPool()

    private struct Key: Hashable {
        let host: String
        let port: Int
        let secure: Bool
        let proxyHost: String?
        let proxyPort: Int?
    }

    private struct Entry {
        let stream: NWByteStream
        let lastUsed: Date
    }

    private let lock = NSLock()
    private var idle: [Key: Entry] = [:]
    private let maxIdlePerHost = 4
    private let idleTimeout: TimeInterval = 90

    /// How long to wait for a connection to reach `.ready` before giving up.
    private let connectTimeout: TimeInterval = 20

    func take(host: String, port: Int, secure: Bool, proxy: (String?, Int?), ignoreTLSErrors: Bool, timeout: Int) async throws -> NWByteStream {
        let key = Key(host: host, port: port, secure: secure, proxyHost: proxy.0, proxyPort: proxy.1)
        lock.lock()
        if let entry = idle[key], Date().timeIntervalSince(entry.lastUsed) < idleTimeout {
            idle.removeValue(forKey: key)
            lock.unlock()
            return entry.stream
        }
        idle.removeValue(forKey: key)
        lock.unlock()

        // An upstream proxy hop means: ask the proxy to reach the origin for us.
        if let proxyHost = proxy.0, let proxyPort = proxy.1 {
            return try await NWByteStream.connect(host: proxyHost, port: proxyPort, tls: false, ignoreTLSErrors: true, timeout: TimeInterval(timeout))
        }
        return try await NWByteStream.connect(
            host: host, port: port, tls: secure,
            ignoreTLSErrors: ignoreTLSErrors,
            timeout: TimeInterval(min(timeout, Int(connectTimeout)))
        )
    }

    func put(_ stream: NWByteStream, host: String, port: Int, secure: Bool, proxy: (String?, Int?)) {
        let key = Key(host: host, port: port, secure: secure, proxyHost: proxy.0, proxyPort: proxy.1)
        lock.lock()
        let sameHost = idle.keys.filter { $0.host == key.host && $0.port == key.port && $0.secure == key.secure }
        if sameHost.count >= maxIdlePerHost, let victim = sameHost.first {
            if let entry = idle.removeValue(forKey: victim) { entry.stream.close() }
        }
        idle[key] = Entry(stream: stream, lastUsed: Date())
        lock.unlock()
    }

    func drain() {
        lock.lock()
        let entries = idle
        idle.removeAll()
        lock.unlock()
        for entry in entries.values { entry.stream.close() }
    }

    func idleCount() -> Int {
        lock.lock(); defer { lock.unlock() }
        return idle.count
    }
}

// ============================================================================
//  Exchange execution
// ============================================================================

struct ExchangeOutcome: Sendable {
    var response: HTTPMessage
    var isUpgrade: Bool
    var upgradeLeftover: Data
}

/// Performs one request/response round-trip: rules → interception → upstream → rules → interception.
enum Exchange {

    static func perform(
        request original: HTTPMessage,
        host: String,
        port: Int,
        isTLS: Bool,
        connectHost: String?,
        connectPort: Int?,
        config: ProxyConfiguration,
        relay: EventRelay,
        gate: InterceptQueue,
        engine: ProxyEngine
    ) async -> ExchangeOutcome {

        let txID = await engine.nextTransactionID()
        let started = Date()
        var request = original
        var rulesFired = 0

        // ---- Match & Replace (request) ----
        let ruleEdit = RulesEngine.shared.applyToRequest(request, pair: nil)
        if let error = ruleEdit.error {
            relay.log("Rule error: \(error)", .warn)
        }
        if ruleEdit.applied > 0 {
            request = ruleEdit.message
            rulesFired += ruleEdit.applied
            relay.log("Applied \(ruleEdit.applied) request rule(s) to \(request.method) \(host)\(request.path)", .info)
        }

        // ---- Request interception ----
        let decision = await gate.hold(
            direction: .request,
            transactionID: txID,
            host: host,
            summary: "\(request.method) \(request.path)",
            message: request
        )
        relay.intercepts()

        switch decision {
        case .drop:
            engine.record(
                HTTPPair(id: txID, time: started, durationMS: 0, host: host, port: port, isSecure: isTLS,
                         request: request, response: nil, error: "Dropped by analyst", isIntercepted: true),
                relay: relay
            )
            let body = "Bleed Suite: request dropped by analyst".data(using: .utf8) ?? Data()
            var headers = [Header(name: "Content-Type", value: "text/plain; charset=utf-8")]
            headers.append(Header(name: "Content-Length", value: String(body.count)))
            return ExchangeOutcome(response: HTTPMessage(isRequest: false, startLine: "HTTP/1.1 502 Bad Gateway", headers: headers, body: body), isUpgrade: false, upgradeLeftover: Data())
        case .edited(let edited):
            if !edited.rawBytes.elementsEqual(request.rawBytes) {
                request = edited
                rulesFired += 1
            }
        case .forward:
            break
        }

        // ---- Route ----
        let route = HTTPParser.route(for: request, connectHost: connectHost, connectPort: connectPort, defaultPort: isTLS ? port : 80)
        var upstreamHost = route.host.isEmpty ? host : route.host
        var upstreamPort = route.port
        var secure = isTLS

        // Plain-text proxying to an https origin without CONNECT.
        if request.path.hasPrefix("https://") {
            secure = true
            if upstreamPort == 80 { upstreamPort = 443 }
        }

        let proxyHop: (String?, Int?) = (config.upstreamProxyHost, config.upstreamProxyPort ?? 8080)

        // ---- Send upstream ----
        var upstream: NWByteStream?
        var upstreamBuffer = Data()
        do {
            // When the client's Connection header said close, the hop is used once only.
            let clientWantsClose = request.header("Connection")?.lowercased().contains("close") == true
            var stream = try await UpstreamPool.shared.take(
                host: upstreamHost, port: upstreamPort, secure: secure, proxy: proxyHop,
                ignoreTLSErrors: config.acceptInvalidUpstreamTLS, timeout: config.requestTimeoutSeconds
            )
            if proxyHop.0 != nil {
                // Send the origin-form target through the upstream proxy.
                if secure {
                    stream.sendSync(Data("CONNECT \(upstreamHost):\(upstreamPort) HTTP/1.1\r\nHost: \(upstreamHost):\(upstreamPort)\r\n\r\n".utf8))
                    var connectBuffer = Data()
                    let marker = try await StreamIO.readResponse(from: stream, buffer: &connectBuffer, method: "CONNECT")
                    if (marker.0.status ?? 0) != 200 {
                        stream.close()
                        throw StreamError.failed("Upstream proxy refused CONNECT (\(marker.0.startLine))")
                    }
                } else {
                    HTTPParser.normalizeTarget(&request)
                }
            } else {
                HTTPParser.normalizeTarget(&request)
                if secure {
                    // The Host header must reflect the default port for the scheme.
                    request.setHeader("Host", hostHeaderValue(host: upstreamHost, port: upstreamPort, secure: secure))
                }
            }

            upstream = stream
            var wire = request
            if config.throttleBytesPerSecond > 0 { wire.body = Data() }
            try await stream.write(request.rawBytes)

            let read = try await StreamIO.readResponse(
                from: stream, buffer: &upstreamBuffer, method: request.method
            )
            let response = read.0
            let isUpgrade = read.isUpgrade

            // ---- Response rules ----
            var finalResponse = response
            if response.body.count <= config.responseBodyLimit {
                let responseRules = RulesEngine.shared.applyToResponse(finalResponse, pair: nil)
                if let error = responseRules.error {
                    relay.log("Rule error: \(error)", .warn)
                }
                if responseRules.applied > 0 {
                    finalResponse = responseRules.message
                    rulesFired += responseRules.applied
                }
            }

            // ---- Response interception ----
            let responseDecision = await gate.hold(
                direction: .response,
                transactionID: txID,
                host: upstreamHost,
                summary: "\(finalResponse.status ?? 0) \(finalResponse.reason)",
                message: finalResponse
            )
            relay.intercepts()

            switch responseDecision {
            case .drop:
                engine.record(
                    HTTPPair(id: txID, time: started, durationMS: Int(-started.timeIntervalSinceNow * 1000),
                             host: host, port: port, isSecure: isTLS, request: request,
                             response: nil, error: "Response dropped by analyst", isIntercepted: true, isModified: rulesFired > 0),
                    relay: relay
                )
                stream.close()
                throw StreamError.closed
            case .edited(let edited):
                if !edited.rawBytes.elementsEqual(finalResponse.rawBytes) {
                    finalResponse = edited
                    rulesFired += 1
                }
            case .forward:
                break
            }

            // ---- Record ----
            let elapsed = Int(-started.timeIntervalSinceNow * 1000)
            engine.record(
                HTTPPair(id: txID, time: started, durationMS: elapsed, host: host, port: port,
                         isSecure: isTLS, request: request, response: finalResponse,
                         error: nil, isIntercepted: decision.wasHeld || responseDecision.wasHeld,
                         isModified: rulesFired > 0),
                relay: relay
            )

            // ---- Connection reuse ----
            let reusable = !clientWantsClose && !isUpgrade && upstreamBuffer.isEmpty
                && (finalResponse.status ?? 0) != 204 && (finalResponse.status ?? 0) != 304
            if reusable {
                UpstreamPool.shared.put(stream, host: upstreamHost, port: upstreamPort, secure: secure, proxy: proxyHop)
            } else {
                stream.close()
            }
            upstream = nil

            return ExchangeOutcome(response: finalResponse, isUpgrade: isUpgrade,
                                   upgradeLeftover: upstreamBuffer)
        } catch {
            upstream?.close()
            let elapsed = Int(-started.timeIntervalSinceNow * 1000)
            let message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            engine.record(
                HTTPPair(id: txID, time: started, durationMS: elapsed, host: host, port: port,
                         isSecure: isTLS, request: request, response: nil,
                         error: message, isIntercepted: decision.wasHeld, isModified: rulesFired > 0),
                relay: relay
            )
            let body = "Bleed Suite upstream error: \(message)".data(using: .utf8) ?? Data()
            var headers = [Header(name: "Content-Type", value: "text/plain; charset=utf-8")]
            headers.append(Header(name: "Content-Length", value: String(body.count)))
            headers.append(Header(name: "Connection", value: "close"))
            return ExchangeOutcome(
                response: HTTPMessage(isRequest: false, startLine: "HTTP/1.1 502 Bad Gateway", headers: headers, body: body),
                isUpgrade: false, upgradeLeftover: Data()
            )
        }
    }

    static func hostHeaderValue(host: String, port: Int, secure: Bool) -> String {
        let defaultPort = secure ? 443 : 80
        return port == defaultPort ? host : "\(host):\(port)"
    }
}

// ============================================================================
//  Client session — one accepted connection
// ============================================================================

final class ProxySession: @unchecked Sendable {
    private let client: NWByteStream
    private let engine: ProxyEngine
    private let relay: EventRelay
    private let gate: InterceptQueue
    private var buffer = Data()

    init(client: NWByteStream, engine: ProxyEngine, relay: EventRelay, gate: InterceptQueue) {
        self.client = client
        self.engine = engine
        self.relay = relay
        self.gate = gate
    }

    func clientClose() { client.close() }

    func run() async {
        defer {
            client.close()
            engine.connectionEnded(self)
        }
        do {
            try await serve()
        } catch StreamError.closed {
            // Normal shutdown.
        } catch {
            relay.log("Session ended: \((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)", .info)
        }
    }

    // MARK: - Plain HTTP loop (keep-alive + pipelining aware)

    private func serve() async throws {
        var connectHost: String?
        var connectPort: Int?
        var isSecure = false

        while true {
            let framedRequest = try await readFramedRequest()
            var request = framedRequest.message

            if let connectHost = framedRequest.connectHost {
                try await handleConnect(host: connectHost, port: framedRequest.connectPort ?? 443)
                return
            }

            var response = await Exchange.perform(
                request: request, host: "", port: 80, isTLS: isSecure,
                connectHost: connectHost, connectPort: connectPort,
                config: engine.configuration, relay: relay, gate: gate, engine: engine
            )

            // Keep the proxy's own connection semantics separate from the client's.
            if request.header("Connection")?.lowercased().contains("close") != true {
                response.response.removeHeader("Connection")
                response.response.setHeader("Connection", "keep-alive")
            }
            try await client.write(response.response.rawBytes)

            if response.isUpgrade {
                if let upstream = try? await engine.upstreamForUpgrade(framedRequest.message) {
                    try await StreamIO.tunnel(client, upstream)
                }
                return
            }
            if framedRequest.isUpgrade {
                return
            }
            if request.header("Connection")?.lowercased().contains("close") == true { return }
        }
    }

    private func readFramedRequest() async throws -> HTTPParser.Framed {
        while true {
            if let framed = HTTPParser.frame(buffer) {
                buffer.consume(framed.length)
                return framed
            }
            if buffer.count > HTTPParser.maxHeadSize, HTTPParser.headEnd(in: buffer) == nil {
                throw StreamError.failed("Request head too large")
            }
            if buffer.count > HTTPParser.maxBodySize {
                throw StreamError.failed("Request too large")
            }
            let chunk = try await client.readSome()
            buffer.append(chunk)
        }
    }

    // MARK: - CONNECT

    private func handleConnect(host: String, port: Int) async throws {
        relay.log("CONNECT \(host):\(port)", .info)

        var identity: SecIdentity?
        if engine.configuration.mitmEnabled {
            do {
                identity = try CertificateAuthority.shared.identity(for: host)
            } catch {
                relay.log("MITM certificate error for \(host): \((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)", .warn)
            }
        }

        let established = Data("HTTP/1.1 200 Connection Established\r\nProxy-Agent: Bleed Suite\r\n\r\n".utf8)
        try await client.write(established)

        if let identity {
            try await runMITM(host: host, port: port, identity: identity)
        } else {
            relay.log("Opaque tunnel to \(host):\(port) (MITM unavailable)", .warn)
            let upstream = try await NWByteStream.connect(
                host: host, port: port, tls: false, ignoreTLSErrors: true,
                timeout: TimeInterval(engine.configuration.requestTimeoutSeconds)
            )
            await StreamIO.tunnel(client, upstream)
        }
    }

    /// In-process TLS termination: the decrypted stream is fed back through the exact same
    /// HTTP pipeline as plain traffic.
    private func runMITM(host: String, port: Int, identity: SecIdentity) async throws {
        let clientStream = client
        let bridge = TLSTerminationBridge(
            onEncryptedOut: { [clientStream] data in clientStream.sendSync(data) },
            onClose: { [clientStream] in clientStream.close() }
        )
        guard bridge.isReady else { throw StreamError.failed("TLS bridge unavailable") }

        bridge.startPump()
        let pump = Task { [clientStream] in
            do {
                while true {
                    let chunk = try await clientStream.readSome()
                    bridge.deliverEncrypted(chunk)
                }
            } catch {
                bridge.close()
            }
        }
        defer {
            pump.cancel()
            bridge.close()
        }

        try await bridge.handshake(identity: identity, extraChain: [CertificateAuthority.shared.caCertificate])
        relay.log("TLS terminated for \(host):\(port)", .good)

        var tlsBuffer = Data()
        while true {
            var request: HTTPMessage
            var isUpgradeRequest = false
            if let framed = HTTPParser.frame(tlsBuffer) {
                request = framed.message
                isUpgradeRequest = framed.isUpgrade
                tlsBuffer.consume(framed.length)
            } else {
                while true {
                    if let framed = HTTPParser.frame(tlsBuffer) {
                        request = framed.message
                        isUpgradeRequest = framed.isUpgrade
                        tlsBuffer.consume(framed.length)
                        break
                    }
                    if tlsBuffer.count > HTTPParser.maxBodySize { throw StreamError.failed("Request too large") }
                    tlsBuffer.append(try await bridge.readSome())
                }
            }

            let wantsClose = request.header("Connection")?.lowercased().contains("close") == true
            let outcome = await Exchange.perform(
                request: request, host: host, port: port, isTLS: true,
                connectHost: host, connectPort: port,
                config: engine.configuration, relay: relay, gate: gate, engine: engine
            )

            var response = outcome.response
            if !wantsClose {
                response.removeHeader("Connection")
                response.setHeader("Connection", "keep-alive")
            }
            try await bridge.write(response.rawBytes)

            if outcome.isUpgrade || isUpgradeRequest {
                relay.log("Protocol upgrade tunnelled for \(host)\(request.path)", .good)
                let upstream = try? await NWByteStream.connect(
                    host: host, port: port, tls: true, ignoreTLSErrors: true, timeout: 30
                )
                if let upstream {
                    if !outcome.upgradeLeftover.isEmpty { upstream.sendSync(outcome.upgradeLeftover) }
                    if !tlsBuffer.isEmpty { upstream.sendSync(tlsBuffer) }
                    await StreamIO.tunnel(bridge, upstream)
                }
                return
            }
            if wantsClose { return }
        }
    }
}

// ============================================================================
//  Live client connection tracking
// ============================================================================

/// Tracks accepted sessions so the UI can show a live connection count.
final class ConnectionRegistry: @unchecked Sendable {
    private let lock = NSLock()
    private var sessions: [ObjectIdentifier: ProxySession] = [:]

    func add(_ session: ProxySession) {
        lock.lock(); sessions[ObjectIdentifier(session)] = session; lock.unlock()
    }

    func remove(_ session: ProxySession) {
        lock.lock(); sessions.removeValue(forKey: ObjectIdentifier(session)); lock.unlock()
    }

    var count: Int {
        lock.lock(); defer { lock.unlock() }
        return sessions.count
    }

    func removeAll() {
        lock.lock(); let all = Array(sessions.values); sessions.removeAll(); lock.unlock()
        all.forEach { $0.clientClose() }
    }
}

// ============================================================================
//  ProxyEngine — listener + bookkeeping
// ============================================================================

actor ProxyEngine {
    static let shared = ProxyEngine()

    private var listener: NWListener?
    private var transactionCounter = 1
    /// Live client connections. Kept outside the actor so `defer` paths can touch it safely.
    nonisolated let registry = ConnectionRegistry()
    private(set) var isRunning = false

    nonisolated let configuration: ProxyConfiguration
    nonisolated let relay: EventRelay
    nonisolated let gate: InterceptQueue

    init(configuration: ProxyConfiguration = .default, relay: EventRelay = EventRelay(), gate: InterceptQueue = InterceptQueue()) {
        self.configuration = configuration
        self.relay = relay
        self.gate = gate
    }

    func nextTransactionID() -> Int {
        defer { transactionCounter += 1 }
        return transactionCounter
    }

    func currentTransactionCount() -> Int { transactionCounter - 1 }

    // MARK: - Recording

    nonisolated func record(_ pair: HTTPPair, relay: EventRelay) {
        HistoryStore.shared.add(pair)
        if ScopeFilterStore.shared.filter.isInScope(host: pair.host, isSecure: pair.isSecure) {
            Spider.shared.onTransaction(pair)
        }
        Scanner.shared.enqueue(pair)
        relay.transaction(pair)
    }

    // MARK: - Listener lifecycle

    func start() throws {
        guard listener == nil else { return }
        let parameters = NWParameters.tcp
        parameters.allowLocalEndpointReuse = true
        guard let nwPort = NWEndpoint.Port(rawValue: configuration.port) else {
            throw StreamError.failed("Invalid port \(configuration.port)")
        }
        let listener = try NWListener(using: parameters, on: nwPort)
        let engine = self
        listener.newConnectionHandler = { connection in
            guard !Task.isCancelled else { connection.cancel(); return }
            let session = ProxySession(
                client: NWByteStream.accepted(connection),
                engine: engine, relay: engine.relay, gate: engine.gate
            )
            Task {
                await engine.register(session)
                await session.run()
            }
        }
        let engineRef = self
        let relayRef = relay
        let configRef = configuration
        listener.stateUpdateHandler = { state in
            switch state {
            case .ready:
                relayRef.log("Proxy listening on \(configRef.listenAddress):\(configRef.port)", .good)
                relayRef.state(true, configRef.port)
                Task { await engineRef.setRunning(true) }
            case .failed(let error):
                relayRef.log("Proxy listener failed: \(error.localizedDescription)", .bad)
                relayRef.state(false, configRef.port)
                Task { await engineRef.handleFailure() }
            default:
                break
            }
        }
        listener.start(queue: DispatchQueue(label: "bleedsuite.listener"))
        self.listener = listener
    }

    func stop() {
        listener?.cancel()
        listener = nil
        UpstreamPool.shared.drain()
        Task { await gate.releaseAll(reason: "Proxy stopped") }
        relay.state(false, configuration.port)
        Task { await setRunning(false) }
    }

    private func handleFailure() {
        listener = nil
        isRunning = false
    }

    private func setRunning(_ value: Bool) { isRunning = value }

    // MARK: - Session registry

    func register(_ session: ProxySession) async {
        registry.add(session)
        relay.connections(registry.count)
    }

    nonisolated func connectionEnded(_ session: ProxySession) {
        registry.remove(session)
        relay.connections(registry.count)
    }

    /// Opens a fresh upstream connection for a protocol upgrade tunnel.
    func upstreamForUpgrade(_ request: HTTPMessage) async throws -> NWByteStream {
        let route = HTTPParser.route(for: request, connectHost: nil, connectPort: nil, defaultPort: 443)
        return try await NWByteStream.connect(
            host: route.host.isEmpty ? "127.0.0.1" : route.host,
            port: route.port, tls: request.path.hasPrefix("https://"),
            ignoreTLSErrors: configuration.acceptInvalidUpstreamTLS, timeout: 30
        )
    }
}

// ============================================================================
//  Direct sender used by Repeater / Intruder / Scanner / Spider
// ============================================================================

/// A single implementation that satisfies both engine protocols, so there is exactly one
/// HTTP client in the app.
final class DirectSender: @unchecked Sendable, ScanRequestSender, IntruderRequestSender {
    static let shared = DirectSender()

    func send(_ request: HTTPMessage, host: String, port: Int, isSecure: Bool, timeoutSeconds: Int) async -> HTTPMessage? {
        var message = request
        HTTPParser.stripHopByHop(&message)
        message.setHeader("Host", Exchange.hostHeaderValue(host: host, port: port, secure: isSecure))
        if message.header("Content-Length") == nil && !message.body.isEmpty {
            message.setHeader("Content-Length", String(message.body.count))
        }

        let started = Date()
        do {
            let stream = try await NWByteStream.connect(
                host: host, port: port, tls: isSecure,
                ignoreTLSErrors: ProxyConfiguration.default.acceptInvalidUpstreamTLS,
                timeout: TimeInterval(timeoutSeconds)
            )
            defer { stream.close() }
            try await stream.write(message.rawBytes)
            var buffer = Data()
            let (response, _) = try await StreamIO.readResponse(from: stream, buffer: &buffer, method: message.method)
            _ = started
            return response
        } catch {
            EngineLog.write("Direct send to \(host):\(port) failed: \((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)", .warn)
            return nil
        }
    }

    /// Full round trip including timing, used by Repeater.
    func exchange(_ request: HTTPMessage, host: String, port: Int, isSecure: Bool, timeoutSeconds: Int = 30) async -> (response: HTTPMessage?, durationMS: Int, error: String?) {
        let started = Date()
        var message = request
        HTTPParser.stripHopByHop(&message)
        message.setHeader("Host", Exchange.hostHeaderValue(host: host, port: port, secure: isSecure))
        if message.header("Content-Length") == nil && !message.body.isEmpty {
            message.setHeader("Content-Length", String(message.body.count))
        }

        do {
            let stream = try await NWByteStream.connect(
                host: host, port: port, tls: isSecure,
                ignoreTLSErrors: true, timeout: TimeInterval(timeoutSeconds)
            )
            defer { stream.close() }
            try await stream.write(message.rawBytes)
            var buffer = Data()
            let (response, _) = try await StreamIO.readResponse(from: stream, buffer: &buffer, method: message.method)
            return (response, Int(-started.timeIntervalSinceNow * 1000), nil)
        } catch {
            return (nil, Int(-started.timeIntervalSinceNow * 1000),
                    (error as? LocalizedError)?.errorDescription ?? error.localizedDescription)
        }
    }
}