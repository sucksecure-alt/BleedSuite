
import SwiftUI
import AppKit

// ============================================================================
//  Target / site map workspace
// ============================================================================

/// Site map on the left (`NSOutlineView`-backed, because a crawl can produce
/// tens of thousands of endpoints), host inspector on the right.
struct TargetView: View {
    @ObservedObject var model: AppModel = AppModel.shared
    @State private var selectedHost: TargetNode?
    @State private var filterText = ""

    var body: some View {
        VStack(spacing: 0) {
            WorkspaceToolbar(title: "Target", subtitle: "Site map") {
                HStack(spacing: 8) {
                    Text(verbatim: "\(model.targetTree.count) host\(model.targetTree.count == 1 ? "" : "s")")
                        .font(Theme.monoSwiftUI(11))
                        .foregroundStyle(Theme.textSecondary)

                    Button {
                        filterHistoryByHost()
                    } label: {
                        Label("Filter history by host", systemImage: "line.3.horizontal.decrease.circle")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                    .disabled(hostName.isEmpty)

                    Button {
                        model.exportHistory(as: .sitemap)
                    } label: {
                        Label("Export sitemap XML", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))

                    Button {
                        model.rescanAll()
                    } label: {
                        Label("Rescan all", systemImage: "arrow.clockwise")
                    }
                    .buttonStyle(CrimsonButtonStyle(compact: true))
                }
            }

            Rectangle().fill(Theme.divider).frame(height: 1)

            if model.targetTree.isEmpty {
                EmptyHint(
                    icon: "point.3.filled.connected.trianglepath.dotted",
                    title: "No targets captured yet",
                    subtitle: "Browse through the proxy and the site map will fill in automatically."
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Theme.background)
            } else {
                SplitLayout(axis: .horizontal, minFirst: 240, minSecond: 320) {
                    AnyView(VStack(spacing: 0) {
                        SearchField(text: $filterText, placeholder: "Filter site map", width: nil)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 6)
                            .background(Theme.surface)
                        Rectangle().fill(Theme.divider).frame(height: 1)
                        TargetTreeView(
                            nodes: filteredNodes,
                            onSelectLeaf: { model.sendToRepeater($0) },
                            onSelectHost: { node in
                                selectedHost = node
                                filterText = ""
                            }
                        )
                    }
                    .background(Theme.background))
                } second: {
                    AnyView(inspector)
                }
            }
        }
        .background(Theme.background)
    }

    // MARK: Filtering

    /// Client-side filter: the site map is a tree of class references, so the
    /// cheap approach is to keep only roots and branches whose label matches.
    private var filteredNodes: [TargetNode] {
        let needle = filterText.trimmingCharacters(in: .whitespaces).lowercased()
        guard !needle.isEmpty else { return model.targetTree }
        return model.targetTree.compactMap { prune($0, needle: needle) }
    }

    private func prune(_ node: TargetNode, needle: String) -> TargetNode? {
        let copy = TargetNode(name: node.name, id: node.id)
        copy.parent = node.parent
        copy.pairs = node.name.lowercased().contains(needle) ? node.pairs : []
        let kept = node.children.compactMap { prune($0, needle: needle) }
        guard !kept.isEmpty || !copy.pairs.isEmpty else { return nil }
        copy.children = kept
        return copy
    }

    // MARK: Inspector

    @ViewBuilder
    private var inspector: some View {
        if let host = selectedHost {
            VStack(spacing: 0) {
                header(host)
                Rectangle().fill(Theme.divider).frame(height: 1)
                actionBar(host)
                Rectangle().fill(Theme.divider).frame(height: 1)

                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        statsPanel(host)
                        pathsPanel(host)
                        parametersPanel(host)
                    }
                    .padding(10)
                }
            }
            .background(Theme.background)
        } else {
            EmptyHint(
                icon: "globe",
                title: "No host selected",
                subtitle: "Double-click a host in the site map to see its paths, parameters and captured exchanges."
            )
            .background(Theme.background)
        }
    }

    private func header(_ host: TargetNode) -> some View {
        HStack(spacing: 10) {
            Image(systemName: "lock.fill")
                .font(.system(size: 10))
                .foregroundStyle(Theme.success)
            VStack(alignment: .leading, spacing: 1) {
                Text(displayHost(host))
                    .font(Theme.monoSwiftUI(12, weight: .bold))
                    .foregroundStyle(Theme.textPrimary)
                Text(verbatim: "\(scheme(host)):\(port(host))")
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)
            }
            Spacer(minLength: 0)
            Badge(text: "\(host.requestCount) requests", color: Theme.crimson)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(Theme.surfaceRaised)
    }

    private func actionBar(_ host: TargetNode) -> some View {
        HStack(spacing: 7) {
            Button {
                model.filterHistoryByHost(displayHost(host))
            } label: {
                Label("Filter history", systemImage: "line.3.horizontal.decrease.circle")
            }
            .buttonStyle(CrimsonButtonStyle(compact: true))

            Button {
                if let pair = firstPair(host) { model.sendToRepeater(pair) }
            } label: {
                Label("Open in Repeater", systemImage: "arrow.triangle.2.circlepath")
            }
            .buttonStyle(GhostButtonStyle(compact: true))
            .disabled(firstPair(host) == nil)

            Spacer(minLength: 0)

            if let pair = latestPair(host) {
                Button {
                    model.scanSelected(pair)
                } label: {
                    Label("Scan latest", systemImage: "shield.lefthalf.filled")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(Theme.surface)
    }

    private func statsPanel(_ host: TargetNode) -> some View {
        Panel(title: "Overview") {
            VStack(alignment: .leading, spacing: 6) {
                LabelledField(label: "Host", text: .constant(displayHost(host)), mono: true)
                LabelledField(label: "Scheme", text: .constant(scheme(host)), mono: true)
                LabelledField(label: "Port", text: .constant(String(port(host))), mono: true)
                LabelledField(label: "Requests", text: .constant(host.requestCount.compactString), mono: true)
                LabelledField(label: "Unique paths", text: .constant(uniquePaths(host).count.compactString), mono: true)
                LabelledField(label: "Parameters", text: .constant(uniqueParameters(host).count.compactString), mono: true)
            }
        }
    }

    private func pathsPanel(_ host: TargetNode) -> some View {
        let paths = uniquePaths(host)
        return Panel(title: "Paths") {
            Text(verbatim: "showing \(min(paths.count, 100)) of \(paths.count)")
                .font(Theme.ui(10))
                .foregroundStyle(Theme.textTertiary)
            if paths.isEmpty {
                Text("No paths captured for this host.")
                    .font(Theme.ui(11))
                    .foregroundStyle(Theme.textTertiary)
            } else {
                VStack(alignment: .leading, spacing: 2) {
                    ForEach(Array(paths.prefix(100)), id: \.self) { path in
                        Button {
                            model.filterHistoryByPath(displayHost(host), path)
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "arrow.turn.down.right")
                                    .font(.system(size: 8))
                                    .foregroundStyle(Theme.textTertiary)
                                Text(path)
                                    .font(Theme.monoSwiftUI(11))
                                    .foregroundStyle(Theme.info)
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                                Spacer(minLength: 0)
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private func parametersPanel(_ host: TargetNode) -> some View {
        let params = uniqueParameters(host)
        return Panel(title: "Parameters") {
            Text(verbatim: "\(params.count) unique name\(params.count == 1 ? "" : "s")")
                .font(Theme.ui(10))
                .foregroundStyle(Theme.textTertiary)
            if params.isEmpty {
                Text("No query parameters seen for this host.")
                    .font(Theme.ui(11))
                    .foregroundStyle(Theme.textTertiary)
            } else {
                HStack(spacing: 5) {
                    ForEach(params, id: \.self) { name in
                        Badge(text: name, color: Theme.crimson)
                    }
                    Spacer(minLength: 0)
                }
            }
        }
    }

    // MARK: Derived data

    private var hostName: String {
        guard let selectedHost else { return "" }
        return displayHost(selectedHost)
    }

    private func filterHistoryByHost() {
        guard !hostName.isEmpty else { return }
        model.filterHistoryByHost(hostName)
    }

    private func displayHost(_ host: TargetNode) -> String {
        // Root labels are "scheme://host:port"; a branch label is a bare name.
        if host.name.contains("://") {
            let afterScheme = host.name.components(separatedBy: "://").last ?? host.name
            return afterScheme.components(separatedBy: ":").first ?? afterScheme
        }
        if let pair = firstPair(host) { return pair.host }
        return host.name
    }

    private func scheme(_ host: TargetNode) -> String {
        if host.name.contains("://") {
            return host.name.components(separatedBy: "://").first ?? "http"
        }
        return firstPair(host)?.scheme ?? "http"
    }

    private func port(_ host: TargetNode) -> Int {
        if host.name.contains("://") {
            let afterScheme = host.name.components(separatedBy: "://").last ?? ""
            return Int(afterScheme.components(separatedBy: ":").last ?? "") ?? 0
        }
        return firstPair(host)?.port ?? 0
    }

    private func uniquePaths(_ host: TargetNode) -> [String] {
        var seen = Set<String>()
        return host.leafPaths.filter { seen.insert($0).inserted }
    }

    /// Parameter names harvested from every captured query string of the host.
    private func uniqueParameters(_ host: TargetNode) -> [String] {
        var seen = Set<String>()
        var names: [String] = []
        for path in host.leafPaths {
            guard let idx = path.firstIndex(of: "?") else { continue }
            let query = String(path[path.index(after: idx)...])
            for param in Params.parseQuery(query) where !param.name.isEmpty {
                if seen.insert(param.name).inserted { names.append(param.name) }
            }
        }
        return names.sorted()
    }

    /// First captured pair in the subtree, used by the repeater shortcut.
    private func firstPair(_ host: TargetNode) -> HTTPPair? {
        if let pair = host.pairs.first { return pair }
        for child in host.children {
            if let pair = firstPair(child) { return pair }
        }
        return nil
    }

    /// Most recently captured pair in the subtree, used by the scan shortcut.
    private func latestPair(_ host: TargetNode) -> HTTPPair? {
        var best: HTTPPair?
        var cursor: [TargetNode] = [host]
        while let node = cursor.popLast() {
            for pair in node.pairs {
                if let current = best {
                    if pair.time > current.time { best = pair }
                } else {
                    best = pair
                }
            }
            cursor.append(contentsOf: node.children)
        }
        return best
    }
}