
import SwiftUI
import AppKit

// ============================================================================
//  Scanner workspace
//
//  Purely presentational: every mutation goes through AppModel or Scanner, this
//  view only owns the filter state (severity / kind / search).
// ============================================================================

struct ScannerView: View {
    @ObservedObject var model: AppModel = AppModel.shared

    @State private var searchText: String = ""
    @State private var severityFilter: ScanIssue.Severity? = nil
    @State private var kindFilter: ScanIssue.Kind? = nil
    @State private var expandedIssues: Set<UUID> = []

    // MARK: - Derived data

    private var issues: [ScanIssue] {
        let needle = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return model.scanIssues.filter { issue in
            if let severityFilter, issue.severity != severityFilter { return false }
            if let kindFilter, issue.kind != kindFilter { return false }
            guard !needle.isEmpty else { return true }
            return issue.name.lowercased().contains(needle)
                || issue.detail.lowercased().contains(needle)
                || issue.host.lowercased().contains(needle)
        }
    }

    private func count(_ severity: ScanIssue.Severity) -> Int {
        model.scanIssues.reduce(0) { $0 + ($1.severity == severity ? 1 : 0) }
    }

    private func count(_ kind: ScanIssue.Kind) -> Int {
        model.scanIssues.reduce(0) { $0 + ($1.kind == kind ? 1 : 0) }
    }

    /// Turning active checks off means "restore every check"; turning them on means
    /// "no explicit allow list", which is how `Scanner` reads an empty set.
    private var activeChecksBinding: Binding<Bool> {
        Binding(
            get: { model.activeChecksEnabled },
            set: { value in
                model.activeChecksEnabled = value
                Scanner.shared.setActiveChecks(value ? [] : Scanner.shared.activeChecks())
            }
        )
    }

    // MARK: - Body

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            Rectangle().fill(Theme.divider).frame(height: 1)
            filterBar
            Rectangle().fill(Theme.divider).frame(height: 1)
            summaryStrip
            Rectangle().fill(Theme.divider).frame(height: 1)
            content
        }
        .background(Theme.background)
    }

    // MARK: Toolbar

    private var toolbar: some View {
        WorkspaceToolbar(
            title: "Scanner",
            subtitle: "\(model.scanIssues.count) issue\(model.scanIssues.count == 1 ? "" : "s")"
        ) {
            HStack(spacing: 8) {
                if model.scannerRunning {
                    Badge(text: "RUNNING", color: Theme.success, filled: true)
                }

                Button {
                    model.rescanAll()
                } label: {
                    Label("Rescan all", systemImage: "arrow.clockwise")
                }
                .buttonStyle(CrimsonButtonStyle(compact: true))

                Button {
                    Scanner.shared.stop()
                } label: {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                .disabled(!model.scannerRunning)

                Button {
                    model.exportScanIssues()
                } label: {
                    Label("Export XML", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                .disabled(model.scanIssues.isEmpty)

                Button {
                    Scanner.shared.clear()
                    expandedIssues.removeAll()
                } label: {
                    Label("Clear", systemImage: "trash")
                }
                .buttonStyle(GhostButtonStyle(tint: Theme.danger, compact: true))
            }
        }
    }

    // MARK: Filter bar

    private var armedCheckCount: Int { Scanner.shared.activeChecks().count }

    private var checkSummary: String {
        armedCheckCount == Scanner.activeCheckNames.count
            ? "all \(Scanner.activeCheckNames.count) checks armed"
            : "\(armedCheckCount) of \(Scanner.activeCheckNames.count) checks armed"
    }

    private var filterBar: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 14) {
                CrimsonToggle(isOn: activeChecksBinding, label: "Active checks")
                Text(checkSummary)
                    .font(Theme.ui(10))
                    .foregroundStyle(Theme.textTertiary)
                Spacer(minLength: 8)
                SearchField(text: $searchText, placeholder: "Search name, detail, host", width: 260)
            }

            HStack(spacing: 6) {
                Text("Severity")
                    .font(Theme.ui(10, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
                ScannerFilterChip(
                    title: "All",
                    count: model.scanIssues.count,
                    tint: Theme.textSecondary,
                    isOn: severityFilter == nil
                ) { severityFilter = nil }
                ForEach(ScanIssue.Severity.allCases.reversed(), id: \.self) { severity in
                    ScannerFilterChip(
                        title: severity.label,
                        count: count(severity),
                        tint: Theme.severityColor(severity),
                        isOn: severityFilter == severity
                    ) {
                        severityFilter = severityFilter == severity ? nil : severity
                    }
                }

                Rectangle().fill(Theme.divider).frame(width: 1, height: 16)

                Text("Kind")
                    .font(Theme.ui(10, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
                ForEach(ScanIssue.Kind.allCases, id: \.self) { kind in
                    ScannerFilterChip(
                        title: kind.label,
                        count: count(kind),
                        tint: kind == .active ? Theme.warning : Theme.info,
                        isOn: kindFilter == kind
                    ) {
                        kindFilter = kindFilter == kind ? nil : kind
                    }
                }

                Spacer(minLength: 0)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .background(Theme.surfaceRaised)
    }

    // MARK: Severity summary

    private var summaryStrip: some View {
        HStack(spacing: 8) {
            ForEach(ScanIssue.Severity.allCases.reversed(), id: \.self) { severity in
                SeverityCard(
                    severity: severity,
                    count: count(severity),
                    isSelected: severityFilter == severity
                ) {
                    severityFilter = severityFilter == severity ? nil : severity
                }
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .background(Theme.surface)
    }

    // MARK: Findings

    @ViewBuilder
    private var content: some View {
        if issues.isEmpty {
            EmptyHint(
                icon: "shield.lefthalf.filled.badge.checkmark",
                title: model.scanIssues.isEmpty ? "No issues found" : "No issues match the filter",
                subtitle: model.scanIssues.isEmpty
                    ? "Passive analysis runs automatically on captured traffic. Use Rescan all to run it again."
                    : "Clear the severity, kind or search filter to see the remaining findings."
            )
        } else {
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(issues) { issue in
                        ScannerRow(
                            issue: issue,
                            isExpanded: expandedIssues.contains(issue.id),
                            onToggle: {
                                if expandedIssues.contains(issue.id) {
                                    expandedIssues.remove(issue.id)
                                } else {
                                    expandedIssues.insert(issue.id)
                                }
                            },
                            onOpenInRepeater: {
                                guard let id = issue.transactionID,
                                      let pair = HistoryStore.shared.pair(withID: id) else { return }
                                model.sendToRepeater(pair)
                            },
                            onFilterHistory: { model.filterHistoryByHost(issue.host) },
                            onCopyReport: { copy(issue) }
                        )
                        Rectangle().fill(Theme.divider.opacity(0.6)).frame(height: 1)
                    }
                }
            }
        }
    }

    // MARK: Helpers

    private func copy(_ issue: ScanIssue) {
        var report = """
        \(issue.name) — \(issue.severity.label)
        confidence: \(issue.confidence.label) · \(issue.kind.label)\(issue.confirmed ? " · confirmed" : "")
        host: \(issue.host)
        url: \(issue.url)
        """
        if !issue.detail.isEmpty { report += "\n\ndetail:\n\(issue.detail)" }
        if !issue.evidence.isEmpty { report += "\n\nevidence:\n\(issue.evidence)" }
        if !issue.remediation.isEmpty { report += "\n\nremediation:\n\(issue.remediation)" }
        if let id = issue.transactionID { report += "\n\ntransaction: #\(id)" }

        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(report, forType: .string)
    }
}

// ============================================================================
//  Severity tile
// ============================================================================

private struct SeverityCard: View {
    let severity: ScanIssue.Severity
    let count: Int
    let isSelected: Bool
    let action: () -> Void

    private var tint: Color { Theme.severityColor(severity) }

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Capsule()
                        .fill(tint)
                        .frame(width: 6, height: 6)
                    Text(severity.label.uppercased())
                        .font(Theme.ui(9, weight: .bold))
                        .tracking(0.8)
                        .foregroundStyle(Theme.textTertiary)
                    Spacer(minLength: 0)
                }
                Text("\(count)")
                    .font(Theme.monoSwiftUI(20, weight: .bold))
                    .foregroundStyle(count == 0 ? Theme.textTertiary : Theme.textPrimary)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .frame(width: 108)
            .background(
                RoundedRectangle(cornerRadius: Theme.corner, style: .continuous)
                    .fill(count == 0 ? Theme.surface : Theme.severityBackground(severity))
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.corner, style: .continuous)
                    .strokeBorder(isSelected ? tint : Theme.divider, lineWidth: 1)
            )
            .opacity(count == 0 ? 0.65 : 1)
        }
        .buttonStyle(.plain)
        .help("Show only \(severity.label.lowercased()) findings")
    }
}

// ============================================================================
//  Filter chip
// ============================================================================

private struct ScannerFilterChip: View {
    let title: String
    let count: Int
    let tint: Color
    let isOn: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 5) {
                Text(title)
                    .font(Theme.ui(11, weight: isOn ? .semibold : .regular))
                    .foregroundStyle(isOn ? Theme.textOnAccent : Theme.textSecondary)
                Text("\(count)")
                    .font(Theme.monoSwiftUI(10, weight: .bold))
                    .foregroundStyle(isOn ? Theme.textOnAccent : tint)
            }
            .padding(.horizontal, 9)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                    .fill(isOn ? tint : Theme.surfaceOverlay)
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                    .strokeBorder(isOn ? Color.clear : Theme.divider, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

// ============================================================================
//  One finding
// ============================================================================

private struct ScannerRow: View {
    let issue: ScanIssue
    let isExpanded: Bool
    let onToggle: () -> Void
    let onOpenInRepeater: () -> Void
    let onFilterHistory: () -> Void
    let onCopyReport: () -> Void

    private var tint: Color { Theme.severityColor(issue.severity) }

    /// `url` minus scheme and authority — the part worth showing in mono.
    private var path: String {
        var url = issue.url
        if let scheme = url.range(of: "://") { url = String(url[scheme.upperBound...]) }
        if let slash = url.firstIndex(of: "/") { return String(url[slash...]) }
        return "/"
    }

    var body: some View {
        HStack(alignment: .top, spacing: 0) {
            Rectangle()
                .fill(tint)
                .frame(width: 3)

            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 7) {
                    Button(action: onToggle) {
                        HStack(spacing: 7) {
                            Image(systemName: isExpanded ? "chevron.down" : "chevron.right")
                                .font(.system(size: 8, weight: .bold))
                                .foregroundStyle(Theme.textTertiary)
                            Text(issue.name)
                                .font(Theme.ui(12, weight: .semibold))
                                .foregroundStyle(Theme.textPrimary)
                                .lineLimit(1)
                            Spacer(minLength: 8)
                            Badge(text: issue.confidence.label, color: confidenceColor)
                            Badge(text: issue.kind.label,
                                  color: issue.kind == .active ? Theme.warning : Theme.info)
                            if issue.confirmed {
                                Badge(text: "CONFIRMED", color: Theme.crimsonBright, filled: true)
                            }
                            if let id = issue.transactionID {
                                Text("#\(id)")
                                    .font(Theme.monoSwiftUI(10))
                                    .foregroundStyle(Theme.textTertiary)
                            }
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }

                HStack(spacing: 5) {
                    Image(systemName: "link")
                        .font(.system(size: 9))
                        .foregroundStyle(Theme.textTertiary)
                    Text(issue.host)
                        .font(Theme.monoSwiftUI(11, weight: .medium))
                        .foregroundStyle(Theme.crimson)
                    Text(path)
                        .font(Theme.monoSwiftUI(11))
                        .foregroundStyle(Theme.textSecondary)
                        .truncationMode(.middle)
                    Spacer(minLength: 0)
                }

                if !issue.detail.isEmpty {
                    Text(issue.detail)
                        .font(Theme.ui(11))
                        .foregroundStyle(Theme.textSecondary)
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                }

                if isExpanded {
                    expandedBody
                        .padding(.top, 3)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 9)
            .frame(maxWidth: .infinity, alignment: .leading)
            .contentShape(Rectangle())
            .onTapGesture(perform: onToggle)
        }
        .background(isExpanded ? Theme.surfaceRaised : Theme.background)
        .contextMenu {
            if issue.transactionID != nil {
                Button {
                    onOpenInRepeater()
                } label: {
                    Label("Open in Repeater", systemImage: "arrow.triangle.2.circlepath")
                }
                Divider()
            }
            Button {
                onCopyReport()
            } label: {
                Label("Copy report", systemImage: "doc.on.doc")
            }
            Button {
                onFilterHistory()
            } label: {
                Label("Filter history by host", systemImage: "line.3.horizontal.decrease.circle")
            }
        }
    }

    private var confidenceColor: Color {
        switch issue.confidence {
        case .certain: return Theme.success
        case .firm: return Theme.info
        case .tentative: return Theme.textSecondary
        }
    }

    @ViewBuilder
    private var expandedBody: some View {
        VStack(alignment: .leading, spacing: 8) {
            if !issue.evidence.isEmpty {
                Panel(title: "Evidence", padding: 8) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        Text(issue.evidence)
                            .font(Theme.monoSwiftUI(11))
                            .foregroundStyle(Theme.textPrimary)
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .frame(maxHeight: 160)
                }
            }

            if !issue.remediation.isEmpty {
                Panel(title: "Remediation", padding: 8) {
                    Text(issue.remediation)
                        .font(Theme.ui(11))
                        .foregroundStyle(Theme.textSecondary)
                        .textSelection(.enabled)
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }

            HStack(spacing: 8) {
                if issue.transactionID != nil {
                    Button {
                        onOpenInRepeater()
                    } label: {
                        Label("Open in Repeater", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                }
                Button {
                    onCopyReport()
                } label: {
                    Label("Copy report", systemImage: "doc.on.doc")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                Button {
                    onFilterHistory()
                } label: {
                    Label("Filter history", systemImage: "line.3.horizontal.decrease.circle")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                Spacer(minLength: 0)
            }
        }
    }
}