
import SwiftUI
import AppKit
import Security

/// Mutable box so a detached task can hand a result back to the parked main thread.
final class ExitCode: @unchecked Sendable {
    private let lock = NSLock()
    private var storage: Int32 = 1
    var value: Int32 {
        get { lock.lock(); defer { lock.unlock() }; return storage }
        set { lock.lock(); storage = newValue; lock.unlock() }
    }
}

/// Entry point. `--selftest` runs the engine suite and exits without launching the UI.
@main
struct BleedSuiteEntry {
    static func main() {
        if let index = CommandLine.arguments.firstIndex(of: "--dump-cert"),
           CommandLine.arguments.count > index + 1 {
            let host = CommandLine.arguments[index + 1]
            var exported = ""
            do {
                let ca = CertificateAuthority.shared
                let der = (try? ca.leafDER(for: host)) ?? Data()
                if der.isEmpty {
                    exported = "error: could not mint a certificate for \(host)\n"
                } else {
                    let b64 = der.base64EncodedString(options: [.lineLength64Characters, .endLineWithLineFeed])
                    exported = "-----BEGIN CERTIFICATE-----\n\(b64)\n-----END CERTIFICATE-----\n"
                }
            } catch {
                exported = "error: \(error.localizedDescription)\n"
            }
            FileHandle.standardOutput.write(Data(exported.utf8))
            return
        }
        // Diagnostics used during setup and support. These run entirely off the main
        // actor — `main` has no run loop here, so anything touching @MainActor would
        // deadlock against the semaphore wait below.
        if CommandLine.arguments.contains("--proxy-on") {
            let done = DispatchSemaphore(value: 0)
            let resultBox = ExitCode()
            Task.detached(priority: .userInitiated) {
                resultBox.value = await SystemProxyToggle.apply(port: 8080) ? 0 : 1
                done.signal()
            }
            _ = done.wait(timeout: .now() + 60)
            exit(resultBox.value)
        }
        if CommandLine.arguments.contains("--proxy-off") {
            let done = DispatchSemaphore(value: 0)
            Task.detached(priority: .userInitiated) {
                await SystemProxyToggle.restore()
                done.signal()
            }
            _ = done.wait(timeout: .now() + 60)
            exit(0)
        }
        if CommandLine.arguments.contains("--selftest") {
            let semaphore = DispatchSemaphore(value: 0)
            Task.detached(priority: .userInitiated) {
                let code = await SelfTest.run()
                semaphore.signal()
                exit(code)
            }
            _ = semaphore.wait(timeout: .now() + 300)
        }
        BleedSuiteApp.main()
    }
}

struct BleedSuiteApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var model = AppModel.shared

    var body: some Scene {
        WindowGroup("Bleed Suite") {
            RootView()
                .frame(minWidth: 1180, minHeight: 720)
                .preferredColorScheme(.dark)
                .onAppear { model.bootstrap() }
                .environmentObject(model)
        }
        .windowStyle(.hiddenTitleBar)
        .commands { BleedCommands(model: model) }
    }
}

struct BleedCommands: Commands {
    @ObservedObject var model: AppModel

    var body: some Commands {
        CommandGroup(replacing: .newItem) {
            Button("New Repeater Tab") { model.repeater.newTab() }
                .keyboardShortcut("t", modifiers: [.command, .shift])
        }

        CommandMenu("Proxy") {
            Button(model.proxyRunning ? "Stop Proxy" : "Start Proxy") { model.toggleProxy() }
                .keyboardShortcut("p", modifiers: [.command, .shift])

            Button(model.interceptEnabled ? "Turn Interception Off" : "Turn Interception On") {
                model.toggleIntercept()
            }
            .keyboardShortcut("i", modifiers: [.command, .shift])

            Divider()

            Button("Open Browser") { model.openBrowser() }
                .keyboardShortcut("b", modifiers: [.command, .shift])

            Button(model.systemProxyEnabled ? "Disable System Proxy" : "Enable System Proxy") {
                model.setSystemProxy(!model.systemProxyEnabled)
            }

            Divider()

            Button("Clear History") { model.clearHistory() }
                .keyboardShortcut("k", modifiers: [.command, .shift])

            Button("Export History…") { model.exportHistory(as: .har) }
                .keyboardShortcut("e", modifiers: [.command, .shift])
        }

        CommandMenu("Tools") {
            ForEach(Workspace.allCases) { workspace in
                Button(workspace.title) { model.workspace = workspace }
                    .keyboardShortcut(workspaceShortcut(workspace), modifiers: [.command, .option])
            }
        }

        CommandMenu("Project") {
            Button("Save Project") { model.saveProject() }
                .keyboardShortcut("s", modifiers: [.command])
            Button("Save Project As…") { model.saveProject() }
                .keyboardShortcut("s", modifiers: [.command, .shift])
        }
    }

    private func workspaceShortcut(_ workspace: Workspace) -> KeyEquivalent {
        switch workspace {
        case .dashboard: return "1"
        case .intercept: return "2"
        case .history: return "3"
        case .target: return "4"
        case .repeater: return "5"
        case .comparer: return "6"
        case .intruder: return "7"
        case .scanner: return "8"
        case .rules: return "9"
        case .settings: return "0"
        }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.appearance = NSAppearance(named: .darkAqua)
        signal(SIGPIPE, SIG_IGN)
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    func applicationWillTerminate(_ notification: Notification) {
        MainActor.assumeIsolated {
            AppModel.shared.shutdown()
        }
    }
}