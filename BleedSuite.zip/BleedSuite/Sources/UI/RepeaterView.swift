
import SwiftUI
import AppKit

// ============================================================================
//  Repeater workspace
// ============================================================================

/// Manual request editor: a tab strip, an editable request, the live response and a
/// per-tab log of previous responses.
///
/// Everything is driven off `RepeaterStore`; the view only owns transient UI state
/// (which tab is being renamed and which history entry is pinned for preview).
struct RepeaterView: View {
    @ObservedObject var model = AppModel.shared
    @ObservedObject var store = RepeaterStore.shared

    /// Tab whose name is being edited inline (double click on the tab strip).
    @State private var renamingID: UUID?
    @State private var renameDraft: String = ""
    /// Index (into `responseHistory`) whose captured response is pinned in the lower pane.
    @State private var pinnedHistoryIndex: Int?
    /// Response bodies captured at send time, keyed by tab then history index. The store only
    /// keeps (status, length, ms, date) tuples, so the body has to be snapshotted here.
    @State private var snapshots: [UUID: [Int: HTTPMessage]] = [:]

    // MARK: Body

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            Rectangle().fill(Theme.divider).frame(height: 1)
            tabStrip
            Rectangle().fill(Theme.divider).frame(height: 1)
            workspace
        }
        .background(Theme.background)
        .foregroundStyle(Theme.textPrimary)
    }

    // MARK: Toolbar

    private var toolbar: some View {
        WorkspaceToolbar(title: "Repeater", subtitle: selectedTab.map { $0.summary } ?? "No tab selected") {
            HStack(spacing: 8) {
                if store.isSending {
                    ProgressView()
                        .controlSize(.small)
                        .scaleEffect(0.7)
                        .frame(width: 14, height: 14)
                }

                Button {
                    store.newTab()
                } label: {
                    Label("New tab", systemImage: "plus")
                }
                .buttonStyle(GhostButtonStyle(compact: true))

                Button {
                    sendSelected()
                } label: {
                    Label("Send", systemImage: "paperplane.fill")
                }
                .buttonStyle(CrimsonButtonStyle(compact: true))
                .keyboardShortcut(.return, modifiers: [.command])
                .disabled(selectedTab == nil || store.isSending)
                .opacity(selectedTab == nil || store.isSending ? 0.5 : 1)

                Button {
                    clearResponse()
                } label: {
                    Label("Clear response", systemImage: "trash")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                .disabled(selectedTab?.response == nil)
                .opacity(selectedTab?.response == nil ? 0.5 : 1)
            }
        }
    }

    // MARK: Tab strip

    private var tabStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 3) {
                ForEach(store.tabs) { tab in
                    RepeaterTabChip(
                        tab: tab,
                        isSelected: tab.id == store.selectedID,
                        isRenaming: renamingID == tab.id,
                        renameText: $renameDraft,
                        onSelect: { select(tab.id) },
                        onBeginRename: { beginRename(tab) },
                        onCommitRename: { commitRename(tab.id) },
                        onCancelRename: { cancelRename() },
                        onClose: { store.close(tab.id) }
                    )
                }
                Button {
                    store.newTab()
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(Theme.textTertiary)
                        .frame(width: 22, height: 22)
                }
                .buttonStyle(.plain)
                .help("New repeater tab")
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
        }
        .frame(height: Theme.tabBarHeight)
        .background(Theme.surface)
    }

    // MARK: Workspace

    @ViewBuilder
    private var workspace: some View {
        if store.tabs.isEmpty {
            EmptyHint(
                icon: "arrow.triangle.2.circlepath",
                title: "No repeater tabs",
                subtitle: "Send a request from the HTTP history or the site map to get started."
            )
        } else if let tab = selectedTab {
            SplitLayout(axis: .horizontal, minFirst: 460, minSecond: 220,
                        first: { AnyView(mainColumn(for: tab)) }) { AnyView(historyPanel(for: tab)) }
        } else {
            EmptyHint(
                icon: "square.dashed",
                title: "Select a tab",
                subtitle: "Pick a repeater tab from the strip above to inspect its traffic."
            )
        }
    }

    private func mainColumn(for tab: RepeaterTab) -> some View {
        VStack(spacing: 0) {
            SplitLayout(axis: .vertical, minFirst: 180, minSecond: 140,
                        first: { AnyView(requestPanel(for: tab)) }) { AnyView(responseColumn(for: tab)) }
        }
        .onAppear { captureSnapshot(tab) }
        .onChange(of: tab.statusCode) { _, _ in captureSnapshot(tab) }
        .onChange(of: tab.response?.body.count) { _, _ in captureSnapshot(tab) }
    }

    // MARK: Request

    private func requestPanel(for tab: RepeaterTab) -> some View {
        VStack(spacing: 0) {
            panelHeader(
                title: "Request",
                trailing: tab.request.method + " " + tab.request.path,
                tint: Theme.methodColor(tab.request.method)
            ) {
                CrimsonToggle(isOn: secureBinding(for: tab.id), label: tab.isSecure ? "HTTPS" : "HTTP")
            }
            Rectangle().fill(Theme.divider).frame(height: 1)
            MessageInspector(
                message: requestBinding(for: tab.id),
                isEditable: true,
                onSubmit: { send(tab.id) }
            )
            // Keyed on the tab so the editor's raw buffer is rebuilt for every
            // request instead of carrying the previous tab's text across.
            .id(tab.id)
        }
        .background(Theme.surface)
    }

    // MARK: Response

    private func responseColumn(for tab: RepeaterTab) -> some View {
        VStack(spacing: 0) {
            statusStrip(for: tab)
            Rectangle().fill(Theme.divider).frame(height: 1)
            responseBody(for: tab)
        }
    }

    @ViewBuilder
    private func responseBody(for tab: RepeaterTab) -> some View {
        if let index = pinnedHistoryIndex,
           tab.responseHistory.indices.contains(index),
           let captured = snapshot(tab: tab, index: index) {
            VStack(spacing: 0) {
                panelHeader(
                    title: "Response",
                    trailing: "history entry #\(index + 1) · \(Format.clock(tab.responseHistory[index].at))",
                    tint: Theme.warning
                ) {
                    Button {
                        pinnedHistoryIndex = nil
                    } label: {
                        Label("Show latest", systemImage: "arrow.uturn.backward")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                }
                Rectangle().fill(Theme.divider).frame(height: 1)
                MessageInspector(message: snapshotBinding(tab: tab, index: index), isEditable: false)
            }
            .background(Theme.surface)
        } else if let response = tab.response {
            VStack(spacing: 0) {
                panelHeader(
                    title: "Response",
                    trailing: response.reason.isEmpty ? nil : response.reason,
                    tint: Theme.statusColor(response.status)
                ) {
                    if pinnedHistoryIndex != nil {
                        Button {
                            pinnedHistoryIndex = nil
                        } label: {
                            Label("Show latest", systemImage: "arrow.uturn.backward")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))
                    }
                }
                Rectangle().fill(Theme.divider).frame(height: 1)
                MessageInspector(message: responseBinding(for: tab.id), isEditable: true)
                    .id("resp-\(tab.id)")
            }
            .background(Theme.surface)
        } else {
            EmptyHint(
                icon: "arrow.down.circle",
                title: "No response yet",
                subtitle: "Press ⌘↩ or hit Send to issue the request."
            )
            .background(Theme.surface)
        }
    }

    // MARK: Status strip

    private func statusStrip(for tab: RepeaterTab) -> some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Circle()
                    .fill(Theme.statusColor(tab.error == nil ? tab.statusCode : nil))
                    .frame(width: 6, height: 6)

                Text("\(tab.statusLabel) · \(Format.bytes(tab.responseLength ?? 0)) · \(Format.ms(tab.durationMS ?? 0))")
                    .font(Theme.monoSwiftUI(11))
                    .foregroundStyle(Theme.textSecondary)
                    .lineLimit(1)

                if tab.isModified {
                    Badge(text: "MODIFIED", color: Theme.warning)
                }

                if let error = tab.error, !error.isEmpty {
                    Text(error)
                        .font(Theme.monoSwiftUI(11))
                        .foregroundStyle(Theme.danger)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }

                Spacer(minLength: 8)

                if let lastSent = tab.lastSent {
                    Text(Format.clock(lastSent))
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textTertiary)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Theme.surfaceRaised)
            .overlay(alignment: .top) {
                Rectangle().fill(Theme.divider).frame(height: 1)
            }
            .overlay(alignment: .bottom) {
                Rectangle().fill(Theme.divider).frame(height: 1)
            }
        }
    }

    // MARK: Response history

    private func historyPanel(for tab: RepeaterTab) -> some View {
        VStack(spacing: 0) {
            SectionLabel(text: "Response history", trailing: "\(tab.responseHistory.count)")
            Rectangle().fill(Theme.divider).frame(height: 1)

            if tab.responseHistory.isEmpty {
                EmptyHint(
                    icon: "clock.arrow.circlepath",
                    title: "No history yet",
                    subtitle: "Every response for this tab is logged here as you send."
                )
            } else {
                ScrollView(.vertical, showsIndicators: true) {
                    LazyVStack(spacing: 0) {
                        ForEach(Array(tab.responseHistory.indices.reversed()), id: \.self) { index in
                            RepeaterHistoryRow(
                                index: index,
                                status: tab.responseHistory[index].status,
                                length: tab.responseHistory[index].length,
                                milliseconds: tab.responseHistory[index].ms,
                                date: tab.responseHistory[index].at,
                                isPinned: pinnedHistoryIndex == index,
                                hasSnapshot: snapshot(tab: tab, index: index) != nil
                            ) {
                                pinnedHistoryIndex = pinnedHistoryIndex == index ? nil : index
                            }
                            Rectangle().fill(Theme.divider.opacity(0.5)).frame(height: 1)
                        }
                    }
                }
            }

            Rectangle().fill(Theme.divider).frame(height: 1)
            HStack(spacing: 8) {
                Button {
                    copyLatestResponse()
                } label: {
                    Label("Copy response", systemImage: "doc.on.doc")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                .disabled(displayedResponse(for: tab) == nil)
                .opacity(displayedResponse(for: tab) == nil ? 0.5 : 1)

                if let index = pinnedHistoryIndex {
                    Button {
                        pinnedHistoryIndex = nil
                    } label: {
                        Label("Latest", systemImage: "arrow.uturn.backward")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                }
                Spacer(minLength: 0)
            }
            .padding(8)
            .background(Theme.surface)
        }
        .background(Theme.surface)
    }

    // MARK: Panel header

    private func panelHeader<Trailing: View>(
        title: String,
        trailing: String?,
        tint: Color,
        @ViewBuilder trailingViews: () -> Trailing
    ) -> some View {
        HStack(spacing: 8) {
            HStack(spacing: 6) {
                Circle().fill(tint).frame(width: 6, height: 6)
                Text(title.uppercased())
                    .font(Theme.ui(10, weight: .semibold))
                    .tracking(1.1)
                    .foregroundStyle(Theme.textTertiary)
            }
            if let trailing, !trailing.isEmpty {
                Text(trailing)
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            Spacer(minLength: 8)
            trailingViews()
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(Theme.surfaceRaised)
    }

    // MARK: Bindings

    private var selectedTab: RepeaterTab? {
        if let selectedID = store.selectedID, let tab = store.tabs.first(where: { $0.id == selectedID }) {
            return tab
        }
        return store.tabs.first
    }

    private func requestBinding(for id: UUID) -> Binding<HTTPMessage> {
        Binding(
            get: {
                store.tabs.first(where: { $0.id == id })?.request
                    ?? HTTPMessage(isRequest: true, startLine: "GET / HTTP/1.1")
            },
            set: { newValue in
                store.update(id) { $0.request = newValue }
                store.syncFromEditor(id)
            }
        )
    }

    private func responseBinding(for id: UUID) -> Binding<HTTPMessage> {
        Binding(
            get: {
                store.tabs.first(where: { $0.id == id })?.response
                    ?? HTTPMessage(isRequest: false, startLine: "HTTP/1.1 200 OK")
            },
            set: { newValue in
                store.update(id) { $0.response = newValue }
            }
        )
    }

    private func secureBinding(for id: UUID) -> Binding<Bool> {
        Binding(
            get: { store.tabs.first(where: { $0.id == id })?.isSecure ?? false },
            set: { newValue in
                store.update(id) {
                    $0.isSecure = newValue
                    if newValue, $0.port == 80 { $0.port = 443 }
                    if !newValue, $0.port == 443 { $0.port = 80 }
                }
            }
        )
    }

    /// Read-only view over a snapshotted history response (the store only keeps metadata).
    private func snapshotBinding(tab: RepeaterTab, index: Int) -> Binding<HTTPMessage> {
        Binding(
            get: { snapshot(tab: tab, index: index) ?? HTTPMessage(isRequest: false, startLine: "HTTP/1.1 200 OK") },
            set: { _ in }
        )
    }

    // MARK: Actions

    private func select(_ id: UUID) {
        store.selectedID = id
        pinnedHistoryIndex = nil
    }

    private func send(_ id: UUID) {
        // Flush any pending raw-editor keystrokes so the tab that goes on the wire
        // is exactly what is on screen.
        NotificationCenter.default.post(name: .bleedFlushPendingEdit, object: nil)
        Task { await store.send(id) }
    }

    private func sendSelected() {
        guard let tab = selectedTab else { return }
        send(tab.id)
    }

    private func clearResponse() {
        guard let id = selectedTab?.id else { return }
        store.update(id) {
            $0.response = nil
            $0.statusCode = nil
            $0.durationMS = nil
            $0.responseLength = nil
            $0.error = nil
        }
        pinnedHistoryIndex = nil
    }

    private func copyLatestResponse() {
        guard let tab = selectedTab, let response = displayedResponse(for: tab) else { return }
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(response.prettyRaw, forType: .string)
    }

    // MARK: Renaming

    private func beginRename(_ tab: RepeaterTab) {
        renamingID = tab.id
        renameDraft = tab.name
    }

    private func commitRename(_ id: UUID) {
        store.rename(id, to: renameDraft.trimmingCharacters(in: .whitespacesAndNewlines))
        cancelRename()
    }

    private func cancelRename() {
        renamingID = nil
        renameDraft = ""
    }

    // MARK: History snapshots

    private func snapshot(tab: RepeaterTab, index: Int) -> HTTPMessage? {
        snapshots[tab.id]?[index]
    }

    private func captureSnapshot(_ tab: RepeaterTab) {
        guard let response = tab.response, let index = tab.responseHistory.indices.last else { return }
        var bucket = snapshots[tab.id] ?? [:]
        bucket[index] = response
        // Keep the map small — history is trimmed at 50 entries by the store anyway.
        if bucket.count > 64 {
            for key in bucket.keys.sorted().dropLast(64) { bucket.removeValue(forKey: key) }
        }
        snapshots[tab.id] = bucket
    }

    private func displayedResponse(for tab: RepeaterTab) -> HTTPMessage? {
        if let index = pinnedHistoryIndex, let captured = snapshot(tab: tab, index: index) {
            return captured
        }
        return tab.response
    }
}

// ============================================================================
//  Tab chip
// ============================================================================

/// One entry of the repeater tab strip. Double click renames it inline.
private struct RepeaterTabChip: View {
    let tab: RepeaterTab
    let isSelected: Bool
    let isRenaming: Bool
    @Binding var renameText: String
    let onSelect: () -> Void
    let onBeginRename: () -> Void
    let onCommitRename: () -> Void
    let onCancelRename: () -> Void
    let onClose: () -> Void

    var body: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(Theme.statusColor(tab.statusCode))
                .frame(width: 6, height: 6)

            if isRenaming {
                TextField("", text: $renameText)
                    .textFieldStyle(.plain)
                    .font(Theme.ui(11))
                    .foregroundStyle(Theme.textPrimary)
                    .frame(width: 110)
                    .onSubmit { onCommitRename() }
                    .onExitCommand { onCancelRename() }
            } else {
                Text(tab.name)
                    .font(Theme.ui(11, weight: isSelected ? .semibold : .regular))
                    .foregroundStyle(isSelected ? Theme.textPrimary : Theme.textSecondary)
                    .lineLimit(1)
            }

            Button(action: onClose) {
                Image(systemName: "xmark")
                    .font(.system(size: 8, weight: .bold))
                    .foregroundStyle(Theme.textTertiary)
                    .frame(width: 14, height: 14)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .help("Close tab")
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(
            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                .fill(isSelected ? Theme.crimson.opacity(0.15) : Theme.surfaceOverlay.opacity(0.55))
        )
        .overlay(
            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                .strokeBorder(isSelected ? Theme.crimson.opacity(0.45) : Theme.divider, lineWidth: 1)
        )
        .contentShape(Rectangle())
        .onTapGesture { onSelect() }
        .onTapGesture(count: 2) { onBeginRename() }
        .help(tab.summary)
    }
}

// ============================================================================
//  History row
// ============================================================================

private struct RepeaterHistoryRow: View {
    let index: Int
    let status: Int
    let length: Int
    let milliseconds: Int
    let date: Date
    let isPinned: Bool
    let hasSnapshot: Bool
    let onTap: () -> Void

    var body: some View {
        HStack(spacing: 7) {
            Text("#\(index + 1)")
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 26, alignment: .trailing)

            StatusChip(status: status)

            Text(Format.bytes(length))
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textSecondary)
                .frame(width: 62, alignment: .trailing)

            Text(Format.ms(milliseconds))
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 58, alignment: .trailing)

            Text(Format.clock(date))
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textTertiary)

            Spacer(minLength: 4)

            if !hasSnapshot {
                Circle()
                    .fill(Theme.dividerBright)
                    .frame(width: 4, height: 4)
                    .help("Body not captured for this entry")
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(isPinned ? Theme.crimson.opacity(0.15) : Color.clear)
        .contentShape(Rectangle())
        .onTapGesture { onTap() }
    }
}