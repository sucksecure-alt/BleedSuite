
import SwiftUI
import AppKit

// ============================================================================
//  HTTP history workspace
// ============================================================================

/// Transactions table on the left, Burp-style inspector of the selected exchange
/// on the right.
///
/// The inspector reads the selected transaction straight out of `HistoryStore` on
/// every render and writes edits straight back, rather than keeping a local copy.
/// `AppModel` republishes `historyGeneration` on each pump tick, so the panel always
/// resolves the current selection — no stale copy can ever fall back to the
/// "No request selected" placeholder.
struct HistoryView: View {
    @ObservedObject var model: AppModel = AppModel.shared
    @State private var tagDraft = ""
    @State private var side: Side = .request

    private enum Side: String, Hashable {
        case request, response
    }

    private let methodFilters = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]
    private let statusFilters: [StatusClass] = [.success, .redirect, .clientError, .serverError]
    private let originFilters: [HTTPPair.Origin] = [.proxy, .repeater, .intruder, .spider, .scanner]

    var body: some View {
        VStack(spacing: 0) {
            WorkspaceToolbar(title: "HTTP history", subtitle: "Captured transactions") {
                HStack(spacing: 8) {
                    Text("\(model.visibleHistoryCount) of \(model.totalHistoryCount)")
                        .font(Theme.monoSwiftUI(11))
                        .foregroundStyle(Theme.textSecondary)

                    Button {
                        model.clearHistoryFilters()
                    } label: {
                        Label("Clear filters", systemImage: "line.3.horizontal.decrease.circle")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))

                    Button {
                        model.clearHistory()
                    } label: {
                        Label("Clear history", systemImage: "trash")
                    }
                    .buttonStyle(GhostButtonStyle(tint: Theme.danger, compact: true))

                    exportMenu
                }
            }

            filterBar
            Rectangle().fill(Theme.divider).frame(height: 1)

            // SplitLayout's slots are `() -> AnyView`, so each pane is erased explicitly.
            SplitLayout(axis: .horizontal, minFirst: 280, minSecond: 340) {
                AnyView(
                    HistoryTableView(model: model)
                        .background(Theme.background)
                )
            } second: {
                AnyView(inspector)
            }
        }
        .background(Theme.background)
    }

    /// The selected transaction, re-read from the store on every render.
    private var editingPair: HTTPPair? { model.selectedPair }

    // MARK: Filter bar

    private var filterBar: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                SearchField(
                    text: Binding(get: { model.historyFilterText }, set: { model.historyFilterText = $0 }),
                    placeholder: "Filter by URL, header or body",
                    width: 280
                )
                .onChange(of: model.historyFilterText) { _, _ in model.historyFilterChanged() }

                if !model.historyFilterHost.isEmpty {
                    Badge(text: "host: \(model.historyFilterHost)", color: Theme.info)
                }

                Spacer(minLength: 0)
            }

            HStack(spacing: 6) {
                ForEach(methodFilters, id: \.self) { method in
                    FilterChip(
                        title: method,
                        isOn: model.historyMethods.contains(method),
                        color: Theme.methodColor(method)
                    ) {
                        toggle(method: method)
                    }
                }

                Rectangle().fill(Theme.divider).frame(width: 1, height: 16)

                ForEach(statusFilters, id: \.self) { statusClass in
                    FilterChip(
                        title: statusClass.label,
                        isOn: model.historyStatusClasses.contains(statusClass),
                        color: statusColor(statusClass)
                    ) {
                        toggle(statusClass: statusClass)
                    }
                }

                Rectangle().fill(Theme.divider).frame(width: 1, height: 16)

                ForEach(originFilters, id: \.self) { origin in
                    FilterChip(
                        title: origin.label,
                        isOn: model.historyOrigins.contains(origin),
                        color: Theme.textSecondary
                    ) {
                        toggle(origin: origin)
                    }
                }

                Spacer(minLength: 0)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Theme.surface)
    }

    private var exportMenu: some View {
        Menu {
            Button("HAR 1.2") { model.exportHistory(as: .har) }
            Button("CSV (Burp history)") { model.exportHistory(as: .csv) }
            Button("Sitemap XML") { model.exportHistory(as: .sitemap) }
            Button("Bleed Suite project") { model.exportHistory(as: .project) }
        } label: {
            Label("Export", systemImage: "square.and.arrow.up")
        }
        .menuStyle(.borderlessButton)
        .fixedSize()
    }

    private func toggle(method: String) {
        if model.historyMethods.contains(method) {
            model.historyMethods.remove(method)
        } else {
            model.historyMethods.insert(method)
        }
        model.applyHistoryFilter()
    }

    private func toggle(statusClass: StatusClass) {
        if model.historyStatusClasses.contains(statusClass) {
            model.historyStatusClasses.remove(statusClass)
        } else {
            model.historyStatusClasses.insert(statusClass)
        }
        model.applyHistoryFilter()
    }

    private func toggle(origin: HTTPPair.Origin) {
        if model.historyOrigins.contains(origin) {
            model.historyOrigins.remove(origin)
        } else {
            model.historyOrigins.insert(origin)
        }
        model.applyHistoryFilter()
    }

    private func statusColor(_ statusClass: StatusClass) -> Color {
        switch statusClass {
        case .success: return Theme.statusColor(200)
        case .redirect: return Theme.statusColor(301)
        case .clientError: return Theme.statusColor(404)
        case .serverError: return Theme.statusColor(500)
        default: return Theme.textSecondary
        }
    }

    // MARK: Inspector

    @ViewBuilder
    private var inspector: some View {
        if let pair = editingPair {
            VStack(spacing: 0) {
                ExchangeSummaryBar(
                    request: pair.request,
                    response: pair.response,
                    host: pair.host,
                    isSecure: pair.isSecure,
                    note: pair.note,
                    tags: pair.tags
                )
                Rectangle().fill(Theme.divider).frame(height: 1)
                actionBar(pair)
                Rectangle().fill(Theme.divider).frame(height: 1)

                SplitLayout(axis: .vertical, minFirst: 240, minSecond: 96) {
                    AnyView(VStack(spacing: 0) {
                        HStack(spacing: 6) {
                            SegmentBar(
                                selection: $side,
                                options: [
                                    (.request, "Request", "arrow.up.left"),
                                    (.response, "Response", "arrow.down.right"),
                                ],
                                compact: true
                            )
                            Spacer(minLength: 0)
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 6)
                        .background(Theme.surfaceRaised)
                        Rectangle().fill(Theme.divider).frame(height: 1)
                        messagePane
                    }
                    .background(Theme.surface))
                } second: {
                    AnyView(metadataBar(pair))
                }
            }
            .background(Theme.background)
        } else {
            EmptyHint(
                icon: "list.bullet.rectangle",
                title: "No request selected",
                subtitle: "Pick a transaction on the left to inspect its request, response and metadata."
            )
            .background(Theme.background)
        }
    }

    @ViewBuilder
    private var messagePane: some View {
        switch side {
        case .request:
            // Identity follows the transaction so the raw editor reloads its
            // buffer instead of showing the previous selection.
            MessageInspector(message: requestBinding, isEditable: true)
                .id(editingPair?.id ?? -1)
        case .response:
            if editingPair?.response != nil {
                MessageInspector(message: responseBinding, isEditable: true)
                    .id(editingPair?.id ?? -1)
            } else {
                EmptyHint(
                    icon: "arrow.down.right.circle",
                    title: "No response captured",
                    subtitle: "This transaction never completed — the connection failed or the request is still held by the interceptor."
                )
                .background(Theme.background)
            }
        }
    }

    private func actionBar(_ pair: HTTPPair) -> some View {
        HStack(spacing: 7) {
            Button {
                model.sendToRepeater(pair)
            } label: {
                Label("Send to Repeater", systemImage: "arrow.triangle.2.circlepath")
            }
            .buttonStyle(CrimsonButtonStyle(compact: true))

            Button {
                model.scanSelected(pair)
            } label: {
                Label("Scan", systemImage: "shield.lefthalf.filled")
            }
            .buttonStyle(GhostButtonStyle(compact: true))

            HStack(spacing: 5) {
                Image(systemName: "tag")
                    .font(.system(size: 10))
                    .foregroundStyle(Theme.textTertiary)
                TextField("New tag, press return", text: $tagDraft)
                    .textFieldStyle(.plain)
                    .font(Theme.monoSwiftUI(11))
                    .foregroundStyle(Theme.textPrimary)
                    .onSubmit { addTag() }
                    .frame(width: 150)
            }
            .padding(.horizontal, 7)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous).fill(Theme.background)
            )
            .overlay(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous).strokeBorder(Theme.divider, lineWidth: 1)
            )

            Button {
                addTag()
            } label: {
                Label("Add tag", systemImage: "plus")
            }
            .buttonStyle(GhostButtonStyle(compact: true))

            Spacer(minLength: 0)

            Button {
                copy(pair.url)
            } label: {
                Label("Copy URL", systemImage: "link")
            }
            .buttonStyle(GhostButtonStyle(compact: true))

            Button {
                copy(pair.request.prettyRaw)
            } label: {
                Label("Copy request", systemImage: "doc.on.doc")
            }
            .buttonStyle(GhostButtonStyle(compact: true))
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(Theme.surface)
    }

    private func metadataBar(_ pair: HTTPPair) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionLabel(text: "Transaction", trailing: pair.origin.label)
            Rectangle().fill(Theme.divider).frame(height: 1)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(alignment: .top, spacing: 16) {
                    metaItem("id", String(pair.id))
                    metaItem("time", Format.stamp(pair.time))
                    metaItem("duration", Format.ms(pair.durationMS))
                    metaItem("port", String(pair.port))
                    metaItem("scheme", pair.scheme)
                    metaItem("origin", pair.origin.label)
                    metaItem("request", Format.bytes(pair.requestLength))
                    metaItem("response", Format.bytes(pair.responseLength))
                    if let error = pair.error {
                        metaItem("error", error, tint: Theme.danger)
                    }
                    if pair.isIntercepted {
                        Badge(text: "INTERCEPTED", color: Theme.warning, filled: true)
                    }
                    if pair.isModified {
                        Badge(text: "MODIFIED", color: Theme.crimsonBright, filled: true)
                    }
                    if !pair.tags.isEmpty {
                        ForEach(pair.tags, id: \.self) { Badge(text: $0, color: Theme.warning) }
                    }
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.surface)
    }

    private func metaItem(_ label: String, _ value: String, tint: Color = Theme.textPrimary) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label.uppercased())
                .font(Theme.ui(9, weight: .semibold))
                .tracking(0.8)
                .foregroundStyle(Theme.textTertiary)
            Text(value)
                .font(Theme.monoSwiftUI(11))
                .foregroundStyle(tint)
                .lineLimit(2)
                .textSelection(.enabled)
        }
        .fixedSize(horizontal: false, vertical: true)
    }

    // MARK: Editing plumbing

    private var requestBinding: Binding<HTTPMessage> {
        Binding(
            get: { editingPair?.request ?? HTTPMessage(isRequest: true, startLine: "GET / HTTP/1.1") },
            set: { newValue in
                guard let id = model.selectedPairID else { return }
                HistoryStore.shared.update(id: id) {
                    $0.request = newValue
                    $0.isModified = true
                }
                model.touchHistory()
            }
        )
    }

    private var responseBinding: Binding<HTTPMessage> {
        Binding(
            get: { editingPair?.response ?? HTTPMessage(isRequest: false, startLine: "HTTP/1.1 200 OK") },
            set: { newValue in
                guard let id = model.selectedPairID else { return }
                HistoryStore.shared.update(id: id) {
                    $0.response = newValue
                    $0.isModified = true
                }
                model.touchHistory()
            }
        )
    }

    

    private func addTag() {
        let tag = tagDraft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !tag.isEmpty, let id = model.selectedPairID else { return }
        HistoryStore.shared.update(id: id) { $0.tags.append(tag) }
        model.touchHistory()
        tagDraft = ""
    }

    private func copy(_ text: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
    }
}

// MARK: - Filter chip

private struct FilterChip: View {
    let title: String
    let isOn: Bool
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(Theme.monoSwiftUI(10, weight: .bold))
                .foregroundStyle(isOn ? Theme.background : color)
                .padding(.horizontal, 7)
                .padding(.vertical, 3)
                .background(Capsule().fill(isOn ? color : color.opacity(0.12)))
                .overlay(Capsule().strokeBorder(color.opacity(isOn ? 0 : 0.3), lineWidth: 1))
                .opacity(isOn ? 1 : 0.75)
        }
        .buttonStyle(.plain)
    }
}