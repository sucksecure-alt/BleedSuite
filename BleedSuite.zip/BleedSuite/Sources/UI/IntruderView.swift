
import SwiftUI
import AppKit
import Combine

// ============================================================================
//  Intruder workspace
// ============================================================================

/// Payload-sweep workspace.
///
/// The engine owns the jobs and their results; this view owns only transient UI state
/// (selection, the locally edited request, the config mirror and the right-hand tab).
/// The request is edited in a local copy because `IntruderEngine` exposes no setter for
/// `IntruderJob.baseRequest` — starting the job reconciles the two (see `reconcileJob`).
struct IntruderView: View {
    @ObservedObject var model = AppModel.shared

    @State private var selectedJobID: UUID?
    /// Locally edited base request. Markers typed by the user are folded away on start.
    @State private var jobRequest = HTTPMessage(isRequest: true, startLine: "GET / HTTP/1.1")
    /// Mirror of the selected job's config; every edit is pushed straight into the engine.
    @State private var config = IntruderConfig()
    @State private var onlyMatched = false
    @State private var jobSearch = ""
    @State private var rightTab: IntruderTab = .options
    @State private var inspecting: IntruderResult?
    @State private var warningMessage: String?
    /// Bumped by the refresh loop so engine state (which is not observable) repaints.
    @State private var tick = 0

    /// How often the history seed menu is rebuilt.
    private static let historySeedLimit = 20

    // MARK: - Body

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            Rectangle().fill(Theme.divider).frame(height: 1)
            if let warningMessage {
                IntruderWarningBar(text: warningMessage) { self.warningMessage = nil }
                Rectangle().fill(Theme.divider).frame(height: 1)
            }
            SplitLayout(axis: .horizontal, minFirst: 200, minSecond: 420,
                        first: { AnyView(jobList) }) { AnyView(detailColumn) }
        }
        .background(Theme.background)
        .foregroundStyle(Theme.textPrimary)
        .onAppear { syncSelection() }
        .onChange(of: selectedJobID) { _, _ in syncSelection() }
        .onReceive(NotificationCenter.default.publisher(for: .bleedSendToIntruder)) { note in
            if let pair = note.object as? HTTPPair { createJob(from: pair) }
        }
        .task { @MainActor in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 350_000_000)
                tick += 1
            }
        }
        .sheet(item: $inspecting) { result in
            IntruderResultSheet(result: result)
        }
    }

    // MARK: - Toolbar

    private var toolbar: some View {
        WorkspaceToolbar(title: "Intruder", subtitle: toolbarSubtitle) {
            HStack(spacing: 8) {
                if IntruderEngine.shared.isRunning {
                    Circle()
                        .fill(Theme.success)
                        .frame(width: 6, height: 6)
                }
                Menu {
                    if recentPairs.isEmpty {
                        Text("HTTP history is empty")
                    } else {
                        ForEach(recentPairs) { pair in
                            Button {
                                createJob(from: pair)
                            } label: {
                                Text("\(pair.request.method)  #\(pair.id)  \(pair.host)\(pair.request.path)")
                            }
                        }
                    }
                } label: {
                    Label("New job from…", systemImage: "plus.square.dashed")
                }
                .menuStyle(.borderlessButton)
                .buttonStyle(GhostButtonStyle(compact: true))
                .fixedSize()
                .disabled(recentPairs.isEmpty)
                .opacity(recentPairs.isEmpty ? 0.5 : 1)
                .help("Seed an Intruder job from one of the last \(IntruderView.historySeedLimit) history items")

                if let job = selectedJob {
                    Button {
                        start(job)
                    } label: {
                        Label(isRunning(job) ? "Stop" : "Start", systemImage: isRunning(job) ? "stop.fill" : "play.fill")
                    }
                    .buttonStyle(CrimsonButtonStyle(compact: true))
                    .keyboardShortcut(.return, modifiers: [.command])

                    Button {
                        IntruderEngine.shared.clearResults(for: job.id)
                    } label: {
                        Label("Clear results", systemImage: "trash")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                    .disabled(displayedResults(for: job).isEmpty)
                    .opacity(displayedResults(for: job).isEmpty ? 0.5 : 1)
                }
            }
        }
    }

    private var toolbarSubtitle: String {
        let all = jobs
        guard !all.isEmpty else { return "No jobs" }
        let matched = all.reduce(0) { $0 + IntruderEngine.shared.matchedResults(for: $1.id).count }
        return "\(all.count) job\(all.count == 1 ? "" : "s") · \(matched) match\(matched == 1 ? "" : "es")"
    }

    /// Newest history entries offered as job templates.
    private var recentPairs: [HTTPPair] {
        let all = HistoryStore.shared.exportSnapshot()
        return Array(all.suffix(IntruderView.historySeedLimit).reversed())
    }

    // MARK: - Job list

    private var jobList: some View {
        VStack(spacing: 0) {
            SectionLabel(text: "Jobs", trailing: "\(jobs.count)")
            SearchField(text: $jobSearch, placeholder: "Filter jobs", width: nil)
                .padding(.horizontal, 8)
                .padding(.bottom, 6)
            Rectangle().fill(Theme.divider).frame(height: 1)

            if jobs.isEmpty {
                EmptyHint(
                    icon: "bolt.slash",
                    title: "No Intruder jobs",
                    subtitle: "Use “New job from…” above to seed a job from the HTTP history."
                )
            } else if filteredJobs.isEmpty {
                EmptyHint(
                    icon: "magnifyingglass",
                    title: "No match",
                    subtitle: "No job name matches “\(jobSearch)”."
                )
            } else {
                ScrollView(.vertical, showsIndicators: true) {
                    LazyVStack(spacing: 0) {
                        ForEach(filteredJobs) { job in
                            IntruderJobRow(
                                job: job,
                                isSelected: job.id == selectedJob?.id,
                                isRunning: isRunning(job),
                                progress: IntruderEngine.shared.progress(for: job.id),
                                resultCount: IntruderEngine.shared.results(for: job.id).count,
                                matchedCount: IntruderEngine.shared.matchedResults(for: job.id).count
                            ) {
                                selectedJobID = job.id
                                rightTab = .options
                            }
                            Rectangle().fill(Theme.divider.opacity(0.5)).frame(height: 1)
                        }
                    }
                }
            }
        }
        .background(Theme.sidebar)
    }

    // MARK: - Detail column

    @ViewBuilder
    private var detailColumn: some View {
        if let job = selectedJob {
            VStack(spacing: 0) {
                IntruderJobHeader(
                    job: job,
                    payloadCount: IntruderEngine.shared.payloadCount(for: job.id),
                    isRunning: isRunning(job),
                    onDelete: { removeJob(job) }
                )
                Rectangle().fill(Theme.divider).frame(height: 1)
                SegmentBar(
                    selection: $rightTab,
                    options: [
                        (.options, "Request & payloads", "slider.horizontal.3"),
                        (.results, "Results", "list.bullet.rectangle"),
                        (.sequencer, "Sequencer", "arrow.up.arrow.down.square"),
                    ],
                    compact: true
                )
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                Rectangle().fill(Theme.divider).frame(height: 1)

                switch rightTab {
                case .options:
                    IntruderOptionsTab(
                        jobID: job.id,
                        request: $jobRequest,
                        config: config,
                        onConfigChange: { apply($0) }
                    )
                case .results:
                    IntruderResultsTab(
                        job: job,
                        results: displayedResults(for: job),
                        matchedTotal: IntruderEngine.shared.matchedResults(for: job.id).count,
                        onlyMatched: $onlyMatched,
                        onInspect: { inspecting = $0 },
                        onCopyCSV: { copyCSV(for: job) }
                    )
                case .sequencer:
                    Panel(title: "Sequencer") { SequencerView() }
                        .padding(10)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                }
            }
            .background(Theme.background)
        } else {
            EmptyHint(
                icon: "bolt.slash",
                title: "No Intruder job selected",
                subtitle: "Pick a job on the left, or create one from a captured request."
            )
            .background(Theme.background)
        }
    }

    // MARK: - Engine reads

    /// Every read goes through this accessor so the refresh loop drives repaints.
    private var jobs: [IntruderEngine.IntruderJob] {
        _ = tick
        return IntruderEngine.shared.jobs()
    }

    private var filteredJobs: [IntruderEngine.IntruderJob] {
        let needle = jobSearch.trimmingCharacters(in: .whitespaces).lowercased()
        guard !needle.isEmpty else { return jobs }
        return jobs.filter {
            $0.name.lowercased().contains(needle) || $0.host.lowercased().contains(needle)
        }
    }

    private var selectedJob: IntruderEngine.IntruderJob? {
        if let selectedJobID, let match = jobs.first(where: { $0.id == selectedJobID }) { return match }
        return jobs.first
    }

    private func isRunning(_ job: IntruderEngine.IntruderJob) -> Bool {
        _ = tick
        return IntruderEngine.shared.runningJobIDs.contains(job.id)
    }

    private func displayedResults(for job: IntruderEngine.IntruderJob) -> [IntruderResult] {
        _ = tick
        return onlyMatched
            ? IntruderEngine.shared.matchedResults(for: job.id)
            : IntruderEngine.shared.results(for: job.id)
    }

    // MARK: - Actions

    private func syncSelection() {
        guard let job = selectedJob else { return }
        selectedJobID = job.id
        jobRequest = job.baseRequest
        config = job.config
    }

    /// Config edits land in the engine immediately so a running job is never stale.
    private func apply(_ newConfig: IntruderConfig) {
        config = newConfig
        guard let job = selectedJob else { return }
        IntruderEngine.shared.updateConfig(newConfig, for: job.id)
    }

    private func createJob(from pair: HTTPPair) {
        if PositionExtractor.positions(in: pair.request).isEmpty {
            warningMessage = "No payload positions found in #\(pair.id) \(pair.request.method) \(pair.request.path) — "
                + "Intruder needs a query value, a path segment, a cookie or a well-known header."
            return
        }
        do {
            let job = try IntruderEngine.shared.createJob(
                template: pair.request,
                host: pair.host,
                port: pair.port,
                isSecure: pair.isSecure,
                name: "#\(pair.id) \(pair.request.path)"
            )
            warningMessage = nil
            selectedJobID = job.id
            rightTab = .options
            syncSelection()
        } catch {
            warningMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }

    private func removeJob(_ job: IntruderEngine.IntruderJob) {
        IntruderEngine.shared.removeJob(id: job.id)
        selectedJobID = nil
        syncSelection()
    }

    private func start(_ job: IntruderEngine.IntruderJob) {
        if isRunning(job) {
            IntruderEngine.shared.cancel(jobID: job.id)
            return
        }
        guard let jobID = reconcileJob(job) else { return }
        Task { await IntruderEngine.shared.start(jobID: jobID, sender: DirectSender.shared) }
    }

    /// Folds the typed `§N§` markers away, refreshes the position list and — when the
    /// request was edited — rebuilds the job so the engine picks the new base request up.
    /// Returns the id of the job that should actually run.
    private func reconcileJob(_ job: IntruderEngine.IntruderJob) -> UUID? {
        let expanded = IntruderSupport.expandMarkers(jobRequest)
        let positions = PositionExtractor.positions(in: expanded)
        guard !positions.isEmpty else {
            warningMessage = "The edited request has no payload positions — add a query parameter, a path "
                + "segment, a cookie or a known header before starting."
            return nil
        }
        guard !PayloadType.generate(config.type, wordlist: config.wordlist).isEmpty else {
            warningMessage = "The payload set is empty — pick a built-in wordlist or load a custom list first."
            return nil
        }

        if expanded.prettyRaw == job.baseRequest.prettyRaw {
            if positions != job.positions {
                do {
                    try IntruderEngine.shared.updatePositions(positions, for: job.id)
                } catch {
                    warningMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                    return nil
                }
            }
            return job.id
        }

        // The request changed: the engine keeps `baseRequest` private to the job, so the
        // edited copy is promoted to a fresh job that inherits the tuned configuration.
        do {
            let created = try IntruderEngine.shared.createJob(
                template: expanded,
                host: job.host,
                port: job.port,
                isSecure: job.isSecure,
                name: job.name
            )
            IntruderEngine.shared.updateConfig(config, for: created.id)
            try IntruderEngine.shared.updatePositions(positions, for: created.id)
            IntruderEngine.shared.removeJob(id: job.id)
            selectedJobID = created.id
            jobRequest = created.baseRequest
            warningMessage = nil
            return created.id
        } catch {
            warningMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            return nil
        }
    }

    private func copyCSV(for job: IntruderEngine.IntruderJob) {
        let text = IntruderSupport.csv(displayedResults(for: job))
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
    }
}

// ============================================================================
//  Support helpers
// ============================================================================

private enum IntruderSupport {
    /// User-typed `§1§` markers are unfolded before the request goes on the wire, so a
    /// stale marker can never leak into a payload or shift a position.
    static func expandMarkers(_ message: HTTPMessage) -> HTTPMessage {
        let text = message.prettyRaw
        guard text.contains(MarkerCodec.open) else { return message }
        return HTTPMessage.parseEditorText(MarkerCodec.strip(MarkerCodec.decode(text)), isRequest: true)
    }

    static func csv(_ results: [IntruderResult]) -> String {
        var lines = ["index,payload,status,length,time_ms,matched,error"]
        for result in results {
            lines.append([
                String(result.index),
                field(result.label),
                result.status.map(String.init) ?? "",
                String(result.length),
                String(result.timeMS),
                result.matched ? "yes" : "no",
                field(result.error ?? ""),
            ].joined(separator: ","))
        }
        return lines.joined(separator: "\n")
    }

    private static func field(_ value: String) -> String {
        guard value.contains(",") || value.contains("\"") || value.contains("\n") else { return value }
        return "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
}

private enum IntruderTab: Hashable {
    case options, results, sequencer
}

private enum IntruderStatusChoice: Hashable {
    case unchanged, changed, equal, inRange

    var label: String {
        switch self {
        case .unchanged: return "Status unchanged"
        case .changed: return "Status changed"
        case .equal: return "Status = N"
        case .inRange: return "Status in range"
        }
    }

    init(_ value: MatchStatus) {
        switch value {
        case .unchanged: self = .unchanged
        case .changed: self = .changed
        case .equal: self = .equal
        case .inRange: self = .inRange
        }
    }

    var matchStatus: MatchStatus {
        switch self {
        case .unchanged: return .unchanged
        case .changed: return .changed
        case .equal: return .equal(0)
        case .inRange: return .inRange(200...299)
        }
    }
}

private enum IntruderSizeChoice: Hashable {
    case unchanged, changed, equal, inRange, greaterThan, lessThan

    var label: String {
        switch self {
        case .unchanged: return "Length unchanged"
        case .changed: return "Length changed"
        case .equal: return "Length = N"
        case .inRange: return "Length in range"
        case .greaterThan: return "Length > N"
        case .lessThan: return "Length < N"
        }
    }

    init(_ value: MatchSize) {
        switch value {
        case .unchanged: self = .unchanged
        case .changed: self = .changed
        case .equal: self = .equal
        case .inRange: self = .inRange
        case .greaterThan: self = .greaterThan
        case .lessThan: self = .lessThan
        }
    }

    var matchSize: MatchSize {
        switch self {
        case .unchanged: return .unchanged
        case .changed: return .changed
        case .equal: return .equal(0)
        case .inRange: return .inRange(0...0)
        case .greaterThan: return .greaterThan(0)
        case .lessThan: return .lessThan(0)
        }
    }
}

// ============================================================================
//  Warning banner
// ============================================================================

private struct IntruderWarningBar: View {
    let text: String
    let onDismiss: () -> Void

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 10))
                .foregroundStyle(Theme.warning)
            Text(text)
                .font(Theme.ui(11))
                .foregroundStyle(Theme.textPrimary)
                .lineLimit(3)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 8)
            Button(action: onDismiss) {
                Image(systemName: "xmark")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(Theme.textTertiary)
            }
            .buttonStyle(.plain)
            .help("Dismiss")
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Theme.warning.opacity(0.12))
        .overlay(alignment: .bottom) {
            Rectangle().fill(Theme.warning.opacity(0.35)).frame(height: 1)
        }
    }
}

// ============================================================================
//  Job list row
// ============================================================================

private struct IntruderJobRow: View {
    let job: IntruderEngine.IntruderJob
    let isSelected: Bool
    let isRunning: Bool
    let progress: (done: Int, total: Int)
    let resultCount: Int
    let matchedCount: Int
    let onSelect: () -> Void

    var body: some View {
        Button(action: onSelect) {
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 5) {
                    Circle()
                        .fill(isRunning ? Theme.success : Theme.textTertiary)
                        .frame(width: 6, height: 6)
                    Text(job.name)
                        .font(Theme.ui(11, weight: isSelected ? .semibold : .regular))
                        .foregroundStyle(isSelected ? Theme.textPrimary : Theme.textSecondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    Spacer(minLength: 4)
                    if resultCount > 0 {
                        Text("\(resultCount)")
                            .font(Theme.monoSwiftUI(10))
                            .foregroundStyle(Theme.textTertiary)
                    }
                }
                HStack(spacing: 4) {
                    Text(job.host)
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textTertiary)
                        .lineLimit(1)
                    Text(":\(job.port)")
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textTertiary)
                    Text("\(job.positions.count) pos")
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textTertiary)
                    Spacer(minLength: 4)
                    if matchedCount > 0 {
                        Badge(text: "\(matchedCount) ✓", color: Theme.success)
                    }
                }
                if isRunning, progress.total > 0 {
                    ProgressView(value: Double(progress.done), total: Double(progress.total))
                        .progressViewStyle(.linear)
                        .tint(Theme.success)
                }
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isSelected ? Theme.crimson.opacity(0.14) : Color.clear)
            .overlay(alignment: .leading) {
                if isSelected {
                    Capsule().fill(Theme.crimson).frame(width: 2, height: 22).offset(x: -4)
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .help(job.name)
    }
}

// ============================================================================
//  Job detail header
// ============================================================================

private struct IntruderJobHeader: View {
    let job: IntruderEngine.IntruderJob
    let payloadCount: Int
    let isRunning: Bool
    let onDelete: () -> Void

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "bolt.fill")
                .font(.system(size: 10))
                .foregroundStyle(isRunning ? Theme.success : Theme.warning)
            Text(job.name)
                .font(Theme.ui(12, weight: .semibold))
                .foregroundStyle(Theme.textPrimary)
                .lineLimit(1)
                .truncationMode(.middle)

            Badge(text: "\(job.positions.count) positions", color: Theme.info)
            Badge(text: "\(payloadCount) requests", color: Theme.textSecondary)
            if isRunning {
                Badge(text: "RUNNING", color: Theme.success, filled: true)
            }

            Spacer(minLength: 8)

            Text("\(job.isSecure ? "https" : "http")://\(job.host):\(job.port)")
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textTertiary)
                .lineLimit(1)

            Button(action: onDelete) {
                Image(systemName: "trash")
                    .font(.system(size: 10))
                    .foregroundStyle(Theme.textTertiary)
            }
            .buttonStyle(.plain)
            .help("Delete this Intruder job")
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(Theme.surfaceRaised)
    }
}

// ============================================================================
//  Request + payload configuration
// ============================================================================

private struct IntruderOptionsTab: View {
    let jobID: UUID
    @Binding var request: HTTPMessage
    let config: IntruderConfig
    let onConfigChange: (IntruderConfig) -> Void

    var body: some View {
        SplitLayout(axis: .vertical, minFirst: 160, minSecond: 150,
                    first: { AnyView(IntruderRequestPane(request: $request)) }) {
            AnyView(IntruderConfigPanel(config: config, onChange: onConfigChange).id(jobID))
        }
    }
}

/// Editable request on the left, the marked-up preview on the right.
private struct IntruderRequestPane: View {
    @Binding var request: HTTPMessage
    @State private var showPreview = true

    private var positions: [PayloadPosition] { PositionExtractor.positions(in: request) }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Text("REQUEST")
                    .font(Theme.ui(10, weight: .semibold))
                    .tracking(1.1)
                    .foregroundStyle(Theme.textTertiary)
                Text(request.startLine)
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textSecondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                Spacer(minLength: 8)
                CrimsonToggle(isOn: $showPreview, label: "Marker preview")
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Theme.surfaceRaised)

            Rectangle().fill(Theme.divider).frame(height: 1)

            HStack(spacing: 0) {
                MessageInspector(message: $request, isEditable: true)
                    .frame(minWidth: 320)
                if showPreview {
                    Rectangle().fill(Theme.divider).frame(width: 1)
                    VStack(spacing: 0) {
                        HStack(spacing: 6) {
                            Text("MARKED UP")
                                .font(Theme.ui(10, weight: .semibold))
                                .tracking(1.1)
                                .foregroundStyle(Theme.textTertiary)
                            Spacer(minLength: 4)
                            if positions.isEmpty {
                                Text("no positions")
                                    .font(Theme.ui(10))
                                    .foregroundStyle(Theme.warning)
                            } else {
                                Text("\(positions.count)")
                                    .font(Theme.monoSwiftUI(10))
                                    .foregroundStyle(Theme.textTertiary)
                            }
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Theme.surfaceRaised)
                        Rectangle().fill(Theme.divider).frame(height: 1)
                        RawTextView(text: PositionExtractor.markedUp(request))
                    }
                    .frame(minWidth: 220)
                }
            }

            Rectangle().fill(Theme.divider).frame(height: 1)

            if positions.isEmpty {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 9))
                        .foregroundStyle(Theme.warning)
                    Text("No payload positions in this request — Intruder needs a query value, a path segment, a cookie or a known header.")
                        .font(Theme.ui(10))
                        .foregroundStyle(Theme.textSecondary)
                        .lineLimit(2)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(Theme.surface)
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 4) {
                        ForEach(Array(positions.enumerated()), id: \.element.id) { index, position in
                            Badge(text: "\(index + 1) \(position.kind.detail)", color: Theme.crimson)
                        }
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                }
                .frame(height: 28)
                .background(Theme.surface)
            }
        }
        .background(Theme.surface)
    }
}

/// Picker-friendly numeric field backed by `LabelledField`.
private struct IntruderNumberField: View {
    let label: String
    @Binding var value: Int
    var width: CGFloat? = 80

    @State private var text = ""

    var body: some View {
        LabelledField(label: label, text: $text, placeholder: "", mono: true, width: width)
            .onAppear { text = String(value) }
            .onChange(of: value) { _, _ in
                if Int(text) != value { text = String(value) }
            }
            .onChange(of: text) { _, new in
                if let parsed = Int(new.trimmingCharacters(in: .whitespaces)), parsed != value {
                    value = parsed
                }
            }
    }
}

/// Every configuration knob of one job. Edits are emitted as a whole `IntruderConfig`.
private struct IntruderConfigPanel: View {
    let config: IntruderConfig
    let onChange: (IntruderConfig) -> Void

    @State private var wordlistText = ""
    @State private var wordlistName = Wordlists.names.first ?? ""
    @State private var showWordlist = false

    // MARK: Bindings

    private var payloadOptions: [(PayloadType, String)] {
        var out = PayloadType.allCases.map { ($0, $0.label) }
        out.append((.custom(wordlist: config.wordlist), "Custom (\(config.wordlist.count))"))
        return out
    }

    private var payloadBinding: Binding<PayloadType> {
        Binding(get: { config.type }, set: { setType($0) })
    }

    private var statusBinding: Binding<IntruderStatusChoice> {
        Binding(
            get: { IntruderStatusChoice(config.matchStatus) },
            set: { choice in
                mutate { current in
                    switch choice {
                    case .unchanged: current.matchStatus = .unchanged
                    case .changed: current.matchStatus = .changed
                    case .equal: current.matchStatus = .equal(statusValue)
                    case .inRange:
                        let low = min(statusLow, statusHigh)
                        current.matchStatus = .inRange(low...max(low, statusHigh))
                    }
                }
            }
        )
    }

    private var sizeBinding: Binding<IntruderSizeChoice> {
        Binding(
            get: { IntruderSizeChoice(config.matchSize) },
            set: { choice in
                mutate { current in
                    switch choice {
                    case .unchanged: current.matchSize = .unchanged
                    case .changed: current.matchSize = .changed
                    case .equal: current.matchSize = .equal(sizeValue)
                    case .inRange:
                        let low = min(sizeLow, sizeHigh)
                        current.matchSize = .inRange(low...max(low, sizeHigh))
                    case .greaterThan: current.matchSize = .greaterThan(sizeValue)
                    case .lessThan: current.matchSize = .lessThan(sizeValue)
                    }
                }
            }
        )
    }

    // MARK: Values carried over from the current rule

    private var statusValue: Int {
        if case .equal(let value) = config.matchStatus { return value }
        return 200
    }

    private var statusLow: Int {
        if case .inRange(let range) = config.matchStatus { return range.lowerBound }
        return 200
    }

    private var statusHigh: Int {
        if case .inRange(let range) = config.matchStatus { return range.upperBound }
        return 299
    }

    private var sizeValue: Int {
        switch config.matchSize {
        case .equal(let value): return value
        case .greaterThan(let value): return value
        case .lessThan(let value): return value
        default: return 1000
        }
    }

    private var sizeLow: Int {
        if case .inRange(let range) = config.matchSize { return range.lowerBound }
        return 900
    }

    private var sizeHigh: Int {
        if case .inRange(let range) = config.matchSize { return range.upperBound }
        return 1100
    }

    private var numberRange: ClosedRange<Int> {
        if case .numbers(let range, _) = config.type { return range }
        return 0...100
    }

    private var numberStep: Int {
        if case .numbers(_, let step) = config.type { return step }
        return 1
    }

    private var payloadValues: [String] {
        PayloadType.generate(config.type, wordlist: config.wordlist)
    }

    // MARK: Mutation

    private func mutate(_ transform: (inout IntruderConfig) -> Void) {
        var copy = config
        transform(&copy)
        onChange(copy)
    }

    private func setType(_ type: PayloadType) {
        var copy = config
        if case .custom = type {
            copy.type = .custom(wordlist: wordlistValues)
        } else {
            copy.type = type
        }
        onChange(copy)
    }

    private var wordlistValues: [String] {
        wordlistText
            .split(separator: "\n", omittingEmptySubsequences: true)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }

    private func loadWordlist(_ name: String) {
        wordlistName = name
        wordlistText = Wordlists.builtIn(name).joined(separator: "\n")
        pushWordlist()
    }

    private func pushWordlist() {
        var copy = config
        let values = wordlistValues
        copy.type = .custom(wordlist: values)
        onChange(copy)
    }

    // MARK: Body

    var body: some View {
        ScrollView(.vertical, showsIndicators: true) {
            VStack(alignment: .leading, spacing: 10) {
                SectionLabel(text: "Payloads")
                payloadSection

                Rectangle().fill(Theme.divider).frame(height: 1)
                SectionLabel(text: "Requests")
                concurrencySection

                Rectangle().fill(Theme.divider).frame(height: 1)
                SectionLabel(text: "Match rules")
                matchSection

                Rectangle().fill(Theme.divider).frame(height: 1)
                SectionLabel(text: "Options")
                optionsSection
            }
            .padding(.bottom, 10)
        }
        .background(Theme.surface)
        .onAppear {
            wordlistText = config.wordlist.joined(separator: "\n")
            if config.type.isCustom { showWordlist = true }
        }
    }

    // MARK: Sections

    private var payloadSection: some View {
        VStack(alignment: .leading, spacing: 7) {
            DarkPicker(title: "Payloads", selection: payloadBinding, options: payloadOptions, width: 190)

            if case .numbers = config.type {
                HStack(spacing: 10) {
                    IntruderNumberField(label: "From", value: Binding(
                        get: { numberRange.lowerBound },
                        set: { new in
                            var copy = config
                            let low = min(new, numberRange.upperBound)
                            copy.type = .numbers(range: low...numberRange.upperBound, step: numberStep)
                            onChange(copy)
                        }
                    ), width: 70)
                    IntruderNumberField(label: "To", value: Binding(
                        get: { numberRange.upperBound },
                        set: { new in
                            var copy = config
                            let high = max(new, numberRange.lowerBound)
                            copy.type = .numbers(range: numberRange.lowerBound...high, step: numberStep)
                            onChange(copy)
                        }
                    ), width: 70)
                    IntruderNumberField(label: "Step", value: Binding(
                        get: { numberStep },
                        set: { new in
                            var copy = config
                            copy.type = .numbers(range: numberRange, step: new == 0 ? 1 : new)
                            onChange(copy)
                        }
                    ), width: 60)
                }
            }

            if config.type.isCustom {
                HStack(spacing: 8) {
                    Text("Wordlist")
                        .font(Theme.ui(11))
                        .foregroundStyle(Theme.textTertiary)
                        .frame(width: 88, alignment: .trailing)
                    Picker("", selection: Binding(
                        get: { wordlistName },
                        set: { loadWordlist($0) }
                    )) {
                        ForEach(Wordlists.names, id: \.self) { Text($0).tag($0) }
                    }
                    .labelsHidden()
                    .pickerStyle(.menu)
                    .font(Theme.ui(12))
                    .frame(width: 150)
                    Button {
                        loadWordlist(wordlistName)
                    } label: {
                        Label("Load", systemImage: "arrow.down.doc")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                    CrimsonToggle(isOn: $showWordlist, label: "Edit list")
                    Spacer(minLength: 0)
                }

                if showWordlist {
                    TextEditor(text: $wordlistText)
                        .font(Theme.monoSwiftUI(11))
                        .foregroundStyle(Theme.textPrimary)
                        .scrollContentBackground(.hidden)
                        .background(Theme.background)
                        .overlay(
                            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                .strokeBorder(Theme.divider, lineWidth: 1)
                        )
                        .frame(height: 90)
                        .onChange(of: wordlistText) { _, _ in pushWordlist() }
                    Text("\(wordlistValues.count) payload\(wordlistValues.count == 1 ? "" : "s") — one entry per line")
                        .font(Theme.ui(10))
                        .foregroundStyle(Theme.textTertiary)
                }
            }

            HStack(spacing: 6) {
                Text("\(payloadValues.count) payload\(payloadValues.count == 1 ? "" : "s") generated")
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)
                if let first = payloadValues.first {
                    Text("first: \(first)")
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textTertiary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }
                Spacer(minLength: 0)
            }
        }
        .padding(.horizontal, 10)
    }

    private var concurrencySection: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 10) {
                IntruderNumberField(label: "Concurrency", value: Binding(
                    get: { config.maxConcurrent },
                    set: { new in
                        mutate { $0.maxConcurrent = min(max(1, new), 32) }
                    }
                ), width: 62)
                Stepper("") {
                    mutate { $0.maxConcurrent = min(32, max(1, $0.maxConcurrent + 1)) }
                } onDecrement: {
                    mutate { $0.maxConcurrent = max(1, $0.maxConcurrent - 1) }
                }
                .controlSize(.small)
            }

            HStack(spacing: 10) {
                IntruderNumberField(label: "Payload limit", value: Binding(
                    get: { config.payloadsPerPosition },
                    set: { new in
                        mutate { $0.payloadsPerPosition = max(0, new) }
                    }
                ), width: 62)
                IntruderNumberField(label: "Delay ms", value: Binding(
                    get: { config.delayMS },
                    set: { new in
                        mutate { $0.delayMS = max(0, new) }
                    }
                ), width: 62)
                IntruderNumberField(label: "Timeout s", value: Binding(
                    get: { config.timeoutSeconds },
                    set: { new in
                        mutate { $0.timeoutSeconds = min(max(1, new), 300) }
                    }
                ), width: 62)
            }
            Text("Payload limit 0 means the whole payload set is used.")
                .font(Theme.ui(10))
                .foregroundStyle(Theme.textTertiary)
        }
        .padding(.horizontal, 10)
    }

    private var matchSection: some View {
        VStack(alignment: .leading, spacing: 7) {
            DarkPicker(title: "Status", selection: statusBinding, options: [
                (.unchanged, "Status unchanged"),
                (.changed, "Status changed"),
                (.equal, "Status = N"),
                (.inRange, "Status in range"),
            ])

            switch IntruderStatusChoice(config.matchStatus) {
            case .equal:
                IntruderNumberField(label: "Code", value: Binding(
                    get: { statusValue },
                    set: { new in mutate { $0.matchStatus = .equal(new) } }
                ), width: 70)
            case .inRange:
                HStack(spacing: 10) {
                    IntruderNumberField(label: "From", value: Binding(
                        get: { statusLow },
                        set: { new in
                            mutate {
                                let low = min(new, statusHigh)
                                $0.matchStatus = .inRange(low...max(low, statusHigh))
                            }
                        }
                    ), width: 70)
                    IntruderNumberField(label: "To", value: Binding(
                        get: { statusHigh },
                        set: { new in
                            mutate {
                                let high = max(new, statusLow)
                                $0.matchStatus = .inRange(min(statusLow, high)...high)
                            }
                        }
                    ), width: 70)
                }
            case .unchanged, .changed:
                EmptyView()
            }

            DarkPicker(title: "Length", selection: sizeBinding, options: [
                (.unchanged, "Length unchanged"),
                (.changed, "Length changed"),
                (.equal, "Length = N"),
                (.inRange, "Length in range"),
                (.greaterThan, "Length > N"),
                (.lessThan, "Length < N"),
            ])

            switch IntruderSizeChoice(config.matchSize) {
            case .equal:
                IntruderNumberField(label: "Bytes", value: Binding(
                    get: { sizeValue },
                    set: { new in mutate { $0.matchSize = .equal(new) } }
                ), width: 70)
            case .greaterThan:
                IntruderNumberField(label: "Bytes", value: Binding(
                    get: { sizeValue },
                    set: { new in mutate { $0.matchSize = .greaterThan(new) } }
                ), width: 70)
            case .lessThan:
                IntruderNumberField(label: "Bytes", value: Binding(
                    get: { sizeValue },
                    set: { new in mutate { $0.matchSize = .lessThan(new) } }
                ), width: 70)
            case .inRange:
                HStack(spacing: 10) {
                    IntruderNumberField(label: "From", value: Binding(
                        get: { sizeLow },
                        set: { new in
                            mutate {
                                let low = min(new, sizeHigh)
                                $0.matchSize = .inRange(low...max(low, sizeHigh))
                            }
                        }
                    ), width: 70)
                    IntruderNumberField(label: "To", value: Binding(
                        get: { sizeHigh },
                        set: { new in
                            mutate {
                                let high = max(new, sizeLow)
                                $0.matchSize = .inRange(min(sizeLow, high)...high)
                            }
                        }
                    ), width: 70)
                }
            case .unchanged, .changed:
                EmptyView()
            }

            LabelledField(
                label: "Marker",
                text: Binding(
                    get: { config.matchMarker },
                    set: { new in mutate { $0.matchMarker = new } }
                ),
                placeholder: "match body contains…",
                mono: true,
                width: 240
            )
            Text("A non-empty marker overrides the status and length rules.")
                .font(Theme.ui(10))
                .foregroundStyle(Theme.textTertiary)
        }
        .padding(.horizontal, 10)
    }

    private var optionsSection: some View {
        VStack(alignment: .leading, spacing: 7) {
            CrimsonToggle(isOn: Binding(
                get: { config.greedy },
                set: { new in mutate { $0.greedy = new } }
            ), label: "Greedy matching")
            CrimsonToggle(isOn: Binding(
                get: { config.followRedirects },
                set: { new in mutate { $0.followRedirects = new } }
            ), label: "Follow redirects")
        }
        .padding(.horizontal, 10)
    }
}

// ============================================================================
//  Results
// ============================================================================

private struct IntruderResultsTab: View {
    let job: IntruderEngine.IntruderJob
    let results: [IntruderResult]
    let matchedTotal: Int
    @Binding var onlyMatched: Bool
    let onInspect: (IntruderResult) -> Void
    let onCopyCSV: () -> Void

    private var progress: (done: Int, total: Int) {
        IntruderEngine.shared.progress(for: job.id)
    }

    var body: some View {
        VStack(spacing: 0) {
            controls
            Rectangle().fill(Theme.divider).frame(height: 1)
            header
            Rectangle().fill(Theme.divider).frame(height: 1)
            table
        }
        .background(Theme.background)
    }

    private var controls: some View {
        VStack(spacing: 6) {
            HStack(spacing: 10) {
                Text("\(progress.done)/\(progress.total)")
                    .font(Theme.monoSwiftUI(11))
                    .foregroundStyle(Theme.textSecondary)
                    .frame(width: 86, alignment: .leading)

                ProgressView(value: Double(progress.done), total: Double(max(1, progress.total)))
                    .progressViewStyle(.linear)
                    .tint(Theme.crimson)

                Text("\(results.count) shown · \(matchedTotal) matched")
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)

                Spacer(minLength: 8)

                CrimsonToggle(isOn: $onlyMatched, label: "Only matches")

                Button {
                    onCopyCSV()
                } label: {
                    Label("Copy as CSV", systemImage: "tablecells")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                .disabled(results.isEmpty)
                .opacity(results.isEmpty ? 0.5 : 1)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Theme.surfaceRaised)
    }

    private var header: some View {
        HStack(spacing: 0) {
            Text("#").frame(width: 46, alignment: .leading)
            Text("Payload").frame(maxWidth: .infinity, alignment: .leading)
            Text("Status").frame(width: 54, alignment: .leading)
            Text("Length").frame(width: 66, alignment: .trailing)
            Text("Time").frame(width: 62, alignment: .trailing)
            Text("Match").frame(width: 52, alignment: .trailing)
        }
        .font(Theme.ui(10, weight: .semibold))
        .foregroundStyle(Theme.textTertiary)
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(Theme.surface)
    }

    @ViewBuilder
    private var table: some View {
        if results.isEmpty {
            EmptyHint(
                icon: "list.bullet.rectangle",
                title: onlyMatched ? "No matches yet" : "No results yet",
                subtitle: onlyMatched
                    ? "Nothing matched the current status / length / marker rules."
                    : "Press Start in the toolbar to run this job."
            )
        } else {
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 0) {
                    ForEach(results) { result in
                        IntruderResultRow(result: result) { onInspect(result) }
                        Rectangle().fill(Theme.divider.opacity(0.5)).frame(height: 1)
                    }
                }
            }
        }
    }
}

private struct IntruderResultRow: View {
    let result: IntruderResult
    let onTap: () -> Void

    var body: some View {
        HStack(spacing: 0) {
            Text("\(result.index)")
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 46, alignment: .leading)

            Text(result.label)
                .font(Theme.monoSwiftUI(11))
                .foregroundStyle(result.isBaseline ? Theme.textTertiary : Theme.textPrimary)
                .lineLimit(1)
                .truncationMode(.middle)
                .frame(maxWidth: .infinity, alignment: .leading)

            HStack(spacing: 4) {
                StatusChip(status: result.status)
                if result.error != nil {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 8))
                        .foregroundStyle(Theme.danger)
                }
            }
            .frame(width: 54, alignment: .leading)

            Text(Format.bytes(result.length))
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textSecondary)
                .frame(width: 66, alignment: .trailing)

            Text(Format.ms(result.timeMS))
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 62, alignment: .trailing)

            Group {
                if result.matched {
                    Badge(text: "MATCH", color: Theme.success, filled: true)
                } else {
                    Text("—").foregroundStyle(Theme.textTertiary)
                }
            }
            .font(Theme.monoSwiftUI(10))
            .frame(width: 52, alignment: .trailing)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(result.matched ? Theme.crimson.opacity(0.10) : Color.clear)
        .contentShape(Rectangle())
        .onTapGesture { onTap() }
        .help(result.error ?? "Inspect this exchange")
    }
}

// ============================================================================
//  Result inspector sheet
// ============================================================================

private enum IntruderResultSide: Hashable {
    case request, response
}

private struct IntruderResultSheet: View {
    let result: IntruderResult
    @State private var side: IntruderResultSide = .response
    @Environment(\.dismiss) private var dismiss

    private var message: HTTPMessage? {
        switch side {
        case .request: return result.request
        case .response: return result.response
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            header
            Rectangle().fill(Theme.divider).frame(height: 1)
            if let request = result.request {
                ExchangeSummaryBar(
                    request: request,
                    response: result.response,
                    host: "",
                    isSecure: false,
                    note: result.label,
                    tags: result.matched ? ["MATCH"] : []
                )
                Rectangle().fill(Theme.divider).frame(height: 1)
            }
            SegmentBar(
                selection: $side,
                options: [
                    (.request, "Request", "paperplane"),
                    (.response, "Response", "arrow.down.circle"),
                ],
                compact: true
            )
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            Rectangle().fill(Theme.divider).frame(height: 1)
            content
            Rectangle().fill(Theme.divider).frame(height: 1)
            footer
        }
        .frame(minWidth: 720, minHeight: 460)
        .background(Theme.background)
        .foregroundStyle(Theme.textPrimary)
    }

    private var header: some View {
        HStack(spacing: 8) {
            Text("Result #\(result.index)")
                .font(Theme.ui(12, weight: .semibold))
                .foregroundStyle(Theme.textPrimary)
            Text(result.label)
                .font(Theme.monoSwiftUI(11))
                .foregroundStyle(Theme.textSecondary)
                .lineLimit(1)
                .truncationMode(.middle)
            if result.matched {
                Badge(text: "MATCH", color: Theme.success, filled: true)
            }
            Spacer(minLength: 8)
            Text("\(Format.bytes(result.length)) · \(Format.ms(result.timeMS))")
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textTertiary)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Theme.surfaceRaised)
    }

    @ViewBuilder
    private var content: some View {
        if let message {
            MessageInspector(message: Binding(
                get: { message },
                set: { _ in }
            ), isEditable: false)
        } else if result.error != nil {
            EmptyHint(
                icon: "wifi.exclamationmark",
                title: "No response",
                subtitle: result.error ?? "The request produced no reply."
            )
        } else {
            EmptyHint(
                icon: "doc.questionmark",
                title: side == .request ? "No request recorded" : "No response recorded",
                subtitle: "This result was captured without a full exchange."
            )
        }
    }

    private var footer: some View {
        HStack(spacing: 8) {
            Button {
                copy(message?.prettyRaw)
            } label: {
                Label("Copy", systemImage: "doc.on.doc")
            }
            .buttonStyle(GhostButtonStyle(compact: true))
            .disabled(message == nil)
            .opacity(message == nil ? 0.5 : 1)

            Spacer(minLength: 0)

            Button {
                dismiss()
            } label: {
                Label("Close", systemImage: "xmark")
            }
            .buttonStyle(CrimsonButtonStyle(prominent: false, compact: true))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Theme.surface)
    }

    private func copy(_ text: String?) {
        guard let text else { return }
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
    }
}