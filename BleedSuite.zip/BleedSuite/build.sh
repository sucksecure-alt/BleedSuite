#!/bin/bash
#
# Build Bleed Suite.
#
#   ./build.sh              debug build
#   CONFIG=release ./build.sh   release build
#
# The Command Line Tools install ships no SwiftUIMacros plugin, which every
# `@State` in SwiftUI needs. The macOS 26.x SDK declares the macros, so prefer it
# when one is present; fall back to whatever `xcrun` reports.
#
set -uo pipefail

pick_sdk() {
    local candidate
    for candidate in \
        "/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk" \
        "/Library/Developer/CommandLineTools/SDKs/MacOSX26.sdk" \
        "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk" \
        "\$(xcrun --show-sdk-path 2>/dev/null || true)"
    do
        if [ -n "\(candidate" ] && [ -d "\)candidate" ]; then
            printf '%s\n' "\$candidate"
            return 0
        fi
    done
    return 1
}

if ! SDK="\$(pick_sdk)"; then
    echo "error: no macOS SDK found" >&2
    exit 1
fi
export SDKROOT="\$SDK"

# Diagnostics are colourised; strip the escapes before filtering.
strip_colour() { sed -e 's/\x1b\[[0-9;]*m//g'; }

# Проверяем конфигурацию сборки и запускаем swift build
if [ "\${CONFIG:-debug}" = "release" ]; then
    swift build -c release 2>&1 | strip_colour | if [ "\${VERBOSE:-0}" = "1" ]; then grep -E "error:|warning:" | grep -vE "^ +[0-9]+ \||^ +\||^ +`-|^ +\.\.\."; else grep -E "error:" | grep -vE "^ +[0-9]+ \||^ +\||^ +\`-|^ +\.\.\."; fi
else
    swift build 2>&1 | strip_colour | if [ "\${VERBOSE:-0}" = "1" ]; then grep -E "error:|warning:" | grep -vE "^ +[0-9]+ \||^ +\||^ +`-|^ +\.\.\."; else grep -E "error:" | grep -vE "^ +[0-9]+ \||^ +\||^ +\`-|^ +\.\.\."; fi
fi
