#!/bin/bash
# Build Bleed Suite with the SDK that ships the SwiftUI macros plugin.
set -uo pipefail
cd "$(dirname "$0")"

SDK=""
for candidate in /Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk \
                 /Library/Developer/CommandLineTools/SDKs/MacOSX26.sdk \
                 /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk \
                 "$(xcrun --show-sdk-path 2>/dev/null)"; do
    if [ -d "$candidate" ]; then SDK="$candidate"; break; fi
done
export SDKROOT="$SDK"

swift build -c "${CONFIG:-debug}" 2>&1 | sed 's/\x1b\[[0-9;]*m//g' \
    | grep -E "error:|warning: (unused|var)" \
    | sed "s|$PWD/||" | grep -vE "^ +[0-9]+ \||^ +\||^ +\`-|^ +\.\.\."