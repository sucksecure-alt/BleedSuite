
import SwiftUI
import AppKit

// ============================================================================
//  Comparer workspace
// ============================================================================

/// Field-level diff between two exchanges from the HTTP history.
///
/// Two exchanges are picked from the most recent history rows and `Comparer.compare`
/// turns them into flat rows grouped by section.
struct ComparerView: View {
    @ObservedObject var model = AppModel.shared

    @State private var leftID: Int?
    @State private var rightID: Int?
    @State private var onlyDifferences = true
    @State private var results: [CompareResult] = []

    /// Cap so the picker stays usable during long sessions.
    private static let optionLimit = 500

    // MARK: Body

    var body: some View {
        let rows = recentPairs
        return VStack(spacing: 0) {
            toolbar(rows)
            Rectangle().fill(Theme.divider).frame(height: 1)
            pickerBar(rows)
            Rectangle().fill(Theme.divider).frame(height: 1)
            resultsArea(rows)
        }
        .background(Theme.background)
        .foregroundStyle(Theme.textPrimary)
        .onAppear { prepareSelection(rows) }
        .onChange(of: model.historyGeneration) { _, _ in prepareSelection(rows) }
        .onChange(of: leftID) { _, _ in runCompare(rows) }
        .onChange(of: rightID) { _, _ in runCompare(rows) }
    }

    // MARK: Toolbar

    private func toolbar(_ rows: [HTTPPair]) -> some View {
        WorkspaceToolbar(title: "Comparer", subtitle: subtitle(rows)) {
            HStack(spacing: 10) {
                CrimsonToggle(isOn: $onlyDifferences, label: "Only differences")

                Button {
                    runCompare(rows)
                } label: {
                    Label("Compare", systemImage: "arrow.left.arrow.right")
                }
                .buttonStyle(CrimsonButtonStyle(compact: true))
                .disabled(leftPair(rows) == nil || rightPair(rows) == nil)
                .opacity(leftPair(rows) == nil || rightPair(rows) == nil ? 0.5 : 1)

                if !visibleRows.isEmpty {
                    Text(verbatim: "\(visibleRows.count) row\(visibleRows.count == 1 ? "" : "s")")
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textTertiary)
                }
            }
        }
    }

    private func subtitle(_ rows: [HTTPPair]) -> String {
        guard let left = leftPair(rows), let right = rightPair(rows) else { return "Pick two exchanges" }
        return "#\(left.id) → #\(right.id)"
    }

    // MARK: Picker bar

    private func pickerBar(_ rows: [HTTPPair]) -> some View {
        HStack(spacing: 12) {
            picker(title: "Left", rows: rows, selection: $leftID)
            Text("vs")
                .font(Theme.ui(11, weight: .medium))
                .foregroundStyle(Theme.textTertiary)
            picker(title: "Right", rows: rows, selection: $rightID)

            Spacer(minLength: 8)

            Button {
                prepareSelection(rows, force: true)
            } label: {
                Label("Latest two", systemImage: "clock.arrow.circlepath")
            }
            .buttonStyle(GhostButtonStyle(compact: true))
            .disabled(rows.count < 2)
            .opacity(rows.count < 2 ? 0.5 : 1)
            .help("Compare the two most recent exchanges")
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Theme.surface)
    }

    private func picker(title: String, rows: [HTTPPair], selection: Binding<Int?>) -> some View {
        HStack(spacing: 6) {
            Text(title)
                .font(Theme.ui(11))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 34, alignment: .trailing)

            Picker("", selection: selection) {
                Text("— none —").tag(Int?.none)
                ForEach(rows) { pair in
                    Text(label(for: pair)).tag(Int?.some(pair.id))
                }
            }
            .labelsHidden()
            .pickerStyle(.menu)
            .font(Theme.monoSwiftUI(11))
        }
    }

    private func label(for pair: HTTPPair) -> String {
        "#\(pair.id) \(pair.request.method) \(pair.host)\(pair.request.path)"
    }

    // MARK: Results

    @ViewBuilder
    private func resultsArea(_ rows: [HTTPPair]) -> some View {
        let left = leftPair(rows)
        let right = rightPair(rows)

        if left == nil || right == nil {
            EmptyHint(
                icon: "arrow.left.arrow.right",
                title: "Pick two exchanges",
                subtitle: "Select any two items in the HTTP history to diff their requests and responses."
            )
        } else if visibleRows.isEmpty {
            EmptyHint(
                icon: "equal.circle",
                title: "No differences",
                subtitle: onlyDifferences
                    ? "The two exchanges are identical — turn off \"Only differences\" to list every field."
                    : "The comparer produced no rows for this pair."
            )
        } else {
            comparisonTable(left: left?.id ?? 0, right: right?.id ?? 0)
        }
    }

    private func comparisonTable(left: Int, right: Int) -> some View {
        ScrollView([.vertical, .horizontal], showsIndicators: true) {
            LazyVStack(alignment: .leading, spacing: 0, pinnedViews: [.sectionHeaders]) {
                headerRow(left: left, right: right)
                ForEach(sections, id: \.section) { group in
                    Section {
                        ForEach(group.rows) { row in
                            ComparerRow(result: row)
                            Rectangle().fill(Theme.divider.opacity(0.45)).frame(height: 1)
                        }
                    } header: {
                        HStack(spacing: 8) {
                            Text(group.section.uppercased())
                                .font(Theme.ui(10, weight: .bold))
                                .tracking(1.1)
                                .foregroundStyle(Theme.crimson)
                            Badge(text: "\(group.rows.count)", color: Theme.textSecondary)
                            Spacer(minLength: 0)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Theme.surfaceRaised)
                        .overlay(alignment: .bottom) {
                            Rectangle().fill(Theme.divider).frame(height: 1)
                        }
                    }
                }
                Color.clear.frame(width: 1, height: 8)
            }
            .frame(minWidth: 940, alignment: .leading)
        }
        .background(Theme.background)
    }

    private func headerRow(left: Int, right: Int) -> some View {
        HStack(spacing: 8) {
            Text("Field")
                .font(Theme.ui(10, weight: .semibold))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 180, alignment: .leading)
            Text(verbatim: "#\(left)")
                .font(Theme.ui(10, weight: .semibold))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 360, alignment: .leading)
            Text(verbatim: "#\(right)")
                .font(Theme.ui(10, weight: .semibold))
                .foregroundStyle(Theme.textTertiary)
                .frame(width: 360, alignment: .leading)
            Text("")
                .frame(width: 18)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.surfaceRaised)
        .overlay(alignment: .bottom) {
            Rectangle().fill(Theme.dividerBright).frame(height: 1)
        }
    }

    // MARK: Data

    /// Newest exchanges, trimmed to `optionLimit`.
    private var recentPairs: [HTTPPair] {
        let snapshot = HistoryStore.shared.exportSnapshot()
        return snapshot.count > Self.optionLimit ? Array(snapshot.suffix(Self.optionLimit)) : snapshot
    }

    private func leftPair(_ rows: [HTTPPair]) -> HTTPPair? {
        guard let leftID else { return nil }
        return rows.first(where: { $0.id == leftID })
    }

    private func rightPair(_ rows: [HTTPPair]) -> HTTPPair? {
        guard let rightID else { return nil }
        return rows.first(where: { $0.id == rightID })
    }

    private var visibleRows: [CompareResult] {
        onlyDifferences ? results.filter(\.isDifferent) : results
    }

    private struct SectionGroup {
        let section: String
        let rows: [CompareResult]
    }

    private var sections: [SectionGroup] {
        var order: [String] = []
        var buckets: [String: [CompareResult]] = [:]
        for row in visibleRows {
            if buckets[row.section] == nil {
                order.append(row.section)
                buckets[row.section] = []
            }
            buckets[row.section]?.append(row)
        }
        return order.map { SectionGroup(section: $0, rows: buckets[$0] ?? []) }
    }

    // MARK: Actions

    /// Fills empty / stale selections with the two newest exchanges.
    private func prepareSelection(_ rows: [HTTPPair], force: Bool = false) {
        let leftStale = leftID == nil || force || !rows.contains { $0.id == leftID }
        let rightStale = rightID == nil || force || !rows.contains { $0.id == rightID }
        if leftStale { leftID = rows.count >= 2 ? rows[rows.count - 2].id : rows.first?.id }
        if rightStale { rightID = rows.last?.id }

        // Both slots can legitimately land on the same row: opening the workspace before the
        // second transaction arrives pins left *and* right to the first one, and neither
        // selection looks stale afterwards. The comparer then reports "no differences" between a
        // transaction and itself, which reads like a broken diff rather than an empty result.
        if !force, leftID != nil, leftID == rightID, rows.count >= 2 {
            rightID = rows.last?.id
        }

        runCompare(rows)
    }

    private func runCompare(_ rows: [HTTPPair]) {
        guard let left = leftPair(rows), let right = rightPair(rows), left.id != right.id else {
            results = []
            return
        }
        results = Comparer.compare(left: left, right: right)
    }
}

// ============================================================================
//  Diff row
// ============================================================================

private struct ComparerRow: View {
    let result: CompareResult

    var body: some View {
        HStack(spacing: 8) {
            Text(result.field)
                .font(Theme.monoSwiftUI(11, weight: .semibold))
                .foregroundStyle(Theme.textPrimary)
                .frame(width: 180, alignment: .leading)
                .lineLimit(1)
                .truncationMode(.middle)

            Text(result.left.isEmpty ? "—" : result.left)
                .font(Theme.monoSwiftUI(11))
                .foregroundStyle(result.isDifferent ? Theme.warning : Theme.textSecondary)
                .frame(width: 360, alignment: .leading)
                .lineLimit(2)
                .truncationMode(.tail)
                .textSelection(.enabled)

            Text(result.right.isEmpty ? "—" : result.right)
                .font(Theme.monoSwiftUI(11))
                .foregroundStyle(result.isDifferent ? Theme.crimsonBright : Theme.textSecondary)
                .frame(width: 360, alignment: .leading)
                .lineLimit(2)
                .truncationMode(.tail)
                .textSelection(.enabled)

            Circle()
                .fill(result.isDifferent ? Theme.crimson : Color.clear)
                .frame(width: 7, height: 7)
                .frame(width: 18)
                .help(result.isDifferent ? "different" : "identical")
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(result.isDifferent ? Theme.crimson.opacity(0.06) : Color.clear)
    }
}