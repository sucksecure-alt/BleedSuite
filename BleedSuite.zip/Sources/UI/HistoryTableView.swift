
import SwiftUI
import AppKit

/// `NSTableView`-backed history grid. SwiftUI `List` rebuilds every row on each insert, which
/// is unusable at 60k transactions, so the whole table is driven from AppKit.
struct HistoryTableView: NSViewRepresentable {
    @ObservedObject var model: AppModel

    func makeNSView(context: Context) -> NSScrollView {
        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.autohidesScrollers = true
        scroll.drawsBackground = false
        scroll.borderType = .noBorder
        scroll.documentView = context.coordinator.tableView
        return scroll
    }

    func updateNSView(_ scroll: NSScrollView, context: Context) {
        context.coordinator.reload(model: model)
    }

    func makeCoordinator() -> Coordinator { Coordinator(model: model) }

    final class Coordinator: NSObject, NSTableViewDataSource, NSTableViewDelegate {
        var model: AppModel
        private var lastVisibleCount = -1
        private var lastGeneration = -1
        private var lastSelection: Int?

        init(model: AppModel) { self.model = model }

        /// Built once per coordinator.
        ///
        /// It must stay a stored property: a computed one built a fresh `NSTableView` on every
        /// access, so the view handed to SwiftUI was not the view that received `reloadData`,
        /// selection and the delegate callbacks. Clicks then did nothing.
        lazy var tableView: NSTableView = {
            let table = NSTableView()
            table.usesAlternatingRowBackgroundColors = false
            table.backgroundColor = Theme.NS.background
            table.style = .plain
            table.rowHeight = Theme.rowHeight
            table.intercellSpacing = .zero
            table.columnAutoresizingStyle = .lastColumnOnlyAutoresizingStyle
            table.allowsColumnReordering = false
            table.allowsMultipleSelection = false
            table.dataSource = self
            table.delegate = self
            table.usesAutomaticRowHeights = false

            table.addTableColumn(Self.column("#", width: 52, min: 40, id: "id"))
            table.addTableColumn(Self.column("Method", width: 66, min: 52, id: "method"))
            table.addTableColumn(Self.column("Host", width: 190, min: 90, id: "host"))
            table.addTableColumn(Self.column("Path", width: 380, min: 120, id: "path"))
            table.addTableColumn(Self.column("Status", width: 58, min: 48, id: "status"))
            table.addTableColumn(Self.column("Length", width: 68, min: 56, id: "length"))
            table.addTableColumn(Self.column("Type", width: 132, min: 70, id: "mime"))
            table.addTableColumn(Self.column("Time", width: 62, min: 52, id: "time"))
            return table
        }()

        private static func column(_ title: String, width: CGFloat, min: CGFloat, id: String) -> NSTableColumn {
            let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier(id))
            column.title = title
            column.width = width
            column.minWidth = min
            return column
        }

        // MARK: Reload

        func reload(model: AppModel) {
            self.model = model
            let store = HistoryStore.shared
            let visible = store.visibleCount
            let generation = store.generation
            guard visible != lastVisibleCount || generation != lastGeneration else {
                syncSelection()
                return
            }
            lastVisibleCount = visible
            lastGeneration = generation
            let selection = MainActor.assumeIsolated { model.selectedPairID }
            lastSelection = selection

            let table = tableView
            table.reloadData()
            if let id = selection, let row = rowIndex(for: id) {
                table.selectRowIndexes(IndexSet(integer: row), byExtendingSelection: false)
            }
        }

        private func syncSelection() {
            let table = tableView
            guard let id = MainActor.assumeIsolated({ model.selectedPairID }) else {
                if table.selectedRow != -1 { table.deselectAll(nil) }
                return
            }
            if let row = rowIndex(for: id), table.selectedRow != row {
                table.selectRowIndexes(IndexSet(integer: row), byExtendingSelection: false)
            }
        }

        private func rowIndex(for id: Int) -> Int? {
            guard id >= 1, id <= HistoryStore.shared.visibleCount else { return nil }
            return id - 1
        }

        // MARK: Data source

        func numberOfRows(in tableView: NSTableView) -> Int {
            HistoryStore.shared.visibleCount
        }

        func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
            guard let pair = HistoryStore.shared.row(at: row) else { return nil }
            let identifier = tableColumn?.identifier.rawValue ?? ""
            let view = HistoryCellView(id: identifier)
            view.configure(pair: pair, column: identifier)
            return view
        }

        func tableViewSelectionDidChange(_ notification: Notification) {
            let row = tableView.selectedRow
            guard row >= 0, let pair = HistoryStore.shared.row(at: row) else { return }
            lastSelection = pair.id
            MainActor.assumeIsolated { model.selectedPairID = pair.id }
        }
    }
}

/// A single rendered history cell, reused across rows by AppKit.
final class HistoryCellView: NSTableCellView {
    private let label = NSTextField(labelWithString: "")
    private let swatch = NSView()
    private let rightAligned: Set<String> = ["id", "length", "time", "status"]

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        translatesAutoresizingMaskIntoConstraints = false
        wantsLayer = true

        swatch.translatesAutoresizingMaskIntoConstraints = false
        swatch.wantsLayer = true
        swatch.layer?.cornerRadius = 2
        addSubview(swatch)

        label.translatesAutoresizingMaskIntoConstraints = false
        label.lineBreakMode = .byTruncatingTail
        label.font = Theme.mono(11)
        label.drawsBackground = false
        addSubview(label)

        NSLayoutConstraint.activate([
            swatch.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 2),
            swatch.centerYAnchor.constraint(equalTo: centerYAnchor),
            swatch.widthAnchor.constraint(equalToConstant: 2),
            swatch.heightAnchor.constraint(equalToConstant: 14),
            label.leadingAnchor.constraint(equalTo: swatch.trailingAnchor, constant: 6),
            label.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -6),
            label.centerYAnchor.constraint(equalTo: centerYAnchor),
        ])
    }

    init(id: String) {
        super.init(frame: .zero)
        identifier = NSUserInterfaceItemIdentifier(id)
        translatesAutoresizingMaskIntoConstraints = false
        wantsLayer = true

        swatch.translatesAutoresizingMaskIntoConstraints = false
        swatch.wantsLayer = true
        swatch.layer?.cornerRadius = 2
        addSubview(swatch)

        label.translatesAutoresizingMaskIntoConstraints = false
        label.lineBreakMode = .byTruncatingTail
        label.font = Theme.mono(11)
        label.drawsBackground = false
        addSubview(label)

        NSLayoutConstraint.activate([
            swatch.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 2),
            swatch.centerYAnchor.constraint(equalTo: centerYAnchor),
            swatch.widthAnchor.constraint(equalToConstant: 2),
            swatch.heightAnchor.constraint(equalToConstant: 14),
            label.leadingAnchor.constraint(equalTo: swatch.trailingAnchor, constant: 6),
            label.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -6),
            label.centerYAnchor.constraint(equalTo: centerYAnchor),
        ])
    }

    required init?(coder: NSCoder) { fatalError("HistoryCellView does not use NSCoder") }

    func configure(pair: HTTPPair, column: String) {
        label.font = Theme.mono(11)
        label.stringValue = ""
        label.alignment = rightAligned.contains(column) ? .right : .left
        swatch.isHidden = true
        layer?.borderWidth = 0
        layer?.backgroundColor = NSColor.clear.cgColor

        switch column {
        case "id":
            label.stringValue = String(pair.id)
            label.textColor = Theme.NS.textTertiary
        case "method":
            label.stringValue = pair.request.method
            label.textColor = NSColor(hex: Palette.method(pair.request.method))
            label.font = Theme.mono(11, weight: .bold)
        case "host":
            label.stringValue = pair.host
            label.textColor = Theme.NS.textPrimary
        case "path":
            label.stringValue = pair.request.path
            label.textColor = Theme.NS.textSecondary
        case "status":
            label.stringValue = pair.status.map(String.init) ?? "—"
            label.textColor = NSColor(hex: Palette.status(pair.status))
            label.font = Theme.mono(11, weight: .bold)
        case "length":
            label.stringValue = Format.bytes(pair.responseLength)
            label.textColor = Theme.NS.textTertiary
        case "mime":
            label.stringValue = pair.response?.contentType.split(separator: ";").first.map(String.init) ?? ""
            label.textColor = Theme.NS.textTertiary
            label.font = NSFont.systemFont(ofSize: 11)
        case "time":
            label.stringValue = Format.clock(pair.time)
            label.textColor = Theme.NS.textTertiary
        default:
            break
        }

        // Colour-code the origin of the exchange and flag anything that failed.
        if pair.origin != .proxy {
            swatch.isHidden = false
            swatch.layer?.backgroundColor = NSColor(hex: Palette.origin(pair.origin)).cgColor
        }
        if pair.isModified {
            swatch.isHidden = false
            swatch.layer?.backgroundColor = NSColor(hex: UInt32(Palette.originIntruder)).cgColor
        }
        if let error = pair.error, !error.isEmpty {
            layer?.borderWidth = 1
            layer?.borderColor = NSColor(hex: UInt32(Palette.originScanner)).cgColor
        }
    }
}
