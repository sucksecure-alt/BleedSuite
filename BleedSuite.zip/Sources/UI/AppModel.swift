
import SwiftUI
import AppKit

// ============================================================================
//  Workspaces
// ============================================================================

enum Workspace: String, CaseIterable, Identifiable {
    case dashboard, intercept, history, target, repeater, comparer, intruder, scanner, rules, settings

    var id: String { rawValue }

    var title: String {
        switch self {
        case .dashboard: return "Dashboard"
        case .intercept: return "Intercept"
        case .history: return "HTTP history"
        case .target: return "Target"
        case .repeater: return "Repeater"
        case .comparer: return "Comparer"
        case .intruder: return "Intruder"
        case .scanner: return "Scanner"
        case .rules: return "Match / Replace"
        case .settings: return "Settings"
        }
    }

    var icon: String {
        switch self {
        case .dashboard: return "gauge.with.dots.needle.33percent"
        case .intercept: return "hand.raised.fill"
        case .history: return "list.bullet.rectangle"
        case .target: return "point.3.connected.trianglepath.dotted"
        case .repeater: return "arrow.triangle.2.circlepath"
        case .comparer: return "arrow.left.arrow.right"
        case .intruder: return "bolt.fill"
        case .scanner: return "shield.lefthalf.filled.badge.checkmark"
        case .rules: return "arrow.left.arrow.right.square"
        case .settings: return "gearshape.fill"
        }
    }

    var tint: Color {
        switch self {
        case .intercept: return Theme.crimson
        case .intruder: return Theme.warning
        case .scanner: return Theme.danger
        default: return Theme.textSecondary
        }
    }
}

// ============================================================================
//  Application model
// ============================================================================

struct LogEntry: Identifiable, Sendable {
    let id = UUID()
    var time: Date
    var level: LogLevel
    var text: String
}

@MainActor
final class AppModel: ObservableObject, ProxyEventSink {
    static let shared = AppModel()

    // MARK: Proxy

    @Published var proxyRunning = false
    @Published var proxyPort: UInt16 = 8080
    @Published var mitmEnabled = true
    @Published var acceptInvalidTLS = true
    @Published var connectionCount = 0
    @Published var systemProxyEnabled = false
    @Published var networkServiceName: String = "—"

    // MARK: Interception

    @Published var interceptEnabled = false
    @Published var interceptItems: [InterceptItem] = []
    @Published var selectedInterceptID: UUID?
    @Published var interceptRepeat = false

    // MARK: Log

    @Published var logEntries: [LogEntry] = []
    @Published var logFilter: String = ""

    // MARK: Navigation

    @Published var workspace: Workspace = .dashboard
    @Published var selectedPairID: Int?
    @Published var historyFilterText = ""
    @Published var historyFilterHost = ""
    @Published var historyMethods: Set<String> = []
    @Published var historyStatusClasses: Set<StatusClass> = []
    @Published var historyOrigins: Set<HTTPPair.Origin> = []
    @Published var targetTree: [TargetNode] = []
    @Published var selectedTargetPath: String?
    @Published var historyGeneration = 0
    @Published var visibleHistoryCount = 0
    @Published var totalHistoryCount = 0

    // MARK: Scanner

    @Published var scanIssues: [ScanIssue] = []
    @Published var scannerRunning = false
    @Published var activeChecksEnabled = true

    // MARK: CA

    @Published var caFingerprint = "—"
    @Published var caTrusted = false
    @Published var caMessage = ""

    // MARK: Repeater bridge

    let repeater = RepeaterStore.shared

    // MARK: Private

    private var historyFilterDebounce: DispatchWorkItem?
    private var lastHostSignature = ""
    private var pumpTask: Task<Void, Never>?
    private let relay: EventRelay
    private let engine: ProxyEngine
    private let scannerSender = DirectSender.shared

    private init() {
        relay = EventRelay()
        engine = ProxyEngine(relay: relay)
        EngineLog.handler = { [weak self] text, level in
            DispatchQueue.main.async {
                self?.appendLog(text, level)
            }
        }
    }

    // MARK: - Bootstrap

    private var bootstrapped = false

    /// Idempotent: `onAppear` on the window content can fire more than once (reopening the
    /// window, scene restoration), and a second bootstrap started a second listener and logged
    /// everything twice.
    func bootstrap() {
        guard !bootstrapped else { return }
        bootstrapped = true
        relay.install(self)
        Scanner.shared.configure(sender: scannerSender)
        loadPersistedRules()
        ScopeFilterStore.shared.loadFromDisk()
        refreshCAInfo()
        CAInstallation.ensureTrusted()
        // A previous session may have exited without putting the system back.
        restoreProxyIfStale()

        let savedPort = UserDefaults.standard.object(forKey: "proxyPort") as? Int
        if let savedPort, savedPort > 0 { proxyPort = UInt16(savedPort) }
        mitmEnabled = UserDefaults.standard.object(forKey: "mitm") as? Bool ?? true

        startProxy()
        startPumps()
        watchdog.start()
    }

    /// Reports main-thread stalls in the event log — see `StallWatchdog`.
    private let watchdog = StallWatchdog()

    private func startProxy() {
        Task {
            do {
                try await engine.start()
                proxyRunning = true
                appendLog("Proxy started on 127.0.0.1:\(proxyPort)", .good)
            } catch {
                proxyRunning = false
                appendLog("Could not start proxy: \((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)", .bad)
            }
        }
    }

    func toggleProxy() {
        if proxyRunning {
            Task { await engine.stop() }
            proxyRunning = false
            disableSystemProxy()
            appendLog("Proxy stopped", .info)
        } else {
            UserDefaults.standard.set(Int(proxyPort), forKey: "proxyPort")
            startProxy()
        }
    }

    func setPort(_ port: UInt16) {
        guard proxyPort != port else { return }
        proxyPort = port
        UserDefaults.standard.set(Int(port), forKey: "proxyPort")
        guard proxyRunning else { return }
        Task {
            await engine.stop()
            startProxy()
        }
    }

    func setMITM(_ value: Bool) {
        mitmEnabled = value
        UserDefaults.standard.set(value, forKey: "mitm")
    }

    // MARK: - Polling pumps

    /// Set by `--verbose`; makes the stall watchdog announce itself so a broken watchdog is
    /// obvious instead of silently useless.
    @Published var logIsVerbose = ProcessInfo.processInfo.arguments.contains("--verbose")

    private func startPumps() {
        pumpTask?.cancel()
        pumpTask = Task { [weak self] in
            while !Task.isCancelled {
                // Once a second, not four times. Every tick assigns `@Published` properties and
                // each assignment invalidates every view observing `AppModel` — four times a
                // second the whole workspace was re-rendered, which wiped in-progress editor
                // input and made buttons look dead.
                // Every assignment below is guarded on an actual change, so a fast tick is
                // nearly free — and the site map tracks traffic as it arrives instead of
                // trailing it by seconds.
                try? await Task.sleep(nanoseconds: 250_000_000)
                guard let self else { return }
                await MainActor.run { self.refresh() }
            }
        }
    }

    /// Exposed for `--uitest`, which drives the same code path the pump runs on a timer.
    func forceRefresh() {
        refresh()
    }

    /// Whether the launch size has been applied; see `WindowSize`.
    var hasSizedWindow = false

    private func refresh() {
        // Assign only on a real change: `@Published` fires `objectWillChange` on every write,
        // even when the new value equals the old one.
        let generation = HistoryStore.shared.generation
        if historyGeneration != generation { historyGeneration = generation }

        let visible = HistoryStore.shared.visibleCount
        if visibleHistoryCount != visible { visibleHistoryCount = visible }

        let total = HistoryStore.shared.totalCount
        if totalHistoryCount != total { totalHistoryCount = total }

        autoSelectNewestTransactionIfNeeded()
        refreshTargetsIfNeeded()
        refreshScannerIfDue()
        refreshCATrustIfDue()
        if systemProxyCheckDue {
            systemProxyCheckDue = false
            Task { await refreshSystemProxyState() }
        }
    }

    private var systemProxyCheckDue = true

    /// Keeps the inspector populated.
    ///
    /// Landing on the history screen with nothing selected made the whole right-hand pane read
    /// "No request selected", which looked like a broken export rather than an empty selection.
    /// Burp selects the newest transaction; so do we, but only while the analyst has not made a
    /// choice of their own — an explicit selection is never stolen.
    private var lastAutoSelectedGeneration = -1

    private func autoSelectNewestTransactionIfNeeded() {
        guard selectedPairID == nil else { return }
        let store = HistoryStore.shared
        guard store.generation != lastAutoSelectedGeneration, !store.allRows.isEmpty else { return }
        lastAutoSelectedGeneration = store.generation
        selectedPairID = store.allRows.last?.id
    }

    // Each of the following shells out or walks the whole history, so none of them
    // may run on every pump tick. A browser page load can add hundreds of
    // transactions in a second; doing this work 4× per second froze the app.
    private var lastTargetRebuild = Date.distantPast
    private var lastScannerRead = Date.distantPast
    private var lastCATrustRead = Date.distantPast

    /// Feeds captured transactions to the scanner in batches.
    ///
    /// The proxy path only appends an id under a lock (`AppModelScannerBridge`), so a
    /// page load cannot block the accept loop. The pump drains the batch here, on the
    /// main actor, at most once per second.
    private func drainScannerBacklog() {
        let batch = AppModelScannerBridge.shared.drain()
        guard !batch.isEmpty else { return }
        let pairs = batch.compactMap { HistoryStore.shared.pair(withID: $0) }
        guard !pairs.isEmpty else { return }
        Scanner.shared.enqueueAll(pairs)
    }

    /// Rebuilds the site map when the history actually changed.
    ///
    /// Keyed off the host fingerprint, not a timer: on a timer the map read "no targets yet"
    /// for seconds after the history already showed the requests. The rebuild is cheap — a walk
    /// of host and path only, capped at 4k rows — so the 5 s timer is only a backstop.
    private func refreshTargetsIfNeeded(force: Bool = false) {
        let signature = HistoryStore.shared.hostSignature
        let backstop = Date().timeIntervalSince(lastTargetRebuild) > 5
        let changed = signature != lastHostSignature
        guard force || changed || backstop else { return }
        lastHostSignature = signature
        lastTargetRebuild = Date()
        let all = Array(HistoryStore.shared.exportSnapshot().prefix(4_000))
        let tree = TargetTreeBuilder.build(from: all)
        // Assigning an identical tree would still invalidate every view observing the model.
        if tree.count != targetTree.count || force || changed {
            targetTree = tree
        }
    }

    private func refreshScannerIfDue() {
        guard Date().timeIntervalSince(lastScannerRead) > 1.0 else { return }
        lastScannerRead = Date()
        drainScannerBacklog()
        let issues = Scanner.shared.issues()
        if issues != scanIssues { scanIssues = issues }
        let scanning = Scanner.shared.isScanning()
        if scannerRunning != scanning { scannerRunning = scanning }
    }

    /// `security verify-cert` is a subprocess spawn. Never on the hot path.
    private func refreshCATrustIfDue() {
        guard Date().timeIntervalSince(lastCATrustRead) > 10 else { return }
        lastCATrustRead = Date()
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let trusted = CertificateAuthority.shared.isTrusted
            DispatchQueue.main.async {
                guard let self, self.caTrusted != trusted else { return }
                self.caTrusted = trusted
            }
        }
    }

    /// Re-read the real system proxy state, e.g. after the analyst changed it in
    /// System Settings behind our back.
    func requestSystemProxyRefresh() {
        systemProxyCheckDue = true
    }

    // MARK: - History filtering

    /// Nudges the UI after a panel wrote to the store directly, so views that read
    /// through `HistoryStore` re-render immediately instead of on the next tick.
    func touchHistory() {
        historyGeneration = HistoryStore.shared.generation + 1
    }

    /// Rebuilds the filtered index and republishes it.
    func applyHistoryFilter() {
        let filter = HistoryStore.Filter(
            text: historyFilterText,
            host: historyFilterHost,
            methods: historyMethods,
            statusClasses: historyStatusClasses,
            origins: historyOrigins
        )
        HistoryStore.shared.applyFilter(filter)
    }

    func historyFilterChanged() {
        historyFilterDebounce?.cancel()
        let item = DispatchWorkItem { [weak self] in self?.applyHistoryFilter() }
        historyFilterDebounce = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: item)
    }

    func clearHistoryFilters() {
        historyFilterText = ""
        historyFilterHost = ""
        historyMethods = []
        historyStatusClasses = []
        historyOrigins = []
        applyHistoryFilter()
    }

    var selectedPair: HTTPPair? {
        guard let selectedPairID else { return nil }
        return HistoryStore.shared.pair(withID: selectedPairID)
    }

    func clearHistory() {
        HistoryStore.shared.clear()
        selectedPairID = nil
        lastHostSignature = ""
        appendLog("History cleared", .info)
    }

    // MARK: - Interception

    func toggleIntercept() {
        interceptEnabled.toggle()
        // The engine-side flag is set synchronously; only the queue refresh is asynchronous.
        InterceptSwitch.shared.set(interceptEnabled)
        Task { @MainActor in
            await InterceptQueue.shared.setEnabled(interceptEnabled)
            await refreshInterceptQueue()
        }
        appendLog(interceptEnabled ? "Interception on — traffic is being held" : "Interception off", interceptEnabled ? .warn : .info)
    }

    func refreshInterceptQueue() async {
        let snapshot = await InterceptQueue.shared.snapshot()
        let ids = Set(snapshot.map(\.id))
        if let selectedInterceptID, !ids.contains(selectedInterceptID) { self.selectedInterceptID = nil }
        if selectedInterceptID == nil { selectedInterceptID = snapshot.first?.id }
        interceptItems = snapshot
    }

    func forwardIntercept(_ item: InterceptItem, edited: HTTPMessage?) async {
        await InterceptQueue.shared.forward(item.id, edited: edited)
        await refreshInterceptQueue()
    }

    func dropIntercept(_ item: InterceptItem) async {
        await InterceptQueue.shared.drop(item.id)
        await refreshInterceptQueue()
    }

    func forwardAllIntercepts() async {
        await InterceptQueue.shared.forwardAll()
        await refreshInterceptQueue()
        appendLog("Released \(interceptItems.count) held item(s)", .info)
    }

    func dropAllIntercepts() async {
        await InterceptQueue.shared.dropAll()
        await refreshInterceptQueue()
    }

    func setInterceptRepeat(_ value: Bool) {
        interceptRepeat = value
        Task { await InterceptQueue.shared.setRepeating(value) }
    }

    // MARK: - Navigation helpers

    func sendToRepeater(_ pair: HTTPPair) {
        repeater.newTab(from: pair)
        workspace = .repeater
    }

    /// Same as `sendToRepeater`, but the tab starts blank so the analyst can build a
    /// request from scratch instead of inheriting the captured one.
    func newRepeaterTab() {
        repeater.newTab()
        workspace = .repeater
    }

    func filterHistoryByHost(_ host: String) {
        historyFilterHost = host
        applyHistoryFilter()
        workspace = .history
    }

    func filterHistoryByPath(_ host: String, _ path: String) {
        historyFilterHost = host
        historyFilterText = path
        applyHistoryFilter()
        workspace = .history
    }

    func sendToIntruder(_ pair: HTTPPair) {
        workspace = .intruder
        NotificationCenter.default.post(name: .bleedSendToIntruder, object: pair)
    }


    /// Rules are stored as JSON in user defaults so they survive relaunches.
    private func loadPersistedRules() {
        guard let data = UserDefaults.standard.data(forKey: "rules") else { return }
        let rules = RulesEngine.load(from: data)
        if !rules.isEmpty { RulesEngine.shared.replaceAll(rules) }
    }

    func persistRules() {
        UserDefaults.standard.set(RulesEngine.shared.persist(), forKey: "rules")
    }

    // MARK: - Scanner

    func scanSelected(_ pair: HTTPPair) {
        Scanner.shared.setActiveChecks(activeChecksEnabled ? [] : Scanner.shared.activeChecks())
        Task { await Scanner.shared.scanNow(pair: pair) }
        workspace = .scanner
    }

    func rescanAll() {
        Scanner.shared.clear()
        Scanner.shared.enqueueAll(HistoryStore.shared.exportSnapshot())
        Scanner.shared.start()
    }

    // MARK: - CA

    func refreshCAInfo() {
        caFingerprint = CertificateAuthority.shared.fingerprintSHA256
        caTrusted = CertificateAuthority.shared.isTrusted
    }

    func installCA() {
        let result = CertificateAuthority.shared.installTrust()
        caMessage = result.message
        refreshCAInfo()
        appendLog(result.message, result.ok ? .good : .bad)
    }

    func removeCA() {
        let result = CertificateAuthority.shared.removeTrust()
        caMessage = result.message
        refreshCAInfo()
        appendLog(result.message, result.ok ? .good : .bad)
    }

    func rotateCA() {
        do {
            try CertificateAuthority.shared.rotate()
            refreshCAInfo()
            caMessage = "New Root CA generated. Trust it again before intercepting HTTPS."
            appendLog("Root CA rotated", .warn)
        } catch {
            caMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }

    func exportCAPEM() {
        let pem = CertificateAuthority.shared.caCertificatePEM
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(pem, forType: .string)
        caMessage = "CA certificate copied to the clipboard"
    }

    // MARK: - System proxy

    func setSystemProxy(_ enabled: Bool) {
        if !enabled {
            disableSystemProxy()
            return
        }
        Task { await ensureSystemProxy() }
    }

    func disableSystemProxy() {
        Task {
            let manager = SystemProxyManager.shared
            if let snapshot = await manager.loadSavedSnapshot() {
                try? await manager.restore(snapshot)
            } else {
                for service in await manager.targetServices() {
                    try? await manager.disable(service: service.name)
                }
            }
            systemProxyEnabled = false
            appendLog("System proxy restored", .info)
        }
    }

    /// Snapshot-only restore, used on launch in case a previous run exited without
    /// putting the system configuration back.
    func restoreProxyIfStale() {
        Task {
            let manager = SystemProxyManager.shared
            guard let snapshot = await manager.loadSavedSnapshot() else {
                await refreshSystemProxyState()
                return
            }
            let ours = snapshot.services.filter { _, settings in
                settings.webServer == "127.0.0.1" || settings.secureServer == "127.0.0.1"
            }
            // The snapshot only recorded a proxy that already pointed at us, so it
            // is safe to restore — otherwise it describes the user's own settings.
            if ours.count == snapshot.services.count, !ours.isEmpty {
                try? await manager.restore(snapshot)
                await manager.clearSavedSnapshot()
                appendLog("Restored the system proxy left over from a previous session", .info)
            }
            await refreshSystemProxyState()
        }
    }

    /// Opens a browser pointed at the proxy, routing system traffic first when needed.
    ///
    /// Browsers obey the macOS HTTP proxy settings, so traffic only shows up in the
    /// history once the system proxy points at us. Doing that automatically here is
    /// what makes "open browser" actually produce traffic.
    func openBrowser() {
        Task {
            let manager = SystemProxyManager.shared
            if systemProxyEnabled {
                try? await manager.openBrowser(url: "http://heartbleed.ru")
            } else {
                // Enabling the system proxy is a dozen `networksetup` calls, each a few hundred
                // milliseconds. Without a line in the log the button looks dead for all of it.
                appendLog("Configuring the system proxy before opening the browser…", .info)
                let routed = await ensureSystemProxy()
                try? await manager.openBrowser(url: routed ? "http://heartbleed.ru" : nil)
            }
        }
    }

    /// Turns the system proxy on for every traffic-carrying network service without
    /// touching any existing configuration beyond what the snapshot can put back.
    /// Safe to call repeatedly.
    @discardableResult
    func ensureSystemProxy() async -> Bool {
        let manager = SystemProxyManager.shared
        if systemProxyEnabled { return true }

        let services = await manager.targetServices()
        guard !services.isEmpty else {
            appendLog("No active network service found — set the proxy manually in System Settings", .bad)
            return false
        }

        // Snapshot every service first, so a partial failure is still fully reversible.
        var snapshot = SystemProxyManager.Snapshot(savedAt: Date(), services: [:])
        for service in services {
            if let captured = try? await manager.capture(service: service.name) {
                snapshot.services[service.name] = captured.services[service.name]
            }
        }
        try? await manager.saveSnapshot(snapshot)

        var failed: [String] = []
        for service in services {
            do {
                try await manager.enable(service: service.name, port: Int(proxyPort))
            } catch {
                failed.append("\(service.name): \((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)")
            }
        }

        if failed.isEmpty {
            networkServiceName = services.map(\.name).joined(separator: ", ")
            systemProxyEnabled = true
            appendLog("System traffic now goes through 127.0.0.1:\(proxyPort) (\(networkServiceName))", .good)
            return true
        }
        appendLog("System proxy failed on \(failed.joined(separator: "; "))", .bad)
        return false
    }

    /// True when the system proxy already points at this app.
    func refreshSystemProxyState() async {
        let manager = SystemProxyManager.shared
        let services = await manager.targetServices()
        guard !services.isEmpty else {
            systemProxyEnabled = false
            networkServiceName = "—"
            return
        }
        networkServiceName = services.map(\.name).joined(separator: ", ")
        // Routed only when every traffic-carrying service points at us, otherwise
        // the browser would silently use some other interface's configuration.
        var active: [Bool] = []
        for service in services { active.append(await manager.isActive(service: service.name)) }
        systemProxyEnabled = active.allSatisfy { $0 }
    }

    // MARK: - Export

    func exportHistory(as format: ImportFormat) {
        let pairs = HistoryStore.shared.exportSnapshot()
        Task {
            do {
                let text: String
                let ext: String
                switch format {
                case .har:
                    text = Exporter.har(pairs: pairs) { id, side in BodyStore.shared.loadBody(id: id, side: side) }
                    ext = "har"
                case .csv:
                    text = Exporter.csv(pairs: pairs)
                    ext = "csv"
                case .sitemap:
                    text = Exporter.sitemapXML(nodes: TargetTreeBuilder.build(from: pairs))
                    ext = "xml"
                case .project:
                    text = Exporter.projectJSON(pairs: pairs, extra: ["port": String(proxyPort)])
                    ext = "bsproj"
                case .rules:
                    text = Exporter.rulesJSON(rules: RulesEngine.shared.rules)
                    ext = "json"
                }
                let url = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent(FileWriter.suggestFilename(prefix: "bleed-history", ext: ext))
                try text.write(to: url, atomically: true, encoding: .utf8)
                appendLog("Exported \(pairs.count) item(s) to \(url.lastPathComponent)", .good)
                NSWorkspace.shared.activateFileViewerSelecting([url])
            } catch {
                appendLog("Export failed: \((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)", .bad)
            }
        }
    }

    func exportScanIssues() {
        let issues = Scanner.shared.issues()
        guard !issues.isEmpty else {
            appendLog("Nothing to export", .warn)
            return
        }
        Task {
            do {
                let text = Exporter.scanIssuesXML(issues: issues)
                let url = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent(FileWriter.suggestFilename(prefix: "bleed-issues", ext: "xml"))
                try text.write(to: url, atomically: true, encoding: .utf8)
                appendLog("Exported \(issues.count) issue(s)", .good)
                NSWorkspace.shared.activateFileViewerSelecting([url])
            } catch {
                appendLog("Export failed: \(error.localizedDescription)", .bad)
            }
        }
    }

    // MARK: - Project persistence

    func saveProject() {
        let pairs = HistoryStore.shared.exportSnapshot()
        let json = Exporter.projectJSON(pairs: pairs, extra: [
            "port": String(proxyPort),
            "mitm": String(mitmEnabled),
            "rules": Exporter.rulesJSON(rules: RulesEngine.shared.rules),
        ])
        do {
            let url = try ProjectStore.shared.save(name: FileWriter.suggestFilename(prefix: "bleed-project", ext: "bsproj")) {
                Data(json.utf8)
            }
            appendLog("Project saved to \(url.lastPathComponent)", .good)
        } catch {
            appendLog("Could not save the project: \((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)", .bad)
        }
    }

    func loadProjects() -> [URL] {
        ProjectStore.shared.list().sorted { $0.lastPathComponent < $1.lastPathComponent }
    }

    // MARK: - Log

    func appendLog(_ text: String, _ level: LogLevel = .info) {
        logEntries.append(LogEntry(time: Date(), level: level, text: text))
        if logEntries.count > 600 { logEntries.removeFirst(logEntries.count - 600) }
    }

    var filteredLog: [LogEntry] {
        guard !logFilter.isEmpty else { return logEntries.reversed() }
        let needle = logFilter.lowercased()
        return logEntries.reversed().filter { $0.text.lowercased().contains(needle) }
    }

    func clearLog() { logEntries.removeAll() }

    func copyLog() {
        let text = filteredLog.map { "[\(Format.clock($0.time))] [\($0.level.label)] \($0.text)" }.joined(separator: "\n")
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
    }

    // MARK: - ProxyEventSink

    /// Marks that new traffic arrived.
    ///
    /// Deliberately cheap. A page load adds hundreds of transactions per second and
    /// each one used to hop to the main actor and re-run `refresh()` — that storm is
    /// what killed the app under load. The pump tick already re-reads everything once
    /// per 250 ms, so this only bumps the published counters that make the views
    /// re-render.
    nonisolated func transactionCompleted(_ pair: HTTPPair) {
        DispatchQueue.main.async {
            self.totalHistoryCount = HistoryStore.shared.totalCount
            self.visibleHistoryCount = HistoryStore.shared.visibleCount
        }
    }

    nonisolated func log(_ text: String, _ level: LogLevel) {
        DispatchQueue.main.async {
            guard self.logEntries.count < 600 else { return }
            self.appendLog(text, level)
        }
    }

    nonisolated func connectionCountChanged(_ count: Int) {
        // Fires once per session, so a page load queues hundreds of these. Assigning an
        // unchanged value still publishes and re-renders every observing view, so the write is
        // skipped unless the number actually moved.
        DispatchQueue.main.async {
            guard self.connectionCount != count else { return }
            self.connectionCount = count
        }
    }

    nonisolated func proxyStateChanged(_ running: Bool, port: UInt16) {
        DispatchQueue.main.async {
            self.proxyRunning = running
            self.proxyPort = port
        }
    }

    nonisolated func interceptQueueChanged() {
        Task { @MainActor in await self.refreshInterceptQueue() }
    }

    // MARK: - Shutdown

    func shutdown() {
        Task {
            await InterceptQueue.shared.releaseAll(reason: "Shutting down")
            await engine.stop()
            if systemProxyEnabled { await disableSystemProxy() }
        }
        // Give the listener a moment to unwind so the port and system proxy are released.
        RunLoop.current.run(until: Date().addingTimeInterval(1.5))
    }
}

// ============================================================================
//  One-shot CA trust helper
// ============================================================================

enum CAInstallation {
    private static var attempted = false

    /// Installs the Root CA once per launch, in the background, so HTTPS interception
    /// works without the analyst having to do anything.
    static func ensureTrusted() {
        guard !attempted else { return }
        attempted = true
        guard !CertificateAuthority.shared.isTrusted else { return }
        DispatchQueue.global(qos: .utility).async {
            let result = CertificateAuthority.shared.installTrust()
            DispatchQueue.main.async {
                AppModel.shared.caMessage = result.message
            }
        }
    }
}

extension Notification.Name {
    static let bleedSendToIntruder = Notification.Name("bleedSendToIntruder")
    /// Broadcast by the repeater before sending, so open editors commit pending edits.
    static let bleedFlushPendingEdit = Notification.Name("bleedFlushPendingEdit")
}