
import SwiftUI
import AppKit

// ============================================================================
//  Settings workspace
// ============================================================================

/// Configuration surface for the listener, the system proxy, the Root CA, the
/// interception queue, the target scope and project persistence.
///
/// Everything here goes through the existing `AppModel` API; the only piece of
/// state the view owns is what it needs to drive text fields (the port and the
/// scope host input) plus a mirror of `ScopeFilterStore`, which is not observable.
struct SettingsView: View {
    @ObservedObject var model = AppModel.shared

    @State private var portText = ""
    @State private var newHost = ""
    @State private var scope = ScopeFilterStore.shared.filter
    @State private var projects: [URL] = []
    @State private var showRotateConfirm = false

    private var version: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
    }

    var body: some View {
        VStack(spacing: 0) {
            WorkspaceToolbar(title: "Settings", subtitle: "Listener, trust store, interception and scope") {
                HStack(spacing: 8) {
                    proxyStateChip
                    Button {
                        model.openBrowser()
                    } label: {
                        Label("Open browser", systemImage: "safari")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))

                    Button {
                        model.toggleProxy()
                    } label: {
                        Label(model.proxyRunning ? "Stop proxy" : "Start proxy",
                              systemImage: model.proxyRunning ? "stop.fill" : "play.fill")
                    }
                    .buttonStyle(CrimsonButtonStyle(compact: true))
                }
            }

            Rectangle().fill(Theme.divider).frame(height: 1)

            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    proxySection
                    systemProxySection
                    certificateSection
                    interceptionSection
                    scopeSection
                    dataSection
                    aboutSection
                }
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(Theme.background)
        }
        .background(Theme.background)
        .confirmationDialog(
            "Rotate the Root CA?",
            isPresented: $showRotateConfirm,
            titleVisibility: .visible
        ) {
            Button("Rotate Root CA", role: .destructive) { model.rotateCA() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("A brand new key pair is generated and every cached leaf certificate is thrown away. "
                 + "The new Root CA has to be trusted again before HTTPS can be intercepted.")
        }
        .onAppear(perform: reload)
        .onChange(of: model.proxyPort) { _, _ in portText = String(model.proxyPort) }
    }

    // MARK: - Sections

    private var proxySection: some View {
        SettingsSection(title: "Proxy") {
            VStack(alignment: .leading, spacing: 10) {
                SettingsRow(title: "Listening port",
                            help: "Changing the port restarts the listener when it is running.") {
                    HStack(spacing: 8) {
                        TextField("8080", text: $portText)
                            .textFieldStyle(.plain)
                            .font(Theme.monoSwiftUI(12))
                            .foregroundStyle(Theme.textPrimary)
                            .padding(.horizontal, 7)
                            .padding(.vertical, 4)
                            .background(
                                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                    .fill(Theme.background)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                    .strokeBorder(Theme.divider, lineWidth: 1)
                            )
                            .frame(width: 96)
                        Button("Apply", action: applyPort)
                            .buttonStyle(CrimsonButtonStyle(compact: true))
                    }
                }

                SettingsRow(title: "Transport") {
                    CrimsonToggle(
                        isOn: Binding(get: { model.mitmEnabled }, set: { model.setMITM($0) }),
                        label: "Intercept HTTPS (MITM)"
                    )
                }

                SettingsRow(title: "Upstream TLS",
                            help: "Continue when the origin server presents an expired or self-signed certificate.") {
                    CrimsonToggle(
                        isOn: Binding(get: { model.acceptInvalidTLS }, set: { model.acceptInvalidTLS = $0 }),
                        label: "Accept invalid upstream certificates"
                    )
                }

                Rectangle().fill(Theme.divider).frame(height: 1)

                SettingsRow(title: "Listener") {
                    HStack(spacing: 8) {
                        Button {
                            model.toggleProxy()
                        } label: {
                            Label(model.proxyRunning ? "Stop proxy" : "Start proxy",
                                  systemImage: model.proxyRunning ? "stop.fill" : "play.fill")
                        }
                        .buttonStyle(CrimsonButtonStyle(compact: true))

                        proxyStateChip
                    }
                }

                SettingsRow(title: "Connections") {
                    Text(verbatim: "\(model.connectionCount)")
                        .font(Theme.monoSwiftUI(12, weight: .semibold))
                        .foregroundStyle(Theme.textSecondary)
                }
            }
        }
    }

    private var systemProxySection: some View {
        SettingsSection(title: "System proxy") {
            VStack(alignment: .leading, spacing: 10) {
                SettingsRow(title: "Routing",
                            help: "Points the primary network service at 127.0.0.1:\(model.proxyPort).") {
                    CrimsonToggle(
                        isOn: Binding(get: { model.systemProxyEnabled }, set: { model.setSystemProxy($0) }),
                        label: "Route system traffic through Bleed Suite"
                    )
                }

                SettingsRow(title: "Network service") {
                    Text(model.systemProxyEnabled ? model.networkServiceName : "not routed")
                        .font(Theme.monoSwiftUI(11))
                        .foregroundStyle(model.systemProxyEnabled ? Theme.success : Theme.textTertiary)
                }

                SettingsRow(title: "Actions") {
                    HStack(spacing: 8) {
                        Button {
                            model.openBrowser()
                        } label: {
                            Label("Open browser", systemImage: "safari")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))

                        Button {
                            model.disableSystemProxy()
                        } label: {
                            Label("Restore now", systemImage: "arrow.uturn.backward")
                        }
                        .buttonStyle(GhostButtonStyle(tint: Theme.warning, compact: true))
                    }
                }

                Text("Bleed Suite talks to networksetup(8) as the current user, so macOS may ask for an "
                     + "administrator password the first time. The previous configuration is snapshotted to "
                     + "~/Library/Application Support/BleedSuite/systemproxy.json and is restored on quit.")
                    .font(Theme.ui(10))
                    .foregroundStyle(Theme.textTertiary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var certificateSection: some View {
        SettingsSection(title: "Certificate authority") {
            VStack(alignment: .leading, spacing: 10) {
                SettingsRow(title: "Trust status") {
                    HStack(spacing: 6) {
                        Circle()
                            .fill(model.caTrusted ? Theme.success : Theme.warning)
                            .frame(width: 7, height: 7)
                        Text(model.caTrusted ? "Trusted" : "Not trusted")
                            .font(Theme.ui(12, weight: .semibold))
                            .foregroundStyle(model.caTrusted ? Theme.success : Theme.warning)
                        Badge(text: CertificateAuthority.shared.subjectSummary,
                              color: model.caTrusted ? Theme.success : Theme.warning)
                    }
                }

                SettingsRow(title: "SHA-256 fingerprint") {
                    Text(model.caFingerprint)
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textSecondary)
                        .textSelection(.enabled)
                        .lineLimit(3)
                        .truncationMode(.middle)
                        .fixedSize(horizontal: false, vertical: true)
                }

                if !model.caMessage.isEmpty {
                    SettingsRow(title: "Last result") {
                        Text(model.caMessage)
                            .font(Theme.ui(11))
                            .foregroundStyle(model.caTrusted ? Theme.success : Theme.warning)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }

                SettingsRow(title: "Actions") {
                    HStack(spacing: 8) {
                        Button {
                            model.refreshCAInfo()
                            model.installCA()
                        } label: {
                            Label(model.caTrusted ? "Re-trust" : "Install",
                                  systemImage: "checkmark.shield")
                        }
                        .buttonStyle(CrimsonButtonStyle(compact: true))

                        Button {
                            model.removeCA()
                        } label: {
                            Label("Remove", systemImage: "trash")
                        }
                        .buttonStyle(GhostButtonStyle(tint: Theme.danger, compact: true))

                        Button {
                            model.exportCAPEM()
                        } label: {
                            Label("Copy CA certificate", systemImage: "doc.on.doc")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))

                        Button {
                            showRotateConfirm = true
                        } label: {
                            Label("Rotate Root CA", systemImage: "arrow.triangle.2.circlepath")
                        }
                        .buttonStyle(GhostButtonStyle(tint: Theme.warning, compact: true))
                    }
                }

                Text("HTTPS is only interceptable while the Root CA validates against the login keychain. "
                     + "Rotating it invalidates the current CA — copy the PEM before handing it to another machine.")
                    .font(Theme.ui(10))
                    .foregroundStyle(Theme.textTertiary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var interceptionSection: some View {
        SettingsSection(title: "Interception") {
            VStack(alignment: .leading, spacing: 10) {
                SettingsRow(title: "Hold traffic",
                            help: "Requests and responses wait in the Intercept queue until they are forwarded or dropped.") {
                    CrimsonToggle(
                        isOn: Binding(
                            get: { model.interceptEnabled },
                            set: { wanted in
                                guard wanted != model.interceptEnabled else { return }
                                model.toggleIntercept()
                            }
                        ),
                        label: "Intercept requests and responses"
                    )
                }

                SettingsRow(title: "Queue") {
                    HStack(spacing: 8) {
                        Badge(text: "\(model.interceptItems.count) held",
                              color: model.interceptItems.isEmpty ? Theme.textSecondary : Theme.crimson)
                        Button {
                            Task { await model.forwardAllIntercepts() }
                        } label: {
                            Label("Forward all", systemImage: "arrow.right")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))
                        .disabled(model.interceptItems.isEmpty)

                        Button {
                            Task { await model.dropAllIntercepts() }
                        } label: {
                            Label("Drop all", systemImage: "trash")
                        }
                        .buttonStyle(GhostButtonStyle(tint: Theme.danger, compact: true))
                        .disabled(model.interceptItems.isEmpty)
                    }
                }

                SettingsRow(title: "Repeating",
                            help: "Keep the interceptor active until the queue is released explicitly.") {
                    CrimsonToggle(
                        isOn: Binding(get: { model.interceptRepeat }, set: { model.setInterceptRepeat($0) }),
                        label: "Repeat last request"
                    )
                }

                SettingsRow(title: "Workspace") {
                    Button {
                        model.workspace = .intercept
                    } label: {
                        Label("Open intercept queue", systemImage: "hand.raised.fill")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                }
            }
        }
    }

    private var scopeSection: some View {
        SettingsSection(title: "Scope") {
            VStack(alignment: .leading, spacing: 10) {
                SettingsRow(title: "Require HTTPS",
                            help: "Plain HTTP traffic is treated as out of scope.") {
                    CrimsonToggle(
                        isOn: Binding(get: { scope.requireHTTPS },
                                      set: { value in persist { $0.requireHTTPS = value } }),
                        label: "HTTPS only"
                    )
                }

                SettingsRow(title: "Add host",
                            help: "Wildcards such as *.example.com are preserved.") {
                    HStack(spacing: 8) {
                        TextField("api.example.com", text: $newHost)
                            .textFieldStyle(.plain)
                            .font(Theme.monoSwiftUI(12))
                            .foregroundStyle(Theme.textPrimary)
                            .padding(.horizontal, 7)
                            .padding(.vertical, 4)
                            .background(
                                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                    .fill(Theme.background)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                    .strokeBorder(Theme.divider, lineWidth: 1)
                            )
                            .frame(width: 200)
                            .onSubmit(addHost)
                        Button("Add", action: addHost)
                            .buttonStyle(CrimsonButtonStyle(compact: true))
                    }
                }

                VStack(alignment: .leading, spacing: 6) {
                    SectionLabel(text: "In scope", trailing: "\(scope.includedHosts.count) host(s)")

                    if scope.includedHosts.isEmpty {
                        Text("Every host is in scope. Add one above to narrow the scope.")
                            .font(Theme.ui(11))
                            .foregroundStyle(Theme.textTertiary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.vertical, 6)
                    } else {
                        VStack(spacing: 0) {
                            ForEach(Array(scope.includedHosts.enumerated()), id: \.offset) { index, host in
                                HStack(spacing: 6) {
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(Theme.ui(10))
                                        .foregroundStyle(Theme.success)
                                    Text(host)
                                        .font(Theme.monoSwiftUI(11))
                                        .foregroundStyle(Theme.textPrimary)
                                    Spacer(minLength: 8)
                                    Button {
                                        removeHost(at: index)
                                    } label: {
                                        Image(systemName: "xmark.circle.fill")
                                            .font(Theme.ui(10))
                                            .foregroundStyle(Theme.textTertiary)
                                    }
                                    .buttonStyle(.plain)
                                }
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                Rectangle().fill(Theme.divider.opacity(0.5)).frame(height: 1)
                            }
                        }
                        .background(
                            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                .fill(Theme.background)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                .strokeBorder(Theme.divider, lineWidth: 1)
                        )
                    }
                }

                if !scope.excludedHosts.isEmpty {
                    VStack(alignment: .leading, spacing: 4) {
                        SectionLabel(text: "Excluded", trailing: "\(scope.excludedHosts.count) host(s)")
                        FlowRow(spacing: 6) {
                            ForEach(Array(scope.excludedHosts.enumerated()), id: \.offset) { index, host in
                                Button {
                                    removeExcluded(at: index)
                                } label: {
                                    HStack(spacing: 4) {
                                        Text(host)
                                            .font(Theme.monoSwiftUI(10))
                                        Image(systemName: "xmark")
                                            .font(Theme.ui(7, weight: .bold))
                                    }
                                    .foregroundStyle(Theme.textSecondary)
                                    .padding(.horizontal, 7)
                                    .padding(.vertical, 3)
                                    .background(
                                        Capsule().fill(Theme.surfaceOverlay)
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }

                HStack(spacing: 8) {
                    Button {
                        persist { $0.removeAll() }
                    } label: {
                        Label("Clear scope", systemImage: "trash")
                    }
                    .buttonStyle(GhostButtonStyle(tint: Theme.danger, compact: true))
                    .disabled(!scope.isActive)

                    if scope.isActive {
                        Badge(text: "scope active", color: Theme.info)
                    }
                    Spacer(minLength: 0)
                }
            }
        }
    }

    private var dataSection: some View {
        SettingsSection(title: "Data") {
            VStack(alignment: .leading, spacing: 10) {
                SettingsRow(title: "Project",
                            help: "History, interception settings and match/replace rules in one .bsproj file.") {
                    HStack(spacing: 8) {
                        Button {
                            model.saveProject()
                            reloadProjects()
                        } label: {
                            Label("Save project", systemImage: "square.and.arrow.down")
                        }
                        .buttonStyle(CrimsonButtonStyle(compact: true))

                        Button {
                            model.rescanAll()
                        } label: {
                            Label("Re-scan history", systemImage: "arrow.clockwise")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))

                        Button {
                            model.exportScanIssues()
                        } label: {
                            Label("Export issues", systemImage: "exclamationmark.triangle")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))
                    }
                }

                SettingsRow(title: "Export") {
                    HStack(spacing: 8) {
                        Button {
                            model.exportHistory(as: .har)
                        } label: {
                            Label("HAR", systemImage: "doc.text")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))

                        Button {
                            model.exportHistory(as: .csv)
                        } label: {
                            Label("CSV", systemImage: "tablecells")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))

                        Button {
                            model.exportHistory(as: .sitemap)
                        } label: {
                            Label("Sitemap", systemImage: "point.3.connected.trianglepath.dotted")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))
                    }
                }

                VStack(alignment: .leading, spacing: 6) {
                    SectionLabel(text: "Saved projects", trailing: "\(projects.count)")
                    if projects.isEmpty {
                        Text("No saved projects yet.")
                            .font(Theme.ui(11))
                            .foregroundStyle(Theme.textTertiary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.vertical, 6)
                    } else {
                        VStack(spacing: 0) {
                            ForEach(projects, id: \.self) { url in
                                HStack(spacing: 8) {
                                    Image(systemName: "doc.badge.gearshape")
                                        .font(Theme.ui(10))
                                        .foregroundStyle(Theme.crimson)
                                    VStack(alignment: .leading, spacing: 1) {
                                        Text(url.lastPathComponent)
                                            .font(Theme.monoSwiftUI(11))
                                            .foregroundStyle(Theme.textPrimary)
                                            .lineLimit(1)
                                            .truncationMode(.middle)
                                        Text(url.deletingLastPathComponent().path)
                                            .font(Theme.monoSwiftUI(9))
                                            .foregroundStyle(Theme.textTertiary)
                                            .lineLimit(1)
                                            .truncationMode(.middle)
                                    }
                                    Spacer(minLength: 8)
                                    Button {
                                        NSWorkspace.shared.activateFileViewerSelecting([url])
                                    } label: {
                                        Image(systemName: "folder")
                                            .font(Theme.ui(10))
                                            .foregroundStyle(Theme.textTertiary)
                                    }
                                    .buttonStyle(.plain)
                                }
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                Rectangle().fill(Theme.divider.opacity(0.5)).frame(height: 1)
                            }
                        }
                        .background(
                            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                .fill(Theme.background)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                .strokeBorder(Theme.divider, lineWidth: 1)
                        )
                    }
                }
            }
        }
    }

    private var aboutSection: some View {
        SettingsSection(title: "About") {
            VStack(alignment: .leading, spacing: 10) {
                SettingsRow(title: "Bleed Suite") {
                    Text(verbatim: "v\(version)")
                        .font(Theme.monoSwiftUI(11, weight: .semibold))
                        .foregroundStyle(Theme.textSecondary)
                }

                SettingsRow(title: "Runtime") {
                    Text(verbatim: "SwiftUI · macOS \(ProcessInfo.processInfo.operatingSystemVersionString)")
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textTertiary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }

                Text("Intercepting proxy for macOS: HTTP/HTTPS interception with an on-device Root CA, "
                     + "live request editing, a repeatable manual attacker, host discovery, "
                     + "match/replace rules and passive/active scanning.")
                    .font(Theme.ui(11))
                    .foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)

                SettingsRow(title: "Support folder") {
                    HStack(spacing: 8) {
                        Button {
                            NSWorkspace.shared.open(FileWriter.exportDirectory())
                        } label: {
                            Label("Open support folder", systemImage: "folder")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))

                        Button {
                            NSWorkspace.shared.open(CertificateAuthority.shared.directory)
                        } label: {
                            Label("App support", systemImage: "externaldrive")
                        }
                        .buttonStyle(GhostButtonStyle(compact: true))
                    }
                }

                Text(CertificateAuthority.shared.directory.path)
                    .font(Theme.monoSwiftUI(9))
                    .foregroundStyle(Theme.textTertiary)
                    .textSelection(.enabled)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
        }
    }

    // MARK: - Pieces

    private var proxyStateChip: some View {
        HStack(spacing: 5) {
            Circle()
                .fill(model.proxyRunning ? Theme.success : Theme.danger)
                .frame(width: 6, height: 6)
            Text(verbatim: model.proxyRunning
                 ? "Listening on 127.0.0.1:\(model.proxyPort)"
                 : "Stopped")
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(model.proxyRunning ? Theme.success : Theme.danger)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(
            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                .fill(model.proxyRunning ? Theme.success.opacity(0.10) : Theme.crimson.opacity(0.10))
        )
        .overlay(
            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                .strokeBorder((model.proxyRunning ? Theme.success : Theme.crimson).opacity(0.35), lineWidth: 1)
        )
    }

    // MARK: - Actions

    private func reload() {
        portText = String(model.proxyPort)
        scope = ScopeFilterStore.shared.filter
        reloadProjects()
    }

    private func reloadProjects() {
        projects = model.loadProjects()
    }

    private func applyPort() {
        let digits = portText.trimmingCharacters(in: .whitespaces)
        guard let port = UInt16(digits), port > 0 else {
            portText = String(model.proxyPort)
            return
        }
        model.setPort(port)
        portText = String(model.proxyPort)
    }

    private func addHost() {
        let host = newHost.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !host.isEmpty else { return }
        persist { $0.include(host) }
        newHost = ""
    }

    private func removeHost(at index: Int) {
        guard scope.includedHosts.indices.contains(index) else { return }
        let host = scope.includedHosts[index]
        persist { filter in
            filter.includedHosts.removeAll { ScopeFilter.normalizeHost($0) == ScopeFilter.normalizeHost(host) }
        }
    }

    private func removeExcluded(at index: Int) {
        guard scope.excludedHosts.indices.contains(index) else { return }
        let host = scope.excludedHosts[index]
        persist { filter in
            filter.excludedHosts.removeAll { ScopeFilter.normalizeHost($0) == ScopeFilter.normalizeHost(host) }
        }
    }

    /// Applies a change to the shared scope filter and mirrors it back into local state.
    private func persist(_ change: (inout ScopeFilter) -> Void) {
        ScopeFilterStore.shared.mutate(change)
        ScopeFilterStore.shared.persistToDisk()
        scope = ScopeFilterStore.shared.filter
    }
}

// ============================================================================
//  Settings building blocks
// ============================================================================

/// A titled panel: `Panel` header plus padded content.
private struct SettingsSection<Content: View>: View {
    let title: String
    var trailing: String? = nil
    @ViewBuilder var content: Content

    var body: some View {
        Panel(title: title) {
            VStack(alignment: .leading, spacing: 0) {
                content
            }
        }
        .overlay(alignment: .topTrailing) {
            if let trailing {
                Text(trailing)
                    .font(Theme.monoSwiftUI(9))
                    .foregroundStyle(Theme.textTertiary)
                    .padding(.trailing, 10)
                    .padding(.top, 5)
            }
        }
    }
}

/// Label on the left, control on the right.
private struct SettingsRow<Accessory: View>: View {
    let title: String
    var help: String? = nil
    @ViewBuilder var accessory: Accessory

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(Theme.ui(12, weight: .medium))
                    .foregroundStyle(Theme.textSecondary)
                if let help {
                    Text(help)
                        .font(Theme.ui(10))
                        .foregroundStyle(Theme.textTertiary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .frame(width: 220, alignment: .leading)

            accessory
                .frame(maxWidth: .infinity, alignment: .leading)

            Spacer(minLength: 0)
        }
        .padding(.vertical, 7)
    }
}

/// Minimal wrapping row of pills, used for the excluded-host list.
private struct FlowRow: Layout {
    var spacing: CGFloat = 6

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxWidth = proposal.width ?? .infinity
        var x: CGFloat = 0
        var y: CGFloat = 0
        var rowHeight: CGFloat = 0
        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if x > 0, x + size.width > maxWidth {
                x = 0
                y += rowHeight + spacing
                rowHeight = 0
            }
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
        }
        return CGSize(width: maxWidth == .infinity ? x : maxWidth, height: y + rowHeight)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX
        var y = bounds.minY
        var rowHeight: CGFloat = 0
        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if x > bounds.minX, x + size.width > bounds.maxX {
                x = bounds.minX
                y += rowHeight + spacing
                rowHeight = 0
            }
            subview.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(size))
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
        }
    }
}
