
import SwiftUI
import AppKit

// ============================================================================
//  Sequencer
// ============================================================================

/// Payload-list generator (Burp "Sequencer"). Purely local: `SequencerEngine` turns the
/// config into strings, the view only formats them and offers the export buttons.
///
/// Embedded as `Panel(title: "Sequencer")` inside `IntruderView`.
struct SequencerView: View {
    @State private var config = SequencerConfig()
    @State private var count = 1000
    @State private var stringsText = ""
    @State private var lines: [String] = []

    /// The generated list is capped for rendering — the full list is still exported.
    private static let displayLimit = 500

    // MARK: - Body

    var body: some View {
        VStack(spacing: 0) {
            controls
            Rectangle().fill(Theme.divider).frame(height: 1)
            output
        }
        .background(Theme.background)
        .foregroundStyle(Theme.textPrimary)
    }

    // MARK: - Controls

    private var controls: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                DarkPicker(title: "Type", selection: typeBinding, options: typeOptions, width: 160)

                if config.type != .strings && config.type != .custom {
                    SeqNumberField(label: "Start", value: $config.startValue, width: 70)
                    SeqNumberField(label: "End", value: $config.endValue, width: 70)
                    SeqNumberField(label: "Step", value: $config.step, width: 60)
                }
                SeqNumberField(label: "Count", value: $count, width: 70)
                Spacer(minLength: 8)
            }

            if config.type == .dates {
                HStack(spacing: 10) {
                    LabelledField(
                        label: "Format",
                        text: Binding(
                            get: { config.dateFormat },
                            set: { config.dateFormat = $0 }
                        ),
                        placeholder: "yyyy-MM-dd",
                        mono: true,
                        width: 150
                    )
                    Text("From")
                        .font(Theme.ui(11))
                        .foregroundStyle(Theme.textTertiary)
                    DatePicker(
                        "",
                        selection: $config.baseDate,
                        displayedComponents: .date
                    )
                    .labelsHidden()
                    .datePickerStyle(.compact)
                    .controlSize(.small)
                    .foregroundStyle(Theme.textPrimary)
                    Spacer(minLength: 0)
                }
            }

            if config.type == .strings || config.type == .custom {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Strings — one entry per line, cycled until the count is reached")
                        .font(Theme.ui(10))
                        .foregroundStyle(Theme.textTertiary)
                    TextEditor(text: $stringsText)
                        .font(Theme.monoSwiftUI(11))
                        .foregroundStyle(Theme.textPrimary)
                        .scrollContentBackground(.hidden)
                        .background(Theme.background)
                        .overlay(
                            RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                                .strokeBorder(Theme.divider, lineWidth: 1)
                        )
                        .frame(height: 80)
                }
            }

            HStack(spacing: 8) {
                Button {
                    generate()
                } label: {
                    Label("Generate", systemImage: "wand.and.stars")
                }
                .buttonStyle(CrimsonButtonStyle(compact: true))

                Button {
                    copyAll()
                } label: {
                    Label("Copy", systemImage: "doc.on.doc")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                .disabled(lines.isEmpty)
                .opacity(lines.isEmpty ? 0.5 : 1)

                Button {
                    lines = []
                } label: {
                    Label("Clear", systemImage: "trash")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                .disabled(lines.isEmpty)
                .opacity(lines.isEmpty ? 0.5 : 1)

                Spacer(minLength: 8)

                Text(counterText)
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)
            }
        }
        .padding(10)
        .background(Theme.surface)
    }

    // MARK: - Output

    @ViewBuilder
    private var output: some View {
        if lines.isEmpty {
            EmptyHint(
                icon: "list.number",
                title: "No sequence yet",
                subtitle: "Pick a type, adjust the bounds and press Generate."
            )
        } else {
            ScrollView([.vertical, .horizontal], showsIndicators: true) {
                LazyVStack(alignment: .leading, spacing: 0) {
                    ForEach(Array(lines.prefix(SequencerView.displayLimit).enumerated()), id: \.offset) { index, line in
                        HStack(spacing: 8) {
                            Text(verbatim: "\(index + 1)")
                                .font(Theme.monoSwiftUI(10))
                                .foregroundStyle(Theme.textTertiary)
                                .frame(width: 46, alignment: .trailing)
                            Text(line.isEmpty ? "—" : line)
                                .font(Theme.monoSwiftUI(11))
                                .foregroundStyle(Theme.textPrimary)
                                .textSelection(.enabled)
                            Spacer(minLength: 0)
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 2)
                        .contentShape(Rectangle())
                        Rectangle().fill(Theme.divider.opacity(0.4)).frame(height: 1)
                    }
                }
                .padding(.vertical, 4)
            }
        }
    }

    // MARK: - Bindings and helpers

    private var typeOptions: [(SequencerType, String)] {
        SequencerType.allCases.map { ($0, $0.label) }
    }

    private var typeBinding: Binding<SequencerType> {
        Binding(
            get: { config.type },
            set: { config.type = $0 }
        )
    }

    private var counterText: String {
        lines.isEmpty
            ? "0 items"
            : "\(lines.count) item\(lines.count == 1 ? "" : "s")"
                + (lines.count > SequencerView.displayLimit
                    ? " · showing first \(SequencerView.displayLimit)"
                    : "")
    }

    private func generate() {
        var prepared = config
        prepared.strings = stringsText
            .split(separator: "\n", omittingEmptySubsequences: true)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        lines = SequencerEngine.generate(prepared, count: max(0, count))
    }

    private func copyAll() {
        guard !lines.isEmpty else { return }
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(lines.joined(separator: "\n"), forType: .string)
    }
}

// ============================================================================
//  Numeric field
// ============================================================================

/// `LabelledField`-backed integer input that keeps its own draft text so the field can
/// be emptied while typing.
private struct SeqNumberField: View {
    let label: String
    @Binding var value: Int
    var width: CGFloat? = 80

    @State private var text = ""

    var body: some View {
        LabelledField(label: label, text: $text, placeholder: "", mono: true, width: width)
            .onAppear { text = String(value) }
            .onChange(of: value) { _, _ in
                if Int(text) != value { text = String(value) }
            }
            .onChange(of: text) { _, new in
                if let parsed = Int(new.trimmingCharacters(in: .whitespaces)), parsed != value {
                    value = parsed
                }
            }
    }
}