//
//  In-process UI smoke test.
//
//  Synthetic mouse events cannot be delivered from a shell without Accessibility
//  permission, so the interactive paths are exercised from inside the app instead: the same
//  state objects the buttons mutate, driven on the main actor exactly as a click would.
//
//  Run with `--uitest`.
//

import Foundation
import SwiftUI

@MainActor
enum UITest {

    private static var failures: [String] = []
    private static var checks = 0

    private static func check(_ condition: Bool, _ what: String) {
        checks += 1
        if condition {
            FileHandle.standardOutput.write(Data("  ✓ \(what)\n".utf8))
        } else {
            FileHandle.standardOutput.write(Data("  ✗ \(what)\n".utf8))
            failures.append(what)
        }
    }

    private static func section(_ title: String) {
        FileHandle.standardOutput.write(Data("▸ \(title)\n".utf8))
    }

    static func run() async -> Int32 {
        let model = AppModel.shared

        section("Match / Replace")
        RulesEngine.shared.replaceAll([])
        let before = RulesEngine.shared.rules.count
        var rule = ProxyRule()
        rule.comment = "UI test rule"
        RulesEngine.shared.add(rule)
        check(RulesEngine.shared.rules.count == before + 1, "Add rule appends to the engine")
        let added = RulesEngine.shared.rules.last
        check(added?.comment == "UI test rule", "the new rule carries its comment")
        RulesEngine.shared.update(ProxyRule())
        check(RulesEngine.shared.rules.count == before + 1, "updating a rule does not duplicate it")
        RulesEngine.shared.remove(id: RulesEngine.shared.rules.last?.id ?? UUID())
        check(RulesEngine.shared.rules.count == before, "removing a rule shrinks the list")
        RulesEngine.shared.replaceAll([])

        section("Raw editor round trip")
        // The exact regression: a commit used to rewrite the buffer with the normalised
        // rendering, so the text the analyst typed snapped back on its own.
        var stored = HTTPMessage(isRequest: true, startLine: "GET /one HTTP/1.1",
                                 headers: [Header(name: "Host", value: "example.com")])
        let typed = "POST /typed-by-hand HTTP/1.1\nHost: example.com\nX-Hand:   spaced   value\n\nbody"
        let parsed = HTTPMessage.parseEditorText(typed, isRequest: true)
        stored = parsed
        check(stored.startLine.contains("/typed-by-hand"), "hand-typed request line is parsed")
        check(stored.path == "/typed-by-hand", "hand-typed path is parsed")
        check(stored.header("X-Hand")?.contains("spaced") == true, "hand-typed header survives")
        // Re-parsing the buffer must be stable, or the editor and the model disagree forever.
        let reparsed = HTTPMessage.parseEditorText(stored.prettyRaw, isRequest: true)
        check(reparsed.rawBytes == stored.rawBytes, "normalised text re-parses to itself")

        section("Repeater")
        let store = RepeaterStore.shared
        store.newTab()
        guard let tabID = store.selectedID else {
            FileHandle.standardOutput.write(Data("  ✗ repeater has no tab\n".utf8))
            return 1
        }
        var typedRequest = HTTPMessage(isRequest: true, startLine: "GET /repeater-typed HTTP/1.1",
                                      headers: [Header(name: "Host", value: "example.com")])
        typedRequest = HTTPMessage.parseEditorText(
            "GET /repeater-typed HTTP/1.1\nHost: example.com\nX-Typed: yes\n\n", isRequest: true)
        store.update(tabID) { $0.request = typedRequest }
        store.syncFromEditor(tabID)
        let tab = store.tabs.first { $0.id == tabID }
        check(tab?.request.path == "/repeater-typed", "the repeater keeps the typed path")
        check(tab?.host == "example.com", "the repeater derives the host from the Host header")
        check(tab?.isModified == true, "editing marks the tab as modified")
        // A fresh tab must not come up pre-modified — the editor used to write the message back
        // during seeding and stamp every new tab.
        store.newTab()
        if let fresh = store.tabs.last {
            check(fresh.isModified == false, "a brand new tab is not marked modified")
        }
        check(store.tabs.count >= 2, "tabs accumulate")
        store.close(tabID)
        check(!store.tabs.contains { $0.id == tabID }, "the closed tab is gone")

        section("Interception wiring")
        model.interceptEnabled = false
        await InterceptQueue.shared.setEnabled(false)
        model.toggleIntercept()
        check(model.interceptEnabled, "the toggle flips the flag")
        let enabledAfterToggle = await InterceptQueue.shared.enabled
        check(enabledAfterToggle, "the toggle reaches the engine queue")
        model.toggleIntercept()
        check(await InterceptQueue.shared.enabled == false, "toggling back off reaches the queue too")

        section("History selection")
        HistoryStore.shared.clear()
        let model1 = HTTPPair(
            id: 900_001, time: Date(), durationMS: 1, host: "ui.test", port: 80, isSecure: false,
            request: HTTPMessage(isRequest: true, startLine: "GET / HTTP/1.1",
                                 headers: [Header(name: "Host", value: "ui.test")]),
            response: HTTPMessage(isRequest: false, startLine: "HTTP/1.1 200 OK",
                                  headers: [Header(name: "Content-Length", value: "0")])
        )
        let model2 = HTTPPair(
            id: 900_002, time: Date(), durationMS: 2, host: "ui.test", port: 80, isSecure: false,
            request: HTTPMessage(isRequest: true, startLine: "GET /two HTTP/1.1",
                                 headers: [Header(name: "Host", value: "ui.test")]),
            response: nil
        )
        HistoryStore.shared.add(model1)
        HistoryStore.shared.add(model2)
        model.selectedPairID = nil
        model.forceRefresh()
        check(model.selectedPairID == model2.id, "the inspector auto-selects the newest exchange")
        check(model.selectedPair != nil, "the selected exchange is readable")
        model.clearHistory()
        check(HistoryStore.shared.totalCount == 0, "history clears")
        check(model.selectedPairID == nil, "clearing history drops the selection")

        section("Proxy configuration")
        let original = model.proxyPort
        model.setPort(9099)
        check(model.proxyPort == 9099, "the port field commits")
        model.setPort(original)

        FileHandle.standardOutput.write(Data("──────────────────────────────────────────────\n".utf8))
        if failures.isEmpty {
            FileHandle.standardOutput.write(Data("PASS  — \(checks) UI checks\n".utf8))
            return 0
        }
        FileHandle.standardOutput.write(Data("FAIL  — \(failures.count) of \(checks) UI checks failed\n\n".utf8))
        for f in failures { FileHandle.standardOutput.write(Data("  ✗ \(f)\n".utf8)) }
        return 1
    }
}