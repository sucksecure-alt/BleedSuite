
import SwiftUI
import AppKit

// ============================================================================
//  Intercept workspace — Burp-style "hold, edit, release" queue
// ============================================================================

/// Tabs of the held-message inspector.
private enum InterceptTab: String, Hashable {
    case message
    case headers
    case params

    var title: String {
        switch self {
        case .message: return "Message"
        case .headers: return "Headers"
        case .params: return "Params"
        }
    }

    var icon: String {
        switch self {
        case .message: return "doc.plaintext"
        case .headers: return "list.bullet.rectangle"
        case .params: return "slider.horizontal.3"
        }
    }
}

/// Left: the list of held exchanges. Right: raw / headers / params editor for the
/// selected one plus the Forward / Forward without changes / Drop / Reset actions.
struct InterceptView: View {
    @ObservedObject var model = AppModel.shared

    @State private var filterText: String = ""
    @State private var tab: InterceptTab = .message

    /// Editable working copy of the selected `InterceptItem`.
    @State private var draft: InterceptItem?
    /// Raw text of `draft.message` while the Message tab is open.
    @State private var draftText: String = ""
    /// Text the draft was loaded from — the baseline for "did the analyst change anything".
    @State private var originalText: String = ""
    /// Set when a header / parameter cell changed outside the raw editor.
    @State private var structuredDirty = false

    // MARK: - Derived data

    private var selectedItem: InterceptItem? {
        guard let id = model.selectedInterceptID else { return nil }
        return model.interceptItems.first { $0.id == id }
    }

    private var filteredItems: [InterceptItem] {
        let all = model.interceptItems
        let needle = filterText.trimmingCharacters(in: .whitespaces).lowercased()
        guard !needle.isEmpty else { return all }
        return all.filter { item in
            item.summary.lowercased().contains(needle)
                || item.host.lowercased().contains(needle)
                || item.direction.label.lowercased().contains(needle)
                || String(item.transactionID).contains(needle)
        }
    }

    private var isModified: Bool { draftText != originalText || structuredDirty }

    // The toggle beside it already states the mode, so the subtitle stays short — the longer
        // phrasing was truncated to "traffic fl…" in a toolbar this crowded.
        private var toolbarSubtitle: String {
        model.interceptEnabled ? "Holding traffic until you release it" : "Traffic flows straight through"
    }

    // MARK: - Body

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            if !model.interceptEnabled && !model.interceptItems.isEmpty {
                offBanner
                Rectangle().fill(Theme.divider).frame(height: 1)
            }
            SplitLayout(axis: .horizontal, minFirst: 260, minSecond: 320, first: { listPane }, second: { editorPane })
        }
        .background(Theme.background)
        .onAppear { syncDraft() }
        .onChange(of: model.selectedInterceptID) { _, _ in syncDraft() }
        .onChange(of: model.interceptItems.map(\.id)) { _, _ in
            if draft == nil || selectedItem == nil { syncDraft() }
        }
        .onChange(of: tab) { _, newValue in tabChanged(newValue) }
    }

    // MARK: - Toolbar

    private var toolbar: some View {
        WorkspaceToolbar(title: "Intercept", subtitle: toolbarSubtitle) {
            CrimsonToggle(
                isOn: Binding(
                    get: { model.interceptEnabled },
                    set: { newValue in
                        // Turning interception on/off has a side effect (queue release), so the
                        // binding must never drift away from the model.
                        guard newValue != model.interceptEnabled else { return }
                        model.toggleIntercept()
                    }
                ),
                label: model.interceptEnabled ? "Intercept on" : "Intercept off"
            )

            Button {
                model.setInterceptRepeat(!model.interceptRepeat)
            } label: {
                HStack(spacing: 6) {
                    Circle()
                        .fill(model.interceptRepeat ? Theme.warning : Theme.dividerBright)
                        .frame(width: 7, height: 7)
                    Text(verbatim: "Repeat \(model.interceptRepeat ? "on" : "off")")
                }
            }
            .buttonStyle(GhostButtonStyle(tint: model.interceptRepeat ? Theme.warning : Theme.textSecondary, compact: true))
            .help("Keep intercepting after every release instead of switching itself off")

            SearchField(text: $filterText, placeholder: "Filter held", width: 170)

            Text(verbatim: "\(model.interceptItems.count) held")
                .font(Theme.monoSwiftUI(11, weight: .semibold))
                .foregroundStyle(model.interceptItems.isEmpty ? Theme.textTertiary : Theme.crimsonBright)

            Button {
                Task { await model.forwardAllIntercepts() }
            } label: {
                Label("Forward all", systemImage: "paperplane.fill")
            }
            .buttonStyle(GhostButtonStyle(tint: Theme.success, compact: true))
            .disabled(model.interceptItems.isEmpty)

            Button {
                Task { await model.dropAllIntercepts() }
            } label: {
                Label("Drop all", systemImage: "trash")
            }
            .buttonStyle(GhostButtonStyle(tint: Theme.danger, compact: true))
            .disabled(model.interceptItems.isEmpty)
        }
    }

    private var offBanner: some View {
        Panel {
            HStack(spacing: 8) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(Theme.ui(11))
                    .foregroundStyle(Theme.warning)
                Text("Interception is off — held items will be released when you turn it off")
                    .font(Theme.ui(11, weight: .medium))
                    .foregroundStyle(Theme.textSecondary)
                Spacer(minLength: 0)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
    }

    // MARK: - List pane

    private var listPane: AnyView {
        AnyView(
            VStack(spacing: 0) {
                HStack(spacing: 8) {
                    SectionLabel(text: "Intercept queue", trailing: "\(filteredItems.count)")
                    Button {
                        Task { await model.refreshInterceptQueue() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(Theme.ui(10))
                            .foregroundStyle(Theme.textTertiary)
                    }
                    .buttonStyle(.plain)
                    .help("Refresh the held queue")
                }
                Rectangle().fill(Theme.divider).frame(height: 1)

                if filteredItems.isEmpty {
                    EmptyHint(
                        icon: "hand.raised.fill",
                        title: "No held items",
                        subtitle: "Turn interception on, then browse — matching traffic will be held here."
                    )
                } else {
                    ScrollView {
                        LazyVStack(spacing: 0) {
                            ForEach(filteredItems) { item in
                                row(for: item)
                                Rectangle().fill(Theme.divider.opacity(0.5)).frame(height: 1)
                            }
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .background(Theme.sidebar)
        )
    }

    private func row(for item: InterceptItem) -> some View {
        let isSelected = model.selectedInterceptID == item.id
        return Button {
            model.selectedInterceptID = item.id
        } label: {
            HStack(spacing: 8) {
                Capsule()
                    .fill(Theme.directionColor(item.direction))
                    .frame(width: 3, height: 26)

                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 6) {
                        Text(verbatim: "#\(item.transactionID)  \(item.summary)")
                            .font(Theme.monoSwiftUI(11, weight: .semibold))
                            .foregroundStyle(Theme.textPrimary)
                            .lineLimit(1)
                            .truncationMode(.middle)
                        if item.wasModified {
                            Badge(text: "MODIFIED", color: Theme.warning)
                        }
                        Spacer(minLength: 0)
                    }
                    Text(verbatim: "\(item.direction.label) · \(item.host.isEmpty ? "—" : item.host) · \(Format.clock(item.receivedAt))")
                        .font(Theme.monoSwiftUI(10))
                        .foregroundStyle(Theme.textTertiary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isSelected ? Theme.crimson.opacity(0.12) : Color.clear)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button {
                model.selectedInterceptID = item.id
                forward(item, edited: nil)
            } label: {
                Label("Forward", systemImage: "paperplane")
            }
            Button {
                model.selectedInterceptID = item.id
                forward(item, edited: editedMessage(for: item))
            } label: {
                Label("Forward edited", systemImage: "pencil.and.outline")
            }
            .disabled(draft?.id != item.id || !isModified)
            Divider()
            Button(role: .destructive) {
                Task { await model.dropIntercept(item) }
            } label: {
                Label("Drop", systemImage: "trash")
            }
        }
    }

    // MARK: - Editor pane

    private var editorPane: AnyView {
        AnyView(
            Group {
                if let item = selectedItem {
                    editor(for: item)
                } else {
                    EmptyHint(
                        icon: "hand.raised.slash",
                        title: "Nothing held",
                        subtitle: "Held requests and responses appear here, ready to be edited before they go on the wire."
                    )
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Theme.surface)
        )
    }

    private func editor(for item: InterceptItem) -> some View {
        VStack(spacing: 0) {
            ExchangeSummaryBar(
                request: item.message,
                response: nil,
                host: item.host,
                isSecure: item.host != "",
                note: item.direction.label
            )
            Rectangle().fill(Theme.divider).frame(height: 1)

            HStack(spacing: 8) {
                SegmentBar(
                    selection: $tab,
                    options: [
                        (.message, InterceptTab.message.title, InterceptTab.message.icon),
                        (.headers, InterceptTab.headers.title, InterceptTab.headers.icon),
                        (.params, InterceptTab.params.title, InterceptTab.params.icon),
                    ],
                    compact: true
                )
                Spacer(minLength: 8)
                Text(item.direction == .request ? "Intercepted request" : "Intercepted response")
                    .font(Theme.ui(10))
                    .foregroundStyle(Theme.textTertiary)
                Text(Format.clock(item.receivedAt))
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)
                Button {
                    copyToPasteboard(draftText)
                } label: {
                    Label("Copy", systemImage: "doc.on.doc")
                        .font(Theme.ui(10))
                }
                .buttonStyle(GhostButtonStyle(compact: true))
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .background(Theme.surfaceRaised)
            Rectangle().fill(Theme.divider).frame(height: 1)

            tabContent(for: item)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            Rectangle().fill(Theme.divider).frame(height: 1)
            actionBar(for: item)
        }
    }

    @ViewBuilder
    private func tabContent(for item: InterceptItem) -> some View {
        switch tab {
        case .message:
            CodeEditor(text: $draftText, isEditable: true) {
                forward(item, edited: editedMessage(for: item))
            }
            .overlay(alignment: .topTrailing) {
                HStack(spacing: 6) {
                    if isModified {
                        Badge(text: "EDITED", color: Theme.warning)
                    }
                    Button {
                        draftText = originalText
                        structuredDirty = false
                    } label: {
                        Image(systemName: "arrow.counterclockwise")
                            .font(Theme.ui(10))
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                    .help("Discard edits")
                }
                .padding(6)
            }
        case .headers:
            HeadersTable(headers: headersBinding)
        case .params:
            paramsContent(for: item)
        }
    }

    @ViewBuilder
    private func paramsContent(for item: InterceptItem) -> some View {
        if draft?.direction == .request || item.message.isRequest {
            ParamsTable(params: queryParamsBinding)
            if item.message.contentType.contains("x-www-form-urlencoded") {
                Rectangle().fill(Theme.divider).frame(height: 1)
                SectionLabel(text: "Form body")
                ParamsTable(params: formParamsBinding)
            }
        } else {
            RawTextView(text: "Parameters apply to requests only.")
        }
    }

    private func actionBar(for item: InterceptItem) -> some View {
        HStack(spacing: 8) {
            Button {
                forward(item, edited: isModified ? editedMessage(for: item) : nil)
            } label: {
                Label("Forward", systemImage: "paperplane.fill")
            }
            .buttonStyle(CrimsonButtonStyle(compact: true))
            .disabled(!model.interceptEnabled)

            Button {
                forward(item, edited: nil)
            } label: {
                Text("Forward without changes")
            }
            .buttonStyle(GhostButtonStyle(tint: Theme.success, compact: true))
            .disabled(!model.interceptEnabled)

            Button {
                Task { await model.dropIntercept(item) }
            } label: {
                Label("Drop", systemImage: "trash")
            }
            .buttonStyle(GhostButtonStyle(tint: Theme.danger, compact: true))

            Button {
                resetDraft()
            } label: {
                Label("Reset", systemImage: "arrow.uturn.backward")
            }
            .buttonStyle(GhostButtonStyle(compact: true))

            Spacer(minLength: 8)

            if isModified {
                Badge(text: "UNSENT EDITS", color: Theme.warning)
            } else {
                Text("No local changes")
                    .font(Theme.ui(10))
                    .foregroundStyle(Theme.textTertiary)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Theme.surfaceRaised)
    }

    // MARK: - Bindings

    private var headersBinding: Binding<[Header]> {
        Binding(
            get: { draft?.message.headers ?? [] },
            set: { newValue in
                guard draft != nil else { return }
                draft?.message.headers = newValue
                structuredDirty = true
                pushDraftToQueue()
            }
        )
    }

    private var queryParamsBinding: Binding<[Param]> {
        Binding(
            get: { draft?.message.queryParams ?? [] },
            set: { newValue in
                guard var message = draft?.message else { return }
                message.setQueryParams(newValue)
                draft?.message = message
                structuredDirty = true
                pushDraftToQueue()
            }
        )
    }

    private var formParamsBinding: Binding<[Param]> {
        Binding(
            get: { draft?.message.formParams ?? [] },
            set: { newValue in
                guard var message = draft?.message else { return }
                message.formParams = newValue
                draft?.message = message
                structuredDirty = true
                pushDraftToQueue()
            }
        )
    }

    // MARK: - Draft lifecycle

    private func syncDraft() {
        guard let item = selectedItem else {
            draft = nil
            draftText = ""
            originalText = ""
            structuredDirty = false
            return
        }
        guard draft?.id != item.id else { return }
        draft = item
        originalText = item.message.prettyRaw
        draftText = originalText
        structuredDirty = false
        tab = .message
    }

    private func tabChanged(_ newValue: InterceptTab) {
        guard draft != nil else { return }
        if newValue == .message {
            // Re-render the raw text from whatever the structured tabs produced.
            draftText = draft!.message.prettyRaw
            originalText = draftText
            structuredDirty = false
        } else if !draftText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            draft?.message = HTTPMessage.parseEditorText(draftText, isRequest: draft!.message.isRequest)
            structuredDirty = true
            pushDraftToQueue()
        }
    }

    private func resetDraft() {
        guard let item = selectedItem else { return }
        draft = item
        originalText = item.message.prettyRaw
        draftText = originalText
        structuredDirty = false
        pushDraftToQueue()
    }

    private func editedMessage(for item: InterceptItem) -> HTTPMessage? {
        guard draft?.id == item.id, isModified else { return nil }
        guard !draftText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        return HTTPMessage.parseEditorText(draftText, isRequest: item.direction == .request)
    }

    /// Mirrors the local draft back into the queue so the row can show the MODIFIED badge.
    private func pushDraftToQueue() {
        guard draft != nil else { return }
        let modified = isModified
        draft?.wasModified = modified
        let snapshot = draft
        Task {
            guard let snapshot else { return }
            await InterceptQueue.shared.update(snapshot.id, message: snapshot.message, modified: modified)
            await model.refreshInterceptQueue()
        }
    }

    // MARK: - Actions

    private func forward(_ item: InterceptItem, edited: HTTPMessage?) {
        if model.selectedInterceptID != item.id { model.selectedInterceptID = item.id }
        Task {
            await model.forwardIntercept(item, edited: edited)
            if draft?.id == item.id {
                draft = nil
                draftText = ""
                originalText = ""
                structuredDirty = false
            }
        }
    }

    private func copyToPasteboard(_ text: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
    }
}