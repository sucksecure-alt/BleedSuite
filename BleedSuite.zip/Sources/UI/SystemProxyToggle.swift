import Foundation

/// System-proxy control that does not depend on the main actor.
///
/// `AppModel` owns the same behaviour for the UI, but it is `@MainActor`-isolated and
/// the command-line entry point has no run loop, so it cannot be reused there.
enum SystemProxyToggle {

    /// Points every traffic-carrying network service at `127.0.0.1:port`, snapshotting
    /// the previous configuration first so it can be restored exactly.
    @discardableResult
    static func apply(port: UInt16) async -> Bool {
        let manager = SystemProxyManager.shared
        let services = await manager.targetServices()
        guard !services.isEmpty else {
            FileHandle.standardError.write(Data("[proxy] no active network service\n".utf8))
            return false
        }

        var snapshot = SystemProxyManager.Snapshot(savedAt: Date(), services: [:])
        for service in services {
            if let captured = try? await manager.capture(service: service.name),
               let settings = captured.services[service.name] {
                snapshot.services[service.name] = settings
            }
        }
        try? await manager.saveSnapshot(snapshot)

        var failed: [String] = []
        for service in services {
            do {
                try await manager.enable(service: service.name, port: Int(port))
                FileHandle.standardError.write(Data("[proxy] \(service.name) -> 127.0.0.1:\(port)\n".utf8))
            } catch {
                failed.append("\(service.name): \((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)")
            }
        }
        for failure in failed {
            FileHandle.standardError.write(Data("[proxy] failed \(failure)\n".utf8))
        }
        return failed.isEmpty
    }

    /// Puts the previous configuration back from the saved snapshot.
    static func restore() async {
        let manager = SystemProxyManager.shared
        if let snapshot = await manager.loadSavedSnapshot() {
            try? await manager.restore(snapshot)
            FileHandle.standardError.write(Data("[proxy] restored from snapshot\n".utf8))
        } else {
            for service in await manager.targetServices() {
                try? await manager.disable(service: service.name)
            }
            FileHandle.standardError.write(Data("[proxy] proxies switched off\n".utf8))
        }
        await manager.clearSavedSnapshot()
    }
}