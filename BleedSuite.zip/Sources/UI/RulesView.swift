
import SwiftUI
import AppKit

// ============================================================================
//  Match / Replace workspace
//
//  The list itself lives in RulesEngine; this view only mirrors it and forwards
//  every edit back through `update(_:)` / `add(_:)` followed by
//  `AppModel.persistRules()`.
// ============================================================================

struct RulesView: View {
    @ObservedObject var model: AppModel = AppModel.shared

    @State private var testInput: String = """
    GET /account/settings?debug=1 HTTP/1.1
    Host: example.com
    User-Agent: BleedSuite
    X-Internal-Token: deadbeef

    """
    @State private var testOutput: String = ""
    @State private var appliedCount: Int? = nil
    @State private var testError: String? = nil
    /// Bumped after every mutation so the mirrored list refreshes immediately.
    @State private var rulesEpoch: Int = 0

    // MARK: - Mirrored rule list

    private var rules: [ProxyRule] {
        _ = rulesEpoch
        return RulesEngine.shared.rules
    }

    private func commit(_ rule: ProxyRule) {
        RulesEngine.shared.update(rule)
        model.persistRules()
        rulesEpoch += 1
    }

    /// Rule list paired with its position — `Identifiable` so `ForEach` is stable.
    private var entries: [RulesListEntry] {
        _ = rulesEpoch
        let list = RulesEngine.shared.rules
        return list.enumerated().map { RulesListEntry(index: $0.offset, rule: $0.element) }
    }

    // MARK: - Body

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            Rectangle().fill(Theme.divider).frame(height: 1)
            mainColumns
        }
        .background(Theme.background)
        .onAppear {
            if testOutput.isEmpty { runTest() }
        }
    }

    // MARK: Toolbar

    private var toolbar: some View {
        WorkspaceToolbar(
            title: "Match / Replace",
            subtitle: "\(rules.count) rule\(rules.count == 1 ? "" : "s")"
        ) {
            HStack(spacing: 8) {
                Button {
                    var rule = ProxyRule()
                    rule.comment = "New rule"
                    RulesEngine.shared.add(rule)
                    model.persistRules()
                    rulesEpoch += 1
                } label: {
                    Label("Add rule", systemImage: "plus")
                }
                .buttonStyle(CrimsonButtonStyle(compact: true))

                Button {
                    importJSON()
                } label: {
                    Label("Import JSON", systemImage: "square.and.arrow.down")
                }
                .buttonStyle(GhostButtonStyle(compact: true))

                Button {
                    exportJSON()
                } label: {
                    Label("Export JSON", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(GhostButtonStyle(compact: true))
                .disabled(rules.isEmpty)

                Button {
                    clearAll()
                } label: {
                    Label("Clear all", systemImage: "trash")
                }
                .buttonStyle(GhostButtonStyle(tint: Theme.danger, compact: true))
                .disabled(rules.isEmpty)

                Badge(text: "\(rules.count) RULE\(rules.count == 1 ? "" : "S")", color: Theme.crimson)
            }
        }
    }

    // MARK: Columns

    private var mainColumns: some View {
        HStack(spacing: 0) {
            ruleList
                .frame(maxWidth: .infinity)
            SplitHandle(axis: .horizontal)
            rightColumn
                .frame(maxWidth: .infinity)
        }
    }

    private var ruleList: some View {
        VStack(spacing: 0) {
            SectionLabel(text: "Rules", trailing: "top to bottom order matters")
            Rectangle().fill(Theme.divider).frame(height: 1)

            if rules.isEmpty {
                EmptyHint(
                    icon: "arrow.left.arrow.right.square",
                    title: "No rules yet",
                    subtitle: "Rewrite headers and bodies on the fly — requests and responses are modified before they hit the wire."
                )
            } else {
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(entries) { entry in
                            let index = entry.index
                            let rule = entry.rule
                            RuleEditor(
                                rule: rule,
                                position: "\(index + 1)/\(rules.count)",
                                canMoveUp: index > 0,
                                canMoveDown: index < rules.count - 1,
                                onChange: { commit($0) },
                                onDuplicate: { duplicate(rule, at: index) },
                                onDelete: { remove(rule, at: index) },
                                onMoveUp: { move(from: index, to: index - 1) },
                                onMoveDown: { move(from: index, to: index + 1) }
                            )
                        }
                    }
                    .padding(10)
                }
            }
        }
        .background(Theme.background)
    }

    private var rightColumn: some View {
        VStack(spacing: 0) {
            testPanel
            Rectangle().fill(Theme.divider).frame(height: 1)
            helpPanel
        }
        .background(Theme.surface)
    }

    // MARK: Test area

    private var testPanel: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Text("Test area")
                    .font(Theme.ui(12, weight: .semibold))
                    .foregroundStyle(Theme.textPrimary)
                Text("paste a raw request, run the request rules")
                    .font(Theme.ui(10))
                    .foregroundStyle(Theme.textTertiary)
                Spacer(minLength: 8)
                Button {
                    runTest()
                } label: {
                    Label("Run rules", systemImage: "play.fill")
                }
                .buttonStyle(CrimsonButtonStyle(compact: true))
                if !testOutput.isEmpty {
                    Button {
                        testInput = ""
                        testOutput = ""
                        appliedCount = nil
                        testError = nil
                    } label: {
                        Label("Reset", systemImage: "arrow.counterclockwise")
                    }
                    .buttonStyle(GhostButtonStyle(compact: true))
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(Theme.surfaceRaised)

            Rectangle().fill(Theme.divider).frame(height: 1)

            VStack(spacing: 0) {
                CodeEditor(text: $testInput, isEditable: true) {
                    runTest()
                }
                .frame(height: 190)
                .background(Theme.background)

                statusStrip

                Rectangle().fill(Theme.divider).frame(height: 1)

                CodeEditor(text: .constant(testOutput), isEditable: false)
                    .frame(maxHeight: .infinity)
            }
        }
    }

    private var statusStrip: some View {
        HStack(spacing: 8) {
            if let appliedCount {
                Badge(text: "\(appliedCount) RULE\(appliedCount == 1 ? "" : "S") APPLIED",
                      color: appliedCount > 0 ? Theme.success : Theme.textSecondary,
                      filled: appliedCount > 0)
            } else {
                Badge(text: "NOT RUN", color: Theme.textSecondary)
            }
            if let testError, !testError.isEmpty {
                Text(testError)
                    .font(Theme.ui(10))
                    .foregroundStyle(Theme.danger)
                    .lineLimit(2)
                    .truncationMode(.tail)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(Theme.surfaceRaised)
    }

    // MARK: Help

    private var helpPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionLabel(text: "How rules work")
            VStack(alignment: .leading, spacing: 7) {
                helpLine("macronumber", "Every enabled rule is tested in order. The first field picks the direction (request or response), the second the part of the message the condition is applied to.")
                helpLine("number", "The condition is matched against that field. Header rules accept either a bare header name (every value is overwritten) or the whole line “Name: value”, in which case only the value is rewritten.")
                helpLine("arrow.left.arrow.right", "On a hit the replacement is written back and Content-Length / Transfer-Encoding are rebuilt, so the peer never sees a truncated message.")
                helpLine("exclamationmark.triangle", "Negate inverts the condition: the rule fires when the pattern does not match.")
                helpLine("textformat.abc", "Replacements are Burp compatible: $1 / ${1} insert a capture group, ${name} inserts a named group (?<name>…), $$ is a literal dollar sign. Literal match types substitute plain text.")
                helpLine("exclamationmark.triangle.fill", "Rules apply to every message that passes through the proxy — including traffic from other applications and your own browser. Disabled rules are skipped.")
            }
            .padding(.horizontal, 10)
            .padding(.bottom, 10)

            Spacer(minLength: 0)
        }
        .frame(maxHeight: 240, alignment: .top)
        .background(Theme.background)
    }

    private func helpLine(_ icon: String, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 7) {
            Image(systemName: icon)
                .font(Theme.ui(10))
                .foregroundStyle(Theme.crimson)
                .frame(width: 14)
            Text(text)
                .font(Theme.ui(11))
                .foregroundStyle(Theme.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
    }

    // MARK: - Actions

    private func duplicate(_ rule: ProxyRule, at index: Int) {
        var copy = rule
        copy.id = UUID()
        copy.comment = rule.comment.isEmpty ? "Copy of rule" : rule.comment + " (copy)"
        RulesEngine.shared.add(copy)
        // `add` appends — move the duplicate next to its original.
        let last = RulesEngine.shared.rules.count - 1
        RulesEngine.shared.move(from: last, to: min(index + 1, last))
        model.persistRules()
        rulesEpoch += 1
    }

    private func remove(_ rule: ProxyRule, at index: Int) {
        RulesEngine.shared.remove(id: rule.id)
        model.persistRules()
        rulesEpoch += 1
    }

    private func move(from: Int, to: Int) {
        RulesEngine.shared.move(from: from, to: to)
        model.persistRules()
        rulesEpoch += 1
    }

    private func runTest() {
        let parsed = HTTPMessage.parseEditorText(testInput, isRequest: true)
        let edit = RulesEngine.shared.apply(to: parsed, direction: .request, pair: nil)
        testOutput = edit.message.prettyRaw
        appliedCount = edit.applied
        testError = edit.error
    }

    private func exportJSON() {
        let text = RulesEngine.shared.exportJSON()
        let url = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first?
            .appendingPathComponent(FileWriter.suggestFilename(prefix: "bleed-rules", ext: "json"))
        guard let url else {
            model.appendLog("Desktop is not available", .warn)
            return
        }
        do {
            try text.write(to: url, atomically: true, encoding: .utf8)
            model.appendLog("Exported \(rules.count) rule(s) to \(url.lastPathComponent)", .good)
            NSWorkspace.shared.activateFileViewerSelecting([url])
        } catch {
            model.appendLog("Export failed: \(error.localizedDescription)", .bad)
        }
    }

    private func importJSON() {
        let alert = NSAlert()
        alert.messageText = "Import match / replace rules"
        alert.informativeText = "Paste a JSON array of rules (or a single rule object). Duplicated ids are re-keyed."

        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: 420, height: 200))
        textView.font = Theme.mono(12)
        textView.isRichText = false
        textView.string = RulesEngine.shared.exportJSON()
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 420, height: 200))
        scroll.hasVerticalScroller = true
        scroll.borderType = .bezelBorder
        scroll.documentView = textView
        alert.accessoryView = scroll
        alert.addButton(withTitle: "Import")
        alert.addButton(withTitle: "Cancel")

        guard alert.runModal() == .alertFirstButtonReturn else { return }
        do {
            try RulesEngine.shared.importJSON(textView.string)
            model.persistRules()
            rulesEpoch += 1
            model.appendLog("Imported \(RulesEngine.shared.count) rule(s)", .good)
        } catch {
            model.appendLog("Import failed: \((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)", .bad)
        }
    }

    private func clearAll() {
        let alert = NSAlert()
        alert.alertStyle = .warning
        alert.messageText = "Remove all \(rules.count) rule(s)?"
        alert.informativeText = "Traffic will stop being rewritten. This cannot be undone."
        alert.addButton(withTitle: "Clear all")
        alert.addButton(withTitle: "Cancel")
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        RulesEngine.shared.removeAll()
        model.persistRules()
        rulesEpoch += 1
    }
}

/// A rule plus its position in the ordered list.
private struct RulesListEntry: Identifiable {
    let index: Int
    let rule: ProxyRule
    var id: UUID { rule.id }
}

// ============================================================================
//  One editable rule
// ============================================================================

private struct RuleEditor: View {
    let rule: ProxyRule
    let position: String
    let canMoveUp: Bool
    let canMoveDown: Bool
    let onChange: (ProxyRule) -> Void
    let onDuplicate: () -> Void
    let onDelete: () -> Void
    let onMoveUp: () -> Void
    let onMoveDown: () -> Void

    /// Any mutation of a field produces a fresh copy which is pushed to the engine.
    private func binding<T>(_ keyPath: WritableKeyPath<ProxyRule, T>) -> Binding<T> {
        Binding(
            get: { rule[keyPath: keyPath] },
            set: { newValue in
                var copy = rule
                copy[keyPath: keyPath] = newValue
                onChange(copy)
            }
        )
    }

    var body: some View {
        Panel {
            VStack(alignment: .leading, spacing: 8) {
                headRow
                scopeRow
                patternRow
                actionRow
            }
        }
        .opacity(rule.enabled ? 1 : 0.55)
    }

    // MARK: Rows

    private var headRow: some View {
        HStack(spacing: 10) {
            Toggle("", isOn: binding(\.enabled))
                .labelsHidden()
                .toggleStyle(.checkbox)
                .help("Enable / disable this rule")

            LabelledField(label: "Comment", text: binding(\.comment), placeholder: "what this rule is for")

            Spacer(minLength: 4)

            Text(position)
                .font(Theme.monoSwiftUI(10))
                .foregroundStyle(Theme.textTertiary)
        }
    }

    private var scopeRow: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Direction")
                    .font(Theme.ui(10, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
                SegmentBar(
                    selection: binding(\.direction),
                    options: [
                        (ProxyRule.Direction.request, "Request", "arrow.up.right"),
                        (ProxyRule.Direction.response, "Response", "arrow.down.left"),
                    ],
                    compact: true
                )
            }

            DarkPicker(
                title: "Target",
                selection: binding(\.target),
                options: ProxyRule.Target.allCases.map { ($0, $0.label) },
                width: 150
            )

            DarkPicker(
                title: "Match",
                selection: binding(\.matchType),
                options: ProxyRule.MatchType.allCases.map { ($0, $0.label) },
                width: 120
            )

            VStack(alignment: .leading, spacing: 3) {
                CrimsonToggle(isOn: binding(\.caseSensitive), label: "Regex case sensitive")
                CrimsonToggle(isOn: binding(\.negateMatch), label: "Negate")
            }

            Spacer(minLength: 0)
        }
    }

    @ViewBuilder
    private var patternRow: some View {
        VStack(alignment: .leading, spacing: 5) {
            LabelledField(
                label: "Pattern",
                text: binding(\.pattern),
                placeholder: rule.target == .header ? "Header-Name: part of value" : "what to look for",
                mono: true
            )
            LabelledField(
                label: "Replace with",
                text: binding(\.replacement),
                placeholder: "use $1 or ${name} for capture groups",
                mono: true
            )

            if rule.target == .header {
                HStack(spacing: 6) {
                    Image(systemName: "info.circle")
                        .font(Theme.ui(9))
                        .foregroundStyle(Theme.warning)
                    Text(rule.headerName.isEmpty
                         ? "Header rules use “Header-Name: part of value”. The header name before the colon is currently empty."
                         : "Target header: \(rule.headerName)")
                        .font(Theme.ui(10))
                        .foregroundStyle(Theme.textSecondary)
                    Spacer(minLength: 0)
                }
            }

            if !rule.comment.isEmpty {
                HStack(spacing: 6) {
                    Image(systemName: "text.bubble")
                        .font(Theme.ui(9))
                        .foregroundStyle(Theme.textTertiary)
                    Text(rule.comment)
                        .font(Theme.ui(10))
                        .foregroundStyle(Theme.textTertiary)
                        .lineLimit(1)
                    Spacer(minLength: 0)
                }
            }
        }
    }

    private var actionRow: some View {
        HStack(spacing: 8) {
            Button(action: onMoveUp) {
                Label("Move up", systemImage: "arrow.up")
            }
            .buttonStyle(GhostButtonStyle(compact: true))
            .disabled(!canMoveUp)

            Button(action: onMoveDown) {
                Label("Move down", systemImage: "arrow.down")
            }
            .buttonStyle(GhostButtonStyle(compact: true))
            .disabled(!canMoveDown)

            Button(action: onDuplicate) {
                Label("Duplicate", systemImage: "plus.square.on.square")
            }
            .buttonStyle(GhostButtonStyle(compact: true))

            Button(action: onDelete) {
                Label("Delete", systemImage: "trash")
            }
            .buttonStyle(GhostButtonStyle(tint: Theme.danger, compact: true))

            Spacer(minLength: 0)

            Text(rule.target.label.uppercased())
                .font(Theme.ui(9, weight: .bold))
                .tracking(0.8)
                .foregroundStyle(rule.enabled ? Theme.crimson : Theme.textTertiary)
        }
    }
}