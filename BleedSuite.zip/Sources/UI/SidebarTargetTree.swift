import SwiftUI

/// The sidebar's site map, drawn entirely in SwiftUI.
///
/// The full Target workspace uses `TargetTreeView`, an `NSOutlineView`. It cannot be reused here:
/// an AppKit view hosted inside SwiftUI is composited as its own layer group, and the sidebar's
/// opaque header paints over the top of it, slicing the first host row in half. The tree is small
/// and the layout simple, so it is drawn directly.
struct SidebarTargetTree: View {

    let nodes: [TargetNode]
    let onSelectLeaf: (HTTPPair) -> Void
    let onSelectHost: (TargetNode) -> Void

    /// Roots start open so the host list is visible straight away, as in the Target workspace.
    @State private var collapsed: Set<String> = []
    @State private var seeded = false

    private let rowHeight: CGFloat = 22
    private let fontSize: CGFloat = 9

    var body: some View {
        ScrollView(.vertical, showsIndicators: true) {
            LazyVStack(alignment: .leading, spacing: 0) {
                ForEach(visibleRows, id: \.id) { row in
                    rowView(row)
                }
            }
            // Room for the last row plus the pane's own breathing space; without it the
            // bottom row butts straight against the footer divider.
            .padding(.bottom, 8)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .onAppear { seedIfNeeded() }
        .onChange(of: nodes.map(\.id)) { seedIfNeeded() }
    }

    // MARK: - Rows

    private struct Row: Identifiable {
        let node: TargetNode
        let depth: Int
        var id: String { node.id }
    }

    /// Flattens the visible part of the tree. Doing it here keeps the view body free of
    /// recursion and lets `LazyVStack` stay lazy.
    private var visibleRows: [Row] {
        guard seeded else { return [] }
        var out: [Row] = []
        for root in nodes {
            append(root, depth: 0, into: &out)
        }
        return out
    }

    private func append(_ node: TargetNode, depth: Int, into out: inout [Row]) {
        out.append(Row(node: node, depth: depth))
        guard !node.isLeaf, !collapsed.contains(node.id) else { return }
        for child in node.children.sorted(by: { $0.name.localizedStandardCompare($1.name) == .orderedAscending }) {
            append(child, depth: depth + 1, into: &out)
        }
    }

    private func seedIfNeeded() {
        guard !seeded, !nodes.isEmpty else { return }
        seeded = true
    }

    @ViewBuilder
    private func rowView(_ row: Row) -> some View {
        if row.node.isLeaf {
            leafRow(row)
        } else {
            folderRow(row)
        }
    }

    private func folderRow(_ row: Row) -> some View {
        let isOpen = !collapsed.contains(row.node.id)
        return HStack(spacing: 4) {
            disclosure(isOpen: isOpen, node: row.node)
            Image(systemName: isOpen ? "folder.fill" : "folder")
                .font(Theme.ui(fontSize))
                .foregroundStyle(Theme.crimson)
                .frame(width: 12)
            Text(row.node.name)
                .font(Theme.monoSwiftUI(fontSize, weight: .semibold))
                .foregroundStyle(Theme.textPrimary)
                .lineLimit(1)
                .truncationMode(.head)
            Spacer(minLength: 6)
            if row.node.requestCount > 0 {
                Text(row.node.requestCount.compactString)
                    .font(Theme.monoSwiftUI(fontSize - 2, weight: .bold))
                    .foregroundStyle(Theme.textTertiary)
                    .lineLimit(1)
            }
        }
        // The padding is what the AppKit cell never had: text starts inside the sidebar
        // instead of against its border, and nothing can run past the right edge.
        .padding(.leading, 8 + CGFloat(row.depth) * 11)
        .padding(.trailing, 8)
        .frame(height: rowHeight)
        .contentShape(Rectangle())
        .onTapGesture { onSelectHost(row.node) }
    }

    private func leafRow(_ row: Row) -> some View {
        let last = row.node.pairs.last
        return HStack(spacing: 5) {
            Circle()
                .fill(Theme.statusColor(last?.status))
                .frame(width: 5, height: 5)
            Text(row.node.name)
                .font(Theme.monoSwiftUI(fontSize + 1))
                .foregroundStyle(Theme.textSecondary)
                .lineLimit(1)
                .truncationMode(.middle)
            Spacer(minLength: 6)
            if let last {
                Text(row.node.pairs.count > 1
                     ? "\(row.node.pairs.count)x  \(Format.bytes(last.responseLength))"
                     : Format.bytes(last.responseLength))
                    .font(Theme.monoSwiftUI(fontSize - 2))
                    .foregroundStyle(Theme.textTertiary)
                    .lineLimit(1)
                    .fixedSize()
            }
        }
        .padding(.leading, 10 + CGFloat(row.depth) * 11)
        .padding(.trailing, 8)
        .frame(height: rowHeight)
        .contentShape(Rectangle())
        .onTapGesture { if let pair = last { onSelectLeaf(pair) } }
    }

    private func disclosure(isOpen: Bool, node: TargetNode) -> some View {
        Button {
            if isOpen { collapsed.insert(node.id) } else { collapsed.remove(node.id) }
        } label: {
            Image(systemName: "triangle.fill")
                .font(Theme.ui(6))
                .foregroundStyle(Theme.textTertiary)
                // Keeps the arrow upright when collapsed instead of mirrored.
                .rotationEffect(.degrees(isOpen ? 90 : 0))
                .frame(width: 10, height: 10)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}