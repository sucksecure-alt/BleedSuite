
import SwiftUI
import AppKit

// ============================================================================
//  Site map tree
// ============================================================================

/// `NSOutlineView`-backed site map. A single `List` cannot hold the tens of
/// thousands of endpoints a crawl produces, so the whole tree is AppKit-driven
/// with view-based cells and a flat item model.
struct TargetTreeView: View {
    let nodes: [TargetNode]
    var isCompact: Bool = false
    var onSelectLeaf: ((HTTPPair) -> Void)? = nil
    var onSelectHost: ((TargetNode) -> Void)? = nil

    var body: some View {
        TargetOutlineView(
            nodes: nodes,
            isCompact: isCompact,
            onSelectLeaf: onSelectLeaf,
            onSelectHost: onSelectHost
        )
    }
}

// MARK: - Flattened outline item

/// One row of the outline. Children are materialised once per data reload so
/// AppKit can ask for them synchronously.
private final class TargetOutlineItem {
    let node: TargetNode
    let children: [TargetOutlineItem]

    var isLeaf: Bool { children.isEmpty }

    init(node: TargetNode) {
        self.node = node
        self.children = node.children.map(TargetOutlineItem.init)
    }

    func allItems() -> [TargetOutlineItem] {
        [self] + children.flatMap { $0.allItems() }
    }
}

// MARK: - AppKit bridge

private struct TargetOutlineView: NSViewRepresentable {
    let nodes: [TargetNode]
    let isCompact: Bool
    let onSelectLeaf: ((HTTPPair) -> Void)?
    let onSelectHost: ((TargetNode) -> Void)?

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeNSView(context: Context) -> NSScrollView {
        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.drawsBackground = false
        scroll.borderType = .noBorder

        let outline = TargetOutlineNSView()
        outline.floatsGroupRows = false
        outline.headerView = nil
        outline.style = .plain
        outline.backgroundColor = Theme.NS.sidebar
        outline.dataSource = context.coordinator
        outline.delegate = context.coordinator
        outline.target = context.coordinator
        outline.doubleAction = #selector(Coordinator.handleDoubleClick(_:))

        // A view-based outline still needs a column to hang the cells off. Its width is
        // pinned to the clip view so the sidebar (288pt) and the full Target workspace both
        // fit; a fixed 320pt column overflowed the sidebar and was clipped on the right.
        let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("main"))
        column.width = 288
        column.minWidth = 120
        column.maxWidth = 4000
        outline.addTableColumn(column)
        outline.outlineTableColumn = column
        outline.autoresizingMask = [.width]
        scroll.documentView = outline
        context.coordinator.attach(outline: outline)
        context.coordinator.update(
            nodes: nodes,
            isCompact: isCompact,
            onSelectLeaf: onSelectLeaf,
            onSelectHost: onSelectHost
        )
        return scroll
    }

    func updateNSView(_ scroll: NSScrollView, context: Context) {
        context.coordinator.update(
            nodes: nodes,
            isCompact: isCompact,
            onSelectLeaf: onSelectLeaf,
            onSelectHost: onSelectHost
        )
    }

    final class Coordinator: NSObject, NSOutlineViewDataSource, NSOutlineViewDelegate {
        private weak var outlineView: TargetOutlineNSView?
        private var items: [TargetOutlineItem] = []
        private var signature = ""
        private var hasLoaded = false
        private var didSeedExpansion = false
        private var isCompact = false
        private var onSelectLeaf: ((HTTPPair) -> Void)?
        private var onSelectHost: ((TargetNode) -> Void)?

        /// Expansion survives `reloadData()`, which otherwise collapses everything.
        private var expanded = Set<String>()

        // MARK: Wiring

        /// Cheap structural fingerprint: every node's identity plus its shape.
        static func fingerprint(_ nodes: [TargetNode]) -> String {
            func walk(_ node: TargetNode) -> String {
                let childPart = node.children.map(walk).joined()
                return node.id + "x\(node.pairs.count)[" + childPart + "]"
            }
            return nodes.map(walk).joined()
        }

        func attach(outline: TargetOutlineNSView) {
            outlineView = outline
            outline.onExpand = { [weak self] item in
                guard let item = item as? TargetOutlineItem else { return }
                self?.expanded.insert(item.node.id)
            }
            outline.onCollapse = { [weak self] item in
                guard let item = item as? TargetOutlineItem else { return }
                self?.expanded.remove(item.node.id)
            }
            outline.menuProvider = { [weak self] point in
                guard let self, let outline = self.outlineView else { return nil }
                let row = outline.row(at: point)
                guard row >= 0, let item = outline.item(atRow: row) as? TargetOutlineItem else { return nil }
                return self.makeMenu(for: item)
            }
        }

        func update(
            nodes: [TargetNode],
            isCompact: Bool,
            onSelectLeaf: ((HTTPPair) -> Void)?,
            onSelectHost: ((TargetNode) -> Void)?
        ) {
            self.onSelectLeaf = onSelectLeaf
            self.onSelectHost = onSelectHost
            guard let outlineView else { return }

            // Only the root ids were used as the change signal, so the outline never reloaded when a
            // host kept its identity but gained or lost children — the sidebar then showed a
            // stale map, or an empty one, long after the traffic had arrived. Fingerprint the
            // whole shape instead.
            let newSignature = Self.fingerprint(nodes)
            let layoutChanged = self.isCompact != isCompact
            guard !hasLoaded || newSignature != signature || layoutChanged else { return }
            hasLoaded = true
            signature = newSignature
            self.isCompact = isCompact

            items = nodes.map(TargetOutlineItem.init)

            // The compact rows carry a 11pt font (9 + typeScale). An 18pt row clipped the
            // text and let it bleed into the neighbouring row — the sidebar looked like it had
            // garbled overlapping labels.
            outlineView.rowHeight = isCompact ? 22 : Theme.rowHeight
            outlineView.indentationPerLevel = isCompact ? 12 : 14

            if !didSeedExpansion {
                // Roots start open so the host list is visible straight away.
                didSeedExpansion = true
                items.forEach { expanded.insert($0.node.id) }
            }

            outlineView.reloadData()
            for item in items where expanded.contains(item.node.id) {
                outlineView.expandItem(item)
            }
        }

        // MARK: Data source

        func outlineView(_ outlineView: NSOutlineView, numberOfChildrenOfItem item: Any?) -> Int {
            children(of: item).count
        }

        func outlineView(_ outlineView: NSOutlineView, child index: Int, ofItem item: Any?) -> Any {
            let list = children(of: item)
            guard list.indices.contains(index) else {
                return items.first ?? TargetOutlineItem(node: TargetNode(name: "", id: ""))
            }
            return list[index]
        }

        func outlineView(_ outlineView: NSOutlineView, isItemExpandable item: Any) -> Bool {
            guard let item = item as? TargetOutlineItem else { return false }
            return !item.isLeaf
        }

        private func children(of item: Any?) -> [TargetOutlineItem] {
            guard let item else { return items }
            return (item as? TargetOutlineItem)?.children ?? []
        }

        // MARK: Delegate

        func outlineView(_ outlineView: NSOutlineView, viewFor tableColumn: NSTableColumn?, item: Any) -> NSView? {
            guard let item = item as? TargetOutlineItem else { return nil }
            if item.isLeaf {
                let cell = outlineView.makeView(withIdentifier: TargetLeafCell.reuseID, owner: self) as? TargetLeafCell
                    ?? TargetLeafCell(identifier: TargetLeafCell.reuseID)
                cell.configure(node: item.node, isCompact: isCompact)
                return cell
            }
            let cell = outlineView.makeView(withIdentifier: TargetFolderCell.reuseID, owner: self) as? TargetFolderCell
                ?? TargetFolderCell(identifier: TargetFolderCell.reuseID)
            cell.configure(node: item.node, isCompact: isCompact)
            return cell
        }

        @objc func handleDoubleClick(_ sender: NSOutlineView) {
            let row = sender.clickedRow
            guard row >= 0, let item = sender.item(atRow: row) as? TargetOutlineItem else { return }
            activate(item)
        }

        private func activate(_ item: TargetOutlineItem) {
            if item.isLeaf {
                guard let pair = item.node.pairs.first else { return }
                let callback = onSelectLeaf
                Task { @MainActor in
                    if let callback {
                        callback(pair)
                    } else {
                        AppModel.shared.sendToRepeater(pair)
                    }
                }
            } else {
                let root = rootNode(of: item.node)
                let callback = onSelectHost
                Task { @MainActor in callback?(root) }
            }
        }

        // MARK: Context menu

        private func makeMenu(for item: TargetOutlineItem) -> NSMenu {
            let menu = NSMenu()
            menu.autoenablesItems = false

            if item.isLeaf {
                guard let pair = item.node.pairs.first else { return menu }
                menu.addItem(makeItem("Send to Repeater", #selector(sendToRepeater), pair))
                menu.addItem(makeItem("Send to Intruder", #selector(sendToIntruder), pair))
                menu.addItem(.separator())
                menu.addItem(makeItem("Copy URL", #selector(copyURL), pair))
                menu.addItem(makeItem("Copy request", #selector(copyRequest), pair))
                menu.addItem(.separator())
                menu.addItem(makeItem("Filter history by host", #selector(filterHistoryByHost), pair.host))
                menu.addItem(makeItem("Scan this endpoint", #selector(scanEndpoint), pair))
            } else {
                menu.addItem(makeItem("Filter history by host", #selector(filterHistoryByHost), targetHostName(for: item.node)))
                menu.addItem(.separator())
                menu.addItem(makeItem("Expand all", #selector(expandAll), nil))
                menu.addItem(makeItem("Collapse all", #selector(collapseAll), nil))
            }
            return menu
        }

        private func makeItem(_ title: String, _ action: Selector, _ object: Any?) -> NSMenuItem {
            let item = NSMenuItem(title: title, action: action, keyEquivalent: "")
            item.target = self
            item.representedObject = object
            return item
        }

        @objc private func sendToRepeater(_ sender: NSMenuItem) {
            guard let pair = sender.representedObject as? HTTPPair else { return }
            let callback = onSelectLeaf
            Task { @MainActor in
                if let callback {
                    callback(pair)
                } else {
                    AppModel.shared.sendToRepeater(pair)
                }
            }
        }

        @objc private func sendToIntruder(_ sender: NSMenuItem) {
            guard let pair = sender.representedObject as? HTTPPair else { return }
            Task { @MainActor in AppModel.shared.sendToIntruder(pair) }
        }

        @objc private func copyURL(_ sender: NSMenuItem) {
            guard let pair = sender.representedObject as? HTTPPair else { return }
            copyToPasteboard(pair.url)
        }

        @objc private func copyRequest(_ sender: NSMenuItem) {
            guard let pair = sender.representedObject as? HTTPPair else { return }
            copyToPasteboard(pair.request.prettyRaw)
        }

        @objc private func filterHistoryByHost(_ sender: NSMenuItem) {
            guard let host = sender.representedObject as? String, !host.isEmpty else { return }
            Task { @MainActor in AppModel.shared.filterHistoryByHost(host) }
        }

        @objc private func scanEndpoint(_ sender: NSMenuItem) {
            guard let pair = sender.representedObject as? HTTPPair else { return }
            Task { @MainActor in AppModel.shared.scanSelected(pair) }
        }

        @objc private func expandAll(_ sender: Any?) {
            guard let outlineView else { return }
            outlineView.expandItem(nil, expandChildren: true)
            items.flatMap { $0.allItems() }.forEach { expanded.insert($0.node.id) }
        }

        @objc private func collapseAll(_ sender: Any?) {
            guard let outlineView else { return }
            outlineView.collapseItem(nil, collapseChildren: true)
            expanded.removeAll()
        }

        private func copyToPasteboard(_ text: String) {
            NSPasteboard.general.clearContents()
            NSPasteboard.general.setString(text, forType: .string)
        }
    }
}

// MARK: - Outline view with a context-menu hook

/// `NSOutlineView` subclass so expansion can be tracked without depending on the
/// private notification keys, and so right-clicks can be answered per row.
private final class TargetOutlineNSView: NSOutlineView {
    var onExpand: ((Any) -> Void)?
    var onCollapse: ((Any) -> Void)?
    /// Receives a point already converted into the outline's coordinates.
    var menuProvider: ((NSPoint) -> NSMenu?)?

    override func expandItem(_ item: Any?) {
        super.expandItem(item)
        onExpand?(item as Any)
    }

    override func collapseItem(_ item: Any?, collapseChildren: Bool) {
        super.collapseItem(item, collapseChildren: collapseChildren)
        onCollapse?(item as Any)
    }

    override func menu(for event: NSEvent) -> NSMenu? {
        guard let menuProvider else { return nil }
        return menuProvider(convert(event.locationInWindow, to: self))
    }
}

// MARK: - Cells

private final class TargetFolderCell: NSTableCellView {
    static let reuseID = NSUserInterfaceItemIdentifier("TargetFolderCell")
    /// SF Symbols are expensive to build; one instance is shared by every cell.
    private static let folderImage = NSImage(systemSymbolName: "folder.fill", accessibilityDescription: nil)

    private let icon = NSImageView()
    private let name = NSTextField(labelWithString: "")
    private let badge = NSTextField(labelWithString: "")

    init(identifier: NSUserInterfaceItemIdentifier) {
        super.init(frame: .zero)
        self.identifier = identifier
        translatesAutoresizingMaskIntoConstraints = false

        icon.translatesAutoresizingMaskIntoConstraints = false
        icon.imageScaling = .scaleProportionallyDown
        icon.contentTintColor = Theme.NS.crimson
        addSubview(icon)

        name.translatesAutoresizingMaskIntoConstraints = false
        name.lineBreakMode = .byTruncatingTail
        name.font = Theme.mono(11, weight: .semibold)
        name.drawsBackground = false
        addSubview(name)

        badge.translatesAutoresizingMaskIntoConstraints = false
        badge.alignment = .right
        badge.font = Theme.mono(9, weight: .bold)
        badge.drawsBackground = false
        addSubview(badge)

        NSLayoutConstraint.activate([
            icon.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 3),
            icon.centerYAnchor.constraint(equalTo: centerYAnchor),
            icon.widthAnchor.constraint(equalToConstant: 13),

            name.leadingAnchor.constraint(equalTo: icon.trailingAnchor, constant: 5),
            name.centerYAnchor.constraint(equalTo: centerYAnchor),

            badge.leadingAnchor.constraint(greaterThanOrEqualTo: name.trailingAnchor, constant: 6),
            badge.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -6),
            badge.centerYAnchor.constraint(equalTo: centerYAnchor),
        ])
    }

    required init?(coder: NSCoder) { return nil }

    func configure(node: TargetNode, isCompact: Bool) {
        let size: CGFloat = isCompact ? 9 : 11
        icon.image = TargetFolderCell.folderImage
        name.font = Theme.mono(size, weight: .semibold)
        name.textColor = Theme.NS.textPrimary
        name.stringValue = node.name

        let count = node.requestCount
        badge.font = Theme.mono(max(size - 2, 8), weight: .bold)
        badge.textColor = Theme.NS.textTertiary
        badge.stringValue = count == 0 ? "" : count.compactString
    }
}

private final class TargetLeafCell: NSTableCellView {
    static let reuseID = NSUserInterfaceItemIdentifier("TargetLeafCell")

    private let dot = NSView()
    private let name = NSTextField(labelWithString: "")
    private let length = NSTextField(labelWithString: "")

    init(identifier: NSUserInterfaceItemIdentifier) {
        super.init(frame: .zero)
        self.identifier = identifier
        translatesAutoresizingMaskIntoConstraints = false

        dot.translatesAutoresizingMaskIntoConstraints = false
        dot.wantsLayer = true
        dot.layer?.cornerRadius = 3
        addSubview(dot)

        name.translatesAutoresizingMaskIntoConstraints = false
        name.lineBreakMode = .byTruncatingMiddle
        name.drawsBackground = false
        addSubview(name)

        length.translatesAutoresizingMaskIntoConstraints = false
        length.alignment = .right
        length.drawsBackground = false
        addSubview(length)

        NSLayoutConstraint.activate([
            dot.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 4),
            dot.centerYAnchor.constraint(equalTo: centerYAnchor),
            dot.widthAnchor.constraint(equalToConstant: 6),
            dot.heightAnchor.constraint(equalToConstant: 6),

            name.leadingAnchor.constraint(equalTo: dot.trailingAnchor, constant: 6),
            name.centerYAnchor.constraint(equalTo: centerYAnchor),

            length.leadingAnchor.constraint(greaterThanOrEqualTo: name.trailingAnchor, constant: 8),
            length.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
            length.centerYAnchor.constraint(equalTo: centerYAnchor),
        ])
    }

    required init?(coder: NSCoder) { return nil }

    func configure(node: TargetNode, isCompact: Bool) {
        let size: CGFloat = isCompact ? 10 : 11
        let last = node.pairs.last

        name.font = Theme.mono(size)
        name.textColor = Theme.NS.textSecondary
        name.stringValue = node.name

        dot.layer?.backgroundColor = Theme.NS.status(last?.status).cgColor

        length.font = Theme.mono(max(size - 2, 8))
        length.textColor = Theme.NS.textTertiary
        if let last {
            length.stringValue = node.pairs.count > 1
                ? "\(node.pairs.count)x  \(Format.bytes(last.responseLength))"
                : Format.bytes(last.responseLength)
        } else {
            length.stringValue = ""
        }
    }
}

// MARK: - Helpers

/// Walks up to the `scheme://host:port` node that owns the given branch.
private func rootNode(of node: TargetNode) -> TargetNode {
    var cursor = node
    while let parent = cursor.parent { cursor = parent }
    return cursor
}

/// Host of a node: the first captured pair in its ancestry, or the host part of
/// the root label when no pair is reachable from it.
private func targetHostName(for node: TargetNode) -> String {
    var cursor: TargetNode? = node
    var fallback: TargetNode? = nil
    while let current = cursor {
        if fallback == nil { fallback = current }
        if let pair = current.pairs.first { return pair.host }
        cursor = current.parent
    }
    guard let label = fallback?.name, !label.isEmpty else { return "" }
    let afterScheme = label.components(separatedBy: "://").last ?? label
    return afterScheme.components(separatedBy: ":").first ?? afterScheme
}