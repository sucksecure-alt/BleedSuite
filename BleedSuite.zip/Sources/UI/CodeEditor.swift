
import SwiftUI
import AppKit

// ============================================================================
//  Raw message editor with HTTP syntax highlighting
// ============================================================================

/// AppKit-backed editor. SwiftUI `TextEditor` cannot colour individual tokens, so the
/// whole app uses this one view for every raw request/response surface.
struct CodeEditor: NSViewRepresentable {
    @Binding var text: String
    var isEditable: Bool = true
    var fontSize: CGFloat = 12
    var onSubmit: (() -> Void)? = nil

    func makeNSView(context: Context) -> NSScrollView {
        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.drawsBackground = false
        scroll.borderType = .noBorder

        let textView = Coordinator.makeTextView()
        textView.isEditable = isEditable
        textView.isSelectable = true
        textView.isRichText = false
        textView.isAutomaticQuoteSubstitutionEnabled = false
        textView.isAutomaticDashSubstitutionEnabled = false
        textView.isAutomaticTextReplacementEnabled = false
        textView.isAutomaticSpellingCorrectionEnabled = false
        textView.isContinuousSpellCheckingEnabled = false
        textView.allowsUndo = true
        textView.backgroundColor = Theme.NS.background
        textView.textContainerInset = NSSize(width: 8, height: 8)
        textView.font = Theme.mono(fontSize)
        textView.textColor = Theme.NS.textPrimary
        textView.insertionPointColor = NSColor(hex: 0x9E3B44)
        textView.selectedTextAttributes = [
            .backgroundColor: NSColor(hex: 0x2A2024),
            .foregroundColor: NSColor.white,
        ]
        textView.minSize = NSSize(width: 0, height: 0)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]

        context.coordinator.highlight(in: textView)
        textView.string = text

        scroll.documentView = textView
        context.coordinator.textView = textView
        context.coordinator.highlight(in: textView)
        return scroll
    }

    func updateNSView(_ scroll: NSScrollView, context: Context) {
        guard let textView = context.coordinator.textView else { return }
        textView.isEditable = isEditable
        textView.font = Theme.mono(fontSize)
        if textView.string != text {
            let selection = textView.selectedRange()
            textView.string = text
            if selection.location <= textView.string.utf16.count {
                textView.setSelectedRange(selection)
            }
            context.coordinator.highlight(in: textView)
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, NSTextViewDelegate {
        private let parent: CodeEditor
        weak var textView: NSTextView?
        private var pendingHighlight: DispatchWorkItem?

        init(_ parent: CodeEditor) {
            self.parent = parent
            super.init()
        }

        static func makeTextView() -> NSTextView {
            let textView = NSTextView()
            textView.isVerticallyResizable = true
            textView.isHorizontallyResizable = false
            return textView
        }

        func textDidChange(_ notification: Notification) {
            guard let textView else { return }
            parent.text = textView.string
            scheduleHighlight(textView)
        }

        /// `⌘↩` is the global "send" shortcut inside editors.
        func textView(_ textView: NSTextView, doCommandBy selector: Selector) -> Bool {
            let command = NSEvent.modifierFlags.contains(.command)
            if command, selector == #selector(NSTextView.insertNewline(_:)) {
                parent.onSubmit?()
                return true
            }
            return false
        }

        private func scheduleHighlight(_ textView: NSTextView) {
            pendingHighlight?.cancel()
            let item = DispatchWorkItem { [weak self, weak textView] in
                guard let self, let textView else { return }
                self.highlight(in: textView)
            }
            pendingHighlight = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.12, execute: item)
        }

        /// Single-pass colouring: request/response start line, header names, values and body.
        func highlight(in textView: NSTextView) {
            guard let storage = textView.textStorage else { return }
            let full = storage.string as NSString
            storage.beginEditing()
            storage.setAttributes(
                [
                    .font: Theme.mono(12),
                    .foregroundColor: NSColor(hex: 0xB4B0B8),
                ],
                range: NSRange(location: 0, length: full.length)
            )

            var inBody = false
            var lineStart = 0
            let lineCount = storage.string.components(separatedBy: "\n").count
            for index in 0..<lineCount {
                let lineRange = full.lineRange(for: NSRange(location: lineStart, length: 0))
                let line = full.substring(with: lineRange)
                let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
                let cleanRange = NSRange(location: lineRange.location, length: max(0, line.utf16.count))

                if !inBody && trimmed.isEmpty && lineStart > 0 {
                    inBody = true
                } else if !inBody {
                    if index == 0 {
                        colorStartLine(line, range: cleanRange, storage: storage)
                    } else if let colon = line.firstIndex(of: ":") {
                        let nameLength = line.distance(from: line.startIndex, to: colon)
                        storage.addAttribute(
                            .foregroundColor, value: NSColor(hex: Palette.methodPOST), range: NSRange(location: lineRange.location, length: nameLength)
                        )
                        let valueStart = nameLength + 1
                        if valueStart < line.utf16.count {
                            storage.addAttribute(
                                .foregroundColor,
                                value: NSColor(hex: Palette.status3xx),
                                range: NSRange(location: lineRange.location + valueStart, length: line.utf16.count - valueStart)
                            )
                        }
                    }
                } else if trimmed.hasPrefix("#") || trimmed.hasPrefix("//") {
                    storage.addAttribute(.foregroundColor, value: NSColor(hex: 0x65616B), range: cleanRange)
                }
                lineStart = NSMaxRange(lineRange)
                if lineStart >= full.length { break }
            }
            storage.endEditing()
        }

        private func colorStartLine(_ line: String, range: NSRange, storage: NSTextStorage) {
            let parts = line.split(separator: " ", maxSplits: 3, omittingEmptySubsequences: false)
            guard parts.count >= 2 else { return }
            if parts[0].uppercased().hasPrefix("HTTP/") {
                // Status line.
                storage.addAttribute(.foregroundColor, value: NSColor(hex: Palette.status3xx), range: range)
                if parts.count >= 2, let code = Int(parts[1]) {
                    storage.addAttribute(
                        .font, value: Theme.mono(12, weight: .bold),
                        range: NSRange(location: range.location + 5, length: parts[1].utf16.count)
                    )
                    storage.addAttribute(
                        .foregroundColor, value: NSColor(hex: statusHex(code)), range: range
                    )
                }
            } else {
                let method = parts[0].uppercased()
                storage.addAttribute(
                    .font, value: Theme.mono(12, weight: .bold),
                    range: NSRange(location: range.location, length: parts[0].utf16.count)
                )
                storage.addAttribute(.foregroundColor, value: NSColor(hex: methodHex(method)), range: range)
                let restStart = range.location + parts[0].utf16.count
                let restLength = max(0, line.utf16.count - parts[0].utf16.count)
                storage.addAttribute(.foregroundColor, value: NSColor(hex: 0xB4B0B8), range: NSRange(location: restStart, length: restLength))
                // Colour the protocol token at the end.
                if let last = parts.last, last.uppercased().hasPrefix("HTTP/") {
                    storage.addAttribute(
                        .foregroundColor, value: NSColor(hex: Palette.status2xx),
                        range: NSRange(location: range.location + line.utf16.count - last.utf16.count, length: last.utf16.count)
                    )
                }
            }
        }

        private func statusHex(_ code: Int) -> UInt32 { Palette.status(code) }
        private func methodHex(_ method: String) -> UInt32 { Palette.method(method) }
    }
}

// ============================================================================
//  Read-only body viewer
// ============================================================================

struct RawTextView: View {
    let text: String

    var body: some View {
        ScrollView([.vertical, .horizontal]) {
            Text(text.isEmpty ? "—" : text)
                .font(Theme.monoSwiftUI(11))
                .foregroundStyle(Theme.textSecondary)
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(8)
        }
        .background(Theme.background)
    }
}