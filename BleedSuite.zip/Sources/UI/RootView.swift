
import SwiftUI
import AppKit

// ============================================================================
//  Root shell: sidebar + workspace
// ============================================================================

struct RootView: View {
    @ObservedObject var model = AppModel.shared
    @State private var sidebarCollapsed = false

    var body: some View {
        HStack(spacing: 0) {
            sidebar
            Rectangle().fill(Theme.divider).frame(width: 1)
            WorkspaceContainer(workspace: model.workspace)
        }
        .background(Theme.background)
        .foregroundStyle(Theme.textPrimary)
    }

    // MARK: Sidebar

    private var sidebar: some View {
        VStack(spacing: 0) {
            brandBar
            Rectangle().fill(Theme.divider).frame(height: 1)
            workspaceList
            Rectangle().fill(Theme.divider).frame(height: 1)
            targetPane
            Rectangle().fill(Theme.divider).frame(height: 1)
            footer
        }
        .frame(width: Theme.sidebarWidth)
        .background(Theme.sidebar)
    }

    private var brandBar: some View {
        HStack(spacing: 11) {
            ZStack {
                Circle()
                    .fill(Theme.accentGradient)
                    .frame(width: 34, height: 34)
                Circle()
                    .strokeBorder(Theme.crimson.opacity(0.35), lineWidth: 1)
                    .frame(width: 34, height: 34)
                Image(systemName: "drop.fill")
                    .font(Theme.ui(15, weight: .bold))
                    .foregroundStyle(.white)
            }
            VStack(alignment: .leading, spacing: 1) {
                Text("BLEED SUITE")
                    .font(Theme.ui(17, weight: .heavy))
                    .tracking(2.0)
                    .foregroundStyle(Theme.textPrimary)
                    .fixedSize(horizontal: true, vertical: false)
                Text(verbatim: "от heartbleed.ru")
                    .font(Theme.ui(10, weight: .medium))
                    .tracking(0.6)
                    .foregroundStyle(Theme.crimson)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
    }

    private var workspaceList: some View {
        VStack(spacing: 1) {
            ForEach(Workspace.allCases) { workspace in
                NavRow(
                    workspace: workspace,
                    isSelected: model.workspace == workspace,
                    badge: badge(for: workspace),
                    badgeColor: badgeColor(for: workspace)
                ) {
                    model.workspace = workspace
                }
            }
        }
        .padding(.horizontal, 7)
        .padding(.vertical, 7)
    }

    private func badge(for workspace: Workspace) -> String? {
        switch workspace {
        case .intercept: return model.interceptItems.isEmpty ? nil : "\(model.interceptItems.count)"
        case .history: return model.totalHistoryCount > 0 ? model.totalHistoryCount.compactString : nil
        case .scanner:
            let high = model.scanIssues.filter { $0.severity >= .high }.count
            return high > 0 ? "\(high)" : (model.scanIssues.isEmpty ? nil : "\(model.scanIssues.count)")
        case .rules: return RulesEngine.shared.count > 0 ? "\(RulesEngine.shared.count)" : nil
        default: return nil
        }
    }

    private func badgeColor(for workspace: Workspace) -> Color {
        switch workspace {
        case .intercept: return Theme.crimson
        case .scanner: return Theme.danger
        default: return Theme.textSecondary
        }
    }

    private var targetPane: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                SectionLabel(text: "Site map")
                Spacer(minLength: 0)
                Button {
                    model.workspace = .target
                } label: {
                    Image(systemName: "arrow.up.left.and.arrow.down.right")
                        .font(Theme.ui(9))
                        .foregroundStyle(Theme.textTertiary)
                }
                .buttonStyle(.plain)
                .padding(.trailing, 8)
            }
            if model.targetTree.isEmpty {
                VStack(spacing: 6) {
                    Image(systemName: "point.3.filled.connected.trianglepath.dotted")
                        .font(Theme.ui(18, weight: .light))
                        .foregroundStyle(Theme.dividerBright)
                    Text("No targets yet")
                        .font(Theme.ui(11))
                        .foregroundStyle(Theme.textTertiary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                TargetTreeView(
                    nodes: model.targetTree,
                    isCompact: true,
                    onSelectLeaf: { pair in model.sendToRepeater(pair) },
                    onSelectHost: { node in model.filterHistoryByHost(Self.hostName(from: node.name)) }
                )
            }
        }
        .frame(maxHeight: .infinity)
    }

    static func hostName(from root: String) -> String {
        var host = root
        if let range = root.range(of: "://") { host = String(root[range.upperBound...]) }
        return host.components(separatedBy: ":").first ?? host
    }

    private var footer: some View {
        VStack(spacing: 7) {
            HStack(spacing: 5) {
                Circle()
                    .fill(model.proxyRunning ? Theme.crimson : Theme.textTertiary)
                    .frame(width: 6, height: 6)
                Text(verbatim: model.proxyRunning ? "Listening on 127.0.0.1:\(model.proxyPort)" : "Proxy stopped")
                    .font(Theme.monoSwiftUI(10))
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                    .foregroundStyle(Theme.textSecondary)
                Spacer(minLength: 0)
            }
            HStack(spacing: 5) {
                Image(systemName: "arrow.left.arrow.right")
                    .font(Theme.ui(9))
                    .foregroundStyle(Theme.textTertiary)
                Text(verbatim: "\(model.connectionCount) connection\(model.connectionCount == 1 ? "" : "s")")
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)
                Spacer(minLength: 0)
                Text(verbatim: "\(model.visibleHistoryCount) shown")
                    .font(Theme.monoSwiftUI(10))
                    .foregroundStyle(Theme.textTertiary)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
    }
}

// MARK: - Nav row

private struct NavRow: View {
    let workspace: Workspace
    let isSelected: Bool
    let badge: String?
    let badgeColor: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 9) {
                Image(systemName: workspace.icon)
                    .font(Theme.ui(11, weight: .medium))
                    .foregroundStyle(isSelected ? Theme.crimsonBright : Theme.textTertiary)
                    .frame(width: 16)
                Text(workspace.title)
                    .font(Theme.ui(12, weight: isSelected ? .semibold : .regular))
                    .foregroundStyle(isSelected ? Theme.textPrimary : Theme.textSecondary)
                Spacer(minLength: 0)
                if let badge {
                    Text(badge)
                        .font(Theme.ui(9, weight: .bold))
                        .foregroundStyle(Theme.background)
                        .padding(.horizontal, 5)
                        .padding(.vertical, 1)
                        .background(Capsule().fill(badgeColor))
                }
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .background(
                RoundedRectangle(cornerRadius: Theme.smallCorner, style: .continuous)
                    .fill(isSelected ? Theme.crimson.opacity(0.12) : Color.clear)
            )
            .overlay(alignment: .leading) {
                if isSelected {
                    Capsule()
                        .fill(Theme.crimson)
                        .frame(width: 2, height: 16)
                        .offset(x: -7)
                }
            }
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Toolbar shown above every workspace

struct WorkspaceToolbar<Content: View>: View {
    let title: String
    var subtitle: String? = nil
    @ViewBuilder var content: Content

    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 1) {
                Text(title)
                    .font(Theme.ui(16, weight: .bold))
                    .foregroundStyle(Theme.textPrimary)
                if let subtitle {
                    Text(subtitle)
                        .font(Theme.ui(10))
                        .foregroundStyle(Theme.textTertiary)
                }
            }
            Spacer(minLength: 12)
            content
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .frame(height: Theme.toolbarHeight)
        .background(Theme.surfaceRaised)
        .overlay(alignment: .bottom) {
            Rectangle().fill(Theme.divider).frame(height: 1)
        }
    }
}

// MARK: - Workspace container

struct WorkspaceContainer: View {
    let workspace: Workspace

    var body: some View {
        VStack(spacing: 0) {
            switch workspace {
            case .dashboard: DashboardView()
            case .intercept: InterceptView()
            case .history: HistoryView()
            case .target: TargetView()
            case .repeater: RepeaterView()
            case .comparer: ComparerView()
            case .intruder: IntruderView()
            case .scanner: ScannerView()
            case .rules: RulesView()
            case .settings: SettingsView()
            }
        }
    }
}

// MARK: - Number formatting

extension Int {
    var compactString: String {
        if self >= 1_000_000 { return String(format: "%.1fM", Double(self) / 1_000_000) }
        if self >= 1_000 { return String(format: "%.1fk", Double(self) / 1_000) }
        return "\(self)"
    }
}