import Foundation

// ============================================================================
//  Spider job
// ============================================================================

/// One URL waiting in the crawl queue.
struct SpiderJob: Sendable, Identifiable, Equatable {
    var id: String { key }
    let url: URL
    var depth: Int
    var method: String
    /// Where the URL came from — shown in the UI, useful for debugging.
    var foundVia: String
    /// Normalized URL, used as the `visited` key.
    var key: String { Spider.normalizedKey(url) }

    init(url: URL, depth: Int, method: String = "GET", foundVia: String = "seed") {
        self.url = url
        self.depth = depth
        self.method = method
        self.foundVia = foundVia
    }
}

// ============================================================================
//  Spider
// ============================================================================

/// Breadth-first crawler with a depth-priority queue.
///
/// The crawler owns no transport: it builds `HTTPMessage` requests and hands
/// them to a `ScanRequestSender` (implemented by `ProxyEngine` / `Sender`).
/// Results are appended to `crawled` as `HTTPPair`s tagged with
/// `origin: .spider` so the UI can tell them apart from proxy traffic.
actor Spider {

    static let shared = Spider()

    // MARK: - Config

    struct Config: Sendable {
        var maxDepth = 3
        var maxPages = 200
        var includeSubdomains = false
        var crawlJavaScript = true
        var delayMS = 100
        var maxBodyToParse = 4 * 1024 * 1024
        /// Extra hosts (and their subdomains) the crawl is allowed to touch.
        /// Empty = derive the scope from the seed URLs.
        var allowedHosts: [String] = []

        init() {}
    }

    // MARK: - State

    enum State: Sendable {
        case idle
        case running
        case finished

        var label: String {
            switch self {
            case .idle: return "Idle"
            case .running: return "Crawling"
            case .finished: return "Finished"
            }
        }
    }

    // MARK: - Stored properties

    private var _config = Config()
    private var sender: ScanRequestSender?

    private(set) var queue: [SpiderJob] = []
    private(set) var visited: Set<String> = []
    private(set) var discovered: [URL] = []
    private(set) var crawled: [HTTPPair] = []
    private(set) var state: State = .idle
    /// Invoked on the main actor after every queue/state change.
    var onUpdate: (@Sendable () -> Void)?

    /// Actor-safe setter for `onUpdate`.
    func setOnUpdate(_ callback: (@Sendable () -> Void)?) {
        onUpdate = callback
    }

    private var seedHosts: Set<String> = []
    private var nextSyntheticID: Int = -1

    // MARK: - Limits

    enum Limits {
        static let requestTimeoutSeconds = 10
        static let defaultUserAgent = "BleedSuite-Spider/1.0"
        /// Body of a response is only parsed when it is textual and under the cap.
        static let maxScriptBytes = 2 * 1024 * 1024
    }

    // MARK: - Configuration

    func configure(_ config: Config) {
        _config = config
        Task { await self.notify() }
    }

    func config() -> Config { _config }

    func configure(sender: ScanRequestSender) {
        self.sender = sender
    }

    // MARK: - Control

    /// Called by the proxy for every captured transaction. While a crawl is running
    /// the URLs the user's own browsing reveals are added to the queue (Burp-like
    /// "crawl in scope traffic"), otherwise the call is a no-op.
    ///
    /// `nonisolated` so the proxy can fire it from a synchronous code path.
    nonisolated func onTransaction(_ pair: HTTPPair) {
        let absolute = URL(string: "\(pair.scheme)://\(pair.host):\(pair.port)\(pair.request.path)")
        guard let absolute else { return }
        Task { await absorb(absolute, source: pair) }
    }

    private func absorb(_ url: URL, source: HTTPPair) async {
        guard state == .running else { return }
        guard isAllowed(url) else { return }
        let key = Spider.normalizedKey(url)
        if !visited.contains(key) {
            await enqueue(url, depth: 0, via: "browser")
        }
        guard let response = source.response else { return }
        for link in extractLinks(from: response, base: url) {
            await enqueue(link, depth: 0, via: "browser:\(source.url)")
        }
    }

    /// Clears previous results and crawls until the queue is empty or a limit is hit.
    ///
    /// `scope` is accepted for call-site compatibility with the rules engine and is
    /// deliberately ignored — scoping is driven by `Config.allowedHosts` and
    /// `Config.includeSubdomains` instead, so Core stays independent.
    func start(sender: ScanRequestSender, seedURLs: [URL], scope: Any?) async {
        _ = scope

        self.sender = sender
        queue.removeAll()
        visited.removeAll()
        discovered.removeAll()
        crawled.removeAll()
        seedHosts.removeAll()
        for seed in seedURLs {
            let host = seed.host?.lowercased() ?? ""
            if !host.isEmpty { seedHosts.insert(host) }
        }

        for seed in seedURLs where isAllowed(seed) {
            await enqueue(seed, depth: 0, via: "seed")
        }
        state = .running
        await notify()

        while state == .running {
            guard let job = nextJob() else {
                state = .finished
                await notify()
                break
            }
            if crawled.count >= _config.maxPages {
                state = .finished
                await notify()
                break
            }
            await crawl(job)
            if _config.delayMS > 0 {
                try? await Task.sleep(nanoseconds: UInt64(_config.delayMS) * 1_000_000)
            }
        }
    }

    func stop() {
        guard state == .running else { return }
        state = .idle
        Task { await self.notify() }
    }

    func reset() {
        queue.removeAll()
        visited.removeAll()
        discovered.removeAll()
        crawled.removeAll()
        seedHosts.removeAll()
        state = .idle
        Task { await self.notify() }
    }

    // MARK: - Stats

    var stats: (queued: Int, visited: Int, discovered: Int, crawled: Int) {
        (queue.count, visited.count, discovered.count, crawled.count)
    }

    // MARK: - Crawling

    private func nextJob() -> SpiderJob? {
        guard !queue.isEmpty else { return nil }
        // Depth priority: shallowest first, FIFO inside a depth level.
        var bestIndex = 0
        for (index, job) in queue.enumerated() where job.depth < queue[bestIndex].depth {
            bestIndex = index
        }
        return queue.remove(at: bestIndex)
    }

    private func enqueue(_ url: URL, depth: Int, via: String) async {
        guard depth <= _config.maxDepth else { return }
        guard let normalized = Spider.normalize(url) else { return }
        guard isAllowed(normalized) else { return }
        let key = Spider.normalizedKey(normalized)
        guard !visited.contains(key) else { return }
        // The queue is depth-priority, so a URL already waiting must not be added twice.
        guard !queue.contains(where: { $0.key == key }) else { return }
        guard crawled.count + queue.count < max(_config.maxPages, 1) * 4 else { return }

        queue.append(SpiderJob(url: normalized, depth: depth, foundVia: via))
        discovered.append(normalized)
        await notify()
    }

    private func crawl(_ job: SpiderJob) async {
        visited.insert(job.key)
        await notify()

        guard let sender, let host = job.url.host else { return }
        let scheme = job.url.scheme?.lowercased() ?? "http"
        let isSecure = scheme == "https"
        let port = job.url.port ?? (isSecure ? 443 : 80)

        let target = Spider.requestTarget(job.url)
        var request = HTTPMessage(isRequest: true, startLine: "\(job.method) \(target) HTTP/1.1")
        request.headers = [
            Header(name: "Host", value: host),
            Header(name: "User-Agent", value: Limits.defaultUserAgent),
            Header(name: "Accept", value: "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8"),
            Header(name: "Accept-Encoding", value: "identity"),
            Header(name: "Connection", value: "close")
        ]
        request.normalizeFraming()

        let started = Date()
        let response = await sender.send(
            request,
            host: host,
            port: port,
            isSecure: isSecure,
            timeoutSeconds: Limits.requestTimeoutSeconds
        )
        let elapsed = Int(Date().timeIntervalSince(started) * 1000)

        nextSyntheticID -= 1
        var pair = HTTPPair(
            id: nextSyntheticID,
            time: started,
            durationMS: elapsed,
            host: host,
            port: port,
            isSecure: isSecure,
            request: request,
            response: response,
            origin: .spider
        )
        pair.note = "depth \(job.depth) via \(job.foundVia)"
        crawled.append(pair)
        await notify()

        guard let response else { return }
        let children = extractLinks(from: response, base: job.url)
        for child in children {
            await enqueue(child, depth: job.depth + 1,
                          via: job.url.path.isEmpty ? job.url.absoluteString : job.url.path)
        }
    }

    // MARK: - Link extraction

    /// Pulls candidate links out of a response body (HTML / JS / JSON).
    func extractLinks(from response: HTTPMessage, base: URL) -> [URL] {
        guard !response.body.isEmpty, response.body.count <= _config.maxBodyToParse else { return [] }
        let body = Scanner.textPrefix(response.body, limit: min(_config.maxBodyToParse, Limits.maxScriptBytes))
        guard !body.isEmpty else { return [] }
        let contentType = response.contentType
        var raw: [String] = []

        if contentType.contains("html") || body.range(of: "<html", options: .caseInsensitive) != nil
            || contentType.isEmpty {
            raw += matches(#"(href|src|action)\s*=\s*["']([^"']+)["']"#, in: body, group: 2)
        }
        if _config.crawlJavaScript {
            if contentType.contains("javascript") || body.contains("<script") || contentType.isEmpty
                || contentType.contains("html") {
                raw += matches(#"["'](/[a-zA-Z0-9_\-/\.]+)["']"#, in: body)
            }
        }
        if contentType.contains("json") || body.first == "{" || body.first == "[" {
            raw += matches(#""url"\s*:\s*"([^"]+)""#, in: body)
        }
        guard !raw.isEmpty else { return [] }

        var out: [URL] = []
        var seen = Set<String>()
        for candidate in raw {
            let trimmed = candidate.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { continue }
            let lower = trimmed.lowercased()
            if lower.hasPrefix("mailto:") || lower.hasPrefix("javascript:") || lower.hasPrefix("tel:")
                || lower.hasPrefix("data:") || lower.hasPrefix("about:") || lower.hasPrefix("file:")
                || lower.hasPrefix("blob:") || lower.hasPrefix("#") {
                continue
            }
            guard let resolved = URL(string: Params.percentDecode(trimmed), relativeTo: base)?.absoluteURL,
                  let scheme = resolved.scheme?.lowercased(), scheme == "http" || scheme == "https" else {
                continue
            }
            guard let normalized = Spider.normalize(resolved) else { continue }
            let key = Spider.normalizedKey(normalized)
            guard !seen.contains(key) else { continue }
            seen.insert(key)
            out.append(normalized)
        }
        return out
    }

    private func matches(_ pattern: String, in text: String, group: Int = 1) -> [String] {
        guard let rx = Regex.regex(pattern, options: [.caseInsensitive]) else { return [] }
        let ns = text as NSString
        var out: [String] = []
        rx.enumerateMatches(in: text, range: NSRange(location: 0, length: ns.length)) { match, _, _ in
            guard let match, match.numberOfRanges > group, let range = Range(match.range(at: group), in: text) else { return }
            out.append(String(text[range]))
        }
        return out
    }

    // MARK: - Scope

    /// In-scope test: explicit `Config.allowedHosts` wins, otherwise the seed hosts.
    private func isAllowed(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        let scheme = url.scheme?.lowercased()
        guard scheme == "http" || scheme == "https" else { return false }

        let explicit = _config.allowedHosts.map { $0.lowercased() }.filter { !$0.isEmpty }
        if !explicit.isEmpty {
            return explicit.contains { Spider.host(host, matches: $0, includeSubdomains: true) }
        }
        guard !seedHosts.isEmpty else { return true }
        return seedHosts.contains { Spider.host(host, matches: $0, includeSubdomains: _config.includeSubdomains) }
    }

    static func host(_ host: String, matches allowed: String, includeSubdomains: Bool) -> Bool {
        if host == allowed { return true }
        guard includeSubdomains, host.hasSuffix("." + allowed) else { return false }
        return true
    }

    // MARK: - Normalization

    /// Canonical form used for `visited` / dedup: no fragment, no default port,
    /// lowercased host, query preserved, empty path becomes `/`.
    static func normalize(_ url: URL) -> URL? {
        guard var comps = URLComponents(url: url, resolvingAgainstBaseURL: true) else { return nil }
        let scheme = (comps.scheme ?? "").lowercased()
        guard scheme == "http" || scheme == "https" else { return nil }
        guard let rawHost = comps.host?.lowercased(), !rawHost.isEmpty else { return nil }
        comps.fragment = nil
        comps.host = rawHost
        if let port = comps.port, (scheme == "http" && port == 80) || (scheme == "https" && port == 443) {
            comps.port = nil
        }
        if comps.path.isEmpty { comps.path = "/" }
        // Strip a trailing slash only for the root path.
        if comps.path.count > 1 && comps.path.hasSuffix("/") { comps.path.removeLast() }
        return comps.url
    }

    static func normalizedKey(_ url: URL) -> String {
        guard var comps = URLComponents(url: url, resolvingAgainstBaseURL: true) else { return url.absoluteString }
        comps.fragment = nil
        var out = comps.url?.absoluteString ?? url.absoluteString
        if out.count > 512 { out = String(out.prefix(512)) }
        return out
    }

    /// Path + query of an absolute URL, ready for a request line.
    static func requestTarget(_ url: URL) -> String {
        guard let comps = URLComponents(url: url, resolvingAgainstBaseURL: true) else { return "/" }
        var target = comps.percentEncodedPath.isEmpty ? "/" : comps.percentEncodedPath
        if let query = comps.percentEncodedQuery, !query.isEmpty { target += "?" + query }
        return target
    }

    // MARK: - Notifications

    /// Hop to the main actor so UI observers can touch AppKit directly.
    private func notify() async {
        guard let callback = onUpdate else { return }
        await MainActor.run { callback() }
    }
}