import Foundation
import Security

/// Shared queues for socket event handlers.
///
/// A page load opens hundreds of TLS sessions at once. A `DispatchQueue` per session meant a
/// private thread per session — and each one parked inside a blocking `read` on the relay socket.
/// Dispatch refused to spawn past 512 threads and the process stalled. Everything that only
/// moves bytes between the browser and the socketpair is event-driven through these shared
/// queues now, so they cost a fixed handful of threads regardless of session count.
enum TLSPools {
    static let io: [DispatchQueue] = (0..<6).map { DispatchQueue(label: "bleedsuite.tls.io.\($0)") }

    static func pick(_ seed: Int) -> DispatchQueue {
        io[abs(seed) % io.count]
    }
}

/// TLS server termination for intercepted HTTPS sessions.
///
/// Network.framework cannot upgrade an already-accepted connection to TLS, so the browser's
/// encrypted byte stream is spliced into one end of a `socketpair` (`relayFD`) while Secure
/// Transport runs a complete TLS server handshake and record layer on the other end (`tlsFD`).
///
/// I/O model — deliberately split, because the two halves want opposite things:
///
/// * **Record layer (`tlsFD`, blocking).** Secure Transport's `SSLReadFunc`/`SSLWriteFunc` are
///   written around blocking descriptors; driving them from readiness callbacks corrupts the
///   record stream (`errSSLProtocol`) and kills every handshake. So `tlsFD` stays blocking and
///   every `SSL*` call is serialised on the per-session `tlsQueue`.
/// * **Relay (`relayFD`, non-blocking, event-driven).** Moving ciphertext between the browser
///   and the socketpair needs no Secure Transport involvement at all, so it runs off
///   `DispatchSource`s on the shared `TLSPools` queues. This is the half that used to cost one
///   parked thread per session.
final class TLSTerminationBridge: ByteStream, @unchecked Sendable {
    private var relayFD: Int32 = -1
    private var tlsFD: Int32 = -1
    private var ctx: SSLContext?

    /// Serialises every Secure Transport call for *this* context. Blocking by design: the record
    /// layer needs a thread that can wait for the peer.
    private let tlsQueue = DispatchQueue(label: "bleedsuite.tls")
    private let ioQueue = TLSPools.pick(Int.random(in: 0..<Int.max))

    private let onEncryptedOut: @Sendable (Data) -> Void
    private let onClose: @Sendable () -> Void

    private let stateLock = NSLock()
    private var closed = false

    /// Guards the three `DispatchSource` ivars. They are installed and torn down from different
    /// queues; two queues writing an ARC-managed ivar unsynchronised double-releases the source
    /// and libdispatch answers with `API MISUSE: Resurrection of an object`.
    private let sourceLock = NSLock()

    /// Bytes still owed to the browser. Written from the record layer and from `deliverEncrypted`
    /// on different queues, so it is guarded.
    private let ioLock = NSLock()
    private var pendingToRelay = Data()

    private var relayInSource: DispatchSourceRead?
    private var relayOutSource: DispatchSourceWrite?

    init(onEncryptedOut: @escaping @Sendable (Data) -> Void, onClose: @escaping @Sendable () -> Void) {
        self.onEncryptedOut = onEncryptedOut
        self.onClose = onClose

        var fds: [Int32] = [0, 0]
        guard socketpair(AF_UNIX, SOCK_STREAM, 0, &fds) == 0 else { return }
        relayFD = fds[0]
        tlsFD = fds[1]

        // A write to a closed socket must never kill the process.
        var on: Int32 = 1
        setsockopt(relayFD, SOL_SOCKET, SO_NOSIGPIPE, &on, socklen_t(MemoryLayout<Int32>.size))
        setsockopt(tlsFD, SOL_SOCKET, SO_NOSIGPIPE, &on, socklen_t(MemoryLayout<Int32>.size))

        // Only the relay end is event-driven. `tlsFD` deliberately stays blocking.
        let flags = fcntl(relayFD, F_GETFL, 0)
        _ = fcntl(relayFD, F_SETFL, flags | O_NONBLOCK)

        // Modest kernel buffers: hundreds of sessions times 2 MB of socket buffers was hundreds
        // of megabytes of pure buffer.
        var bufferSize: Int32 = 256 * 1024
        for fd in [relayFD, tlsFD] {
            setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &bufferSize, socklen_t(MemoryLayout<Int32>.size))
            setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &bufferSize, socklen_t(MemoryLayout<Int32>.size))
        }
    }

    var isReady: Bool { tlsFD >= 0 && relayFD >= 0 }

    // MARK: - Lifecycle

    func handshake(identity: SecIdentity, extraChain: [SecCertificate] = []) async throws {
        guard tlsFD >= 0, relayFD >= 0 else { throw StreamError.closed }
        guard let context = SSLCreateContext(kCFAllocatorDefault, .serverSide, .streamType) else {
            throw StreamError.failed("SSLCreateContext failed")
        }
        ctx = context

        var status = SSLSetIOFuncs(context, Self.tlsRead, Self.tlsWrite)
        guard status == noErr else { throw StreamError.failed("SSLSetIOFuncs: \(status)") }
        status = SSLSetConnection(context, Unmanaged.passUnretained(self).toOpaque())
        guard status == noErr else { throw StreamError.failed("SSLSetConnection: \(status)") }

        var chain: [AnyObject] = [identity]
        chain.append(contentsOf: extraChain)
        status = SSLSetCertificate(context, chain as CFArray)
        guard status == noErr else { throw StreamError.failed("SSLSetCertificate: \(status)") }

        // TLS 1.2 is the ceiling of the legacy Secure Transport stack; browsers accept it.
        SSLSetProtocolVersionMin(context, .tlsProtocol12)

        let result = await withCheckedContinuation { (cont: CheckedContinuation<OSStatus, Never>) in
            tlsQueue.async {
                var outcome = errSSLWouldBlock
                repeat { outcome = SSLHandshake(context) } while outcome == errSSLWouldBlock
                cont.resume(returning: outcome)
            }
        }
        guard result == noErr else { throw StreamError.failed("TLS handshake failed: \(result)") }
    }

    /// Feeds encrypted bytes received from the browser into the TLS record layer.
    func deliverEncrypted(_ data: Data) {
        guard !data.isEmpty else { return }
        ioLock.lock()
        pendingToRelay.append(data)
        ioLock.unlock()
        flushRelay()
    }

    // MARK: - ByteStream (decrypted side)

    func readSome() async throws -> Data {
        try await withCheckedThrowingContinuation { cont in
            tlsQueue.async { [self] in
                guard self.tlsFD >= 0, let context = self.ctx else {
                    cont.resume(throwing: StreamError.closed)
                    return
                }
                var buffer = [UInt8](repeating: 0, count: 256 * 1024)
                while true {
                    var processed = 0
                    let status = buffer.withUnsafeMutableBytes { raw -> OSStatus in
                        SSLRead(context, raw.baseAddress!, raw.count, &processed)
                    }
                    if processed > 0 {
                        cont.resume(returning: Data(buffer[0..<processed]))
                        return
                    }
                    switch status {
                    case noErr, errSSLWouldBlock:
                        continue
                    case errSSLClosedGraceful, errSSLClosedAbort, errSSLClosedNoNotify:
                        cont.resume(throwing: StreamError.eof)
                        self.close()
                        return
                    default:
                        cont.resume(throwing: StreamError.failed("SSLRead: \(status)"))
                        self.close()
                        return
                    }
                }
            }
        }
    }

    func write(_ data: Data) async throws {
        guard !data.isEmpty else { return }
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            tlsQueue.async { [self] in
                guard self.tlsFD >= 0, let context = self.ctx else {
                    cont.resume(throwing: StreamError.closed)
                    return
                }
                let result: OSStatus = data.withUnsafeBytes { raw -> OSStatus in
                    guard let base = raw.baseAddress else { return errSecParam }
                    var total = 0
                    while total < raw.count {
                        var written = 0
                        let status = SSLWrite(context, base.advanced(by: total), raw.count - total, &written)
                        if status != noErr && status != errSSLWouldBlock { return status }
                        total += written
                        if written == 0 && status == errSSLWouldBlock {
                            // The relay socket is backed up; push what we have and wait for room.
                            self.flushRelay()
                            return errSecIO
                        }
                    }
                    return noErr
                }
                if result == noErr {
                    self.flushRelay()
                    cont.resume()
                } else {
                    cont.resume(throwing: StreamError.failed("SSLWrite: \(result)"))
                    self.close()
                }
            }
        }
    }

    func close() {
        stateLock.lock()
        let already = closed
        closed = true
        stateLock.unlock()
        guard !already else { return }

        // Cancel before closing: a live source on a recycled descriptor is a crash waiting to
        // happen.
        sourceLock.lock()
        let sources: [any DispatchSourceProtocol] = [relayInSource, relayOutSource].compactMap { $0 }
        relayInSource = nil
        relayOutSource = nil
        sourceLock.unlock()
        for source in sources { source.cancel() }

        // No `SSLClose` here, on purpose.
        //
        // Secure Transport keeps the I/O callbacks and the connection pointer for the whole life
        // of a session: `SSLClose` flushes a close-notify through them after the bridge that owns
        // the socketpair may already have been released, and `SSLSetIOFuncs` cannot revoke them
        // once the handshake has run. The result was a SIGSEGV inside the record layer's write
        // queue, reproducibly, under load.
        //
        // Closing the descriptors ends the session just as effectively — the peer sees the
        // socket go away, a parked `SSLRead` returns, and nothing can reach back into this object.
        ctx = nil
        if tlsFD >= 0 { Darwin.close(tlsFD); tlsFD = -1 }
        if relayFD >= 0 { Darwin.close(relayFD); relayFD = -1 }
        onClose()
    }

    /// Starts pumping encrypted bytes from the TLS record layer toward the browser.
    func startPump() {
        ioQueue.async { [weak self] in self?.installRelayIn() }
    }

    // MARK: - Relay socket (event-driven, never parks a thread)

    private func installRelayIn() {
        sourceLock.lock()
        defer { sourceLock.unlock() }
        guard relayInSource == nil, relayFD >= 0, !isClosed else { return }
        let source = DispatchSource.makeReadSource(fileDescriptor: relayFD, queue: ioQueue)
        source.setEventHandler { [weak self] in self?.drainRelay() }
        relayInSource = source
        source.resume()
    }

    /// Writes as much of `pendingToRelay` into `relayFD` as the socket will take and reports how
    /// many bytes actually moved. Callers must never claim more than this.
    private func flushRelayCount() -> Int {
        ioLock.lock()
        defer { ioLock.unlock() }
        guard relayFD >= 0 else { return -1 }

        var written = 0
        while !pendingToRelay.isEmpty {
            let n = pendingToRelay.withUnsafeBytes { raw -> Int in
                guard let base = raw.baseAddress else { return -1 }
                return Darwin.write(relayFD, base, raw.count)
            }
            if n > 0 {
                pendingToRelay.removeFirst(n)
                written += n
                continue
            }
            if n < 0, errno == EINTR { continue }
            break
        }
        return written
    }

    private func flushRelay() {
        guard flushRelayCount() >= 0 else { return }
        ioLock.lock()
        let drained = pendingToRelay.isEmpty
        ioLock.unlock()
        if drained {
            disarmRelayWritable()
        } else {
            armRelayWritable()
        }
    }

    private func armRelayWritable() {
        ioQueue.async { [weak self] in
            guard let self else { return }
            self.sourceLock.lock()
            defer { self.sourceLock.unlock() }
            guard self.relayOutSource == nil, self.relayFD >= 0, !self.isClosed else { return }
            let source = DispatchSource.makeWriteSource(fileDescriptor: self.relayFD, queue: self.ioQueue)
            source.setEventHandler { [weak self] in self?.flushRelay() }
            self.relayOutSource = source
            source.resume()
        }
    }

    private func disarmRelayWritable() {
        ioQueue.async { [weak self] in
            guard let self else { return }
            self.sourceLock.lock()
            let source = self.relayOutSource
            self.relayOutSource = nil
            self.sourceLock.unlock()
            source?.cancel()
        }
    }

    private func drainRelay() {
        guard relayFD >= 0 else { return }
        var buffer = [UInt8](repeating: 0, count: 256 * 1024)
        while true {
            let n = Darwin.read(relayFD, &buffer, buffer.count)
            if n > 0 {
                onEncryptedOut(Data(buffer[0..<n]))
                continue
            }
            if n == 0 { close(); return }
            if errno == EINTR { continue }
            return // EAGAIN: the source fires again when more arrives
        }
    }

    private var isClosed: Bool {
        stateLock.lock(); defer { stateLock.unlock() }
        return closed
    }

    // MARK: - Secure Transport I/O callbacks

    private static let tlsRead: SSLReadFunc = { connection, data, dataLength in
        let bridge = Unmanaged<TLSTerminationBridge>.fromOpaque(connection).takeUnretainedValue()
        while true {
            let n = Darwin.read(bridge.tlsFD, data, dataLength.pointee)
            if n > 0 {
                dataLength.pointee = n
                return noErr
            }
            if n == 0 {
                dataLength.pointee = 0
                return errSSLClosedGraceful
            }
            if errno == EINTR { continue }
            return errSecIO
        }
    }

    private static let tlsWrite: SSLWriteFunc = { connection, data, dataLength in
        let bridge = Unmanaged<TLSTerminationBridge>.fromOpaque(connection).takeUnretainedValue()
        let total = dataLength.pointee
        guard total > 0 else { return noErr }
        let rawPointer = UnsafeRawPointer(data)

        // Written directly to `tlsFD`, never through `pendingToRelay`.
        //
        // The socketpair is crossed: `deliverEncrypted` writes the browser's ciphertext into
        // `relayFD` and the record layer reads it back on `tlsFD`; the record layer writes its own
        // output to `tlsFD` and the relay pump reads that on `relayFD` and forwards it to the
        // browser. Writing the record output into `relayFD` instead puts it in the *inbound*
        // queue, the stream desynchronises, and every handshake dies with `errSSLProtocol`.
        //
        // A short write is legal — Secure Transport calls back with the remainder — and on
        // `EAGAIN` it retries the same buffer, which is why nothing is queued here.
        bridge.ioLock.lock()
        defer { bridge.ioLock.unlock() }
        guard bridge.tlsFD >= 0 else { return errSecIO }

        var totalWritten = 0
        while totalWritten < total {
            let n = Darwin.write(bridge.tlsFD, rawPointer.advanced(by: totalWritten), total - totalWritten)
            if n > 0 {
                totalWritten += n
                continue
            }
            if n < 0, errno == EINTR { continue }
            break
        }
        dataLength.pointee = totalWritten
        if totalWritten == 0 { return errSSLWouldBlock }
        return noErr
    }
}