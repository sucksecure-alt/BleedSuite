import Foundation

// ============================================================================
//  Send protocol (stub)
// ============================================================================

/// Performs a prepared HTTP request and returns the response.
///
/// The scanner never touches sockets itself — `ProxyEngine` / `Sender` provide
/// the implementation. Probe requests are ordinary `HTTPMessage`s; the scanner
/// builds the start line and headers itself and only reads the response.
protocol ScanRequestSender: Sendable {
    /// Выполняет подготовленный HTTP-запрос и возвращает ответ (или nil при ошибке).
    func send(_ request: HTTPMessage, host: String, port: Int, isSecure: Bool, timeoutSeconds: Int) async -> HTTPMessage?
}

// ============================================================================
//  Scanner
// ============================================================================

/// Passive + active auditor for captured exchanges.
///
/// Passive checks are pure functions of one transaction (no network traffic).
/// Active checks send at most `Limits.maxProbesPerCheck` synthetic requests
/// through a `ScanRequestSender` and only report a finding when a byte-level
/// marker comes back — those findings are flagged `confirmed`.
///
/// Probe traffic is *not* written to the history: only the returned
/// `HTTPMessage` is inspected. `process` therefore never produces an
/// `HTTPPair` for probes; when a probe pair is ever surfaced it must carry
/// `origin: .scanner`.
final class Scanner: @unchecked Sendable {

    static let shared = Scanner()

    // MARK: - Limits / constants

    enum Limits {
        /// Concurrent transactions processed by the queue workers.
        static let parallelism = 4
        /// Timeout handed to the sender for every probe.
        static let requestTimeoutSeconds = 10
        /// Upper bound for any body we are willing to scan as text.
        static let maxBodyScanBytes = 2 * 1024 * 1024
        /// Debug-leftover scan is cheaper than the full body scan.
        static let maxDebugScanBytes = 512 * 1024
        /// Hard cap of requests per active check (the prompt budget).
        static let maxProbesPerCheck = 3
        /// Small pause between probes so a target is not flooded.
        static let probeDelayMS = 30
        /// Idle poll interval of the queue workers.
        static let queuePollMS = 40
        /// Minimum length before a query value is treated as a token.
        static let tokenMinLength = 24
        /// How many times a host must have been seen before it is scanned when
        /// `scanAllHosts == false` (first sighting is skipped).
        static let minRepeatsForScan = 1
        static let probeUserAgent = "BleedSuite-Scanner/1.0"
        /// Max URL body length we hand over to the response parsers.
        static let probeSleepGranularityNS: UInt64 = 1_000_000
    }

    /// Names of the active checks, used by the settings UI.
    static let activeCheckNames: [String] = [
        "Reflected XSS", "Error-based SQLi", "Path Traversal", "Open Redirect"
    ]

    // MARK: - State

    private struct State {
        var issues: [ScanIssue] = []
        /// Transaction IDs waiting to be processed.
        var queued: [Int] = []
        /// Transaction IDs currently being processed.
        var running: Set<Int> = []
        /// Pairs kept so the queue can resolve an ID back into a pair.
        var pairsByID: [Int: HTTPPair] = [:]
        var scanAllHosts = true
        var isRunning = false
        var activeCheckNames: Set<String> = []
        /// `(host, path)` keys already probed by an active check.
        var scanned: Set<String> = []
        /// Hosts seen over https — feeds the downgrade check.
        var secureHosts: Set<String> = []
        /// How many transactions we have seen per host.
        var hostHits: [String: Int] = [:]
    }

    private let lock = NSLock()
    private let queue = DispatchQueue(label: "bleed.scanner", attributes: .concurrent)
    private let slots = DispatchSemaphore(value: Limits.parallelism)
    private var state = State()
    private var sender: ScanRequestSender?

    private init() {}

    private func withState<T>(_ body: (inout State) -> T) -> T {
        lock.lock()
        defer { lock.unlock() }
        return body(&state)
    }

    // MARK: - Configuration

    /// Must be called before any active check can run.
    func configure(sender: ScanRequestSender) {
        lock.lock()
        self.sender = sender
        lock.unlock()
    }

    /// Restricts (or enables) the active checks. An empty set means "all".
    func setActiveChecks(_ names: Set<String>) {
        withState { $0.activeCheckNames = names }
    }

    func activeChecks() -> Set<String> {
        withState { s in s.activeCheckNames.isEmpty ? Set(Scanner.activeCheckNames) : s.activeCheckNames }
    }

    /// When `false` only hosts with repeat traffic are scanned.
    func setScanAllHosts(_ value: Bool) {
        withState { $0.scanAllHosts = value }
    }

    func isScanning() -> Bool { withState { $0.isRunning } }

    // MARK: - Reading

    func issues() -> [ScanIssue] { withState { $0.issues } }

    /// Counts for every severity, including the zero buckets (handy for meters).
    func issueCountBySeverity() -> [ScanIssue.Severity: Int] {
        withState { s in
            var out: [ScanIssue.Severity: Int] = [:]
            for sev in ScanIssue.Severity.allCases { out[sev] = 0 }
            for issue in s.issues { out[issue.severity, default: 0] += 1 }
            return out
        }
    }

    func clear() {
        withState { s in
            s.issues.removeAll(keepingCapacity: true)
            s.queued.removeAll(keepingCapacity: true)
            s.running.removeAll(keepingCapacity: true)
            s.pairsByID.removeAll(keepingCapacity: true)
            s.scanned.removeAll(keepingCapacity: true)
            s.secureHosts.removeAll(keepingCapacity: true)
            s.hostHits.removeAll(keepingCapacity: true)
            s.isRunning = false
        }
    }

    // MARK: - Queueing

    func enqueue(_ pair: HTTPPair) {
        withState { s in
            if s.running.contains(pair.id) { return }
            if s.pairsByID[pair.id] != nil && s.queued.contains(pair.id) { return }
            s.pairsByID[pair.id] = pair
            if pair.isSecure { s.secureHosts.insert(pair.host.lowercased()) }
            if !s.queued.contains(pair.id) { s.queued.append(pair.id) }
        }
    }

    func enqueueAll(_ pairs: [HTTPPair]) {
        guard !pairs.isEmpty else { return }
        withState { s in
            for pair in pairs {
                if s.running.contains(pair.id) { continue }
                if s.pairsByID[pair.id] != nil && s.queued.contains(pair.id) { continue }
                s.pairsByID[pair.id] = pair
                if pair.isSecure { s.secureHosts.insert(pair.host.lowercased()) }
                if !s.queued.contains(pair.id) { s.queued.append(pair.id) }
            }
        }
    }

    /// Starts the workers. Repeated calls while running are no-ops.
    func start() {
        let launch: Bool = withState { s in
            guard !s.isRunning else { return false }
            s.isRunning = true
            return true
        }
        guard launch else { return }
        for _ in 0..<Limits.parallelism {
            let sem = slots
            Task.detached(priority: .utility) { [weak self] in
                await self?.worker(slots: sem)
            }
        }
    }

    /// Stops the workers. Already running transactions finish their current pass.
    func stop() {
        withState { s in
            s.isRunning = false
            s.queued.removeAll(keepingCapacity: true)
            s.pairsByID = s.pairsByID.filter { s.running.contains($0.key) }
        }
    }

    /// Scans one transaction right now, bypassing the queue.
    func scanNow(pair: HTTPPair) async {
        await slots.waitAsync()
        _ = withState { $0.running.insert(pair.id) }
        await process(pair)
        slots.signal()
    }

    // MARK: - Worker loop

    private func worker(slots sem: DispatchSemaphore) async {
        while true {
            let pair: HTTPPair? = withState { s in
                guard let id = s.queued.first else { return nil }
                s.queued.removeFirst()
                guard let pair = s.pairsByID[id] else { return nil }
                s.running.insert(id)
                return pair
            }
            guard let pair else { break }
            await sem.waitAsync()
            await process(pair)
            sem.signal()
            try? await Task.sleep(nanoseconds: UInt64(Limits.queuePollMS) * Limits.probeSleepGranularityNS)
        }
        withState { s in
            if s.queued.isEmpty { s.isRunning = false }
        }
    }

    // MARK: - Processing

    /// Runs every applicable check against one transaction.
    private func process(_ pair: HTTPPair) async {
        defer { _ = withState { $0.running.remove(pair.id) } }

        let hostKey = pair.host.lowercased()
        let allowed: Bool = withState { s in
            let hits = s.hostHits[hostKey] ?? 0
            s.hostHits[hostKey] = hits + 1
            if pair.isSecure { s.secureHosts.insert(hostKey) }
            return s.scanAllHosts || hits >= Limits.minRepeatsForScan
        }
        guard allowed else { return }

        var found = passiveIssues(for: pair)

        if let response = pair.response, let sender {
            found += await activeIssues(for: pair, response: response, sender: sender)
        }
        guard !found.isEmpty else { return }
        withState { $0.issues.append(contentsOf: found) }
    }

    /// Claims `(host, path)` for an active check. False → already probed.
    private func claimProbeKey(_ key: String) -> Bool {
        withState { s in
            if s.scanned.contains(key) { return false }
            s.scanned.insert(key)
            return true
        }
    }

    private func activeChecksEnabled(_ name: String) -> Bool {
        withState { s in s.activeCheckNames.isEmpty ? true : s.activeCheckNames.contains(name) }
    }

    private func activeIssues(for pair: HTTPPair, response: HTTPMessage, sender: ScanRequestSender) async -> [ScanIssue] {
        var out: [ScanIssue] = []
        if activeChecksEnabled("Reflected XSS") { out += await reflectedXSS(pair, response: response, sender: sender) }
        if activeChecksEnabled("Error-based SQLi") { out += await errorBasedSQLi(pair, response: response, sender: sender) }
        if activeChecksEnabled("Path Traversal") { out += await pathTraversal(pair, sender: sender) }
        if activeChecksEnabled("Open Redirect") { out += await openRedirect(pair, sender: sender) }
        return out
    }

    // ==========================================================================
    //  PASSIVE CHECKS
    // ==========================================================================

    private func passiveIssues(for pair: HTTPPair) -> [ScanIssue] {
        var out: [ScanIssue] = []
        out += missingSecurityHeaders(pair)
        out += cookiesWithoutSecureOrHttpOnly(pair)
        out += serverVersionDisclosure(pair)
        out += verboseErrorPage(pair)
        out += httpsDowngrade(pair)
        out += sensitiveDataInQuery(pair)
        out += tokenInURL(pair)
        out += passwordInRequestBody(pair)
        out += clickjackingVulnerable(pair)
        out += missingCORSHeaders(pair)
        out += insecureCookieDomain(pair)
        out += debugLeftovers(pair)
        return out
    }

    /// 1. Missing hardening headers. One issue per missing header so the detail
    ///    names exactly what is absent.
    private func missingSecurityHeaders(_ pair: HTTPPair) -> [ScanIssue] {
        guard let response = pair.response, let status = response.status, status < 500 else { return [] }
        let wanted: [(name: String, severity: ScanIssue.Severity, remediation: String)] = [
            ("Strict-Transport-Security",
             .low,
             "Добавить Strict-Transport-Security: max-age=31536000; includeSubDomains (заголовок имеет смысл только для https)."),
            ("Content-Security-Policy",
             .low,
             "Добавить Content-Security-Policy хотя бы с 'default-src \"self\"'."),
            ("X-Content-Type-Options",
             .low,
             "Добавить X-Content-Type-Options: nosniff."),
            ("X-Frame-Options",
             .info,
             "Добавить X-Frame-Options: DENY или CSP frame-ancestors 'none'.")
        ]
        var out: [ScanIssue] = []
        for item in wanted where response.header(item.name) == nil {
            out.append(issue(
                "Missing security header: \(item.name)",
                severity: item.severity,
                confidence: .certain,
                kind: .passive,
                pair: pair,
                detail: "Ответ \(response.startLine) не содержит заголовка \(item.name). "
                      + "Ответ: \(pair.url)",
                remediation: item.remediation
            ))
        }
        return out
    }

    /// 2. Set-Cookie without Secure / HttpOnly.
    private func cookiesWithoutSecureOrHttpOnly(_ pair: HTTPPair) -> [ScanIssue] {
        let cookies = pair.response?.headerValues("Set-Cookie") ?? []
        guard !cookies.isEmpty else { return [] }
        var offenders: [String] = []
        var missingSecure = 0
        var missingHttpOnly = 0
        for cookie in cookies {
            let lower = cookie.lowercased()
            let name = cookie.split(separator: "=").first.map(String.init) ?? cookie
            let hasSecure = Scanner.cookieAttribute(lower, "secure")
            let hasHttpOnly = Scanner.cookieAttribute(lower, "httponly")
            if hasSecure { } else { missingSecure += 1 }
            if hasHttpOnly { } else { missingHttpOnly += 1 }
            if !hasSecure || !hasHttpOnly {
                var why: [String] = []
                if !hasSecure { why.append("без Secure") }
                if !hasHttpOnly { why.append("без HttpOnly") }
                offenders.append("Set-Cookie: \(name) — \(why.joined(separator: ", "))")
            }
        }
        guard !offenders.isEmpty else { return [] }
        return [issue(
            "Cookie without Secure / HttpOnly",
            severity: .medium,
            confidence: .certain,
            kind: .passive,
            pair: pair,
            detail: "В ответе \(cookies.count) cookie, из них без флагов: \(offenders.count) "
                  + "(без Secure: \(missingSecure), без HttpOnly: \(missingHttpOnly)).",
            evidence: offenders.joined(separator: "\n")
        )]
    }

    /// 3. Server / framework version banners.
    private func serverVersionDisclosure(_ pair: HTTPPair) -> [ScanIssue] {
        guard let response = pair.response else { return [] }
        let interesting = ["Server", "X-Powered-By", "X-AspNet-Version", "X-AspNetMvc-Version", "X-Generator"]
        var found: [String] = []
        for name in interesting {
            for value in response.headerValues(name) where Regex.firstMatch(value, #"(?i)\d+\.\d+"#) != nil {
                found.append("\(name): \(value)")
            }
        }
        guard !found.isEmpty else { return [] }
        return [issue(
            "Server version disclosure",
            severity: .info,
            confidence: .certain,
            kind: .passive,
            pair: pair,
            detail: "Заголовки ответа раскрывают версию сервера или фреймворка: \(found.joined(separator: "; ")).",
            evidence: found.joined(separator: "\n"),
            remediation: "Убрать или переопределить баннер (ServerTokens Prod, скрыть X-Powered-By)."
        )]
    }

    /// 4. Stack traces / framework debug output in the body.
    private func verboseErrorPage(_ pair: HTTPPair) -> [ScanIssue] {
        guard let response = pair.response else { return [] }
        guard response.body.count < Limits.maxBodyScanBytes else { return [] }
        let body = Scanner.textPrefix(response.body, limit: Limits.maxBodyScanBytes)
        guard !body.isEmpty, response.isBodyTextual || response.contentType.contains("text/") else { return [] }

        let signatures: [(name: String, pattern: String)] = [
            ("Java stack trace", #"at [\w.$<>]+\([\w$]+\.java:\d+\)"#),
            ("PHP stack trace", #"stack trace:"#),
            ("Python traceback", #"(?i)Traceback \(most recent call last\)"#),
            ("Uncaught exception", #"(?i)\bException\b"#),
            ("PHP fatal error", #"Fatal error\b"#),
            ("Oracle error", #"(?i)ORA-\d{5}"#),
            ("ADO.NET provider error", #"Microsoft OLE DB Provider"#),
            ("JDBC / SQLite error", #"(?i)(java\.sql\.|SQLite\.JDBCDriver|sqlite3\.OperationalError)"#),
            ("Dotnet line number", #"(?i)\bat [\w.$<>]+ \([\w.]+:\d+\)"#),
            ("Encoded path disclosure", #"%2[fF]"#),
            ("ASP.NET error code", #"Server Error in \"?/'? ?Application"#)
        ]
        var hits: [String] = []
        var evidence: [String] = []
        for sig in signatures {
            guard let hit = Regex.firstMatch(body, sig.pattern) else { continue }
            hits.append(sig.name)
            evidence.append("\(sig.name): \(hit)")
            if hits.count >= 4 { break }
        }
        guard !hits.isEmpty else { return [] }
        let isError = (response.status ?? 0) >= 400
        return [issue(
            "Verbose error page",
            severity: .medium,
            confidence: isError ? .certain : .tentative,
            kind: .passive,
            pair: pair,
            detail: "Тело ответа \(pair.url) (\(Format.bytes(response.body.count))) содержит признаки "
                  + "подробной ошибки: \(hits.joined(separator: ", ")).",
            evidence: evidence.joined(separator: "\n"),
            remediation: "Отключить подробные ошибки в production (custom error pages, display_errors=Off)."
        )]
    }

    /// 5. http:// transaction on a host that is also reachable over https.
    private func httpsDowngrade(_ pair: HTTPPair) -> [ScanIssue] {
        guard !pair.isSecure, let response = pair.response else { return [] }
        let host = pair.host.lowercased()
        let hasSecureTwin: Bool = withState { $0.secureHosts.contains(host) }
        guard hasSecureTwin else { return [] }
        guard response.header("Strict-Transport-Security") == nil else { return [] }
        return [issue(
            "HTTPS downgrade / missing HSTS",
            severity: .low,
            confidence: .tentative,
            kind: .passive,
            pair: pair,
            detail: "Транзакция выполнена по http:// к хосту \(pair.host), который ранее использовался по https; "
                  + "ответ не содержит Strict-Transport-Security, поэтому браузер не зафиксирует апгрейд.",
            remediation: "Отдавать HSTS и редирект 301 http→https."
        )]
    }

    /// 6. Credentials-looking parameters in the query string / path.
    private func sensitiveDataInQuery(_ pair: HTTPPair) -> [ScanIssue] {
        let path = pair.request.path
        let pattern = #"(?i)(?i)(^|[?&;/])(password|passwd|pwd|token|secret|apikey|api_key|api-key|authorization|session|sessionid|access_token|refresh_token)=([^&;/]{1,})"#
        guard let rx = Regex.regex(pattern) else { return [] }
        let ns = path as NSString
        var names: [String] = []
        rx.enumerateMatches(in: path, range: NSRange(location: 0, length: ns.length)) { match, _, _ in
            guard let match,
                  match.numberOfRanges > 2,
                  let nameRange = Range(match.range(at: 2), in: path),
                  let valueRange = Range(match.range(at: 3), in: path) else { return }
            let value = String(path[valueRange])
            guard !value.isEmpty else { return }
            let name = String(path[nameRange]).lowercased()
            names.append("\(name) (значение \(value.count) символов)")
        }
        guard !names.isEmpty else { return [] }
        return [issue(
            "Sensitive data in query string",
            severity: .medium,
            confidence: .certain,
            kind: .passive,
            pair: pair,
            detail: "В URL \(pair.url) передаются чувствительные параметры: \(names.joined(separator: ", ")). "
                  + "Query string попадает в логи, историю браузера и Referer.",
            evidence: names.joined(separator: "\n"),
            remediation: "Передавать секреты в теле POST или в заголовке Authorization."
        )]
    }

    /// 7. Long base64url / hex looking values in URL.
    private func tokenInURL(_ pair: HTTPPair) -> [ScanIssue] {
        let path = pair.request.path
        let pattern = #"(?<![A-Za-z0-9_\-])[A-Za-z0-9_\-]{24,}={0,2}"#
        guard let rx = Regex.regex(pattern) else { return [] }
        let ns = path as NSString
        var hits: [String] = []
        rx.enumerateMatches(in: path, range: NSRange(location: 0, length: ns.length)) { match, _, _ in
            guard let match, let range = Range(match.range(at: 0), in: path) else { return }
            let value = String(path[range])
            guard Scanner.looksLikeToken(value) else { return }
            hits.append(value.count > 12 ? String(value.prefix(6)) + "…\(value.count) симв." : value)
        }
        guard !hits.isEmpty else { return [] }
        return [issue(
            "Token in URL",
            severity: .info,
            confidence: .tentative,
            kind: .passive,
            pair: pair,
            detail: "В URL \(pair.url) найдено \(hits.count) значение(й) длиной >= "
                  + "\(Limits.tokenMinLength) символов, похожих на base64url/hex токен: "
                  + "\(hits.joined(separator: ", ")). Токены в URL утекают через логи и Referer.",
            remediation: "Передавать токен в заголовке Authorization или в теле."
        )]
    }

    /// 8. Password field in a form / JSON body over a cleartext connection.
    private func passwordInRequestBody(_ pair: HTTPPair) -> [ScanIssue] {
        let request = pair.request
        guard !request.body.isEmpty, request.body.count < Limits.maxBodyScanBytes else { return [] }
        let body = String(decoding: request.body, as: UTF8.self)
        var found: [String] = []

        let keyPattern = #"(?i)["']?(password|passwd|pwd|pass|secret|token)["']?\s*[:=]\s*["']?([^"'\s,&;}]{1,})"#
        if let rx = Regex.regex(keyPattern) {
            rx.enumerateMatches(in: body, range: NSRange(location: 0, length: (body as NSString).length)) { match, _, _ in
                guard let match, match.numberOfRanges > 1, let r = Range(match.range(at: 1), in: body) else { return }
                found.append(String(body[r]))
            }
        }
        guard !found.isEmpty else { return [] }

        let isJSON = request.contentType.contains("json")
        let isForm = request.contentType.contains("application/x-www-form-urlencoded")
        let transport = pair.isSecure ? "https (TLS)" : "http (cleartext)"
        let severity: ScanIssue.Severity = pair.isSecure ? .low : .high
        return [issue(
            "Password in request body over cleartext",
            severity: severity,
            confidence: .certain,
            kind: .passive,
            pair: pair,
            detail: "\(pair.request.method) \(pair.url) передаёт поля пароля "
                  + "(\(found.joined(separator: ", "))) в \(isJSON ? "JSON" : isForm ? "form" : "теле") "
                  + "запроса по \(transport).",
            remediation: pair.isSecure
                ? "Пароль в HTTPS-запросе допустим, убедитесь что он не логируется."
                : "Использовать HTTPS для передачи учётных данных."
        )]
    }

    /// 9. HTML document without clickjacking protection.
    private func clickjackingVulnerable(_ pair: HTTPPair) -> [ScanIssue] {
        guard let response = pair.response, response.contentType.contains("text/html") else { return [] }
        guard let status = response.status, (200..<400).contains(status) else { return [] }
        if response.header("X-Frame-Options") != nil { return [] }
        let csp = response.header("Content-Security-Policy")?.lowercased() ?? ""
        if csp.contains("frame-ancestors") { return [] }
        return [issue(
            "Clickjacking vulnerable",
            severity: .medium,
            confidence: .certain,
            kind: .passive,
            pair: pair,
            detail: "HTML-документ \(pair.url) возвращается без X-Frame-Options и без "
                  + "'frame-ancestors' в Content-Security-Policy — его можно встроить в iframe.",
            remediation: "Добавить X-Frame-Options: DENY/SAMEORIGIN или CSP frame-ancestors 'none'."
        )]
    }

    /// 10. Wildcard CORS without credentials protection / without Vary: Origin.
    private func missingCORSHeaders(_ pair: HTTPPair) -> [ScanIssue] {
        guard let response = pair.response else { return [] }
        let acao = response.header("Access-Control-Allow-Origin")?.trimmingCharacters(in: .whitespaces)
        guard let acao, !acao.isEmpty else { return [] }
        let vary = (response.header("Vary") ?? "").lowercased()
        let varyOrigin = vary.split(separator: ",").contains { $0.trimmingCharacters(in: .whitespaces) == "origin" }
        let acac = (response.header("Access-Control-Allow-Credentials") ?? "").lowercased()
        let isJSON = response.contentType.contains("json")
        let wildcard = acao == "*"

        var problems: [String] = []
        if wildcard && acac.contains("true") {
            problems.append("Access-Control-Allow-Origin: * вместе с Access-Control-Allow-Credentials: true")
        }
        if !varyOrigin {
            problems.append("нет Vary: Origin при динамическом Access-Control-Allow-Origin")
        }
        guard !problems.isEmpty else { return [] }

        var confidence: ScanIssue.Confidence = .firm
        if !wildcard && varyOrigin { confidence = .tentative }
        return [issue(
            "Permissive / misconfigured CORS",
            severity: .info,
            confidence: confidence,
            kind: .passive,
            pair: pair,
            detail: "Ответ \(pair.url) (\(isJSON ? "JSON API" : "content-type \(response.contentType)")) имеет "
                  + "Access-Control-Allow-Origin: \(acao). Проблемы: \(problems.joined(separator: "; ")).",
            remediation: "Валидировать Origin по 白списку и всегда слать Vary: Origin."
        )]
    }

    /// 11. Cookie without Secure delivered over https.
    private func insecureCookieDomain(_ pair: HTTPPair) -> [ScanIssue] {
        guard pair.isSecure else { return [] }
        let cookies = pair.response?.headerValues("Set-Cookie") ?? []
        let offenders = cookies.filter { !Scanner.cookieAttribute($0.lowercased(), "secure") }
        guard !offenders.isEmpty else { return [] }
        return [issue(
            "Cookie without Secure over HTTPS",
            severity: .low,
            confidence: .certain,
            kind: .passive,
            pair: pair,
            detail: "HTTPS-ответ \(pair.url) устанавливает \(offenders.count) из \(cookies.count) cookie без флага Secure; "
                  + "по HTTP эти cookie тоже будут отправлены.",
            evidence: offenders.joined(separator: "\n"),
            remediation: "Добавить Secure (и SameSite) ко всем cookie."
        )]
    }

    /// 12. Debug leftovers in headers or body.
    private func debugLeftovers(_ pair: HTTPPair) -> [ScanIssue] {
        guard let response = pair.response else { return [] }
        let signatures: [(String, String)] = [
            ("TODO", #"\bTODO\b"#),
            ("FIXME", #"\bFIXME\b"#),
            ("XXX", #"\bXXX\b"#),
            ("console.log(", #"console\.log\("#),
            ("var_dump(", #"(?i)var_dump\("#),
            ("print_r(", #"(?i)print_r\("#),
            ("System.out.println", #"(?i)System\.out\.println"#)
        ]
        var hits: [String] = []
        var headerHits: [String] = []
        for header in response.headers where header.enabled {
            for sig in signatures {
                guard let m = Regex.firstMatch(header.trimmedValue, sig.1) else { continue }
                headerHits.append("\(header.trimmedName): \(m)")
                if hits.count < 6 { hits.append(sig.0) }
            }
        }
        var bodyHits: [String] = []
        if !response.body.isEmpty, response.body.count < Limits.maxDebugScanBytes {
            let body = Scanner.textPrefix(response.body, limit: Limits.maxDebugScanBytes)
            for sig in signatures {
                guard let m = Regex.firstMatch(body, sig.1) else { continue }
                bodyHits.append("\(sig.0): \(m)")
                if hits.count < 6 { hits.append(sig.0) }
            }
        }
        guard !headerHits.isEmpty || !bodyHits.isEmpty else { return [] }
        return [issue(
            "Debug leftovers",
            severity: .info,
            confidence: .firm,
            kind: .passive,
            pair: pair,
            detail: "В ответе \(pair.url) найдены отладочные остатки: \(hits.joined(separator: ", ")) "
                  + "(заголовков: \(headerHits.count), в теле: \(bodyHits.count)).",
            evidence: (headerHits + bodyHits).prefix(5).joined(separator: "\n")
        )]
    }

    // ==========================================================================
    //  ACTIVE CHECKS
    // ==========================================================================

    // MARK: 1. Reflected XSS

    private func reflectedXSS(_ pair: HTTPPair, response: HTTPMessage, sender: ScanRequestSender) async -> [ScanIssue] {
        guard response.contentType.contains("text/html") || Scanner.textPrefix(response.body, limit: 4096).contains("<html") else {
            return []
        }
        let key = "xss|\(pair.host.lowercased()):\(pair.port)\(pair.request.path)"
        guard claimProbeKey(key) else { return [] }

        // The original query is preserved so the page renders in a realistic state.
        let baseParams = pair.request.queryParams
        let payloads: [(name: String, value: String, marker: String)] = [
            ("bleedprobe1", "<bleedprobe123>", "<bleedprobe123>"),
            ("bleedprobe2", "\"><bleedprobe456>", "\"><bleedprobe456>")
        ]
        for payload in payloads.prefix(Limits.maxProbesPerCheck) {
            var mutated = baseParams
            mutated.append(Param(name: payload.name, value: payload.value))
            let target = Scanner.replacingPath(pair.request.path, query: Params.buildQuery(mutated))
            guard let probeResponse = await sendProbe(sender, pair: pair, target: target) else {
                continue
            }
            let body = Scanner.textPrefix(probeResponse.body, limit: Limits.maxBodyScanBytes)
            guard !body.isEmpty else { continue }
            switch Scanner.reflectedVerdict(body: body, marker: payload.marker) {
            case .unescaped(let snippet):
                return [issue(
                    "Reflected XSS",
                    severity: .high,
                    confidence: .certain,
                    kind: .active,
                    pair: pair,
                    detail: "Проба \(payload.name)=\(Scanner.urlEncode(payload.value)) отражается в HTML "
                          + "без экранирования '<' в ответе на \(pair.url) — подтверждённая XSS.",
                    evidence: snippet,
                    remediation: "Экранировать вывод (htmlspecialchars / textContent), включить CSP.",
                    transactionID: pair.id,
                    confirmed: true
                )]
            case .escaped, .absent:
                continue
            }
        }
        return []
    }

    // MARK: 2. Error-based SQLi

    private func errorBasedSQLi(_ pair: HTTPPair, response: HTTPMessage, sender: ScanRequestSender) async -> [ScanIssue] {
        let key = "sqli|\(pair.host.lowercased()):\(pair.port)\(pair.request.path)"
        guard claimProbeKey(key) else { return [] }

        let params = pair.request.queryParams
        let numericIndex = params.firstIndex { Scanner.isNumeric($0.value) }
        let numericPathSegment = params.isEmpty ? Scanner.trailingNumericSegment(pair.request.path) != nil : false

        let payloads = ["'", "1' AND 1=2--", "\""]
        var budget = Limits.maxProbesPerCheck

        if let numericIndex {
            let base = params[numericIndex].value.isEmpty ? "1" : params[numericIndex].value
            for payload in payloads where budget > 0 {
                budget -= 1
                var mutated = params
                mutated[numericIndex].value = base + payload
                let target = Scanner.replacingPath(pair.request.path, query: Params.buildQuery(mutated))
                guard let probe = await sendProbe(sender, pair: pair, target: target),
                      let hit = Scanner.databaseError(probe) else { continue }
                return [issue(
                    "Error-based SQL injection",
                    severity: .high,
                    confidence: .certain,
                    kind: .active,
                    pair: pair,
                    detail: "Параметр '\(params[numericIndex].name)' на \(pair.url) принимает SQL-метасимволы; "
                          + "ответ содержит сообщение СУБД: \(hit)",
                    evidence: hit,
                    remediation: "Использовать параметризованные запросы, валидировать тип параметра.",
                    transactionID: pair.id,
                    confirmed: true
                )]
            }
        } else if numericPathSegment, let segment = Scanner.trailingNumericSegment(pair.request.path) {
            for payload in ["'", "1' AND 1=2--"] where budget > 0 {
                budget -= 1
                let target = Scanner.replacingPath(pair.request.path, segment: segment, with: "1" + Scanner.urlEncode(payload))
                guard let probe = await sendProbe(sender, pair: pair, target: target),
                      let hit = Scanner.databaseError(probe) else { continue }
                return [issue(
                    "Error-based SQL injection",
                    severity: .high,
                    confidence: .certain,
                    kind: .active,
                    pair: pair,
                    detail: "Числовой сегмент пути '\(segment)' на \(pair.url) принимает SQL-метасимволы; "
                          + "ответ содержит сообщение СУБД: \(hit)",
                    evidence: hit,
                    remediation: "Использовать параметризованные запросы, валидировать тип параметра.",
                    transactionID: pair.id,
                    confirmed: true
                )]
            }
        }
        return []
    }

    // MARK: 3. Path traversal

    private func pathTraversal(_ pair: HTTPPair, sender: ScanRequestSender) async -> [ScanIssue] {
        guard pair.response != nil else { return [] }
        let key = "traversal|\(pair.host.lowercased()):\(pair.port)\(pair.request.path)"
        guard claimProbeKey(key) else { return [] }

        let payloads = [
            "../../../../etc/passwd",
            "..%2f..%2f..%2fetc%2fpasswd",
            "....//....//....//etc/passwd"
        ]
        for payload in payloads.prefix(Limits.maxProbesPerCheck) {
            let target = Scanner.replacingPath(pair.request.path, segment: Scanner.lastSegment(pair.request.path) ?? "", with: payload)
            guard !target.isEmpty,
                  let probe = await sendProbe(sender, pair: pair, target: target) else { continue }
            let body = Scanner.textPrefix(probe.body, limit: 256 * 1024)
            guard let hit = Scanner.firstMarker(body, "root:x:0:0:") else { continue }
            return [issue(
                "Path traversal",
                severity: .critical,
                confidence: .certain,
                kind: .active,
                pair: pair,
                detail: "Подстановка '\(payload)' в последний сегмент пути вернула содержимое /etc/passwd — "
                      + "LFI/RFI с обходом фильтра подтверждён.",
                evidence: hit,
                remediation: "Канонизировать путь, whitelist допустимых файлов, отключить переход по символам.",
                transactionID: pair.id,
                confirmed: true
            )]
        }
        return []
    }

    // MARK: 4. Open redirect

    private func openRedirect(_ pair: HTTPPair, sender: ScanRequestSender) async -> [ScanIssue] {
        let params = pair.request.queryParams
        guard !params.isEmpty,
              let index = params.firstIndex(where: { Scanner.isRedirectParam($0.name) }) else { return [] }
        let key = "redirect|\(pair.host.lowercased()):\(pair.port)\(pair.request.path)"
        guard claimProbeKey(key) else { return [] }

        let probeURL = "https://bleed-probe.invalid/"
        var mutated = params
        mutated[index].value = probeURL
        let target = Scanner.replacingPath(pair.request.path, query: Params.buildQuery(mutated))
        guard let probe = await sendProbe(sender, pair: pair, target: target) else { return [] }

        let locations = probe.headerValues("Location")
        for location in locations where location.lowercased().contains("bleed-probe.invalid")
            || Params.percentDecode(location).lowercased().contains("bleed-probe.invalid") {
            return [issue(
                "Open redirect",
                severity: .medium,
                confidence: .certain,
                kind: .active,
                pair: pair,
                detail: "Параметр '\(params[index].name)' на \(pair.url) принимает абсолютный URL: "
                      + "проба \(probeURL) отражена в заголовке Location.",
                evidence: "Location: \(location)",
                remediation: "Валидировать redirect по белому списку хостов / использовать относительные пути.",
                transactionID: pair.id,
                confirmed: true
            )]
        }
        let body = Scanner.textPrefix(probe.body, limit: Limits.maxBodyScanBytes)
        if let hit = Scanner.redirectBodyHit(body) {
            return [issue(
                "Open redirect",
                severity: .medium,
                confidence: .certain,
                kind: .active,
                pair: pair,
                detail: "Параметр '\(params[index].name)' на \(pair.url) отражает внешний URL в теле ответа "
                      + "(meta refresh / JavaScript redirect).",
                evidence: hit,
                remediation: "Валидировать redirect по белому списку хостов / использовать относительные пути.",
                transactionID: pair.id,
                confirmed: true
            )]
        }
        return []
    }

    // ==========================================================================
    //  Probe plumbing
    // ==========================================================================

    /// Builds a bare GET/HEAD request for the target and hands it to the sender.
    /// The response is returned for inspection only — never stored in history.
    private func sendProbe(_ sender: ScanRequestSender, pair: HTTPPair, target: String) async -> HTTPMessage? {
        guard !target.isEmpty else { return nil }
        var request = HTTPMessage(isRequest: true, startLine: "GET \(target) HTTP/1.1")
        var headers: [Header] = [
            Header(name: "Host", value: pair.host),
            Header(name: "User-Agent", value: Limits.probeUserAgent),
            Header(name: "Accept", value: "*/*"),
            Header(name: "Accept-Encoding", value: "identity"),
            Header(name: "Cache-Control", value: "no-cache"),
            Header(name: "Connection", value: "close")
        ]
        if let cookie = pair.request.header("Cookie"), !cookie.isEmpty {
            headers.append(Header(name: "Cookie", value: cookie))
        }
        if let referer = pair.request.header("Referer"), !referer.isEmpty {
            headers.append(Header(name: "Referer", value: referer))
        }
        request.headers = headers
        request.normalizeFraming()
        let response = await sender.send(
            request,
            host: pair.host,
            port: pair.port,
            isSecure: pair.isSecure,
            timeoutSeconds: Limits.requestTimeoutSeconds
        )
        if Limits.probeDelayMS > 0 {
            try? await Task.sleep(nanoseconds: UInt64(Limits.probeDelayMS) * Limits.probeSleepGranularityNS)
        }
        return response
    }

    // ==========================================================================
    //  Helpers
    // ==========================================================================

    private func issue(
        _ name: String,
        severity: ScanIssue.Severity,
        confidence: ScanIssue.Confidence,
        kind: ScanIssue.Kind,
        pair: HTTPPair,
        detail: String,
        evidence: String = "",
        remediation: String = "",
        transactionID: Int? = nil,
        confirmed: Bool = false
    ) -> ScanIssue {
        ScanIssue(
            name: name,
            severity: severity,
            confidence: confidence,
            kind: kind,
            host: pair.host,
            url: pair.url,
            detail: detail,
            evidence: evidence,
            remediation: remediation,
            transactionID: transactionID ?? pair.id,
            confirmed: confirmed
        )
    }

    // MARK: Strings

    /// Decodes as much of `data` as is valid UTF-8 (bounded by `limit`).
    static func textPrefix(_ data: Data, limit: Int) -> String {
        guard !data.isEmpty else { return "" }
        let slice = data.prefix(max(0, limit))
        if let text = String(data: slice, encoding: .utf8) { return text }
        return String(decoding: slice, as: UTF8.self)
    }

    static func cookieAttribute(_ loweredCookie: String, _ attribute: String) -> Bool {
        for part in loweredCookie.split(separator: ";") {
            let token = part.split(separator: "=", maxSplits: 1).first.map(String.init)?
                .trimmingCharacters(in: .whitespaces) ?? ""
            if token == attribute { return true }
        }
        return false
    }

    static func isNumeric(_ value: String) -> Bool {
        guard !value.isEmpty, value.count <= 18 else { return false }
        return value.allSatisfy { $0.isNumber }
    }

    /// base64url / hex looking value of at least `Limits.tokenMinLength` chars.
    static func looksLikeToken(_ value: String) -> Bool {
        guard value.count >= Limits.tokenMinLength else { return false }
        if value.allSatisfy(\.isHexDigit), value.count >= 32 { return true }
        let hasDigit = value.contains { $0.isNumber }
        let hasUpper = value.contains { $0.isUppercase }
        let hasLower = value.contains { $0.isLowercase }
        return hasDigit && hasUpper && hasLower
    }

    static func isRedirectParam(_ name: String) -> Bool {
        let n = name.lowercased()
        let candidates = ["redirect", "redirect_uri", "redirect_url", "redir", "url", "next", "return",
                          "returnurl", "return_url", "returnto", "to", "target", "dest", "destination",
                          "goto", "go", "out", "continue", "view", "forward", "callback", "link"]
        return candidates.contains { n == $0 || n == $0.replacingOccurrences(of: "-", with: "_") }
    }

    static func urlEncode(_ value: String) -> String {
        var out = ""
        for byte in Array(value.utf8) {
            let c = Character(UnicodeScalar(byte))
            if (byte >= 0x41 && byte <= 0x5A) || (byte >= 0x61 && byte <= 0x7A) || (byte >= 0x30 && byte <= 0x39)
                || "-._~".contains(c) {
                out.append(c)
            } else {
                out += String(format: "%%%02X", byte)
            }
        }
        return out
    }

    /// Replaces the query string, keeping the path.
    static func replacingPath(_ path: String, query: String) -> String {
        let base = path.split(separator: "?", maxSplits: 1).first.map(String.init) ?? "/"
        return query.isEmpty ? base : base + "?" + query
    }

    /// Replaces the last path segment, keeping the query string.
    static func replacingPath(_ path: String, segment: String, with replacement: String) -> String {
        let parts = path.split(separator: "?", maxSplits: 1, omittingEmptySubsequences: false)
        let base = parts.first ?? "/"
        let query = parts.count > 1 ? "?" + parts[1] : ""
        var segments = base.components(separatedBy: "/")
        if let last = segments.last, last.isEmpty {
            segments[segments.count - 1] = replacement
        } else if !segments.isEmpty {
            segments[segments.count - 1] = replacement
        } else {
            return replacement + query
        }
        return segments.joined(separator: "/") + query
    }

    static func lastSegment(_ path: String) -> String? {
        let base = path.split(separator: "?", maxSplits: 1).first.map(String.init) ?? path
        guard let last = base.split(separator: "/").last, !last.isEmpty else { return nil }
        return String(last)
    }

    static func trailingNumericSegment(_ path: String) -> String? {
        guard let last = lastSegment(path), isNumeric(last) else { return nil }
        return last
    }

    // MARK: Response analysis

    enum ReflectionVerdict {
        case unescaped(String)
        case escaped(String)
        case absent
    }

    /// Byte-level reflection check. The payload may come back raw (XSS), partially
    /// encoded, percent-encoded or HTML-entity-encoded (safe) — or not at all.
    static func reflectedVerdict(body: String, marker: String) -> ReflectionVerdict {
        let lowerBody = body.lowercased()
        let lowerMarker = marker.lowercased()
        let markerName = lowerMarker.filter { $0.isLetter || $0.isNumber }
        guard !markerName.isEmpty, lowerBody.contains(markerName) else { return .absent }

        // Raw "<...probe..." → the angle bracket survived, output is injectable.
        if let range = lowerBody.range(of: "<" + markerName) {
            return .unescaped(snippet(body, range: range, radius: 60))
        }
        // Safe encodings.
        let escapedForms = ["&lt;" + markerName, "%3c" + markerName, "&#60;" + markerName,
                            "&#x3c;" + markerName, "&LT;" + markerName]
        if let found = escapedForms.first(where: { lowerBody.contains($0) }) {
            return .escaped(snippet(body, range: lowerBody.range(of: found)!, radius: 40))
        }
        // Marker present but the leading quote/bracket was dropped — report as escaped.
        if let range = lowerBody.range(of: markerName) {
            return .escaped(snippet(body, range: range, radius: 40))
        }
        return .absent
    }

    static func snippet(_ text: String, range: Range<String.Index>, radius: Int) -> String {
        let lower = text.index(range.lowerBound, offsetBy: -radius, limitedBy: text.startIndex) ?? text.startIndex
        let upper = text.index(range.upperBound, offsetBy: radius, limitedBy: text.endIndex) ?? text.endIndex
        return String(text[lower..<upper]).replacingOccurrences(of: "\n", with: " ")
    }

    static func firstMarker(_ text: String, _ marker: String) -> String? {
        guard let range = text.range(of: marker) else { return nil }
        return snippet(text, range: range, radius: 20)
    }

    /// Recognisable database error messages in a probe response.
    static func databaseError(_ response: HTTPMessage) -> String? {
        let body = textPrefix(response.body, limit: 256 * 1024)
        let haystack = body + "\n" + response.headers.map { "\($0.trimmedName): \($0.trimmedValue)" }.joined(separator: "\n")
        let signatures = [
            #"(?i)SQL syntax.*MySQL"#,
            #"(?i)mysql_fetch_(array|row|assoc)"#,
            #"(?i)ORA-\d{5}"#,
            #"PostgreSQL.*ERROR"#,
            #"(?i)pg_query\(\)"#,
            #"(?i)SQLite\/JDBCDriver"#,
            #"(?i)sqlite3\.\w*Error"#,
            #"(?i)Unclosed quotation mark"#,
            #"(?i)syntax error at or near"#,
            #"Warning.*mysqli?_"#
        ]
        for sig in signatures {
            guard let hit = Regex.firstMatch(haystack, sig) else { continue }
            return hit.replacingOccurrences(of: "\n", with: " ")
        }
        return nil
    }

    static func redirectBodyHit(_ body: String) -> String? {
        let forms = ["bleed-probe.invalid"]
        for form in forms {
            let decoded = Params.percentDecode(body)
            for haystack in [body, decoded] {
                guard let range = haystack.range(of: form) else { continue }
                let context = snippet(haystack, range: range, radius: 40)
                let lower = context.lowercased()
                guard lower.contains("location") || lower.contains("url=") || lower.contains("window.location")
                    || lower.contains("http-equiv") || lower.contains("meta") else { continue }
                return context
            }
        }
        return nil
    }
}

// ============================================================================
//  Regex helpers
// ============================================================================

/// Thread-safe cache of compiled patterns — the checks run on several workers.
enum Regex {
    private static let lock = NSLock()
    private static var cache: [String: NSRegularExpression] = [:]

    static func regex(_ pattern: String, options: NSRegularExpression.Options = [.caseInsensitive]) -> NSRegularExpression? {
        let key = "\(options.rawValue)|\(pattern)"
        lock.lock()
        defer { lock.unlock() }
        if let cached = cache[key] { return cached }
        guard let compiled = try? NSRegularExpression(pattern: pattern, options: options) else { return nil }
        cache[key] = compiled
        return compiled
    }

    /// First matching substring, nil when the pattern does not match.
    static func firstMatch(
        _ text: String,
        _ pattern: String,
        options: NSRegularExpression.Options = [.caseInsensitive]
    ) -> String? {
        guard let rx = regex(pattern, options: options) else { return nil }
        let ns = text as NSString
        guard let match = rx.firstMatch(in: text, range: NSRange(location: 0, length: ns.length)),
              match.numberOfRanges > 0,
              let range = Range(match.range(at: 0), in: text) else { return nil }
        return String(text[range])
    }
}

// ============================================================================
//  Small utilities
// ============================================================================

private extension DispatchSemaphore {
    /// Bridges `wait()` onto the concurrency runtime so a worker task never blocks
    /// a cooperative-pool thread. The semaphore stays the parallelism limiter.
    func waitAsync() async {
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            DispatchQueue.global(qos: .utility).async {
                self.wait()
                continuation.resume()
            }
        }
    }
}