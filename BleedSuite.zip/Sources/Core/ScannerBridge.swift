import Foundation

/// Carries captured transactions from the proxy path to the scanner.
///
/// `ProxyEngine.record` runs on whatever task finished an exchange, and a browser
/// page load can produce hundreds per second. Both of the obvious designs were
/// fatal in production: pushing each one onto the main actor starved the UI, and
/// enqueuing on the proxy thread blocked the accept loop. This bridge therefore
/// does the minimum possible work on the caller — an append under a lock — and the
/// UI pump drains the batch on its own schedule.
final class AppModelScannerBridge: @unchecked Sendable {
    static let shared = AppModelScannerBridge()

    private let lock = NSLock()
    private var backlog: [Int] = []
    private(set) var offered = 0
    /// Hard bound so a long scan cannot grow without limit.
    private let maxBacklog = 8_000

    func offer(id: Int) {
        lock.lock()
        backlog.append(id)
        offered += 1
        if backlog.count > maxBacklog { backlog.removeFirst(backlog.count - maxBacklog) }
        lock.unlock()
    }

    /// Non-blocking drain. Returns the ids currently queued.
    func drain() -> [Int] {
        lock.lock(); defer { lock.unlock() }
        guard !backlog.isEmpty else { return [] }
        let batch = backlog
        backlog.removeAll(keepingCapacity: true)
        return batch
    }
}