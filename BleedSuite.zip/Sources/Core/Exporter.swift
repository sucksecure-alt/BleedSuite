import Foundation

// ============================================================================
//  Burp-compatible exporters
//
//  Everything here is pure: no UI, no networking, no global state. Every
//  function returns a `String` (or, for the importer, a value type) so the
//  callers can decide where the bytes end up.
// ============================================================================

enum Exporter {

    // MARK: - HAR 1.2

    /// Exports the exchanges as HAR 1.2, the format Burp, Chrome DevTools,
    /// Firefox and `mitmproxy` all understand.
    ///
    /// `bodyLoader` is consulted when a body is empty *and* was spilled to disk
    /// (or truncated) by the proxy, so an export still carries the real payload.
    static func har(pairs: [HTTPPair], bodyLoader: ((Int, BodySide) -> Data?)? = nil) -> String {
        let root = HARRoot(log: HARLog(version: "1.2",
                                       creator: HARNameVersion(name: "Bleed Suite", version: "1.0"),
                                       entries: pairs.map { entry(for: $0, bodyLoader: bodyLoader) }))

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        encoder.dateEncodingStrategy = .custom { date, encoder in
            var container = encoder.singleValueContainer()
            try container.encode(isoFormatter.string(from: date))
        }
        guard let data = try? encoder.encode(root), let text = String(data: data, encoding: .utf8) else {
            return #"{"log":{"version":"1.2","creator":{"name":"Bleed Suite","version":"1.0"},"entries":[]}}"#
        }
        return text
    }

    private static func entry(for pair: HTTPPair, bodyLoader: ((Int, BodySide) -> Data?)?) -> HAREntry {
        let requestBody = body(for: pair, side: .request, loader: bodyLoader)
        let responseMessage = pair.response
        let responseBody = body(for: pair, side: .response, loader: bodyLoader)

        let queryItems = Params.parseQuery(pair.request.query).map {
            HARNameValue(name: $0.name, value: $0.value)
        }
        let requestPayload = textPayload(requestBody)

        var postData: HARPostData?
        if !requestBody.isEmpty || !queryItems.isEmpty {
            postData = HARPostData(mimeType: harMimeType(of: pair.request),
                                   text: requestPayload.text,
                                   encoding: requestPayload.encoding,
                                   params: queryItems)
        }

        let responseHeaders = responseMessage?.headers.filter { !$0.isSeparator }.map {
            HARNameValue(name: $0.trimmedName, value: $0.trimmedValue)
        } ?? []
        let responsePayload = textPayload(responseBody)

        let response = HARResponse(
            status: responseMessage?.status ?? 0,
            statusText: responseMessage?.reason ?? "",
            httpVersion: responseMessage?.version ?? "HTTP/1.1",
            cookies: setCookies(from: responseMessage?.headerValues("Set-Cookie") ?? []),
            headers: responseHeaders,
            content: HARContent(size: responseBody.count,
                                mimeType: harMimeType(of: responseMessage),
                                text: responsePayload.text,
                                encoding: responsePayload.encoding),
            redirectURL: responseMessage?.header("Location") ?? "",
            headersSize: -1,
            bodySize: responseBody.count)

        return HAREntry(
            startedDateTime: pair.time,
            time: Double(max(0, pair.durationMS)),
            request: HARRequest(
                method: pair.request.method,
                url: pair.url,
                httpVersion: pair.request.version,
                cookies: cookies(from: pair.request.headerValues("Cookie")),
                headers: pair.request.headers.filter { !$0.isSeparator }.map {
                    HARNameValue(name: $0.trimmedName, value: $0.trimmedValue)
                },
                queryString: queryItems,
                postData: postData,
                headersSize: -1,
                bodySize: requestBody.count),
            response: response,
            cache: [:],
            timings: HARTimings(send: 0, wait: Double(max(0, pair.durationMS)), receive: 0),
            bleedSuite: HARExtension(id: pair.id,
                                      origin: pair.origin.rawValue,
                                      error: pair.error,
                                      isIntercepted: pair.isIntercepted,
                                      isModified: pair.isModified,
                                      note: pair.note))
    }

    // MARK: - CSV (Burp history "CSV" export shape)

    static func csv(pairs: [HTTPPair], separator: Character = ",") -> String {
        let columns = ["#", "Time", "Method", "Host", "Port", "Scheme", "Path",
                       "Status", "Length", "MIME type", "Extension", "Status class",
                       "Duration ms", "Origin"]

        var lines: [String] = [columns.map { csvField($0, separator: separator) }.joined(separator: String(separator))]
        for pair in pairs {
            let row = [
                String(pair.id),
                Format.clock(pair.time),
                pair.request.method,
                pair.host,
                String(pair.port),
                pair.scheme,
                pair.request.path,
                pair.status.map(String.init) ?? "0",
                String(pair.responseLength),
                mimeType(of: pair.response),
                fileExtension(ofPath: pair.request.path),
                pair.statusClass.label,
                String(pair.durationMS),
                pair.origin.label,
            ]
            lines.append(row.map { csvField($0, separator: separator) }.joined(separator: String(separator)))
        }
        return lines.joined(separator: "\r\n") + "\r\n"
    }

    /// Quotes a field when needed and doubles any embedded quote.
    static func csvField(_ value: String, separator: Character = ",") -> String {
        let needsQuotes = value.contains(separator)
            || value.contains("\"")
            || value.contains("\n")
            || value.contains("\r")
        guard needsQuotes else { return value }
        return "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }

    // MARK: - Sitemap XML

    /// Burp-style sitemap export: one `<host>` per root, one `<status>` per
    /// leaf exchange, with the full URL as the element text.
    static func sitemapXML(nodes: [TargetNode]) -> String {
        var out = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<items>\n"
        for node in nodes {
            out += hostElement(node, indent: 1, isHost: true)
        }
        out += "</items>\n"
        return out
    }

    private static func hostElement(_ node: TargetNode, indent: Int, isHost: Bool) -> String {
        let pad = String(repeating: "  ", count: indent)
        // The roots are hosts (`scheme://host:port`); anything deeper is a
        // directory in the site map. (`TargetNode.parent` is `weak` and the
        // tree is rebuilt from `sorted` copies, so depth is the only reliable
        // signal.)
        let tag: String
        if isHost {
            let parts = hostParts(from: node.name)
            tag = "<host ip=\"\(xmlEscape(parts.host))\" port=\"\(parts.port)\" scheme=\"\(xmlEscape(parts.scheme))\">"
        } else {
            tag = "<dir name=\"\(xmlEscape(node.name))\">"
        }
        var out = pad + tag + "\n"

        for pair in node.pairs {
            out += statusElement(pair, indent: indent + 1)
        }
        for child in node.children {
            out += hostElement(child, indent: indent + 1, isHost: false)
        }
        out += pad + (isHost ? "</host>" : "</dir>") + "\n"
        return out
    }

    private static func statusElement(_ pair: HTTPPair, indent: Int) -> String {
        let pad = String(repeating: "  ", count: indent)
        let code = pair.status ?? 0
        let url = pair.url
        let mime = mimeType(of: pair.response)
        let meta = "<meta method=\"\(xmlEscape(pair.request.method))\""
            + " mime=\"\(xmlEscape(mime.isEmpty ? "unknown" : mime))\""
            + " length=\"\(pair.responseLength)\""
            + " duration=\"\(pair.durationMS)\"/>"
        return pad + "<status code=\"\(code)\" path=\"\(xmlEscape(pair.request.path))\">"
            + xmlEscape(url) + "\n" + pad + "  " + meta + "\n" + pad + "</status>\n"
    }

    private static func hostParts(from name: String) -> (host: String, port: Int, scheme: String) {
        if let url = URL(string: name), let host = url.host {
            let scheme = url.scheme ?? "http"
            let port = url.port ?? (scheme == "https" ? 443 : 80)
            return (host, port, scheme)
        }
        // Bare `host:port` or plain host names.
        let pieces = name.split(separator: ":", maxSplits: 1).map(String.init)
        if pieces.count == 2, let port = Int(pieces[1]) {
            return (pieces[0], port, "http")
        }
        return (name, 80, "http")
    }

    // MARK: - Scanner issues XML

    /// Burp-style "Scanner Issues Export". `type` is a numeric issue-type code:
    /// `100` = passive finding, `200` = active finding.
    static func scanIssuesXML(issues: [ScanIssue]) -> String {
        var out = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<issues>\n"
        for issue in issues {
            let parts = hostParts(from: issue.url.isEmpty ? issue.host : issue.url)
            let path = issuePath(from: issue.url)
            let typeCode = issue.kind == .active ? 200 : 100

            out += "  <issue>\n"
            out += "    <host ip=\"\(xmlEscape(parts.host))\" port=\"\(parts.port)\" protocol=\"\(xmlEscape(parts.scheme))\">"
                + xmlEscape(issue.url.isEmpty ? issue.host : issue.url) + "</host>\n"
            out += "    <name>\(xmlEscape(issue.name))</name>\n"
            out += "    <severity>\(xmlEscape(issue.severity.label))</severity>\n"
            out += "    <confidence>\(xmlEscape(issue.confidence.label))</confidence>\n"
            out += "    <type>\(typeCode)</type>\n"
            out += "    <path>\(xmlEscape(path))</path>\n"
            out += "    <message>\(xmlEscape(issue.detail))</message>\n"
            out += "    <remediation>\(xmlEscape(issue.remediation))</remediation>\n"
            out += "    <evidence>\(xmlEscape(issue.evidence))</evidence>\n"
            out += "    <element name=\"\(xmlEscape(issue.name))\" evidence=\"\(xmlEscape(issue.evidence))\"/>\n"
            out += "    <status>\(issue.confirmed ? "confirmed" : "unconfirmed")</status>\n"
            out += "  </issue>\n"
        }
        out += "</issues>\n"
        return out
    }

    private static func issuePath(from url: String) -> String {
        guard !url.isEmpty else { return "/" }
        if let parsed = URL(string: url), !parsed.path.isEmpty { return parsed.path }
        if let range = url.range(of: "://"), let slash = url[range.upperBound...].firstIndex(of: "/") {
            return String(url[slash...])
        }
        return url
    }

    // MARK: - Rules

    static func rulesJSON(rules: [ProxyRule]) -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        guard let data = try? encoder.encode(rules), let text = String(data: data, encoding: .utf8) else {
            return "[]"
        }
        return text
    }

    static func rulesFromJSON(_ s: String) -> [ProxyRule] {
        guard let data = s.data(using: .utf8) else { return [] }
        return (try? JSONDecoder().decode([ProxyRule].self, from: data)) ?? []
    }

    // MARK: - Project dump (.bsproj)

    /// Compact, self-contained dump of the project. Bodies travel as base64 so
    /// binary payloads survive the round trip untouched.
    static func projectJSON(pairs: [HTTPPair], extra: [String: String]) -> String {
        let file = ProjectFile(
            version: 1,
            savedAt: Date(),
            meta: extra,
            items: pairs.map { item(for: $0) })

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        encoder.dateEncodingStrategy = .iso8601
        guard let data = try? encoder.encode(file), let text = String(data: data, encoding: .utf8) else {
            return #"{"version":1,"savedAt":"","meta":{},"items":[]}"#
        }
        return text
    }

    private static func item(for pair: HTTPPair) -> ProjectItem {
        ProjectItem(
            id: pair.id,
            time: pair.time,
            durationMS: pair.durationMS,
            host: pair.host,
            port: pair.port,
            isSecure: pair.isSecure,
            origin: pair.origin,
            error: pair.error,
            isIntercepted: pair.isIntercepted,
            isModified: pair.isModified,
            note: pair.note,
            tags: pair.tags,
            request: message(for: pair.request),
            response: pair.response.map { message(for: $0) })
    }

    private static func message(for message: HTTPMessage) -> ProjectMessage {
        ProjectMessage(startLine: message.startLine,
                       headers: message.headers,
                       bodyBase64: message.body.base64EncodedString(),
                       bodySpilled: message.bodySpilled)
    }

    // MARK: - Shared helpers

    /// Resolves a body, asking `bodyLoader` when the in-memory copy is gone.
    private static func body(for pair: HTTPPair, side: BodySide, loader: ((Int, BodySide) -> Data?)?) -> Data {
        let message = side == .request ? pair.request : pair.response
        if let message, !message.bodySpilled, !message.body.isEmpty { return message.body }
        if let loader, let loaded = loader(pair.id, side), !loaded.isEmpty { return loaded }
        return message?.body ?? Data()
    }

    private struct BodyPayload {
        var text: String
        var encoding: String?
    }

    /// Text bodies are embedded verbatim; binary ones are base64 with an
    /// explicit `encoding` marker, as the HAR spec requires.
    private static func textPayload(_ data: Data) -> BodyPayload {
        guard !data.isEmpty else { return BodyPayload(text: "", encoding: nil) }
        if HexDump.isPrintable(data) {
            return BodyPayload(text: String(decoding: data, as: UTF8.self), encoding: nil)
        }
        return BodyPayload(text: data.base64EncodedString(), encoding: "base64")
    }

    /// `Content-Type` without any parameters, lower-cased.
    static func mimeType(of message: HTTPMessage?) -> String {
        guard let raw = message?.header("Content-Type"), !raw.isEmpty else { return "" }
        let base = raw.split(separator: ";", maxSplits: 1, omittingEmptySubsequences: false)[0]
        return base.trimmingCharacters(in: .whitespaces).lowercased()
    }

    /// HAR requires a MIME type, so fall back to the generic binary type.
    private static func harMimeType(of message: HTTPMessage?) -> String {
        let type = mimeType(of: message)
        return type.isEmpty ? "application/octet-stream" : type
    }

    /// Lower-cased extension of the last path component, or an empty string.
    static func fileExtension(ofPath path: String) -> String {
        let last = path.split(separator: "?").first.map(String.init) ?? path
        let component = last.split(separator: "/").last.map(String.init) ?? ""
        guard let dot = component.lastIndex(of: "."), dot != component.startIndex else { return "" }
        let ext = component[component.index(after: dot)...]
        guard ext.allSatisfy({ $0.isLetter || $0.isNumber }) else { return "" }
        return ext.lowercased()
    }

    private static func cookies(from values: [String]) -> [HARCookie] {
        var out: [HARCookie] = []
        for value in values {
            // A single `Set-Cookie` header may carry several cookies, separated
            // by commas; a `Cookie` header carries several separated by semicolons.
            for chunk in value.split(whereSeparator: { $0 == "," || $0 == ";" }) {
                let pair = chunk.trimmingCharacters(in: .whitespaces)
                guard !pair.isEmpty else { continue }
                let parts = pair.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
                guard let name = parts.first, !name.isEmpty else { continue }
                out.append(HARCookie(name: String(name).trimmingCharacters(in: .whitespaces),
                                     value: parts.count > 1
                                        ? String(parts[1]).trimmingCharacters(in: .whitespaces)
                                        : ""))
            }
        }
        return out
    }

    /// `Set-Cookie` cookies keep their attributes; `Cookie` pairs do not have any.
    private static func setCookies(from values: [String]) -> [HARCookie] {
        var out: [HARCookie] = []
        for value in values {
            for raw in value.split(separator: ",") {
                let segments = raw.split(separator: ";").map {
                    $0.trimmingCharacters(in: .whitespaces)
                }
                guard let first = segments.first else { continue }
                let parts = first.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
                guard let name = parts.first, !name.isEmpty else { continue }
                var cookie = HARCookie(name: String(name).trimmingCharacters(in: .whitespaces),
                                       value: parts.count > 1 ? String(parts[1]) : "")
                for attribute in segments.dropFirst() {
                    let kv = attribute.split(separator: "=", maxSplits: 1).map(String.init)
                    guard let key = kv.first?.trimmingCharacters(in: .whitespaces).lowercased() else { continue }
                    let attributeValue = kv.count > 1 ? kv[1].trimmingCharacters(in: .whitespaces) : ""
                    switch key {
                    case "path": cookie.path = attributeValue
                    case "domain": cookie.domain = attributeValue
                    case "expires": cookie.expires = attributeValue
                    case "max-age": cookie.expires = "max-age=" + attributeValue
                    case "httponly": cookie.httpOnly = true
                    case "secure": cookie.secure = true
                    default: break
                    }
                }
                out.append(cookie)
            }
        }
        return out
    }

    /// Escapes `& < > " '` so the value is safe in both text and attributes.
    static func xmlEscape(_ s: String) -> String {
        var out = ""
        out.reserveCapacity(s.count)
        for ch in s {
            switch ch {
            case "&": out += "&amp;"
            case "<": out += "&lt;"
            case ">": out += "&gt;"
            case "\"": out += "&quot;"
            case "'": out += "&apos;"
            default: out.append(ch)
            }
        }
        return out
    }

    private static let isoFormatter: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f
    }()
}

// ============================================================================
//  HAR payloads — private to the exporter, never leak into the app model
// ============================================================================

private struct HARRoot: Codable {
    var log: HARLog
}

private struct HARLog: Codable {
    var version: String
    var creator: HARNameVersion
    var entries: [HAREntry]
}

private struct HARNameVersion: Codable {
    var name: String
    var version: String
}

private struct HAREntry: Codable {
    var startedDateTime: Date
    var time: Double
    var request: HARRequest
    var response: HARResponse
    var cache: [String: [String: String]]
    var timings: HARTimings
    /// Bleed Suite specific extras — the JSON key really is `_bleedSuite`.
    var bleedSuite: HARExtension

    enum CodingKeys: String, CodingKey {
        case startedDateTime, time, request, response, cache, timings
        case bleedSuite = "_bleedSuite"
    }
}

private struct HARRequest: Codable {
    var method: String
    var url: String
    var httpVersion: String
    var cookies: [HARCookie]
    var headers: [HARNameValue]
    var queryString: [HARNameValue]
    var postData: HARPostData?
    var headersSize: Int
    var bodySize: Int
}

private struct HARResponse: Codable {
    var status: Int
    var statusText: String
    var httpVersion: String
    var cookies: [HARCookie]
    var headers: [HARNameValue]
    var content: HARContent
    var redirectURL: String
    var headersSize: Int
    var bodySize: Int
}

private struct HARContent: Codable {
    var size: Int
    var mimeType: String
    var text: String
    var encoding: String?
}

private struct HARPostData: Codable {
    var mimeType: String
    var text: String
    var encoding: String?
    var params: [HARNameValue]
}

private struct HARNameValue: Codable {
    var name: String
    var value: String
}

private struct HARCookie: Codable {
    var name: String
    var value: String
    var path: String?
    var domain: String?
    var expires: String?
    var httpOnly: Bool?
    var secure: Bool?
}

private struct HARTimings: Codable {
    var send: Double
    var wait: Double
    var receive: Double
}

private struct HARExtension: Codable {
    var id: Int
    var origin: String
    var error: String?
    var isIntercepted: Bool
    var isModified: Bool
    var note: String
}

// ============================================================================
//  Project dump payloads
// ============================================================================

private struct ProjectFile: Codable {
    var version: Int
    var savedAt: Date
    var meta: [String: String]
    var items: [ProjectItem]
}

private struct ProjectItem: Codable {
    var id: Int
    var time: Date
    var durationMS: Int
    var host: String
    var port: Int
    var isSecure: Bool
    var origin: HTTPPair.Origin
    var error: String?
    var isIntercepted: Bool
    var isModified: Bool
    var note: String
    var tags: [String]
    var request: ProjectMessage
    var response: ProjectMessage?
}

private struct ProjectMessage: Codable {
    var startLine: String
    var headers: [Header]
    var bodyBase64: String
    var bodySpilled: Bool
}

// ============================================================================
//  Import
// ============================================================================

enum ImportFormat: String, CaseIterable, Sendable {
    case har, csv, sitemap, project, rules

    var label: String {
        switch self {
        case .har: return "HAR 1.2"
        case .csv: return "CSV (Burp history)"
        case .sitemap: return "Sitemap XML"
        case .project: return "Bleed Suite project"
        case .rules: return "Match & Replace rules"
        }
    }

    var fileExtension: String {
        switch self {
        case .har: return "har"
        case .csv: return "csv"
        case .sitemap: return "xml"
        case .project: return "bsproj"
        case .rules: return "json"
        }
    }
}

enum Importer {

    /// Rebuilds exchanges from a HAR document. Bodies are decoded from either
    /// `text` or base64 (HAR `encoding: "base64"`).
    static func parseHAR(_ text: String) -> [HTTPPair] {
        guard let data = text.data(using: .utf8),
              let root = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let log = root["log"] as? [String: Any],
              let entries = log["entries"] as? [[String: Any]] else { return [] }

        var pairs: [HTTPPair] = []
        pairs.reserveCapacity(entries.count)
        for (index, entry) in entries.enumerated() {
            let requestDict = entry["request"] as? [String: Any] ?? [:]
            let responseDict = entry["response"] as? [String: Any]

            let urlString = requestDict["url"] as? String ?? ""
            let method = (requestDict["method"] as? String ?? "GET").uppercased()
            let version = requestDict["httpVersion"] as? String ?? "HTTP/1.1"
            let target = requestTarget(from: urlString, fallback: "/")
            var request = HTTPMessage(
                isRequest: true,
                startLine: "\(method) \(target) \(version)",
                headers: headers(from: requestDict["headers"] as? [[String: Any]]),
                body: body(from: requestDict["postData"] as? [String: Any]))
            request.normalizeFraming()

            var response: HTTPMessage?
            if let responseDict {
                let status = responseDict["status"] as? Int ?? 0
                let statusText = responseDict["statusText"] as? String ?? ""
                let responseVersion = responseDict["httpVersion"] as? String ?? "HTTP/1.1"
                let content = responseDict["content"] as? [String: Any]
                let payload = body(from: content)
                let hasHeaders = !(responseDict["headers"] as? [[String: Any]] ?? []).isEmpty
                if status > 0 || !payload.isEmpty || hasHeaders {
                    let message = HTTPMessage(
                        isRequest: false,
                        startLine: "HTTP/1.1 \(status) \(statusText)".replacingOccurrences(of: "HTTP/1.1", with: responseVersion),
                        headers: headers(from: responseDict["headers"] as? [[String: Any]]),
                        body: payload)
                    response = message
                }
            }

            let started = (entry["startedDateTime"] as? String).flatMap(parseISODate) ?? Date()
            let elapsed = entry["time"] as? Double ?? 0

            pairs.append(HTTPPair(id: index + 1,
                                  time: started,
                                  durationMS: Int(elapsed.rounded()),
                                  host: host(from: urlString),
                                  port: port(from: urlString),
                                  isSecure: URL(string: urlString)?.scheme?.lowercased() == "https",
                                  request: request,
                                  response: response,
                                  error: (entry["_bleedSuite"] as? [String: Any])?["error"] as? String,
                                  origin: .proxy))
        }
        return pairs
    }

    /// Best-effort import of a Burp-style CSV history export. Only the fields
    /// that map onto `HTTPPair` are restored; bodies stay empty.
    static func parseCSV(_ text: String) -> [HTTPPair] {
        let rows = splitCSV(text)
        guard let header = rows.first else { return [] }
        let names = header.map { $0.trimmingCharacters(in: .whitespaces).lowercased() }
        func index(of column: String) -> Int? { names.firstIndex(of: column) }

        let iMethod = index(of: "method")
        let iHost = index(of: "host")
        let iPort = index(of: "port")
        let iScheme = index(of: "scheme")
        let iPath = index(of: "path")
        let iStatus = index(of: "status")
        let iTime = index(of: "time")
        let iDuration = index(of: "duration ms")
        let iID = index(of: "#")

        var pairs: [HTTPPair] = []
        var fallbackID = 1
        for row in rows.dropFirst() {
            func field(_ i: Int?) -> String {
                guard let i, i < row.count else { return "" }
                return row[i].trimmingCharacters(in: .whitespaces)
            }
            let path = field(iPath).isEmpty ? "/" : field(iPath)
            let host = field(iHost)
            guard !host.isEmpty || !path.isEmpty else { continue }

            let scheme = field(iScheme).lowercased()
            let isSecure = scheme == "https"
            let port = Int(field(iPort)) ?? (isSecure ? 443 : 80)
            let method = field(iMethod).uppercased().isEmpty ? "GET" : field(iMethod).uppercased()
            let status = Int(field(iStatus)) ?? 0

            var request = HTTPMessage(isRequest: true,
                                      startLine: "\(method) \(path) HTTP/1.1",
                                      headers: headers(Host: host, port: port, secure: isSecure))
            request.normalizeFraming()

            var response: HTTPMessage?
            if status > 0 {
                response = HTTPMessage(isRequest: false, startLine: "HTTP/1.1 \(status) \(StatusClass(status: status).fullName)")
            }

            pairs.append(HTTPPair(id: Int(field(iID)) ?? fallbackID,
                                  time: clockDate(field(iTime)),
                                  durationMS: Int(field(iDuration)) ?? 0,
                                  host: host,
                                  port: port,
                                  isSecure: isSecure,
                                  request: request,
                                  response: response,
                                  origin: .proxy))
            fallbackID += 1
        }
        return pairs
    }

    // MARK: - CSV plumbing

    /// Splits a CSV document into rows of fields, honouring quotes, doubled
    /// quotes and embedded separators/newlines.
    static func splitCSV(_ text: String, separator: Character = ",") -> [[String]] {
        var rows: [[String]] = []
        var row: [String] = []
        var field = ""
        var inQuotes = false

        // Note: in Swift `"\r\n"` is a *single* Character, so CRLF has to be
        // matched as one unit or rows would never be split.
        let chars = Array(text)
        var index = 0

        func endField() {
            row.append(field)
            field = ""
        }
        func endRow() {
            endField()
            rows.append(row)
            row = []
        }

        while index < chars.count {
            let ch = chars[index]
            if inQuotes {
                if ch == "\"" {
                    let next = index + 1
                    if next < chars.count, chars[next] == "\"" {
                        field.append("\"")
                        index = next
                    } else {
                        inQuotes = false
                    }
                } else {
                    field.append(ch)
                }
            } else {
                if ch == "\r\n" {
                    endRow()
                    index += 2
                    continue
                }
                switch ch {
                case "\"": inQuotes = true
                case separator: endField()
                case "\r", "\n": endRow()
                default: field.append(ch)
                }
            }
            index += 1
        }
        if !field.isEmpty || !row.isEmpty { endRow() }
        return rows
    }

    private static func headers(Host host: String, port: Int, secure: Bool) -> [Header] {
        let defaultPort = secure ? 443 : 80
        return [Header(name: "Host", value: port == defaultPort ? host : "\(host):\(port)")]
    }

    private static func clockDate(_ text: String) -> Date {
        guard !text.isEmpty else { return Date() }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "HH:mm:ss"
        if let time = formatter.date(from: text) {
            return Calendar.current.date(
                bySettingHour: Calendar.current.component(.hour, from: time),
                minute: Calendar.current.component(.minute, from: time),
                second: Calendar.current.component(.second, from: time),
                of: Date()) ?? Date()
        }
        for format in ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ssZ"] {
            formatter.dateFormat = format
            if let date = formatter.date(from: text) { return date }
        }
        return Date()
    }

    // MARK: - HAR plumbing

    private static func headers(from array: [[String: Any]]?) -> [Header] {
        guard let array else { return [] }
        return array.compactMap { item in
            guard let name = item["name"] as? String, !name.isEmpty else { return nil }
            return Header(name: name, value: item["value"] as? String ?? "")
        }
    }

    private static func body(from dict: [String: Any]?) -> Data {
        guard let dict else { return Data() }
        // Content blocks and postData blocks use the same two keys.
        if let text = dict["text"] as? String {
            if (dict["encoding"] as? String)?.lowercased() == "base64" {
                return Data(base64Encoded: text, options: [.ignoreUnknownCharacters]) ?? Data()
            }
            return Data(text.utf8)
        }
        if let params = dict["params"] as? [[String: Any]], !params.isEmpty {
            let form = params.compactMap { item -> String? in
                guard let name = item["name"] as? String else { return nil }
                let value = item["value"] as? String ?? ""
                return value.isEmpty ? Params.escape(name) : "\(Params.escape(name))=\(Params.escape(value))"
            }.joined(separator: "&")
            return Data(form.utf8)
        }
        return Data()
    }

    private static func requestTarget(from urlString: String, fallback: String) -> String {
        guard !urlString.isEmpty else { return fallback }
        if let parsed = URL(string: urlString), !parsed.path.isEmpty {
            var target = parsed.path
            if let query = parsed.query { target += "?" + query }
            return target
        }
        if let range = urlString.range(of: "://"), let slash = urlString[range.upperBound...].firstIndex(of: "/") {
            return String(urlString[slash...])
        }
        return urlString.hasPrefix("/") ? urlString : fallback
    }

    private static func host(from urlString: String) -> String {
        if let host = URL(string: urlString)?.host { return host }
        var s = Substring(urlString)
        if let range = s.range(of: "://") { s = s[range.upperBound...] }
        if let slash = s.firstIndex(of: "/") { s = s[..<slash] }
        if let colon = s.firstIndex(of: ":") { s = s[..<colon] }
        return String(s)
    }

    private static func port(from urlString: String) -> Int {
        if let url = URL(string: urlString), let port = url.port { return port }
        return URL(string: urlString)?.scheme?.lowercased() == "https" ? 443 : 80
    }

    private static func parseISODate(_ text: String) -> Date? {
        let withFraction = ISO8601DateFormatter()
        withFraction.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = withFraction.date(from: text) { return date }
        let plain = ISO8601DateFormatter()
        plain.formatOptions = [.withInternetDateTime]
        if let date = plain.date(from: text) { return date }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        return formatter.date(from: text)
    }
}

// ============================================================================
//  File IO
// ============================================================================

enum FileWriterError: Error, LocalizedError {
    case cannotCreateDirectory(URL, Error)
    case encodingFailed

    var errorDescription: String? {
        switch self {
        case let .cannotCreateDirectory(url, error):
            return "Could not create \(url.path): \(error.localizedDescription)"
        case .encodingFailed:
            return "Text could not be encoded as UTF-8."
        }
    }
}

enum FileWriter {

    static func write(_ text: String, to url: URL) throws {
        guard let data = text.data(using: .utf8) else { throw FileWriterError.encodingFailed }
        let directory = url.deletingLastPathComponent()
        if !directory.path.isEmpty, !FileManager.default.fileExists(atPath: directory.path) {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        }
        try data.write(to: url, options: .atomic)
    }

    static func read(from url: URL) throws -> String {
        let data = try Data(contentsOf: url)
        if let text = String(data: data, encoding: .utf8) { return text }
        if let text = String(data: data, encoding: .isoLatin1) { return text }
        throw FileWriterError.encodingFailed
    }

    /// `~/Library/Application Support/BleedSuite/exports`, created on demand.
    static func exportDirectory() -> URL {
        let base = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Application Support/BleedSuite/exports", isDirectory: true)
        if !FileManager.default.fileExists(atPath: base.path) {
            try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        }
        return base
    }

    /// `"<prefix>-yyyyMMdd-HHmmss.<ext>"`, with any path separators stripped.
    static func suggestFilename(prefix: String, ext: String, date: Date = Date()) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone.current
        formatter.dateFormat = "yyyyMMdd-HHmmss"

        let safePrefix = prefix
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let stem = safePrefix.isEmpty ? "bleedsuite" : safePrefix
        let cleanExt = ext.trimmingCharacters(in: CharacterSet(charactersIn: ". "))
        return cleanExt.isEmpty ? "\(stem)-\(formatter.string(from: date))"
                                : "\(stem)-\(formatter.string(from: date)).\(cleanExt)"
    }
}