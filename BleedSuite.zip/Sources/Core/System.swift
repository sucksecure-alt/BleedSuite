import Foundation
import Darwin

// ============================================================================
//  Shell
// ============================================================================

enum ShellError: LocalizedError {
    case notExecutable(String)
    case launchFailed(path: String, underlying: String)

    var errorDescription: String? {
        switch self {
        case .notExecutable(let p):
            return "Not an executable file: \(p)"
        case .launchFailed(let p, let underlying):
            return "Could not launch \(p): \(underlying)"
        }
    }
}

/// Deadlock-free wrapper around `Foundation.Process`.
///
/// Two things this deliberately does *not* do, because both are classic sources of
/// hangs in a GUI app:
///   * it never calls `waitUntilExit()` (that would block the calling thread and,
///     with a 64 KiB pipe buffer, deadlock against a child that is still writing);
///   * it never drains stdout and stderr from the same thread. Each stream gets
///     its own pipe, its own queue and its own blocking `readDataToEndOfFile()`.
enum Shell {

    struct Output: Sendable {
        var status: Int32 = 0
        var stdout: String = ""
        var stderr: String = ""
        /// stdout and stderr interleaved in that order — handy for error messages.
        var combined: String = ""
        /// True when the watchdog had to kill the child.
        var timedOut: Bool = false

        var ok: Bool { status == 0 }
        var trimmedStdout: String { stdout.trimmingCharacters(in: .whitespacesAndNewlines) }
        /// Exit status used when the watchdog fires (GNU `timeout` convention).
        static let timeoutStatus: Int32 = 124
    }

    // MARK: - Running a process

    /// Runs `path` with `args` and collects its output.
    ///
    /// - Parameters:
    ///   - input: Written to stdin; the pipe is closed immediately afterwards so the
    ///     child sees EOF instead of blocking forever on `read()`.
    ///   - env: Merged into the current environment (PATH etc. survive), not replacing it.
    ///   - timeout: Watchdog deadline. On expiry: `terminate()`, 2 s grace, then `SIGKILL`.
    /// - Throws: `ShellError` only when the process could not be started at all.
    ///   A non-zero exit status or a timeout is reported through `Output`, not thrown.
    static func run(_ path: String,
                    _ args: [String],
                    input: String? = nil,
                    cwd: String? = nil,
                    env: [String: String]? = nil,
                    timeout: TimeInterval = 30) throws -> Output {

        guard FileManager.default.isExecutableFile(atPath: path) else {
            throw ShellError.notExecutable(path)
        }

        let process = Process()
        process.executableURL = URL(fileURLWithPath: path)
        process.arguments = args
        if let cwd { process.currentDirectoryURL = URL(fileURLWithPath: cwd) }
        if let env {
            var merged = ProcessInfo.processInfo.environment
            for (key, value) in env { merged[key] = value }
            process.environment = merged
        }

        let outPipe = Pipe()
        let errPipe = Pipe()
        process.standardOutput = outPipe
        process.standardError = errPipe

        let inPipe: Pipe? = input == nil ? nil : Pipe()
        if let inPipe { process.standardInput = inPipe }

        // --- drain both streams concurrently -------------------------------------
        let outBox = DataBox()
        let errBox = DataBox()
        let readers = DispatchGroup()

        readers.enter()
        DispatchQueue(label: "Shell.stdout.\(UUID().uuidString)").async {
            outBox.append(outPipe.fileHandleForReading.readDataToEndOfFile())
            readers.leave()
        }

        readers.enter()
        DispatchQueue(label: "Shell.stderr.\(UUID().uuidString)").async {
            errBox.append(errPipe.fileHandleForReading.readDataToEndOfFile())
            readers.leave()
        }

        // --- feed stdin, then close it so the child gets EOF --------------------
        if let inPipe, let input {
            DispatchQueue(label: "Shell.stdin").async {
                if let data = input.data(using: .utf8), !data.isEmpty {
                    try? inPipe.fileHandleForWriting.write(contentsOf: data)
                }
                try? inPipe.fileHandleForWriting.close()
            }
        }

        // --- termination, via handler + semaphore (never waitUntilExit) ---------
        let exitBox = StatusBox()
        let terminated = DispatchSemaphore(value: 0)
        process.terminationHandler = { p in
            exitBox.set(p.terminationStatus)
            terminated.signal()
        }

        do {
            try process.run()
        } catch {
            throw ShellError.launchFailed(path: path, underlying: error.localizedDescription)
        }

        // Watchdog: poll every 20 ms until the child dies or the deadline passes.
        let deadline = Date().addingTimeInterval(max(0.1, timeout))
        var timedOut = false
        while terminated.wait(timeout: .now() + 0.02) == .timedOut {
            if Date() >= deadline {
                timedOut = true
                break
            }
            if !process.isRunning {
                // Exited, but the termination handler has not fired yet.
                _ = terminated.wait(timeout: .now() + 1.0)
                break
            }
        }

        if timedOut || process.isRunning {
            process.terminate()                                     // SIGTERM
            _ = terminated.wait(timeout: .now() + 2.0)
            if process.isRunning {
                kill(process.processIdentifier, SIGKILL)             // hard stop
                _ = terminated.wait(timeout: .now() + 2.0)
            }
        }

        // A grandchild may have inherited the write end and keep the pipe open
        // forever, so we never block indefinitely on the readers.
        if readers.wait(timeout: .now() + 2.0) != .success {
            try? outPipe.fileHandleForReading.close()
            try? errPipe.fileHandleForReading.close()
            _ = readers.wait(timeout: .now() + 0.5)
        }

        let stdout = String(decoding: outBox.data, as: UTF8.self)
        let stderr = String(decoding: errBox.data, as: UTF8.self)
        let status: Int32 = timedOut ? Output.timeoutStatus : (exitBox.status ?? process.terminationStatus)

        return Output(status: status,
                      stdout: stdout,
                      stderr: stderr,
                      combined: [stdout, stderr].filter { !$0.isEmpty }.joined(separator: "\n"),
                      timedOut: timedOut)
    }

    /// Off-thread version of `run`, for use from actors / async contexts so the
    /// cooperative thread pool is not blocked for the whole duration of a command.
    static func runAsync(_ path: String,
                         _ args: [String],
                         input: String? = nil,
                         cwd: String? = nil,
                         env: [String: String]? = nil,
                         timeout: TimeInterval = 30) async throws -> Output {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    continuation.resume(returning: try run(path, args, input: input, cwd: cwd, env: env, timeout: timeout))
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    // MARK: - PATH lookup

    private static let whichLock = NSLock()
    private static var whichCache: [String: String?] = [:]

    /// Resolves `tool` against PATH (+ the usual sbin dirs). Cached, `nil` included.
    static func which(_ tool: String) -> String? {
        whichLock.lock()
        defer { whichLock.unlock() }
        if let cached = whichCache[tool] { return cached }

        var found: String?
        if tool.contains("/") {
            if FileManager.default.isExecutableFile(atPath: tool) { found = tool }
        } else {
            var searchPath = ProcessInfo.processInfo.environment["PATH"] ?? "/usr/bin:/bin:/usr/sbin:/sbin"
            for extra in ["/usr/sbin", "/sbin", "/usr/local/bin", "/opt/homebrew/bin"] where !searchPath.contains(extra) {
                searchPath += ":" + extra
            }
            for dir in searchPath.split(separator: ":") where !dir.isEmpty {
                let candidate = String(dir) + "/" + tool
                if FileManager.default.isExecutableFile(atPath: candidate) {
                    found = candidate
                    break
                }
            }
        }
        whichCache[tool] = found
        return found
    }

    // MARK: - Quoting / privileges

    /// Wraps `s` in single quotes for /bin/sh, escaping embedded single quotes.
    static func shellQuote(_ s: String) -> String {
        return "'" + s.replacingOccurrences(of: "'", with: "'\\''") + "'"
    }

    /// Quotes an argv into a single shell command line.
    static func shellCommand(_ path: String, _ args: [String]) -> String {
        ([path] + args).map(shellQuote).joined(separator: " ")
    }

    /// Runs `script` as root through the macOS authentication dialog.
    ///
    /// `script` must already be a shell-safe command line (see `shellCommand`).
    /// AppleScript string escaping happens here: `\` → `\\`, `"` → `\"`.
    static func adminPrivilegeEscalation(_ script: String, timeout: TimeInterval = 300) async throws -> Output {
        let escaped = script
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
        let appleScript = "do shell script \"\(escaped)\" with administrator privileges"
        return try await runAsync("/usr/bin/osascript", ["-e", appleScript], timeout: timeout)
    }

    /// Convenience: escalates `path args…` instead of a raw command line.
    static func adminPrivilegeEscalation(_ path: String, _ args: [String], timeout: TimeInterval = 300) async throws -> Output {
        try await adminPrivilegeEscalation(shellCommand(path, args), timeout: timeout)
    }

    // MARK: - Thread-safe collectors

    private final class DataBox: @unchecked Sendable {
        private let lock = NSLock()
        private var storage = Data()
        func append(_ chunk: Data) {
            guard !chunk.isEmpty else { return }
            lock.lock(); storage.append(chunk); lock.unlock()
        }
        var data: Data {
            lock.lock(); defer { lock.unlock() }
            return storage
        }
    }

    private final class StatusBox: @unchecked Sendable {
        private let lock = NSLock()
        private var storage: Int32?
        func set(_ value: Int32) {
            lock.lock(); storage = value; lock.unlock()
        }
        var status: Int32? {
            lock.lock(); defer { lock.unlock() }
            return storage
        }
    }
}

// ============================================================================
//  SystemProxyManager
// ============================================================================

enum ProxyError: LocalizedError {
    case serviceNotFound(String)
    case commandFailed(command: String, output: String)
    case commandTimedOut(command: String)
    case verificationFailed(service: String, expected: String, actual: String)
    case invalidPort(Int)
    case notPermitted

    var errorDescription: String? {
        switch self {
        case .serviceNotFound(let name):
            return "Network service «\(name)» was not found. It may have been removed since it was configured."
        case .commandFailed(let command, let output):
            let detail = output.trimmingCharacters(in: .whitespacesAndNewlines)
            return "networksetup \(command) failed\(detail.isEmpty ? "." : ": \(detail)")"
        case .commandTimedOut(let command):
            return "networksetup \(command) did not answer in time and was killed. The system proxy state may now be inconsistent."
        case .verificationFailed(let service, let expected, let actual):
            return "Could not apply the proxy to «\(service)»: expected \(expected), but networksetup reports \(actual)."
        case .invalidPort(let port):
            return "\(port) is not a valid proxy port (1…65535)."
        case .notPermitted:
            return "Changing the system proxy requires an administrator password."
        }
    }

    var recoverySuggestion: String? {
        switch self {
        case .serviceNotFound:
            return "Run a fresh scan of the network services and pick another one."
        case .commandFailed:
            return "Check that the service is still present in System Settings › Network."
        case .verificationFailed, .commandTimedOut:
            return "Open System Settings › Network › Details › Proxies and fix the state by hand."
        case .notPermitted:
            return "Retry — macOS will show an authentication dialog."
        case .invalidPort:
            return nil
        }
    }
}

/// Owns the macOS HTTP(S) system proxy for the lifetime of the interceptor.
///
/// Every mutation is verified by re-reading the state, and every session can be
/// snapshotted to `~/Library/Application Support/BleedSuite/systemproxy.json` so a
/// crash (or a force quit) does not leave the machine pointed at a dead proxy.
actor SystemProxyManager {

    static let shared = SystemProxyManager()

    static let networksetupPath = "/usr/sbin/networksetup"
    static let openPath = "/usr/bin/open"

    static var snapshotURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
        return base.appendingPathComponent("BleedSuite", isDirectory: true).appendingPathComponent("systemproxy.json")
    }

    /// Host the interceptor always listens on.
    static let listenHost = "127.0.0.1"

    // MARK: - Model

    struct ProxySettings: Sendable, Codable {
        var webEnabled = false
        var webServer = ""
        var webPort = ""
        var webAutoURL = ""
        var secureEnabled = false
        var secureServer = ""
        var securePort = ""
        var secureAutoURL = ""
        /// Comma-separated view for the UI (Burp-style "Proxy exceptions").
        var exceptions: [String] = []
        /// Exact bypass-domain list as reported by networksetup (what we restore).
        var ignoreProxyHosts: [String] = []

        /// Any proxy is on and points at us.
        var intercepts: Bool {
            let loopback = { (server: String) in
                let s = server.lowercased()
                return s == "127.0.0.1" || s == "localhost"
            }
            return (webEnabled && loopback(webServer)) || (secureEnabled && loopback(secureServer))
        }

        /// True when an auto-discovery (PAC/WPAD) URL is configured.
        var hasAutoProxy: Bool {
            !webAutoURL.isEmpty && webAutoURL != "(null)"
        }
    }

    struct NetworkService: Identifiable, Sendable {
        var id: String
        var name: String
        var isEnabled: Bool

        /// Hardware port / BSD device, when known ("Wi-Fi, Device: en0" → "en0").
        var device: String = ""
    }

    struct Snapshot: Codable, Sendable {
        var savedAt: Date
        var services: [String: ProxySettings]
    }

    // MARK: - Discovery

    /// Services in the system's preference order, disabled ones flagged.
    func services() async -> [NetworkService] {
        let all = (try? await networksetup(["-listallnetworkservices"], ignoreFailure: true))?
            .trimmedStdout.components(separatedBy: .newlines) ?? []
        let order = (try? await networksetup(["-listnetworkserviceorder"], ignoreFailure: true))?
            .trimmedStdout ?? ""

        // `-listallnetworkservices` keys the enabled flag: a leading `*` means disabled.
        var byName: [String: NetworkService] = [:]
        for raw in all {
            let line = raw.trimmingCharacters(in: .whitespaces)
            guard !line.isEmpty, !line.hasPrefix("An asterisk") else { continue }
            let disabled = line.hasPrefix("*")
            let name = String(line.drop(while: { $0 == "*" || $0 == " " }))
            guard !name.isEmpty else { continue }
            byName[name] = NetworkService(id: name, name: name, isEnabled: !disabled)
        }

        // `-listnetworkserviceorder` gives the preference order plus "Device: en0".
        var ordered: [NetworkService] = []
        var devices: [String: String] = [:]
        var disabledInOrder: Set<String> = []
        let entryPattern = try! NSRegularExpression(pattern: #"^\((\d+|\*)\)\s+(.+)$"#)
        var currentName: String?

        for raw in order.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            guard !line.isEmpty, !line.hasPrefix("An asterisk") else { continue }

            if line.hasPrefix("("),
               let match = entryPattern.firstMatch(in: line, range: NSRange(line.startIndex..., in: line)),
               let indexRange = Range(match.range(at: 1), in: line),
               let nameRange = Range(match.range(at: 2), in: line) {
                let index = String(line[indexRange])
                var name = String(line[nameRange]).trimmingCharacters(in: .whitespaces)
                if name.hasPrefix("*") { name = String(name.dropFirst()).trimmingCharacters(in: .whitespaces) }
                currentName = name
                if index == "*" { disabledInOrder.insert(name) }
                if let existing = byName[name] {
                    ordered.append(NetworkService(id: existing.id, name: name,
                                                 isEnabled: existing.isEnabled && !disabledInOrder.contains(name),
                                                 device: existing.device))
                }
                continue
            }

            if line.contains("Device:"), let name = currentName {
                // "Device: en0)" — the closing paren belongs to the Hardware Port block.
                let device = String(line.split(separator: "Device:", maxSplits: 1)[1])
                    .trimmingCharacters(in: CharacterSet(charactersIn: " )\t"))
                devices[name] = device
            }
        }

        ordered = ordered.map { service in
            var copy = service
            copy.device = devices[service.name] ?? service.device
            copy.id = copy.device.isEmpty ? copy.name : copy.device
            return copy
        }

        // Services missing from the order listing go last.
        for service in byName.values where !ordered.contains(where: { $0.name == service.name }) {
            ordered.append(service)
        }
        return ordered
    }

    /// Best guess at "the service that actually carries my traffic".
    ///
    /// Enabled services in preference order, minus virtual ones, ranked by what the
    /// BSD interface actually looks like. An enabled Ethernet adapter with no cable
    /// still reports IFF_RUNNING and sits above Wi-Fi in the order list, so the
    /// decisive signal is whether the interface holds a routable address.
    func primaryService() async -> NetworkService? {
        let all = await services()
        let live = all.filter { $0.isEnabled && !Self.isVirtual($0) }
        let ranked = live
            .map { (service: $0, info: Self.interfaceInfo($0.device)) }
            .filter { $0.info.hasRoutableAddress || $0.info.isUp }
            .sorted { lhs, rhs in
                lhs.info.score == rhs.info.score ? false : lhs.info.score > rhs.info.score
            }
        return ranked.first?.service ?? live.first ?? all.first(where: { $0.isEnabled }) ?? all.first
    }

    /// Every service that should carry the proxy: the primary one plus any other
    /// enabled, non-virtual service. Multi-homed Macs (Wi-Fi plus Ethernet) and VPN
    /// pseudo-services route different traffic, so configuring only one of them
    /// leaves part of the browsing invisible to the proxy.
    func targetServices() async -> [NetworkService] {
        let all = await services()
        let live = all.filter { $0.isEnabled && !Self.isVirtual($0) }
        guard let primary = await primaryService() else { return [] }
        var result = [primary]
        for service in live where service.id != primary.id {
            // Only add services that actually carry traffic.
            let info = Self.interfaceInfo(service.device)
            if info.hasRoutableAddress || info.isUp { result.append(service) }
        }
        return result
    }

    /// Live view of a BSD device ("en0"). `score` is the ranking used above.
    struct InterfaceInfo {
        var isUp = false
        var isRunning = false
        var hasIPv4 = false
        var hasGlobalIPv6 = false

        var hasRoutableAddress: Bool { hasIPv4 || hasGlobalIPv6 }
        var score: Int {
            (hasIPv4 ? 4 : 0) + (hasGlobalIPv6 ? 2 : 0) + (isRunning ? 1 : 0) + (isUp ? 1 : 0)
        }
    }

    static func interfaceInfo(_ device: String) -> InterfaceInfo {
        guard !device.isEmpty else { return InterfaceInfo() }
        var info = InterfaceInfo()
        var head: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&head) == 0, let head else { return info }
        defer { freeifaddrs(head) }
        var node: UnsafeMutablePointer<ifaddrs>? = head
        while let current = node {
            let ifa = current.pointee
            node = ifa.ifa_next
            guard String(cString: ifa.ifa_name) == device else { continue }

            let flags = Int32(ifa.ifa_flags)
            info.isUp = (flags & IFF_UP) != 0
            info.isRunning = (flags & IFF_RUNNING) != 0

            guard let addr = ifa.ifa_addr else { continue }
            switch addr.pointee.sa_family {
            case sa_family_t(AF_INET):
                info.hasIPv4 = true
            case sa_family_t(AF_INET6):
                let in6 = withUnsafePointer(to: addr.pointee) { raw -> in6_addr in
                    raw.withMemoryRebound(to: sockaddr_in6.self, capacity: 1) { $0.pointee.sin6_addr }
                }
                // fe80::/10 is link-local and exists on every interface.
                info.hasGlobalIPv6 = !in6IsLinkLocal(in6)
            default:
                continue
            }
        }
        return info
    }

    private static func in6IsLinkLocal(_ address: in6_addr) -> Bool {
        withUnsafePointer(to: address) { pointer in
            pointer.withMemoryRebound(to: UInt8.self, capacity: 16) { bytes in
                bytes[0] == 0xFE && (bytes[1] & 0xC0) == 0x80
            }
        }
    }

    /// Virtual / interface-less services that can never route user traffic.
    static func isVirtual(_ service: NetworkService) -> Bool {
        if service.device.isEmpty { return true }
        let blocked = ["thunderbolt bridge", "bluetooth", "pan", "bridge0",
                       "vpn", "virtual", "nullmodem", "loopback"]
        let name = service.name.lowercased()
        return blocked.contains { name.contains($0) }
    }

    // MARK: - Reading the current state

    func currentSettings(for service: String) async throws -> ProxySettings {
        var settings = ProxySettings()

        let web = try await networksetup(["-getwebproxy", service])
        settings.webEnabled = Self.flag(web, "Enabled")
        settings.webServer = Self.value(web, "Server")
        settings.webPort = Self.value(web, "Port")

        let secure = try await networksetup(["-getsecurewebproxy", service])
        settings.secureEnabled = Self.flag(secure, "Enabled")
        settings.secureServer = Self.value(secure, "Server")
        settings.securePort = Self.value(secure, "Port")

        let auto = try await networksetup(["-getautoproxyurl", service])
        let autoURL = Self.value(auto, "URL")
        let autoEnabled = Self.flag(auto, "Enabled")
        // Only an *active* PAC counts as configured. networksetup keeps a URL around
        // after the state is switched off; treating that as "configured" would make us
        // switch auto-discovery back on later.
        settings.webAutoURL = (autoEnabled && !autoURL.isEmpty && autoURL != "(null)") ? autoURL : ""
        settings.secureAutoURL = settings.webAutoURL

        let bypass = try await networksetup(["-getproxybypassdomains", service])
        settings.ignoreProxyHosts = Self.bypassDomains(bypass)
        settings.exceptions = settings.ignoreProxyHosts
        return settings
    }

    /// True when this service is currently pointed at our listener.
    func isActive(service: String) async -> Bool {
        guard let settings = try? await currentSettings(for: service) else { return false }
        return settings.intercepts
    }

    // MARK: - Mutating the state

    /// Points web + secure proxies at `127.0.0.1:port` and verifies the result.
    @discardableResult
    func enable(service: String, port: Int) async throws -> ProxySettings {
        guard (1...65_535).contains(port) else { throw ProxyError.invalidPort(port) }
        let portText = String(port)

        try await networksetup(["-setwebproxy", service, Self.listenHost, portText])
        try await networksetup(["-setsecurewebproxy", service, Self.listenHost, portText])

        // Re-read: networksetup silently succeeds on some setups without applying.
        let applied = try await currentSettings(for: service)
        let webOK = applied.webEnabled && applied.webServer == Self.listenHost && applied.webPort == portText
        let secureOK = applied.secureEnabled && applied.secureServer == Self.listenHost && applied.securePort == portText
        guard webOK && secureOK else {
            throw ProxyError.verificationFailed(
                service: service,
                expected: "HTTP/HTTPS → \(Self.listenHost):\(portText) (enabled)",
                actual: "HTTP \(applied.webEnabled ? applied.webServer : "off"):\(applied.webPort) / HTTPS \(applied.secureEnabled ? applied.secureServer : "off"):\(applied.securePort)"
            )
        }
        return applied
    }

    /// Turns the manual proxies off, leaving auto-discovery (PAC) exactly as found.
    ///
    /// If a snapshot of this service is on disk (taken by `saveSnapshot()`), the
    /// previous server/port are restored from it rather than left pointing at our
    /// now-dead listener. Without a snapshot the proxies are simply switched off.
    func disable(service: String) async throws {
        if let saved = loadSavedSnapshot(), let previous = saved.services[service] {
            try await restore(Snapshot(savedAt: saved.savedAt, services: [service: previous]))
            return
        }

        let before = try await currentSettings(for: service)

        try await networksetup(["-setwebproxystate", service, "off"])
        try await networksetup(["-setsecurewebproxystate", service, "off"])

        // If a PAC/WPAD URL was configured, put it back and make sure it is on.
        if before.hasAutoProxy {
            try await networksetup(["-setautoproxyurl", service, before.webAutoURL])
            try await networksetup(["-setautoproxystate", service, "on"])
        }

        let after = try await currentSettings(for: service)
        guard !after.webEnabled, !after.secureEnabled else {
            throw ProxyError.verificationFailed(service: service,
                                                 expected: "proxies off",
                                                 actual: "HTTP \(after.webEnabled ? after.webServer : "off"), HTTPS \(after.secureEnabled ? after.secureServer : "off")")
        }
    }

    // MARK: - Snapshots

    /// Captures the full proxy state of `service` (and only that service).
    func capture(service: String) async throws -> Snapshot {
        Snapshot(savedAt: Date(), services: [service: try await currentSettings(for: service)])
    }

    /// Captures the primary service plus every service currently pointed at a proxy.
    /// Deliberately narrow: restoring must not touch services we never changed.
    func captureCurrentState() async throws -> Snapshot {
        var names: [String] = []
        if let primary = await primaryService() { names.append(primary.name) }
        for service in await services() where service.isEnabled && !names.contains(service.name) {
            if let settings = try? await currentSettings(for: service.name), settings.intercepts {
                names.append(service.name)
            }
        }
        var captured: [String: ProxySettings] = [:]
        for name in names {
            if let settings = try? await currentSettings(for: name) { captured[name] = settings }
        }
        return Snapshot(savedAt: Date(), services: captured)
    }

    /// Restores every service in `snapshot` to exactly its recorded state.
    func restore(_ snapshot: Snapshot) async throws {
        for name in snapshot.services.keys.sorted() {
            guard let target = snapshot.services[name] else { continue }
            do {
                try await apply(target, to: name)
            } catch {
                // Keep going: a missing service must not block restoring the others.
                if case ProxyError.serviceNotFound = error { continue }
                throw error
            }
        }
    }

    /// Drives one service into `target` and verifies it.
    private func apply(_ target: ProxySettings, to service: String) async throws {
        // Manual proxy
        if target.webEnabled, !target.webServer.isEmpty {
            try await networksetup(["-setwebproxy", service, target.webServer, target.webPort])
        } else {
            try await networksetup(["-setwebproxy", service, target.webServer.isEmpty ? Self.listenHost : target.webServer,
                                    target.webPort.isEmpty ? "0" : target.webPort])
            try await networksetup(["-setwebproxystate", service, "off"])
        }
        if target.secureEnabled, !target.secureServer.isEmpty {
            try await networksetup(["-setsecurewebproxy", service, target.secureServer, target.securePort])
        } else {
            try await networksetup(["-setsecurewebproxy", service, target.secureServer.isEmpty ? Self.listenHost : target.secureServer,
                                    target.securePort.isEmpty ? "0" : target.securePort])
            try await networksetup(["-setsecurewebproxystate", service, "off"])
        }

        // Auto proxy (PAC)
        if target.hasAutoProxy {
            try await networksetup(["-setautoproxyurl", service, target.webAutoURL])
            try await networksetup(["-setautoproxystate", service, "on"])
        } else {
            try await networksetup(["-setautoproxystate", service, "off"])
        }

        // Bypass / exceptions. An explicit empty argument clears the list —
        // omitting the domain entirely makes networksetup print its usage text.
        let domains = target.ignoreProxyHosts.isEmpty
            ? target.exceptions.flatMap { $0.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) } }
            : target.ignoreProxyHosts
        let cleaned = domains.filter { !$0.isEmpty }
        try await networksetup(["-setproxybypassdomains", service] + (cleaned.isEmpty ? [""] : cleaned))

        let actual = try await currentSettings(for: service)
        guard actual.webEnabled == target.webEnabled,
              actual.secureEnabled == target.secureEnabled,
              actual.webAutoURL == target.webAutoURL,
              actual.ignoreProxyHosts == target.ignoreProxyHosts else {
            throw ProxyError.verificationFailed(
                service: service,
                expected: "web=\(target.webEnabled ? "\(target.webServer):\(target.webPort)" : "off") "
                        + "secure=\(target.secureEnabled ? "\(target.secureServer):\(target.securePort)" : "off") "
                        + "pac=\(target.webAutoURL.isEmpty ? "none" : target.webAutoURL)",
                actual: "web=\(actual.webEnabled ? "\(actual.webServer):\(actual.webPort)" : "off") "
                      + "secure=\(actual.secureEnabled ? "\(actual.secureServer):\(actual.securePort)" : "off") "
                      + "pac=\(actual.webAutoURL.isEmpty ? "none" : actual.webAutoURL)")
        }
    }

    // MARK: - Crash-safe persistence

    private var lastSnapshot: Snapshot?

    /// Writes the current state to disk so the next launch can undo our changes.
    func saveSnapshot() async throws {
        try await saveSnapshot(try await captureCurrentState())
    }

    /// Persists a snapshot built by the caller. `ensureSystemProxy` assembles its own
    /// so that every service is captured *before* any of them is modified.
    func saveSnapshot(_ snapshot: Snapshot) async throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(snapshot)
        try FileManager.default.createDirectory(at: SystemProxyManager.snapshotURL.deletingLastPathComponent(),
                                                withIntermediateDirectories: true)
        try data.write(to: SystemProxyManager.snapshotURL, options: .atomic)
        lastSnapshot = snapshot
    }

    func loadSavedSnapshot() -> Snapshot? {
        if let lastSnapshot { return lastSnapshot }
        guard let data = try? Data(contentsOf: SystemProxyManager.snapshotURL) else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        guard let snapshot = try? decoder.decode(Snapshot.self, from: data), !snapshot.services.isEmpty else { return nil }
        lastSnapshot = snapshot
        return snapshot
    }

    func clearSavedSnapshot() {
        lastSnapshot = nil
        try? FileManager.default.removeItem(at: SystemProxyManager.snapshotURL)
    }

    // MARK: - Opening things

    func openBrowser(url: String?) async {
        var args = ["-a", "Safari"]
        if let url, !url.isEmpty { args.append(url) }
        _ = try? await Shell.runAsync(SystemProxyManager.openPath, args, timeout: 10)
    }

    func openSystemSettings(proxy: Bool) async {
        // The URL is identical for the whole Network pane; deep-linking to the
        // Proxies tab is not supported by any public API, so we aim at the extension.
        _ = try? await Shell.runAsync(SystemProxyManager.openPath,
                                      ["x-apple.systempreferences:com.apple.Network-Settings.extension"],
                                      timeout: 10)
    }

    nonisolated func hasAdministratorPrivileges() -> Bool {
        SystemProxyManager.hasAdministratorPrivileges()
    }

    nonisolated static func hasAdministratorPrivileges() -> Bool {
        geteuid() == 0
    }

    // MARK: - networksetup plumbing

    @discardableResult
    private func networksetup(_ args: [String], ignoreFailure: Bool = false) async throws -> Shell.Output {
        let output = try await Shell.runAsync(SystemProxyManager.networksetupPath, args, timeout: 20)
        if output.timedOut {
            if ignoreFailure { return output }
            throw ProxyError.commandTimedOut(command: args.joined(separator: " "))
        }
        guard output.ok else {
            if ignoreFailure { return output }
            let text = output.combined
            // `-get*` on a stale service says "Unable to find item in network database",
            // `-set*` says "The parameters were not valid." — both mean the same thing.
            if text.contains("Unable to find item") || text.contains("parameters were not valid"),
               let service = args.dropFirst().first {
                throw ProxyError.serviceNotFound(service)
            }
            throw ProxyError.commandFailed(command: args.joined(separator: " "), output: text)
        }
        return output
    }

    // MARK: - Output parsing
    //
    //  -getwebproxy / -getsecurewebproxy
    //      Enabled: Yes
    //      Server: 127.0.0.1
    //      Port: 8080
    //      Authenticated Proxy Enabled: 0
    //
    //  -getautoproxyurl
    //      URL: (null)
    //      Enabled: No
    //
    //  -getproxybypassdomains
    //      *.local
    //      169.254/16
    //  …or "There aren't any bypass domains set on Wi-Fi."

    static func value(_ output: Shell.Output, _ key: String) -> String {
        for raw in output.stdout.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            guard let colon = line.firstIndex(of: ":"), colon > line.startIndex else { continue }
            guard String(line[..<colon]).trimmingCharacters(in: .whitespaces).caseInsensitiveCompare(key) == .orderedSame else { continue }
            return String(line[line.index(after: colon)...]).trimmingCharacters(in: .whitespaces)
        }
        return ""
    }

    static func flag(_ output: Shell.Output, _ key: String) -> Bool {
        let raw = value(output, key).lowercased()
        return raw == "yes" || raw == "1" || raw == "true"
    }

    static func bypassDomains(_ output: Shell.Output) -> [String] {
        var domains: [String] = []
        for raw in output.stdout.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            guard !line.isEmpty, !line.hasPrefix("There aren't any") else { continue }
            domains.append(line)
        }
        return domains
    }
}