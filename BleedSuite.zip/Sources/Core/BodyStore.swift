import Foundation
import SQLite3

private let sqliteTransient = unsafeBitCast(-1, to: sqlite3_destructor_type.self)

/// SQLite-backed offload for oversized bodies plus embedded project blobs.
///
/// Every operation is synchronous and serialized by a lock: bodies are written on
/// the proxy hot path, and SQLite handles its own file-level serialization.
final class BodyStore: @unchecked Sendable {
    static let shared = BodyStore()

    /// Bodies at or above this size belong on disk rather than in `HTTPMessage`.
    let spillThreshold = 2 * 1024 * 1024

    private let lock = NSLock()
    private var db: OpaquePointer?

    static var defaultURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
        return base.appendingPathComponent("BleedSuite", isDirectory: true).appendingPathComponent("bodies.sqlite")
    }

    let url: URL

    init(url: URL = BodyStore.defaultURL) {
        self.url = url
        let dir = url.deletingLastPathComponent()
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)

        var handle: OpaquePointer?
        let flags = SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX
        guard sqlite3_open_v2(url.path, &handle, flags, nil) == SQLITE_OK, let handle else {
            if handle != nil { sqlite3_close_v2(handle) }
            return
        }
        db = handle
        sqlite3_busy_timeout(handle, 2000)
        exec("PRAGMA journal_mode=WAL;")
        exec("CREATE TABLE IF NOT EXISTS bodies(id INTEGER, side TEXT, data BLOB, PRIMARY KEY(id, side));")
        exec("CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, name TEXT, saved INTEGER, blob BLOB);")
    }

    deinit {
        if let db { sqlite3_close_v2(db) }
    }

    // MARK: - Bodies

    func saveBody(id: Int, side: BodySide, data: Data) {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return }
        let sql = "INSERT OR REPLACE INTO bodies(id, side, data) VALUES(?,?,?);"
        guard let stmt = prepare(sql, db: db) else { return }
        defer { sqlite3_finalize(stmt) }
        sqlite3_bind_int64(stmt, 1, sqlite3_int64(id))
        sqlite3_bind_text(stmt, 2, side.rawValue, -1, sqliteTransient)
        _ = bind(data, to: stmt, at: 3)
        _ = sqlite3_step(stmt)
    }

    func loadBody(id: Int, side: BodySide) -> Data? {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return nil }
        let sql = "SELECT data FROM bodies WHERE id = ? AND side = ?;"
        guard let stmt = prepare(sql, db: db) else { return nil }
        defer { sqlite3_finalize(stmt) }
        sqlite3_bind_int64(stmt, 1, sqlite3_int64(id))
        sqlite3_bind_text(stmt, 2, side.rawValue, -1, sqliteTransient)
        guard sqlite3_step(stmt) == SQLITE_ROW else { return nil }
        let count = Int(sqlite3_column_bytes(stmt, 0))
        guard count > 0, let bytes = sqlite3_column_blob(stmt, 0) else { return Data() }
        return Data(bytes: bytes, count: count)
    }

    func hasBody(id: Int, side: BodySide) -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return false }
        let sql = "SELECT 1 FROM bodies WHERE id = ? AND side = ? LIMIT 1;"
        guard let stmt = prepare(sql, db: db) else { return false }
        defer { sqlite3_finalize(stmt) }
        sqlite3_bind_int64(stmt, 1, sqlite3_int64(id))
        sqlite3_bind_text(stmt, 2, side.rawValue, -1, sqliteTransient)
        return sqlite3_step(stmt) == SQLITE_ROW
    }

    func deleteBody(id: Int, side: BodySide) {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return }
        guard let stmt = prepare("DELETE FROM bodies WHERE id = ? AND side = ?;", db: db) else { return }
        defer { sqlite3_finalize(stmt) }
        sqlite3_bind_int64(stmt, 1, sqlite3_int64(id))
        sqlite3_bind_text(stmt, 2, side.rawValue, -1, sqliteTransient)
        _ = sqlite3_step(stmt)
    }

    func deleteAll() {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return }
        execLocked("DELETE FROM bodies;", db: db)
    }

    func dataSize() -> Int64 {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return 0 }
        guard let stmt = prepare("SELECT COALESCE(SUM(LENGTH(data)), 0) FROM bodies;", db: db) else { return 0 }
        defer { sqlite3_finalize(stmt) }
        guard sqlite3_step(stmt) == SQLITE_ROW else { return 0 }
        return sqlite3_column_int64(stmt, 0)
    }

    // MARK: - Projects

    func saveProject(id: String, name: String, data: Data) {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return }
        let sql = "INSERT OR REPLACE INTO projects(id, name, saved, blob) VALUES(?,?,?,?);"
        guard let stmt = prepare(sql, db: db) else { return }
        defer { sqlite3_finalize(stmt) }
        sqlite3_bind_text(stmt, 1, id, -1, sqliteTransient)
        sqlite3_bind_text(stmt, 2, name, -1, sqliteTransient)
        sqlite3_bind_int64(stmt, 3, sqlite3_int64(Date().timeIntervalSince1970))
        _ = bind(data, to: stmt, at: 4)
        _ = sqlite3_step(stmt)
    }

    func loadProject(id: String) -> Data? {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return nil }
        guard let stmt = prepare("SELECT blob FROM projects WHERE id = ?;", db: db) else { return nil }
        defer { sqlite3_finalize(stmt) }
        sqlite3_bind_text(stmt, 1, id, -1, sqliteTransient)
        guard sqlite3_step(stmt) == SQLITE_ROW else { return nil }
        let count = Int(sqlite3_column_bytes(stmt, 0))
        guard count > 0, let bytes = sqlite3_column_blob(stmt, 0) else { return Data() }
        return Data(bytes: bytes, count: count)
    }

    func listProjects() -> [(id: String, name: String, saved: Date)] {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return [] }
        guard let stmt = prepare("SELECT id, name, saved FROM projects ORDER BY saved DESC;", db: db) else { return [] }
        defer { sqlite3_finalize(stmt) }
        var out: [(id: String, name: String, saved: Date)] = []
        while sqlite3_step(stmt) == SQLITE_ROW {
            let id = text(stmt, 0) ?? ""
            let name = text(stmt, 1) ?? ""
            let stamp = sqlite3_column_int64(stmt, 2)
            let date = stamp > 0 ? Date(timeIntervalSince1970: TimeInterval(stamp)) : Date(timeIntervalSince1970: 0)
            out.append((id, name, date))
        }
        return out
    }

    func deleteProject(id: String) {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return }
        guard let stmt = prepare("DELETE FROM projects WHERE id = ?;", db: db) else { return }
        defer { sqlite3_finalize(stmt) }
        sqlite3_bind_text(stmt, 1, id, -1, sqliteTransient)
        _ = sqlite3_step(stmt)
    }

    // MARK: - SQLite plumbing

    private func exec(_ sql: String) {
        lock.lock()
        defer { lock.unlock() }
        guard let db else { return }
        execLocked(sql, db: db)
    }

    private func execLocked(_ sql: String, db: OpaquePointer) {
        if sqlite3_exec(db, sql, nil, nil, nil) != SQLITE_OK { return }
    }

    private func prepare(_ sql: String, db: OpaquePointer) -> OpaquePointer? {
        var stmt: OpaquePointer?
        guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else {
            if stmt != nil { sqlite3_finalize(stmt) }
            return nil
        }
        return stmt
    }

    private func bind(_ data: Data, to stmt: OpaquePointer?, at index: Int32) -> Int32 {
        data.withUnsafeBytes { raw in
            sqlite3_bind_blob(stmt, index, raw.baseAddress, Int32(raw.count), sqliteTransient)
        }
    }

    private func text(_ stmt: OpaquePointer?, _ column: Int32) -> String? {
        guard let cString = sqlite3_column_text(stmt, column) else { return nil }
        return String(cString: cString)
    }
}



/// File-based project archive. Each project is a single `.bsproj` blob written
/// atomically so a crash mid-save can never leave a half-written project behind.
final class ProjectStore: @unchecked Sendable {
    static let shared = ProjectStore()

    let directory: URL

    init(directory: URL? = nil) {
        let base = directory ?? (FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support"))
            .appendingPathComponent("BleedSuite", isDirectory: true)
            .appendingPathComponent("projects", isDirectory: true)
        self.directory = base
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
    }

    @discardableResult
    func save(name: String, encode: () throws -> Data) throws -> URL {
        let url = fileURL(for: name)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let data = try encode()
        try data.write(to: url, options: .atomic)
        return url
    }

    func load(name: String) throws -> Data {
        let url = fileURL(for: name)
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw CocoaError(.fileNoSuchFile)
        }
        return try Data(contentsOf: url)
    }

    func list() -> [URL] {
        let contents = try? FileManager.default.contentsOfDirectory(
            at: directory, includingPropertiesForKeys: [.contentModificationDateKey], options: [.skipsHiddenFiles])
        return (contents ?? []).filter { $0.pathExtension.lowercased() == "bsproj" }
    }

    func delete(name: String) {
        let url = fileURL(for: name)
        try? FileManager.default.removeItem(at: url)
    }

    func fileURL(for name: String) -> URL {
        directory.appendingPathComponent(slugify(name)).appendingPathExtension("bsproj")
    }

    func slugify(_ s: String) -> String {
        var out = ""
        out.reserveCapacity(min(s.count, 64))
        var lastWasDash = false
        for ch in s.unicodeScalars {
            if out.count >= 64 { break }
            if ch == " " || ch == "\t" || ch == "/" || ch == ":" {
                if !out.isEmpty && !lastWasDash { out.append("-") }
                lastWasDash = true
                continue
            }
            if CharacterSet.alphanumerics.contains(ch) || ch == "-" || ch == "_" {
                out.unicodeScalars.append(ch)
                lastWasDash = ch == "-"
            } else if !out.isEmpty && !lastWasDash {
                out.append("-")
                lastWasDash = true
            }
        }
        while out.hasSuffix("-") { out.removeLast() }
        return out.isEmpty ? "project" : out
    }
}