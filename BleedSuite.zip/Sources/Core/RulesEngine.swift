import Foundation

// ============================================================================
//  Match & Replace — the Core half of "Proxy > Match and Replace".
//
//  The engine is deliberately UI free: it owns the rule list, persists it and
//  knows how to rewrite an `HTTPMessage` in place. Every mutation funnels
//  through a single NSLock so the proxy hot path and the UI can call it from
//  different threads.
// ============================================================================

// ============================================================================
//  Result of one rule pass
// ============================================================================

/// Outcome of running the rule list over a single message.
struct RuleEdit {
    /// The (possibly rewritten) message. Always returned, even on failure.
    var message: HTTPMessage
    /// How many rules fired (`negateMatch` taken into account).
    var applied: Int
    /// First error encountered (bad regex, empty scope, …). Rules keep running.
    var error: String?

    init(message: HTTPMessage, applied: Int = 0, error: String? = nil) {
        self.message = message
        self.applied = applied
        self.error = error
    }

    var didChangeAnything: Bool { applied > 0 }
}

// ============================================================================
//  Errors
// ============================================================================

enum RulesEngineError: LocalizedError {
    case invalidJSON(String)
    case notARuleList

    var errorDescription: String? {
        switch self {
        case .invalidJSON(let detail): return "Not valid rule JSON — \(detail)"
        case .notARuleList: return "JSON does not contain a list of match/replace rules."
        }
    }
}

// ============================================================================
//  Low level text matching / replacing
// ============================================================================

/// Result of a single text transformation attempt.
struct TextTransform {
    var output: String
    var matched: Bool
    var error: String?
}

enum RuleMatcher {
    /// Bodies bigger than this are never touched (regex on a 50 MB blob is a UI freeze).
    static let maxBodyBytes = 1 * 1024 * 1024

    // MARK: - Matching

    static func matches(_ text: String, _ rule: ProxyRule) -> TextTransform {
        // An empty needle is never useful and, as a regex, would match everywhere.
        guard !rule.pattern.isEmpty else {
            return TextTransform(output: text, matched: false, error: nil)
        }
        switch rule.matchType {
        case .regex:
            return regexTransform(text, rule)
        case .contains, .startsWith, .endsWith, .equals:
            return TextTransform(output: text, matched: literalMatch(text, rule), error: nil)
        }
    }

    /// Case sensitivity for literal match types, using the localized comparisons
    /// Foundation offers so diacritics behave the way users expect.
    static func literalMatch(_ text: String, _ rule: ProxyRule) -> Bool {
        let needle = rule.pattern
        if rule.caseSensitive {
            switch rule.matchType {
            case .contains, .regex: return text.contains(needle)
            case .startsWith: return text.hasPrefix(needle)
            case .endsWith: return text.hasSuffix(needle)
            case .equals: return text == needle
            }
        }
        switch rule.matchType {
        case .contains, .regex: return text.localizedCaseInsensitiveContains(needle)
        case .startsWith: return text.lowercased().hasPrefix(needle.lowercased())
        case .endsWith: return text.lowercased().hasSuffix(needle.lowercased())
        case .equals: return text.localizedCaseInsensitiveCompare(needle) == .orderedSame
        }
    }

    private static func regexOptions(_ rule: ProxyRule) -> NSRegularExpression.Options {
        rule.caseSensitive ? [] : [.caseInsensitive]
    }

    private static func regexTransform(_ text: String, _ rule: ProxyRule) -> TextTransform {
        let regex: NSRegularExpression
        do {
            regex = try NSRegularExpression(pattern: rule.pattern, options: regexOptions(rule))
        } catch {
            return TextTransform(
                output: text,
                matched: false,
                error: "Invalid regex “\(rule.pattern)” — \(error.localizedDescription)"
            )
        }
        let range = NSRange(text.startIndex..., in: text)
        let matches = regex.matches(in: text, options: [], range: range)
        guard !matches.isEmpty else { return TextTransform(output: text, matched: false, error: nil) }
        // `$1`, `${1}` and `${name}` are all expanded by hand: ICU's own template
        // syntax understands `$1` but silently drops `${name}`.
        let names = groupNames(in: rule.pattern)
        let ns = text as NSString
        var out = ""
        var cursor = 0
        for match in matches {
            out += ns.substring(with: NSRange(location: cursor, length: match.range.location - cursor))
            out += expandTemplate(rule.replacement, match: match, text: ns, names: names)
            cursor = match.range.location + match.range.length
        }
        out += ns.substring(from: cursor)
        return TextTransform(output: out, matched: true, error: nil)
    }

    /// Maps `(?<name>…)` / `(?'name'…)` capture names onto their group index.
    private static func groupNames(in pattern: String) -> [String: Int] {
        var names: [String: Int] = [:]
        var index = 1
        var scanner = pattern.startIndex
        while scanner < pattern.endIndex {
            let char = pattern[scanner]
            var consumedTo: String.Index?
            if char == "\\", pattern.index(after: scanner) < pattern.endIndex {
                // \Q…\E literal run: skip it entirely.
                if pattern[pattern.index(after: scanner)] == "Q" {
                    var q = pattern.index(after: scanner)
                    while q < pattern.endIndex {
                        if pattern[q] == "\\", pattern.index(after: q) < pattern.endIndex,
                           pattern[pattern.index(after: q)] == "E" {
                            q = pattern.index(q, offsetBy: 2)
                            break
                        }
                        q = pattern.index(after: q)
                    }
                    scanner = q
                    continue
                }
                scanner = pattern.index(after: scanner)
            } else if char == "[" {
                var q = scanner
                while q < pattern.endIndex, pattern[q] != "]" { q = pattern.index(after: q) }
                scanner = q < pattern.endIndex ? pattern.index(after: q) : pattern.endIndex
                continue
            } else if char == "(" {
                if pattern[pattern.index(after: scanner)] == "?" {
                    let after = pattern.index(after: scanner)
                    let next = pattern.index(after: after)
                    if next < pattern.endIndex, pattern[next] == "<" || pattern[next] == "'" {
                        let quote = pattern[next]
                        // `(?<name>…)` is closed by ">", `(?'name'…)` by the quote.
                        let terminator: Character = quote == "<" ? ">" : quote
                        let nameStart = pattern.index(after: next)
                        var nameEnd = nameStart
                        while nameEnd < pattern.endIndex, pattern[nameEnd] != terminator {
                            nameEnd = pattern.index(after: nameEnd)
                        }
                        let name = String(pattern[nameStart..<nameEnd])
                        // Only a *closed* `(?<name>` counts; `(?<=` / `(?<!` and an
                        // unterminated run are assertions (or broken patterns).
                        if nameEnd < pattern.endIndex, pattern[nameEnd] == terminator, !name.isEmpty {
                            names[name] = index
                            consumedTo = nameEnd
                        }
                    } else {
                        index += 1
                    }
                } else {
                    index += 1
                }
            }
            scanner = consumedTo.map { pattern.index(after: $0) } ?? pattern.index(after: scanner)
        }
        return names
    }

    /// Expands `$0`, `$1`, `${1}`, `${name}`, `$$` and `\1` inside a replacement.
    private static func expandTemplate(_ template: String,
                                       match: NSTextCheckingResult,
                                       text: NSString,
                                       names: [String: Int]) -> String {
        func groupValue(_ index: Int) -> String {
            guard index < match.numberOfRanges else { return "" }
            let range = match.range(at: index)
            return range.location == NSNotFound ? "" : text.substring(with: range)
        }
        func groupIndex(_ token: String) -> Int? {
            if token.isEmpty { return nil }
            if token.allSatisfy({ $0.isNumber }) { return Int(token) }
            return names[token]
        }

        var out = ""
        var scanner = template.startIndex
        while scanner < template.endIndex {
            let char = template[scanner]
            guard char == "$" || char == "\\" else {
                out.append(char)
                scanner = template.index(after: scanner)
                continue
            }
            let next = template.index(after: scanner)
            guard next < template.endIndex else {
                out.append(char)
                scanner = next
                continue
            }
            let follower = template[next]
            if follower == char {                       // $$ or \\
                out.append(char)
                scanner = template.index(after: next)
                continue
            }
            if follower == "{" {
                let close = template[next...].firstIndex(of: "}") ?? template.endIndex
                let token = String(template[template.index(after: next)..<close])
                if let index = groupIndex(token) {
                    out += groupValue(index)
                } else {
                    out += String(template[scanner...close])
                }
                scanner = close < template.endIndex ? template.index(after: close) : template.endIndex
                continue
            }
            if follower.isNumber {
                var digits = ""
                var cursor = next
                while cursor < template.endIndex, template[cursor].isNumber {
                    digits.append(template[cursor])
                    cursor = template.index(after: cursor)
                }
                if let index = Int(digits) {
                    out += groupValue(index)
                    scanner = cursor
                    continue
                }
            }
            out.append(char)
            scanner = next
        }
        return out
    }

    // MARK: - Replacing

    /// Rewrites `text` according to `rule`. Works even when the match is
    /// negative — a negated rule that does not match simply changes nothing.
    static func transform(_ text: String, _ rule: ProxyRule) -> TextTransform {
        guard !rule.pattern.isEmpty else {
            return TextTransform(output: text, matched: false, error: nil)
        }
        switch rule.matchType {
        case .regex:
            return regexTransform(text, rule)
        case .contains, .startsWith, .endsWith, .equals:
            let hit = literalMatch(text, rule)
            return TextTransform(output: literalReplace(text, rule), matched: hit, error: nil)
        }
    }

    private static func literalReplace(_ text: String, _ rule: ProxyRule) -> String {
        guard !rule.pattern.isEmpty else { return text }
        if rule.caseSensitive {
            return text.replacingOccurrences(of: rule.pattern, with: rule.replacement)
        }
        // Case-insensitive literals still go through the regex engine so that
        // *all* occurrences are replaced, whatever their casing.
        guard let regex = try? NSRegularExpression(pattern: NSRegularExpression.escapedPattern(for: rule.pattern),
                                                  options: [.caseInsensitive]) else {
            return text
        }
        // Literal replacements must not interpret `$1`, hence escapedTemplate.
        let template = NSRegularExpression.escapedTemplate(for: rule.replacement)
        return regex.stringByReplacingMatches(in: text, options: [],
                                              range: NSRange(text.startIndex..., in: text),
                                              withTemplate: template)
    }
}

// ============================================================================
//  RulesEngine
// ============================================================================

final class RulesEngine: @unchecked Sendable {
    static let shared = RulesEngine()

    private let lock = NSLock()
    private var storage: [ProxyRule]

    /// Read-only, thread safe view of the ordered rule list.
    var rules: [ProxyRule] {
        lock.lock(); defer { lock.unlock() }
        return storage
    }

    var count: Int { rules.count }

    init(rules: [ProxyRule] = []) {
        self.storage = rules
    }

    // MARK: - List management

    func add(_ rule: ProxyRule) {
        lock.lock(); defer { lock.unlock() }
        storage.append(rule)
    }

    /// Replaces the rule carrying the same `id`. Unknown ids are ignored.
    func update(_ rule: ProxyRule) {
        lock.lock(); defer { lock.unlock() }
        guard let idx = storage.firstIndex(where: { $0.id == rule.id }) else { return }
        storage[idx] = rule
    }

    func remove(id: UUID) {
        lock.lock(); defer { lock.unlock() }
        storage.removeAll { $0.id == id }
    }

    @discardableResult
    func remove(at index: Int) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard storage.indices.contains(index) else { return false }
        storage.remove(at: index)
        return true
    }

    /// Reorders a single rule (drag & drop in the list).
    func move(from: Int, to: Int) {
        guard from >= 0, to >= 0, from < storage.count, to < storage.count, from != to else { return }
        lock.lock(); defer { lock.unlock() }
        let item = storage.remove(at: from)
        storage.insert(item, at: to)
    }

    func setEnabled(_ enabled: Bool, for id: UUID) {
        lock.lock(); defer { lock.unlock() }
        guard let idx = storage.firstIndex(where: { $0.id == id }) else { return }
        storage[idx].enabled = enabled
    }

    func replaceAll(_ newRules: [ProxyRule]) {
        lock.lock(); defer { lock.unlock() }
        storage = newRules
    }

    func removeAll() {
        lock.lock(); defer { lock.unlock() }
        storage.removeAll()
    }

    func rule(id: UUID) -> ProxyRule? {
        lock.lock(); defer { lock.unlock() }
        return storage.first { $0.id == id }
    }

    func enabledRules(for direction: ProxyRule.Direction) -> [ProxyRule] {
        rules.filter { $0.enabled && $0.direction == direction }
    }

    // MARK: - Serialization

    /// JSON snapshot of the current rule list (`nil` only on encoder failure).
    func persist() -> Data? {
        let snapshot = rules
        guard !snapshot.isEmpty else { return Data("[]".utf8) }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        return try? encoder.encode(snapshot)
    }

    /// Tolerant decoder: accepts a bare array, a single rule object or `{"rules":[…]}`.
    static func load(from data: Data) -> [ProxyRule] {
        if let list = try? JSONDecoder().decode([ProxyRule].self, from: data) { return list }
        if let single = try? JSONDecoder().decode(ProxyRule.self, from: data) { return [single] }
        if let wrapper = try? JSONDecoder().decode(RulesWrapper.self, from: data) { return wrapper.rules }
        return lenientLoad(from: data)
    }

    /// Manual, default-filling decoder used as a fallback. Rules exported by other
    /// tools rarely carry every field, so anything missing keeps its default.
    private static func lenientLoad(from data: Data) -> [ProxyRule] {
        guard let json = try? JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed]) else {
            return []
        }
        func objectToRule(_ dict: [String: Any]) -> ProxyRule? {
            // A rule object always carries a condition or a replacement.
            guard dict["pattern"] != nil || dict["replacement"] != nil || dict["condition"] != nil else { return nil }
            var rule = ProxyRule()
            if let s = dict["comment"] as? String { rule.comment = s }
            if let b = dict["enabled"] as? Bool { rule.enabled = b }
            if let s = dict["direction"] as? String,
               let d = ProxyRule.Direction(rawValue: s.lowercased()) { rule.direction = d }
            if let s = dict["target"] as? String ?? dict["type"] as? String,
               let t = ProxyRule.Target(rawValue: s.lowercased()) { rule.target = t }
            if let s = dict["matchType"] as? String ?? dict["matchtype"] as? String,
               let m = ProxyRule.MatchType(rawValue: s.lowercased()) { rule.matchType = m }
            if let b = dict["negateMatch"] as? Bool ?? dict["negate"] as? Bool { rule.negateMatch = b }
            if let b = dict["caseSensitive"] as? Bool ?? dict["casesensitive"] as? Bool { rule.caseSensitive = b }
            if let s = dict["pattern"] as? String { rule.pattern = s }
            if let s = dict["replacement"] as? String { rule.replacement = s }
            if let s = dict["id"] as? String, let uuid = UUID(uuidString: s) { rule.id = uuid }
            return rule
        }
        func rules(from object: Any) -> [ProxyRule] {
            if let array = object as? [Any] {
                return array.compactMap { $0 as? [String: Any] }.compactMap(objectToRule)
            }
            if let dict = object as? [String: Any] {
                if let nested = dict["rules"] { return rules(from: nested) }
                return objectToRule(dict).map { [$0] } ?? []
            }
            return []
        }
        return rules(from: json)
    }

    func exportJSON() -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        guard let data = try? encoder.encode(rules),
              let text = String(data: data, encoding: .utf8) else { return "[]" }
        return text
    }

    func importJSON(_ s: String) throws {
        let trimmed = s.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw RulesEngineError.notARuleList }
        guard let data = trimmed.data(using: .utf8) else {
            throw RulesEngineError.invalidJSON("input is not UTF-8")
        }
        guard (try? JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed])) != nil else {
            throw RulesEngineError.invalidJSON("input is not JSON")
        }
        let incoming = RulesEngine.load(from: data)
        guard !incoming.isEmpty else {
            // An explicit empty list is a valid "clear everything" import.
            if trimmed.replacingOccurrences(of: " ", with: "").hasPrefix("[") { replaceAll([]); return }
            throw RulesEngineError.notARuleList
        }
        replaceAll(mergeDuplicates(incoming))
    }

    /// Imports without touching the live list — handy for preview / validation.
    static func parse(_ s: String) -> [ProxyRule] {
        guard let data = s.data(using: .utf8) else { return [] }
        return load(from: data)
    }

    private func mergeDuplicates(_ incoming: [ProxyRule]) -> [ProxyRule] {
        var seen = Set<UUID>()
        var out: [ProxyRule] = []
        out.reserveCapacity(incoming.count)
        for var rule in incoming {
            // Imported files may carry duplicated ids; keep every rule, re-key the dupes.
            while !seen.insert(rule.id).inserted { rule.id = UUID() }
            out.append(rule)
        }
        return out
    }

    private struct RulesWrapper: Codable {
        var rules: [ProxyRule]
    }

    // MARK: - Application

    func applyToRequest(_ m: HTTPMessage, pair: HTTPPair?) -> RuleEdit {
        apply(to: m, direction: .request, pair: pair)
    }

    func applyToResponse(_ m: HTTPMessage, pair: HTTPPair?) -> RuleEdit {
        apply(to: m, direction: .response, pair: pair)
    }

    /// Runs every enabled rule for `direction` over a copy of `message`.
    func apply(to message: HTTPMessage, direction: ProxyRule.Direction, pair: HTTPPair?) -> RuleEdit {
        var working = message
        let list = enabledRules(for: direction)
        var applied = 0
        var errors: [String] = []
        var bodyChanged = false
        let isRequestSide = (direction == .request)

        for rule in list {
            let outcome = RulesEngine.applyRule(rule, to: &working, pair: pair, isRequestSide: isRequestSide)
            if let err = outcome.error {
                let label = rule.comment.isEmpty ? rule.target.label : rule.comment
                errors.append("\(label): \(err)")
            }
            if outcome.bodyChanged { bodyChanged = true }
            if outcome.fired { applied += 1 }
        }

        // Content-Length / Transfer-Encoding are fixed up once, at the very end.
        if bodyChanged { working.normalizeFraming() }

        return RuleEdit(message: working,
                        applied: applied,
                        error: errors.isEmpty ? nil : errors.joined(separator: "\n"))
    }

    /// Applies the whole list to a request/response pair in one go.
    func apply(to pair: HTTPPair) -> (request: RuleEdit, response: RuleEdit?) {
        let req = applyToRequest(pair.request, pair: pair)
        if let resp = pair.response {
            return (req, applyToResponse(resp, pair: pair))
        }
        return (req, nil)
    }

    // MARK: - Single rule

    struct RuleOutcome {
        var fired: Bool = false
        var changed: Bool = false
        var bodyChanged: Bool = false
        var error: String? = nil
    }

    /// Rewrites one rule into `message`. Never throws: a broken regex only sets `error`.
    static func applyRule(_ rule: ProxyRule,
                          to message: inout HTTPMessage,
                          pair: HTTPPair?,
                          isRequestSide: Bool) -> RuleOutcome {
        var outcome = RuleOutcome()
        guard !rule.pattern.isEmpty else {
            outcome.error = "empty pattern"
            return outcome
        }

        switch rule.target {
        case .url:
            applyURL(rule, &message, pair, isRequestSide, &outcome)
        case .host:
            applyHost(rule, &message, pair, isRequestSide, &outcome)
        case .path:
            applyPathPart(rule, &message, isRequestSide, &outcome, includeQuery: false)
        case .query:
            applyPathPart(rule, &message, isRequestSide, &outcome, includeQuery: true)
        case .header:
            applyHeader(rule, &message, &outcome)
        case .body:
            applyBody(rule, &message, &outcome)
        case .method:
            guard isRequestSide, message.isRequest else { return outcome }
            applyMethod(rule, &message, &outcome)
        case .statusCode:
            guard !isRequestSide, !message.isRequest else { return outcome }
            applyStatus(rule, &message, &outcome)
        }
        return outcome
    }

    // MARK: URL

    private static func applyURL(_ rule: ProxyRule,
                                 _ message: inout HTTPMessage,
                                 _ pair: HTTPPair?,
                                 _ isRequestSide: Bool,
                                 _ outcome: inout RuleOutcome) {
        if isRequestSide {
            // The request target already carries "path?query".
            let text = message.path
            guard !text.isEmpty else { return }
            let result = RuleMatcher.transform(text, rule)
            finish(result, rule, original: text, &outcome) { newValue in
                rewriteTarget(&message, newValue)
            }
        } else {
            // A response owns no URL; fall back to the pair's URL when we have one.
            guard let url = pair?.url, !url.isEmpty else { return }
            let result = RuleMatcher.transform(url, rule)
            if let err = result.error { if outcome.error == nil { outcome.error = err }; return }
            guard (rule.negateMatch ? !result.matched : result.matched) else { return }
            outcome.fired = true
            // There is nowhere to store a response-side URL: the caller keeps
            // ownership of `pair`, so the substitution is evaluated and reported only.
        }
    }

    // MARK: Host

    private static func applyHost(_ rule: ProxyRule,
                                  _ message: inout HTTPMessage,
                                  _ pair: HTTPPair?,
                                  _ isRequestSide: Bool,
                                  _ outcome: inout RuleOutcome) {
        if message.header("Host") != nil {
            let current = message.header("Host") ?? ""
            let result = RuleMatcher.transform(current, rule)
            finish(result, rule, original: current, &outcome) { newValue in
                message.setHeader("Host", newValue)
            }
            return
        }
        guard !isRequestSide, let host = pair?.host, !host.isEmpty else { return }
        let result = RuleMatcher.transform(host, rule)
        if let err = result.error { if outcome.error == nil { outcome.error = err }; return }
        guard (rule.negateMatch ? !result.matched : result.matched) else { return }
        outcome.fired = true
        // Response without a Host header: evaluated against the pair, nothing to write.
    }

    // MARK: Path / Query

    private static func applyPathPart(_ rule: ProxyRule,
                                      _ message: inout HTTPMessage,
                                      _ isRequestSide: Bool,
                                      _ outcome: inout RuleOutcome,
                                      includeQuery: Bool) {
        guard isRequestSide, message.isRequest else { return }
        let full = message.path
        guard !full.isEmpty else { return }
        let separatorIdx = full.firstIndex(of: "?")
        let pathOnly = separatorIdx.map { String(full[..<$0]) } ?? full
        let query = separatorIdx.map { String(full[full.index(after: $0)...]) } ?? ""
        let text = includeQuery ? query : pathOnly
        guard !text.isEmpty else { return }

        let result = RuleMatcher.transform(text, rule)
        finish(result, rule, original: text, &outcome) { newValue in
            let rebuilt: String
            if includeQuery {
                rebuilt = newValue.isEmpty ? pathOnly : pathOnly + "?" + newValue
            } else {
                rebuilt = separatorIdx == nil ? newValue : newValue + "?" + query
            }
            rewriteTarget(&message, rebuilt)
        }
    }

    private static func rewriteTarget(_ message: inout HTTPMessage, _ newTarget: String) {
        let parts = message.startLine.split(separator: " ", omittingEmptySubsequences: false).map(String.init)
        guard parts.count >= 2 else { return }
        var line = parts
        line[1] = newTarget
        message.startLine = line.joined(separator: " ")
    }

    // MARK: Header

    private static func applyHeader(_ rule: ProxyRule,
                                    _ message: inout HTTPMessage,
                                    _ outcome: inout RuleOutcome) {
        let name = rule.headerName.trimmingCharacters(in: .whitespaces)
        guard !name.isEmpty else {
            outcome.error = "header name is empty"
            return
        }
        let lowerName = name.lowercased()
        var indexes = message.headers.indices.filter {
            message.headers[$0].enabled && message.headers[$0].trimmedName.lowercased() == lowerName
        }
        if indexes.isEmpty {
            // Tolerate regex-anchored conditions such as "^Cookie: a=b".
            let trimmed = name.trimmingCharacters(in: CharacterSet(charactersIn: "^$\\A"))
            let alt = trimmed.lowercased()
            indexes = message.headers.indices.filter {
                message.headers[$0].enabled && message.headers[$0].trimmedName.lowercased() == alt
            }
        }
        guard !indexes.isEmpty else { return }

        // "Name: value" form: the condition matches the whole header line and only
        // its value is rewritten. Without a colon the pattern *is* the header name,
        // so the value of every header with that name is replaced outright.
        let wholeLine = rule.pattern.contains(":")

        for idx in indexes {
            let value = message.headers[idx].value

            if !wholeLine {
                guard !rule.negateMatch else { continue }   // nothing to rewrite when negated
                outcome.fired = true
                if rule.replacement != value {
                    message.headers[idx].value = rule.replacement
                    outcome.changed = true
                }
                continue
            }

            let subject = "\(message.headers[idx].trimmedName): \(value)"
            let result = RuleMatcher.transform(subject, rule)
            if let err = result.error {
                if outcome.error == nil { outcome.error = err }
                continue
            }
            guard (rule.negateMatch ? !result.matched : result.matched) else { continue }
            outcome.fired = true

            // The rewrite kept the "Name:" prefix -> only the value is replaced.
            // Otherwise the rule swallowed the name too, and the whole result is
            // the new value.
            var newValue = result.output
            if let colon = result.output.firstIndex(of: ":"),
               String(result.output[..<colon]).trimmingCharacters(in: .whitespaces)
                   .compare(message.headers[idx].trimmedName, options: .caseInsensitive) == .orderedSame {
                newValue = String(result.output[result.output.index(after: colon)...])
            }
            if newValue != value {
                message.headers[idx].value = newValue
                outcome.changed = true
            }
        }
    }

    // MARK: Body

    private static func applyBody(_ rule: ProxyRule,
                                  _ message: inout HTTPMessage,
                                  _ outcome: inout RuleOutcome) {
        guard !message.body.isEmpty else { return }
        guard message.body.count <= RuleMatcher.maxBodyBytes else {
            outcome.error = "body is \(message.body.count) bytes, above the \(RuleMatcher.maxBodyBytes) byte limit"
            return
        }
        guard message.isBodyTextual else {
            outcome.error = "body is not textual — rule skipped"
            return
        }
        let text = String(decoding: message.body, as: UTF8.self)
        let result = RuleMatcher.transform(text, rule)
        if let err = result.error { if outcome.error == nil { outcome.error = err }; return }
        guard (rule.negateMatch ? !result.matched : result.matched) else { return }
        outcome.fired = true
        guard result.output != text else { return }
        message.body = Data(result.output.utf8)
        outcome.changed = true
        outcome.bodyChanged = true
    }

    // MARK: Method / Status

    private static func applyMethod(_ rule: ProxyRule,
                                   _ message: inout HTTPMessage,
                                   _ outcome: inout RuleOutcome) {
        let current = message.method
        let result = RuleMatcher.transform(current, rule)
        finish(result, rule, original: current, &outcome) { newValue in
            message.method = newValue
        }
    }

    private static func applyStatus(_ rule: ProxyRule,
                                    _ message: inout HTTPMessage,
                                    _ outcome: inout RuleOutcome) {
        guard let code = message.status else { return }
        let current = String(code)
        let result = RuleMatcher.transform(current, rule)
        finish(result, rule, original: current, &outcome) { newValue in
            let candidate = newValue.trimmingCharacters(in: .whitespaces)
            guard Int(candidate) != nil else { return }   // never emit a broken status line
            let parts = message.startLine.split(separator: " ", omittingEmptySubsequences: false).map(String.init)
            guard parts.count >= 2 else { return }
            var line = parts
            line[1] = candidate
            message.startLine = line.joined(separator: " ")
        }
        if outcome.fired && message.status != Int(rule.replacement.trimmingCharacters(in: .whitespaces)),
           message.status == code {
            outcome.changed = false
            outcome.error = "replacement “\(rule.replacement)” is not a valid status code — status line left untouched"
        }
    }

    // MARK: Shared plumbing

    /// Applies the "did it match / did it change / write it back" bookkeeping.
    ///
    /// A negated rule fires when the condition does *not* match; in that case the
    /// substitution is a no-op on its own (there is nothing to replace), so the
    /// message is only ever rewritten on a real hit.
    private static func finish(_ result: TextTransform,
                               _ rule: ProxyRule,
                               original: String,
                               _ outcome: inout RuleOutcome,
                               _ commit: (String) -> Void) {
        if let err = result.error {
            if outcome.error == nil { outcome.error = err }
            return
        }
        guard (rule.negateMatch ? !result.matched : result.matched) else { return }
        outcome.fired = true
        guard result.output != original else { return }
        outcome.changed = true
        commit(result.output)
    }
}

// ============================================================================
//  Target scope
// ============================================================================

/// Burp's "Target scope": which hosts rules / logging may touch.
struct ScopeFilter: Codable, Sendable, Equatable {
    /// Empty = everything is in scope.
    var includedHosts: [String] = []
    /// Exclusion always wins over inclusion.
    var excludedHosts: [String] = []
    var requireHTTPS: Bool = false

    var isActive: Bool {
        !includedHosts.isEmpty || !excludedHosts.isEmpty || requireHTTPS
    }

    func isInScope(host: String, isSecure: Bool) -> Bool {
        if requireHTTPS && !isSecure { return false }
        let target = ScopeFilter.normalizeHost(host)
        if target.isEmpty { return false }
        for pattern in excludedHosts where ScopeFilter.host(target, matches: pattern) {
            return false
        }
        if includedHosts.isEmpty { return true }
        for pattern in includedHosts where ScopeFilter.host(target, matches: pattern) {
            return true
        }
        return false
    }

    func isInScope(_ pair: HTTPPair) -> Bool {
        isInScope(host: pair.host, isSecure: pair.isSecure)
    }

    // MARK: - Editing

    /// Adds the host to the include list, or removes it when it is already there.
    /// Hosts currently excluded are promoted to "included" on toggle.
    mutating func toggleHost(_ host: String) {
        let key = ScopeFilter.normalizeHost(host)
        guard !key.isEmpty else { return }
        if let idx = includedHosts.firstIndex(where: { ScopeFilter.normalizeHost($0) == key }) {
            includedHosts.remove(at: idx)
            return
        }
        excludedHosts.removeAll { ScopeFilter.normalizeHost($0) == key }
        includedHosts.append(key)
    }

    mutating func include(_ host: String) {
        let key = ScopeFilter.normalizeHost(host)
        guard !key.isEmpty else { return }
        excludedHosts.removeAll { ScopeFilter.normalizeHost($0) == key }
        if !includedHosts.contains(where: { ScopeFilter.normalizeHost($0) == key }) {
            includedHosts.append(key)
        }
    }

    mutating func exclude(_ host: String) {
        let key = ScopeFilter.normalizeHost(host)
        guard !key.isEmpty else { return }
        includedHosts.removeAll { ScopeFilter.normalizeHost($0) == key }
        if !excludedHosts.contains(where: { ScopeFilter.normalizeHost($0) == key }) {
            excludedHosts.append(key)
        }
    }

    mutating func removeAll() {
        includedHosts.removeAll()
        excludedHosts.removeAll()
        requireHTTPS = false
    }

    // MARK: - Host matching

    /// Strips scheme, port, path and stray whitespace so `https://a.com:443/x` → `a.com`.
    /// A leading `*.` wildcard is *kept*: it is part of the pattern, not decoration.
    static func normalizeHost(_ raw: String) -> String {
        var host = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if let schemeRange = host.range(of: "://") {
            host = String(host[schemeRange.upperBound...])
        }
        if let slash = host.firstIndex(of: "/") {
            host = String(host[..<slash])
        }
        if let at = host.firstIndex(of: "@") {
            host = String(host[host.index(after: at)...])
        }
        if let colon = host.firstIndex(of: ":") {
            host = String(host[..<colon])
        }
        var wildcard = false
        while host.hasPrefix("*") || host.hasPrefix(".") {
            if host.hasPrefix("*") {
                host = String(host.dropFirst())
                wildcard = true
            } else {
                host = String(host.dropFirst())
            }
        }
        return wildcard ? "*." + host : host
    }

    /// Exact host, `*.example.com` subdomains (and the apex), or a bare `*` catch-all.
    static func host(_ target: String, matches pattern: String) -> Bool {
        let p = normalizeHost(pattern)
        if p == "*" || p == "*:*" { return true }
        if p.hasPrefix("*.") {
            let suffix = String(p.dropFirst(2))
            guard !suffix.isEmpty else { return true }
            return target == suffix || target.hasSuffix("." + suffix)
        }
        return target == p
    }

    // MARK: - JSON

    func toJSON() -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        guard let data = try? encoder.encode(self), let text = String(data: data, encoding: .utf8) else {
            return "{\n  \"includedHosts\" : [],\n  \"excludedHosts\" : [],\n  \"requireHTTPS\" : false\n}"
        }
        return text
    }

    static func fromJSON(_ s: String) -> ScopeFilter {
        guard let data = s.data(using: .utf8) else { return ScopeFilter() }
        return (try? JSONDecoder().decode(ScopeFilter.self, from: data)) ?? ScopeFilter()
    }
}

// ============================================================================
//  Scope store
// ============================================================================

/// Thread safe owner of the single active `ScopeFilter`, persisted on disk.
final class ScopeFilterStore: @unchecked Sendable {
    static let shared = ScopeFilterStore()

    static let directoryName = "BleedSuite"
    static let fileName = "scope.json"

    private let lock = NSLock()
    private var storage: ScopeFilter

    init(filter: ScopeFilter = ScopeFilter()) {
        self.storage = filter
    }

    var filter: ScopeFilter {
        get { lock.lock(); defer { lock.unlock() }; return storage }
        set { lock.lock(); storage = newValue; lock.unlock() }
    }

    func replace(_ newFilter: ScopeFilter) {
        lock.lock(); defer { lock.unlock() }
        storage = newFilter
    }

    func mutate(_ body: (inout ScopeFilter) -> Void) {
        lock.lock(); defer { lock.unlock() }
        body(&storage)
    }

    func toggleHost(_ host: String) {
        lock.lock(); defer { lock.unlock() }
        storage.toggleHost(host)
    }

    func isInScope(host: String, isSecure: Bool) -> Bool {
        lock.lock(); defer { lock.unlock() }
        return storage.isInScope(host: host, isSecure: isSecure)
    }

    func removeAll() {
        lock.lock(); defer { lock.unlock() }
        storage.removeAll()
    }

    // MARK: - Disk

    static var directoryURL: URL? {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first?
            .appendingPathComponent(directoryName, isDirectory: true)
    }

    static var fileURL: URL? {
        directoryURL?.appendingPathComponent(fileName, isDirectory: false)
    }

    func loadFromDisk() {
        guard let url = ScopeFilterStore.fileURL,
              let data = try? Data(contentsOf: url) else { return }
        let loaded = ScopeFilter.fromJSON(String(decoding: data, as: UTF8.self))
        lock.lock(); defer { lock.unlock() }
        storage = loaded
    }

    @discardableResult
    func persistToDisk() -> Bool {
        guard let dir = ScopeFilterStore.directoryURL, let url = ScopeFilterStore.fileURL else { return false }
        let text: String = {
            lock.lock(); defer { lock.unlock() }
            return storage.toJSON()
        }()
        do {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            try Data(text.utf8).write(to: url, options: .atomic)
            return true
        } catch {
            return false
        }
    }
}