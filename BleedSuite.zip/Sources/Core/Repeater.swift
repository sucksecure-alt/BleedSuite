import Foundation

// ============================================================================
//  Repeater
// ============================================================================

struct RepeaterTab: Identifiable, Sendable {
    var id: UUID = UUID()
    var name: String
    var request: HTTPMessage
    var response: HTTPMessage?
    var statusCode: Int?
    var durationMS: Int?
    var responseLength: Int?
    var error: String?
    var isSecure: Bool
    var host: String
    var port: Int
    var isModified: Bool = false
    var lastSent: Date?
    /// Saved in-project history of previous responses for this tab.
    var responseHistory: [(status: Int, length: Int, ms: Int, at: Date)] = []

    static func blank() -> RepeaterTab {
        var headers = [
            Header(name: "Host", value: ""),
            Header(name: "User-Agent", value: "BleedSuite/1.0"),
            Header(name: "Accept", value: "*/*"),
            Header(name: "Connection", value: "close"),
        ]
        headers.append(Header(name: "", value: ""))
        return RepeaterTab(
            name: "Tab 1",
            request: HTTPMessage(isRequest: true, startLine: "GET / HTTP/1.1", headers: headers),
            response: nil, statusCode: nil, durationMS: nil, responseLength: nil,
            error: nil, isSecure: false, host: "", port: 80
        )
    }

    static func from(_ pair: HTTPPair, index: Int, name: String? = nil) -> RepeaterTab {
        var tab = RepeaterTab(
            name: name ?? "Tab \(index)",
            request: pair.request,
            response: pair.response,
            statusCode: pair.status,
            durationMS: pair.durationMS,
            responseLength: pair.responseLength,
            error: pair.error,
            isSecure: pair.isSecure,
            host: pair.host,
            port: pair.port
        )
        tab.lastSent = pair.time
        return tab
    }

    var summary: String {
        "\(request.method) \(host.isEmpty ? request.path : host + request.path)"
    }

    var statusLabel: String {
        if let statusCode { return "\(statusCode)" }
        if error != nil { return "ERR" }
        return "—"
    }
}

@MainActor
final class RepeaterStore: ObservableObject {
    static let shared = RepeaterStore()

    @Published var tabs: [RepeaterTab] = [RepeaterTab.blank()]
    @Published var selectedID: UUID?
    @Published var isSending = false

    private var counter = 1

    var selectedIndex: Int? {
        guard let selectedID, let index = tabs.firstIndex(where: { $0.id == selectedID }) else { return nil }
        return index
    }

    func selected() -> RepeaterTab? {
        guard let index = selectedIndex else { return tabs.first }
        return tabs[index]
    }

    func addTab(_ tab: RepeaterTab) {
        tabs.append(tab)
        selectedID = tab.id
    }

    func newTab(from pair: HTTPPair? = nil) {
        counter += 1
        let tab = pair.map { RepeaterTab.from($0, index: counter) } ?? {
            var blank = RepeaterTab.blank()
            blank.name = "Tab \(counter)"
            return blank
        }()
        addTab(tab)
    }

    func close(_ id: UUID) {
        tabs.removeAll { $0.id == id }
        if tabs.isEmpty { newTab() }
        if selectedID == id { selectedID = tabs.first?.id }
    }

    func rename(_ id: UUID, to name: String) {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        tabs[index].name = name.isEmpty ? tabs[index].name : name
    }

    func update(_ id: UUID, _ mutate: (inout RepeaterTab) -> Void) {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        mutate(&tabs[index])
    }

    /// Re-derives host, port and scheme after the analyst edited the raw request.
    func syncFromEditor(_ id: UUID, markModified: Bool = true) {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        let request = tabs[index].request
        let target = request.rawTarget
        let isAbsolute = target.lowercased().hasPrefix("http://") || target.lowercased().hasPrefix("https://")

        // An absolute target is authoritative for both the origin and the scheme.
        if isAbsolute {
            let secure = target.lowercased().hasPrefix("https://")
            let route = HTTPParser.route(for: request, connectHost: nil, connectPort: nil,
                                         defaultPort: secure ? 443 : 80)
            if !route.host.isEmpty {
                tabs[index].host = route.host
                tabs[index].port = route.port
            }
            tabs[index].isSecure = secure
        } else if let header = request.header("Host"), !header.isEmpty {
            let split = HTTPParser.splitAuthority(header)
            if !split.host.isEmpty { tabs[index].host = split.host }
            if let explicit = split.port {
                tabs[index].port = explicit
                // A non-standard port on an origin-form request is plain HTTP in practice.
                if explicit != 443, !tabs[index].isSecure { tabs[index].port = explicit }
            }
        }
        if markModified { tabs[index].isModified = true }
    }

    /// Sends the tab's current request and stores the result.
    func send(_ id: UUID) async {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        isSending = true
        defer { isSending = false }

        let tab = tabs[index]
        // An absolute target is authoritative; otherwise the Host header plus the HTTPS switch decide.
        let target = tab.request.rawTarget.lowercased()
        var host = tab.host
        var port = tab.port
        var secure = tab.isSecure

        if target.hasPrefix("http://") || target.hasPrefix("https://") {
            let route = HTTPParser.route(for: tab.request, connectHost: nil, connectPort: nil, defaultPort: target.hasPrefix("https://") ? 443 : 80)
            host = route.host
            port = route.port
            secure = target.hasPrefix("https://")
        } else if let header = tab.request.header("Host"), !header.isEmpty {
            let split = HTTPParser.splitAuthority(header)
            host = split.host
            if let explicit = split.port {
                port = explicit
                // A non-standard port is almost always plain HTTP.
                if !target.hasPrefix("https://") && explicit != 443 { secure = false }
            } else {
                port = secure ? 443 : 80
            }
        }

        guard !host.isEmpty else {
            tabs[index].error = "No host — add a Host header or use an absolute URL such as https://example.com/"
            return
        }
        // Port 80 with HTTPS switched on still means 443.
        if secure, port == 80 { port = 443 }

        tabs[index].host = host
        tabs[index].port = port
        tabs[index].isSecure = secure

        var request = tab.request
        // Make the request self-consistent: drop absolute-form duplication and fix framing.
        if request.path.hasPrefix("http://") || request.path.hasPrefix("https://") {
            HTTPParser.normalizeTarget(&request)
        }
        if request.header("Content-Length") == nil, !request.body.isEmpty {
            request.normalizeFraming()
        }

        let result = await DirectSender.shared.exchange(
            request, host: host, port: port, isSecure: secure, timeoutSeconds: 60
        )

        tabs[index].request = request
        tabs[index].response = result.response
        tabs[index].statusCode = result.response?.status
        tabs[index].durationMS = result.durationMS
        tabs[index].responseLength = result.response?.body.count
        tabs[index].error = result.error
        tabs[index].lastSent = Date()
        tabs[index].isModified = false
        if let code = result.response?.status {
            tabs[index].responseHistory.append((code, result.response?.body.count ?? 0, result.durationMS, Date()))
            if tabs[index].responseHistory.count > 50 {
                tabs[index].responseHistory.removeFirst(tabs[index].responseHistory.count - 50)
            }
        }

        let txID = await ProxyEngine.shared.nextTransactionID()
        HistoryStore.shared.add(
            HTTPPair(id: txID, time: Date(), durationMS: result.durationMS, host: host, port: port,
                     isSecure: secure, request: request, response: result.response,
                     error: result.error, origin: .repeater)
        )
    }
}

// ============================================================================
//  Comparer
// ============================================================================

struct CompareResult: Identifiable, Sendable {
    var id = UUID()
    var section: String
    var field: String
    var left: String
    var right: String
    var isDifferent: Bool
}

enum Comparer {
    /// Field-level diff between two exchanges, mirroring Burp's Comparer output.
    static func compare(left: HTTPPair, right: HTTPPair) -> [CompareResult] {
        var results: [CompareResult] = []

        func row(_ section: String, _ field: String, _ a: String, _ b: String) {
            results.append(CompareResult(section: section, field: field, left: a, right: b, isDifferent: a != b))
        }

        row("Summary", "Method", left.request.method, right.request.method)
        row("Summary", "Protocol", left.request.version, right.request.version)
        row("Summary", "URL", left.url, right.url)
        row("Summary", "Status", left.status.map(String.init) ?? "—", right.status.map(String.init) ?? "—")
        row("Summary", "Response length", String(left.responseLength), String(right.responseLength))
        row("Summary", "MIME type", mimeType(left), mimeType(right))

        let leftHeaders = left.request.headers.filter(\.enabled)
        let rightHeaders = right.request.headers.filter(\.enabled)
        for name in Set(leftHeaders.map { $0.name.lowercased() }).union(rightHeaders.map { $0.name.lowercased() }).sorted() {
            let a = leftHeaders.filter { $0.name.lowercased() == name }.map(\.value).joined(separator: ", ")
            let b = rightHeaders.filter { $0.name.lowercased() == name }.map(\.value).joined(separator: ", ")
            row("Request headers", name, a, b)
        }

        if let l = left.response {
            let leftHeaders = l.headers.filter(\.enabled)
            let rightHeaders = (right.response?.headers ?? []).filter(\.enabled)
            for name in Set(leftHeaders.map { $0.name.lowercased() }).union(rightHeaders.map { $0.name.lowercased() }).sorted() {
                let a = leftHeaders.filter { $0.name.lowercased() == name }.map(\.value).joined(separator: ", ")
                let b = rightHeaders.filter { $0.name.lowercased() == name }.map(\.value).joined(separator: ", ")
                row("Response headers", name, a, b)
            }
        }

        if left.request.body != right.request.body {
            row("Request body", "<body>", left.request.bodyText, right.request.bodyText)
        }
        if (left.response?.body ?? Data()) != (right.response?.body ?? Data()) {
            row("Response body", "<body>", left.response?.bodyText ?? "", right.response?.bodyText ?? "")
        }
        return results
    }

    private static func mimeType(_ pair: HTTPPair) -> String {
        guard let type = pair.response?.contentType else { return "—" }
        return type.split(separator: ";").first.map(String.init) ?? type
    }
}