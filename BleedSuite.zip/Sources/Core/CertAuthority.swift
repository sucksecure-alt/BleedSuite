import Foundation
import Security
import CryptoKit

// ============================================================================
//  Minimal DER encoder
// ============================================================================

enum DER {
    static func encode(_ tag: UInt8, _ content: Data) -> Data {
        Data([tag]) + length(content.count) + content
    }

    static func length(_ n: Int) -> Data {
        if n < 0x80 { return Data([UInt8(n)]) }
        var bytes: [UInt8] = []
        var v = n
        while v > 0 {
            bytes.insert(UInt8(v & 0xFF), at: 0)
            v >>= 8
        }
        return Data([0x80 | UInt8(bytes.count)] + bytes)
    }

    static func sequence(_ parts: [Data]) -> Data {
        encode(0x30, parts.reduce(into: Data()) { $0.append($1) })
    }

    static func set(_ parts: [Data]) -> Data {
        encode(0x31, parts.reduce(into: Data()) { $0.append($1) })
    }

    static func integer(_ value: Data) -> Data {
        var d = value
        while d.count > 1, d.first == 0x00, (d[d.index(after: d.startIndex)] & 0x80) == 0 {
            d = Data(d.dropFirst())
        }
        if let first = d.first, first & 0x80 != 0 { d.insert(0x00, at: 0) }
        return encode(0x02, d)
    }

    static func integer(_ value: UInt64) -> Data {
        var bytes: [UInt8] = []
        var v = value
        repeat {
            bytes.insert(UInt8(v & 0xFF), at: 0)
            v >>= 8
        } while v > 0
        return integer(Data(bytes))
    }

    static func boolean(_ b: Bool) -> Data { encode(0x01, Data([b ? 0xFF : 0x00])) }

    static func oid(_ dotted: String) -> Data {
        let arcs = dotted.split(separator: ".").compactMap { UInt64($0) }
        guard arcs.count >= 2 else { return Data() }
        var bytes: [UInt8] = []
        func base128(_ value: UInt64) {
            var stack: [UInt8] = [UInt8(value & 0x7F)]
            var v = value >> 7
            while v > 0 {
                stack.insert(UInt8(0x80 | (v & 0x7F)), at: 0)
                v >>= 7
            }
            bytes.append(contentsOf: stack)
        }
        base128(arcs[0] * 40 + arcs[1])
        for arc in arcs.dropFirst(2) { base128(arc) }
        return encode(0x06, Data(bytes))
    }

    static func utf8String(_ s: String) -> Data { encode(0x0C, Data(s.utf8)) }
    static func ia5String(_ s: String) -> Data { encode(0x16, Data(s.utf8)) }
    static func octetString(_ d: Data) -> Data { encode(0x04, d) }

    static func bitString(_ content: Data, unusedBits: UInt8 = 0) -> Data {
        encode(0x03, Data([unusedBits]) + content)
    }

    static func explicit(_ number: UInt8, _ inner: Data) -> Data { encode(0xA0 | number, inner) }

    static func time(_ date: Date) -> Data {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "UTC")
        let year = Calendar(identifier: .gregorian).component(.year, from: date)
        if year >= 2050 {
            formatter.dateFormat = "yyyyMMddHHmmss'Z'"
            return encode(0x18, Data(formatter.string(from: date).utf8))
        }
        formatter.dateFormat = "yyMMddHHmmss'Z'"
        return encode(0x17, Data(formatter.string(from: date).utf8))
    }
}

// ============================================================================
//  X.509 v3 builder (ECDSA P-256 / SHA-256) — no external openssl needed
// ============================================================================

enum X509 {
    static let algorithmECPublicKey = DER.oid("1.2.840.10045.2.1")
    static let algorithmPrime256v1 = DER.oid("1.2.840.10045.3.1.7")
    static let algorithmECDSASHA256 = DER.oid("1.2.840.10045.4.3.2")

    static var algorithmIdentifier: Data { DER.sequence([algorithmECDSASHA256]) }

    static func name(commonName: String, organization: String) -> Data {
        DER.sequence([
            DER.set([DER.sequence([DER.oid("2.5.4.10"), DER.utf8String(organization)])]),
            DER.set([DER.sequence([DER.oid("2.5.4.3"), DER.utf8String(commonName)])]),
        ])
    }

    static func subjectPublicKeyInfo(publicKey: SecKey) throws -> Data {
        var error: Unmanaged<CFError>?
        guard let rep = SecKeyCopyExternalRepresentation(publicKey, &error) else {
            throw CertError.keyExportFailed(String(describing: error?.takeRetainedValue()))
        }
        // EC keys export as ANSI X9.63 (04 || X || Y), which is exactly the SPKI BIT STRING payload.
        return DER.sequence([
            DER.sequence([algorithmECPublicKey, algorithmPrime256v1]),
            DER.bitString(rep as Data),
        ])
    }

    enum SAN: Sendable {
        case dns(String)
        case ip(String)
    }

    static func certificate(
        subject: Data,
        issuer: Data,
        subjectPublicKey: SecKey,
        signingKey: SecKey,
        serial: UInt64,
        notBefore: Date,
        notAfter: Date,
        isCA: Bool,
        sans: [SAN],
        /// SKID of the issuer. Self-signed roots omit the extension, leaves carry the CA's.
        authorityKeyIdentifier: Data? = nil
    ) throws -> Data {
        let sigAlg = algorithmIdentifier
        var extensions: [Data] = []

        // BasicConstraints (2.5.29.19)
        extensions.append(DER.sequence([
            DER.oid("2.5.29.19"),
            DER.boolean(true),
            DER.octetString(DER.sequence([DER.boolean(isCA)])),
        ]))

        // KeyUsage (2.5.29.15)
        if isCA {
            // digitalSignature(0) + keyCertSign(5) + cRLSign(6)
            extensions.append(DER.sequence([
                DER.oid("2.5.29.15"), DER.boolean(true),
                DER.octetString(DER.bitString(Data([0x86]), unusedBits: 1)),
            ]))
        } else {
            // digitalSignature(0) + keyEncipherment(2)
            extensions.append(DER.sequence([
                DER.oid("2.5.29.15"), DER.boolean(true),
                DER.octetString(DER.bitString(Data([0xA0]), unusedBits: 5)),
            ]))
        }

        // ExtendedKeyUsage (2.5.29.37) — serverAuth on leaves only
        if !isCA {
            extensions.append(DER.sequence([
                DER.oid("2.5.29.37"),
                DER.octetString(DER.sequence([DER.oid("1.3.6.1.5.5.7.3.1")])),
            ]))
        }

        // SubjectKeyIdentifier (2.5.29.14)
        var error: Unmanaged<CFError>?
        guard let pubRep = SecKeyCopyExternalRepresentation(subjectPublicKey, &error) else {
            throw CertError.keyExportFailed(String(describing: error?.takeRetainedValue()))
        }
        let ski = Insecure.SHA1.hash(data: pubRep as Data)
        extensions.append(DER.sequence([
            DER.oid("2.5.29.14"),
            DER.octetString(DER.octetString(Data(ski))),
        ]))

        // AuthorityKeyIdentifier (2.5.29.35): `keyIdentifier [0] KeyIdentifier` is
        // IMPLICIT, so the tagged value *is* the raw key hash — no inner OCTET
        // STRING header. Adding one yields "wrong tag … AUTHORITY_KEYID" and every
        // verifier then reports "unable to get local issuer certificate".
        if let authorityKeyIdentifier {
            extensions.append(DER.sequence([
                DER.oid("2.5.29.35"),
                DER.octetString(DER.sequence([DER.encode(0x80, Data(authorityKeyIdentifier))])),
            ]))
        }

        // SubjectAltName (2.5.29.17)
        if !sans.isEmpty {
            var names: [Data] = []
            for san in sans {
                switch san {
                case .dns(let host):
                    // IA5String (0x16) becomes dNSName (0x82) in the GeneralName CHOICE.
                    names.append(replacingTag(DER.ia5String(host), from: 0x16, to: 0x82))
                case .ip(let ip):
                    if let bytes = parseIPv4(ip) { names.append(DER.encode(0x84, bytes)) }
                }
            }
            extensions.append(DER.sequence([
                DER.oid("2.5.29.17"),
                DER.octetString(DER.sequence(names)),
            ]))
        }

        let tbs = DER.sequence([
            DER.explicit(0, DER.integer(UInt64(2))), // v3
            DER.integer(Data(serial.bigEndianBytes)),
            sigAlg,
            issuer,
            DER.sequence([DER.time(notBefore), DER.time(notAfter)]),
            subject,
            try subjectPublicKeyInfo(publicKey: subjectPublicKey),
            DER.explicit(3, DER.sequence(extensions)),
        ])

        var signError: Unmanaged<CFError>?
        guard let signature = SecKeyCreateSignature(
            signingKey, .ecdsaSignatureMessageX962SHA256, tbs as CFData, &signError
        ) else {
            throw CertError.signingFailed(String(describing: signError?.takeRetainedValue()))
        }

        return DER.sequence([tbs, sigAlg, DER.bitString(signature as Data)])
    }

    private static func replacingTag(_ data: Data, from old: UInt8, to new: UInt8) -> Data {
        var d = data
        if !d.isEmpty { d[d.startIndex] = new }
        return d
    }

    private static func parseIPv4(_ s: String) -> Data? {
        let parts = s.split(separator: ".").compactMap { UInt8($0) }
        guard parts.count == 4 else { return nil }
        return Data(parts)
    }
}

extension UInt64 {
    var bigEndianBytes: [UInt8] {
        var v = self.bigEndian
        return withUnsafeBytes(of: &v) { Array($0) }
    }
}

// ============================================================================
//  Errors
// ============================================================================

enum CertError: Error, LocalizedError {
    case keyGenerationFailed(String)
    case keyExportFailed(String)
    case signingFailed(String)
    case identityFailed(String)
    case ioFailed(String)

    var errorDescription: String? {
        switch self {
        case .keyGenerationFailed(let m): return "Key generation failed: \(m)"
        case .keyExportFailed(let m): return "Key export failed: \(m)"
        case .signingFailed(let m): return "Certificate signing failed: \(m)"
        case .identityFailed(let m): return "Identity creation failed: \(m)"
        case .ioFailed(let m): return "IO failed: \(m)"
        }
    }
}

// ============================================================================
//  Certificate authority
// ============================================================================

/// Owns the Bleed Suite Root CA and mints per-host leaf certificates signed by it.
///
/// Everything is produced by the Security framework — there is no dependency on the
/// `openssl` binary, and no temporary key material is ever written to disk.
///
/// Leaf private keys live in a dedicated keychain file inside the app support directory
/// instead of the user's login keychain, so a long browsing session does not accumulate
/// hundreds of permanent key items in Keychain Access.
final class CertificateAuthority: @unchecked Sendable {
    static let shared = CertificateAuthority()

    let directory: URL
    let caCertificateURL: URL
    private let caKeyURL: URL
    private let leafKeychainURL: URL

    private let lock = NSLock()
    private var caKey: SecKey
    private var caSubject: Data
    /// SubjectKeyIdentifier of the Root CA, referenced by every leaf's AuthorityKeyIdentifier.
    private var caSubjectKeyID: Data
    private var leafCache: [String: SecIdentity] = [:]
    private var leafOrder: [String] = []
    /// In-memory handles to the cached leaf keys, one per host.
    private var leafKeys: [String: SecKey] = [:]
    private var leafKeychain: SecKeychain?
    /// Serialises key generation + signing + identity assembly. The keychain calls below are not
    /// safe to run concurrently, and a page load mints leaves for many hosts at once.
    private let mintLock = NSLock()
    private let maxCachedLeaves = 512

    private(set) var caCertificate: SecCertificate

    private init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("BleedSuite", isDirectory: true)
        directory = base
        caCertificateURL = base.appendingPathComponent("root-ca.der")
        caKeyURL = base.appendingPathComponent("root-ca.key")
        leafKeychainURL = base.appendingPathComponent("leafs.keychain-db")
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)

        var key: SecKey?
        var cert: SecCertificate?
        if let keyData = try? Data(contentsOf: caKeyURL),
           let certData = try? Data(contentsOf: caCertificateURL) {
            let attrs: [String: Any] = [
                kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
                kSecAttrKeyClass as String: kSecAttrKeyClassPrivate,
                kSecAttrKeySizeInBits as String: 256,
            ]
            key = SecKeyCreateWithData(keyData as CFData, attrs as CFDictionary, nil)
            cert = SecCertificateCreateWithData(nil, certData as CFData)
        }

        if key == nil || cert == nil {
            let (newKey, newCert) = CertificateAuthority.createSelfSignedCA()
            key = newKey
            cert = newCert
            if let k = newKey, let external = SecKeyCopyExternalRepresentation(k, nil) {
                try? (external as Data).write(to: caKeyURL, options: .atomic)
                try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: caKeyURL.path)
            }
            if let c = newCert, let der = SecCertificateCopyData(c) as Data? {
                try? der.write(to: caCertificateURL, options: .atomic)
            }
        }

        guard let key, let cert else {
            fatalError("Bleed Suite: unable to create the Root CA key pair (Security framework failure)")
        }
        caKey = key
        caCertificate = cert
        caSubject = X509.name(commonName: "Bleed Suite Root CA", organization: "Bleed Suite")
        caSubjectKeyID = CertificateAuthority.subjectKeyID(of: key)

        openLeafKeychain()
    }

    // MARK: - Leaf keychain

    private func openLeafKeychain() {
        if FileManager.default.fileExists(atPath: leafKeychainURL.path) {
            var kc: SecKeychain?
            if SecKeychainOpen(leafKeychainURL.path, &kc) == errSecSuccess, let kc {
                leafKeychain = kc
            }
        }
        if leafKeychain == nil {
            var kc: SecKeychain?
            let status = SecKeychainCreate(leafKeychainURL.path, 0, nil, false, nil, &kc)
            if status == errSecSuccess, let kc {
                SecKeychainUnlock(kc, UInt32.max, nil, false)
                leafKeychain = kc
            }
        }
    }

    /// Mints the P-256 key backing a leaf certificate.
    ///
    /// The key has to be **permanent in a keychain**: `SecIdentityCreateWithCertificate` resolves
    /// the private key through the keychain and fails with `errSecInvalidItemRef` (-25300) for an
    /// in-memory key. Writing to that keychain is a process-wide, non-reentrant resource, so
    /// concurrent minting used to fail outright — "Key generation failed" — and every MITM quietly
    /// degraded to an opaque tunnel. Callers hold `mintLock` across generation, signing and
    /// identity assembly, and a cached per-host key means a repeat CONNECT costs nothing.
    private func generateLeafKey(host: String) -> SecKey? {
        lock.lock()
        if let cached = leafKeys[host] {
            lock.unlock()
            return cached
        }
        let kc = leafKeychain
        lock.unlock()

        let tag = "bleed.leaf.\(host)"
        let privateAttrs: [String: Any] = [
            kSecAttrIsPermanent as String: true,
            kSecAttrApplicationTag as String: Data(tag.utf8),
            kSecAttrLabel as String: "Bleed Suite MITM \(host)",
        ]
        var attrs: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
            kSecAttrKeySizeInBits as String: 256,
            kSecPrivateKeyAttrs as String: privateAttrs,
        ]
        if let kc { attrs[kSecUseKeychain as String] = kc }

        guard let key = SecKeyCreateRandomKey(attrs as CFDictionary, nil) else { return nil }

        lock.lock()
        let settled = leafKeys[host] ?? key
        leafKeys[host] = settled
        lock.unlock()
        return settled
    }

    private func deleteLeafKey(host: String) {
        lock.lock()
        let kc = leafKeychain
        leafKeys.removeValue(forKey: host)
        lock.unlock()

        var attrs: [String: Any] = [
            kSecClass as String: kSecClassKey,
            kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
            kSecAttrApplicationTag as String: Data("bleed.leaf.\(host)".utf8),
        ]
        if let kc { attrs[kSecUseKeychain as String] = kc }
        SecItemDelete(attrs as CFDictionary)
    }

    // MARK: - CA material

    var caCertificateDER: Data { (SecCertificateCopyData(caCertificate) as Data?) ?? Data() }

    var caCertificatePEM: String {
        let b64 = caCertificateDER.base64EncodedString(options: [.lineLength64Characters, .endLineWithLineFeed])
        return "-----BEGIN CERTIFICATE-----\n\(b64)\n-----END CERTIFICATE-----\n"
    }

    var fingerprintSHA256: String {
        let digest = SHA256.hash(data: caCertificateDER)
        return digest.map { String(format: "%02X", $0) }.joined(separator: ":")
    }

    var subjectSummary: String { "Bleed Suite Root CA" }

    private static func createSelfSignedCA() -> (SecKey?, SecCertificate?) {
        let key = generateEphemeralKey()
        guard let key, let pub = SecKeyCopyPublicKey(key) else { return (nil, nil) }
        let name = X509.name(commonName: "Bleed Suite Root CA", organization: "Bleed Suite")
        let now = Date()
        guard let der = try? X509.certificate(
            subject: name, issuer: name, subjectPublicKey: pub, signingKey: key,
            serial: randomSerial(), notBefore: now.addingTimeInterval(-3600),
            notAfter: now.addingTimeInterval(60 * 60 * 24 * 3650), isCA: true, sans: []
        ) else { return (key, nil) }
        return (key, SecCertificateCreateWithData(nil, der as CFData))
    }

    static func generateEphemeralKey() -> SecKey? {
        let attrs: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
            kSecAttrKeySizeInBits as String: 256,
            kSecPrivateKeyAttrs as String: [kSecAttrIsPermanent as String: false],
        ]
        return SecKeyCreateRandomKey(attrs as CFDictionary, nil)
    }

    /// SHA-1 over the *public* key's external representation — the same value that
    /// `X509.certificate` writes into SubjectKeyIdentifier. Hashing the private key
    /// instead yields an identifier no verifier can match.
    static func subjectKeyID(of key: SecKey) -> Data {
        guard let publicKey = SecKeyCopyPublicKey(key),
              let rep = SecKeyCopyExternalRepresentation(publicKey, nil) else { return Data() }
        return Data(Insecure.SHA1.hash(data: rep as Data))
    }

    static func randomSerial() -> UInt64 {
        var s: UInt64 = 0
        _ = SecRandomCopyBytes(kSecRandomDefault, MemoryLayout<UInt64>.size, &s)
        return (s >> 1) | (1 << 62)
    }

    // MARK: - Leaf issuance

    func identity(for host: String) throws -> SecIdentity {
        lock.lock()
        if let cached = leafCache[host] {
            touch(host)
            lock.unlock()
            return cached
        }
        lock.unlock()

        // One leaf at a time. The keychain calls below are process-wide and reentrancy-hostile;
        // without this a single page load mints a dozen leaves at once and half of them fail.
        mintLock.lock()
        defer { mintLock.unlock() }

        lock.lock()
        if let cached = leafCache[host] {
            touch(host)
            lock.unlock()
            return cached
        }
        lock.unlock()

        guard let leafKey = generateLeafKey(host: host), let leafPub = SecKeyCopyPublicKey(leafKey) else {
            throw CertError.keyGenerationFailed("leaf key for \(host)")
        }

        let labels = host.split(separator: ".")
        let isIPv4 = labels.count == 4 && labels.allSatisfy { UInt8($0) != nil }
        var sans: [X509.SAN]
        if isIPv4 {
            sans = [.ip(host)]
        } else {
            sans = [.dns(host)]
            if labels.count > 2 { sans.append(.dns("*." + labels.suffix(2).joined(separator: "."))) }
        }

        let now = Date()
        let der = try X509.certificate(
            subject: X509.name(commonName: host, organization: "Bleed Suite"),
            issuer: caSubject, subjectPublicKey: leafPub, signingKey: caKey,
            serial: CertificateAuthority.randomSerial(),
            notBefore: now.addingTimeInterval(-3600),
            notAfter: now.addingTimeInterval(60 * 60 * 24 * 825),
            isCA: false, sans: sans,
            authorityKeyIdentifier: caSubjectKeyID
        )

        guard let leafCert = SecCertificateCreateWithData(nil, der as CFData) else {
            throw CertError.identityFailed("invalid DER produced for \(host)")
        }

        var identity: SecIdentity?
        var status = SecIdentityCreateWithCertificate(nil, leafCert, &identity)
        if status != errSecSuccess || identity == nil {
            // The certificate is in memory but the key may not have landed in the keychain yet.
            persistKey(leafKey, host: host)
            status = SecIdentityCreateWithCertificate(nil, leafCert, &identity)
        }
        guard let identity, status == errSecSuccess else {
            throw CertError.identityFailed("SecIdentityCreateWithCertificate(\(host)) -> \(status)")
        }

        lock.lock()
        leafCache[host] = identity
        touch(host)
        evictIfNeeded()
        lock.unlock()
        return identity
    }

    private func touch(_ host: String) {
        if let idx = leafOrder.firstIndex(of: host) { leafOrder.remove(at: idx) }
        leafOrder.append(host)
    }

    private func evictIfNeeded() {
        while leafOrder.count > maxCachedLeaves {
            let victim = leafOrder.removeFirst()
            leafCache.removeValue(forKey: victim)
            deleteLeafKey(host: victim)
        }
    }

    private func persistKey(_ key: SecKey, host: String) {
        var keyAttrs: [String: Any] = [
            kSecClass as String: kSecClassKey,
            kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
            kSecAttrKeyClass as String: kSecAttrKeyClassPrivate,
            kSecAttrApplicationTag as String: Data("bleed.leaf.\(host)".utf8),
            kSecAttrLabel as String: "Bleed Suite MITM \(host)",
            kSecValueRef as String: key,
            kSecAttrIsPermanent as String: true,
        ]
        lock.lock()
        let kc = leafKeychain
        lock.unlock()
        if let kc { keyAttrs[kSecUseKeychain as String] = kc }
        SecItemDelete(keyAttrs as CFDictionary)
        if SecItemAdd(keyAttrs as CFDictionary, nil) != errSecSuccess {
            keyAttrs.removeValue(forKey: kSecValueRef as String)
            SecItemAdd(keyAttrs as CFDictionary, nil)
        }
    }

    func cachedLeafCount() -> Int {
        lock.lock(); defer { lock.unlock() }
        return leafCache.count
    }

    /// DER of the leaf certificate issued for `host` — used by diagnostics and tests.
    func leafDER(for host: String) throws -> Data {
        let identity = try identity(for: host)
        var leaf: SecCertificate?
        let status = SecIdentityCopyCertificate(identity, &leaf)
        guard status == errSecSuccess, let leaf else {
            throw CertError.identityFailed("SecIdentityCopyCertificate(\(host)) -> \(status)")
        }
        return SecCertificateCopyData(leaf) as Data
    }

    func clearLeafCache() {
        lock.lock()
        let hosts = leafOrder
        leafCache.removeAll()
        leafOrder.removeAll()
        lock.unlock()
        for host in hosts { deleteLeafKey(host: host) }
    }

    // MARK: - Trust management

    struct TrustResult {
        var ok: Bool
        var message: String
    }

    /// Installs the Root CA into the user trust store (`login.keychain-db`).
    @discardableResult
    func installTrust(systemWide: Bool = false) -> TrustResult {
        let arguments: [String]
        if systemWide {
            arguments = ["add-trusted-cert", "-d", "-r", "trustRoot", "-k", "/Library/Keychains/System.keychain", caCertificateURL.path]
        } else {
            let keychain = NSString(string: "~/Library/Keychains/login.keychain-db").expandingTildeInPath
            arguments = ["add-trusted-cert", "-r", "trustRoot", "-k", keychain, caCertificateURL.path]
        }
        guard let output = try? runSecurity(arguments) else {
            return TrustResult(ok: false, message: "security add-trusted-cert could not be launched")
        }
        if output.ok {
            return TrustResult(ok: true, message: "Root CA trusted (\(systemWide ? "system" : "user") store)")
        }
        return TrustResult(ok: false, message: output.combined.isEmpty
                           ? "security exited with code \(output.status)"
                           : output.combined.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    func removeTrust(systemWide: Bool = false) -> TrustResult {
        let domain = systemWide ? "/Library/Keychains/System.keychain"
            : NSString(string: "~/Library/Keychains/login.keychain-db").expandingTildeInPath
        guard let output = try? runSecurity(["remove-trusted-cert", "-d", caCertificateURL.path, "-k", domain]) else {
            return TrustResult(ok: false, message: "security remove-trusted-cert could not be launched")
        }
        return output.ok
            ? TrustResult(ok: true, message: "Root CA removed from trust store")
            : TrustResult(ok: false, message: output.combined.isEmpty ? "not trusted" : output.combined)
    }

    /// Whether the CA currently validates against the system trust store.
    var isTrusted: Bool {
        guard let output = try? runSecurity(["verify-cert", "-c", caCertificateURL.path]) else { return false }
        return output.ok
    }

    /// Discards the Root CA and creates a fresh one. All cached leaves are invalidated.
    func rotate() throws {
        lock.lock()
        leafCache.removeAll()
        leafOrder.removeAll()
        lock.unlock()

        leafKeys.removeAll()
        try? FileManager.default.removeItem(at: leafKeychainURL)

        let (key, cert) = CertificateAuthority.createSelfSignedCA()
        guard let key, let cert, let external = SecKeyCopyExternalRepresentation(key, nil) else {
            throw CertError.keyGenerationFailed("rotation")
        }
        try? (external as Data).write(to: caKeyURL, options: .atomic)
        try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: caKeyURL.path)
        let der = SecCertificateCopyData(cert) as Data
        try der.write(to: caCertificateURL, options: .atomic)

        lock.lock()
        caKey = key
        caCertificate = cert
        caSubjectKeyID = CertificateAuthority.subjectKeyID(of: key)
        lock.unlock()
    }

    // MARK: - helpers

    private func runSecurity(_ arguments: [String]) throws -> (ok: Bool, status: Int32, combined: String) {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/security")
        process.arguments = arguments
        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe
        process.standardInput = FileHandle.nullDevice
        try process.run()
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        let text = String(data: data, encoding: .utf8) ?? ""
        return (process.terminationStatus == 0, process.terminationStatus, text)
    }
}