// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "BleedSuite",
    platforms: [.macOS(.v14)],
    targets: [
        .executableTarget(
            name: "BleedSuite",
            path: "Sources",
            swiftSettings: [.swiftLanguageMode(.v5)],
            linkerSettings: [
                .linkedLibrary("sqlite3"),
                .linkedFramework("Network"),
                .linkedFramework("Security"),
                .linkedFramework("CryptoKit"),
            ]
        ),
    ]
)