#!/usr/bin/env swift
// Prints the window id of the first on-screen window owned by "BleedSuite".
// Used by scripts/screens.sh so the shot captures the app window and not whatever
// happens to be floating in front of it.
import CoreGraphics
import Foundation

let wanted = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "BleedSuite"
let info = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID)
    as? [[String: Any]] ?? []

var best: (Int, Int) = (-1, -1)
for w in info {
    let owner = (w[kCGWindowOwnerName as String] as? String) ?? ""
    guard owner.lowercased() == wanted.lowercased() else { continue }
    let number = (w[kCGWindowNumber as String] as? Int) ?? -1
    let bounds = (w[kCGWindowBounds as String] as? [String: Any]) ?? [:]
    let area = (bounds["Width"] as? Double ?? 0) * (bounds["Height"] as? Double ?? 0)
    if area > Double(best.1) { best = (number, Int(area)) }
}
print(best.0)