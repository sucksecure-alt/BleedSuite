#!/bin/bash
# Browser-shaped load: hammer a real host with many parallel connections and report
# failures, timeouts and thread growth. This is the shape that produced
# "Timed out connecting to <host>:443" at a few hundred requests.
cd ~/Downloads/BleedSuite || exit 1

HOST=${1:-example.com}
ROUNDS=${2:-20}
PER=${3:-15}

pkill -9 -f "\.build/debug/BleedSuite" 2>/dev/null
sleep 1
nohup ./.build/debug/BleedSuite > /tmp/bleed-load-real.log 2>&1 &
sleep 9

PID=$(pgrep -f "\.build/debug/BleedSuite" | head -1)
echo "pid=$PID host=$HOST"

ok=0; fail=0; timeout=0
for r in $(seq 1 "$ROUNDS"); do
    pids=""
    for n in $(seq 1 "$PER"); do
        (
            code=$(curl -sk -x http://127.0.0.1:8080 -m 15 -o /dev/null -w '%{http_code}' \
                "https://$HOST/page$r-$n")
            case "$code" in
                200|301|302|404) echo ok ;;
                000) echo timeout ;;
                *)   echo "bad:$code" ;;
            esac
        ) > /tmp/bleed-cell.$n 2>/dev/null &
        pids="$pids $!"
    done
    for p in $pids; do wait "$p" 2>/dev/null; done
    cat /tmp/bleed-cell.* 2>/dev/null | sort | uniq -c
    rm -f /tmp/bleed-cell.*
    o=$(echo ok | wc -l)
    alive=$(pgrep -f "\.build/debug/BleedSuite" | head -1)
    if [ -z "$alive" ]; then echo "t=$r PROCESS GONE"; break; fi
    echo "t=$r threads=$(ps -M "$alive" | wc -l) rssMB=$(( $(ps -o rss= -p "$alive") / 1024 ))"
done

echo
echo "=== totals ==="
echo "ok      : $ok"
echo "failed  : $fail"
echo "timeout : $timeout"
echo "timeouts in log: $(grep -c 'Timed out' /tmp/bleed-load-real.log)"
echo "upstream errors: $(grep -c 'upstream error' /tmp/bleed-load-real.log)"
grep -iE "Timed out|upstream error" /tmp/bleed-load-real.log | sed 's/.*error/error/' | sort | uniq -c | sort -rn | head -5

pkill -9 -f "\.build/debug/BleedSuite" 2>/dev/null
exit 0