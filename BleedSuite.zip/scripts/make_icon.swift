#!/usr/bin/env swift
//
// Renders the Bleed Suite app icon: a crimson droplet over a dark,
// subtly-lit rounded-rect plate. Run with `swift scripts/make_icon.swift <outdir>`.
//
import AppKit
import Foundation

let outDir = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "Resources"
let fm = FileManager.default
try? fm.createDirectory(atPath: outDir, withIntermediateDirectories: true)

func color(_ hex: UInt32, _ a: CGFloat = 1) -> NSColor {
    NSColor(srgbRed: CGFloat((hex >> 16) & 0xFF) / 255,
            green: CGFloat((hex >> 8) & 0xFF) / 255,
            blue: CGFloat(hex & 0xFF) / 255, alpha: a)
}

func drawIcon(size: CGFloat) -> Data {
    let image = NSImage(size: NSSize(width: size, height: size))
    image.lockFocus()

    // ---- plate: macOS "squircle"-ish rounded rect with a vertical gradient ----
    let inset = size * 0.055
    let rect = NSRect(x: inset, y: inset, width: size - inset * 2, height: size - inset * 2)
    let plate = NSBezierPath(roundedRect: rect, xRadius: size * 0.2237, yRadius: size * 0.2237)

    let gradient = NSGradient(colors: [
        color(0x1A1A22),
        color(0x0C0C11),
        color(0x050508),
    ])
    gradient?.draw(in: plate, angle: -90)

    // soft crimson bloom in the upper third
    NSGraphicsContext.saveGraphicsState()
    plate.addClip()
    let bloom = NSGradient(colors: [color(0xE02B4A, 0.55), color(0xE02B4A, 0)])
    bloom?.draw(in: NSRect(x: rect.minX, y: rect.midY, width: rect.width, height: rect.height / 2),
                relativeCenterPosition: NSPoint(x: 0, y: 0))
    NSGraphicsContext.restoreGraphicsState()

    // inner hairline
    plate.lineWidth = max(1, size * 0.006)
    color(0xFFFFFF, 0.10).setStroke()
    let inner = NSBezierPath(roundedRect: rect.insetBy(dx: size * 0.012, dy: size * 0.012),
                              xRadius: size * 0.2137, yRadius: size * 0.2137)
    inner.lineWidth = max(1, size * 0.005)
    inner.stroke()

    // ---- droplet ----
    let cx = size / 2
    let top = size * 0.76
    let bottom = size * 0.245
    let halfWidth = size * 0.178

    let drop = NSBezierPath()
    drop.move(to: NSPoint(x: cx, y: top))
    // right shoulder
    drop.curve(to: NSPoint(x: cx + halfWidth, y: bottom + size * 0.13),
               controlPoint1: NSPoint(x: cx + size * 0.015, y: top - size * 0.055),
               controlPoint2: NSPoint(x: cx + halfWidth, y: bottom + size * 0.29))
    // bottom bulb
    drop.curve(to: NSPoint(x: cx - halfWidth, y: bottom + size * 0.13),
               controlPoint1: NSPoint(x: cx + halfWidth, y: bottom - size * 0.012),
               controlPoint2: NSPoint(x: cx - halfWidth, y: bottom - size * 0.012))
    // left shoulder back to the tip
    drop.curve(to: NSPoint(x: cx, y: top),
               controlPoint1: NSPoint(x: cx - halfWidth, y: bottom + size * 0.29),
               controlPoint2: NSPoint(x: cx - size * 0.015, y: top - size * 0.055))
    drop.close()

    NSGraphicsContext.saveGraphicsState()
    NSShadow().set()
    let shadow = NSShadow()
    shadow.shadowColor = color(0xFF2D55, 0.75)
    shadow.shadowBlurRadius = size * 0.10
    shadow.shadowOffset = NSSize(width: 0, height: -size * 0.012)
    shadow.set()

    let dropGradient = NSGradient(colors: [color(0xFF3B5C), color(0xE02B4A), color(0x8E1230)])
    dropGradient?.draw(in: drop, angle: -90)
    NSGraphicsContext.restoreGraphicsState()

    // highlight inside the droplet
    NSGraphicsContext.saveGraphicsState()
    drop.addClip()
    color(0xFFFFFF, 0.32).setFill()
    let highlight = NSBezierPath(ovalIn: NSRect(x: cx - size * 0.085, y: bottom + size * 0.12,
                                               width: size * 0.075, height: size * 0.145))
    highlight.fill()
    NSGraphicsContext.restoreGraphicsState()

    // drip highlight on the plate
    color(0xFF3B5C, 0.55).setFill()
    NSBezierPath(ovalIn: NSRect(x: cx - size * 0.035, y: rect.minY + size * 0.055,
                                width: size * 0.07, height: size * 0.035)).fill()

    image.unlockFocus()

    guard let tiff = image.tiffRepresentation,
          let rep = NSBitmapImageRep(data: tiff),
          let png = rep.representation(using: .png, properties: [:]) else {
        FileHandle.standardError.write(Data("failed to render icon\n".utf8))
        exit(1)
    }
    return png
}

let iconset = "\(outDir)/AppIcon.iconset"
try? fm.removeItem(atPath: iconset)
try! fm.createDirectory(atPath: iconset, withIntermediateDirectories: true)

let variants: [(name: String, size: CGFloat, scale: Int)] = [
    ("icon_16x16", 16, 1), ("icon_16x16@2x", 32, 2),
    ("icon_32x32", 32, 1), ("icon_32x32@2x", 64, 2),
    ("icon_128x128", 128, 1), ("icon_128x128@2x", 256, 2),
    ("icon_256x256", 256, 1), ("icon_256x256@2x", 512, 2),
    ("icon_512x512", 512, 1), ("icon_512x512@2x", 1024, 2),
]

for variant in variants {
    let data = drawIcon(size: variant.size)
    try! data.write(to: URL(fileURLWithPath: "\(iconset)/\(variant.name).png"))
}

// macOS app icons are drawn inside a rounded-rect plate; strip it for icns.
let icns = "\(outDir)/AppIcon.icns"
try? fm.removeItem(atPath: icns)
let task = Process()
task.executableURL = URL(fileURLWithPath: "/usr/bin/iconutil")
task.arguments = ["-c", "icns", iconset, "-o", icns]
try? task.run()
task.waitUntilExit()

if fm.fileExists(atPath: icns) {
    try? fm.removeItem(atPath: iconset)
    print("icon written to \(icns)")
} else {
    print("iconutil failed; PNGs left in \(iconset)")
}