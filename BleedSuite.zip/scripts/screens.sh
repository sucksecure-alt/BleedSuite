#!/bin/bash
# Smoke-test every workspace screen: launch on a tab, drive traffic, capture the app window.
#
# Notes:
#  * Only the curl workers are waited on. A bare `wait` would also wait for the app launched in
#    the background and the script would never finish.
#  * The window is captured by id rather than full-screen, otherwise whatever is in front of
#    the app ends up in the shot.
cd ~/Downloads/BleedSuite || exit 1
OUT=/tmp/bleed-shots
WID=/tmp/bleed-wid
rm -rf "$OUT"; mkdir -p "$OUT"

SDKROOT=${SDKROOT:-/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk}
export SDKROOT
swiftc -O scripts/windowid.swift -o "$WID" 2>/dev/null || { echo "cannot build windowid helper"; exit 1; }

for tab in dashboard intercept history target repeater comparer intruder scanner rules settings; do
    pkill -9 -f "\.build/debug/BleedSuite" 2>/dev/null
    sleep 1
    nohup ./.build/debug/BleedSuite --open "$tab" > "/tmp/bleed-tab-$tab.log" 2>&1 &
    app=$!
    sleep 7

    workers=""
    for u in "https://example.com/?tab=$tab" "https://www.iana.org/?tab=$tab" \
             "http://neverssl.com/?tab=$tab" "https://github.com/?tab=$tab"; do
        curl -sk -x http://127.0.0.1:8080 -m 10 -o /dev/null "$u" &
        workers="$workers $!"
    done
    for w in $workers; do wait "$w" 2>/dev/null; done

    sleep 4
    wid=$("$WID" BleedSuite 2>/dev/null | tail -1)
    if [ -n "$wid" ] && [ "$wid" != "-1" ]; then
        screencapture -x -o -l "$wid" "$OUT/$tab.png"
    else
        screencapture -x -o "$OUT/$tab.png"
        echo "$tab: window not found, full-screen fallback"
    fi

    if kill -0 "$app" 2>/dev/null; then
        echo "$tab: ok threads=$(ps -M "$app" | wc -l)"
    else
        echo "$tab: DIED"
    fi
done

pkill -9 -f "\.build/debug/BleedSuite" 2>/dev/null
echo "shots in $OUT"
exit 0