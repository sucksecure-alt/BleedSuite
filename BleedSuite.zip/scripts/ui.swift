#!/usr/bin/env swift
// Synthesises mouse clicks so the UI can actually be driven from a terminal.
//
//   click <x> <y>          click at global points
//   clickmove <x1> <y1> <x2> <y2>
//   window                 prints "id x y w h" of the Bleed Suite window
//
// Coordinates are global screen points. CGEventPost needs Accessibility permission for the
// posting process; if that is missing the clicks silently do nothing, so `window` is the way
// to check what we are aiming at first.
import CoreGraphics
import AppKit
import Foundation

/// Brings the app to the front. Injected clicks land on whatever window is frontmost, so this
/// has to run first or the click is delivered to some other app entirely.
func activate(_ name: String) {
    let wanted = name.lowercased()
    for app in NSWorkspace.shared.runningApplications {
        let local = (app.localizedName ?? "").lowercased()
        if local.contains(wanted) {
            app.activate(options: [.activateAllWindows, .activateIgnoringOtherApps])
            return
        }
    }
}

func windowRect() -> (id: Int, x: Int, y: Int, w: Int, h: Int)? {
    let info = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID)
        as? [[String: Any]] ?? []
    var best: (Int, CGRect)?
    for w in info {
        let owner = (w[kCGWindowOwnerName as String] as? String) ?? ""
        guard owner.lowercased() == "bleedsuite" else { continue }
        guard let number = w[kCGWindowNumber as String] as? Int,
              let bounds = w[kCGWindowBounds as String] as? [String: Any],
              let rect = CGRect(dictionaryRepresentation: bounds as CFDictionary) else { continue }
        if best == nil || rect.width * rect.height > best!.1.width * best!.1.height {
            best = (number, rect)
        }
    }
    guard let b = best else { return nil }
    return (b.0, Int(b.1.origin.x), Int(b.1.origin.y), Int(b.1.width), Int(b.1.height))
}

@discardableResult
func moveMouse(_ x: Double, _ y: Double) -> Bool {
    guard let move = CGEvent(mouseEventSource: nil, mouseType: .mouseMoved,
                             mouseCursorPosition: CGPoint(x: x, y: y), mouseButton: .left) else { return false }
    move.post(tap: .cghidEventTap)
    return true
}

func post(_ type: CGEventType, _ x: Double, _ y: Double, clickCount: Int64 = 1) {
    _ = moveMouse(x, y)
    usleep(60_000)

    guard let down = CGEvent(mouseEventSource: nil, mouseType: .leftMouseDown,
                             mouseCursorPosition: CGPoint(x: x, y: y), mouseButton: .left),
          let up = CGEvent(mouseEventSource: nil, mouseType: .leftMouseUp,
                           mouseCursorPosition: CGPoint(x: x, y: y), mouseButton: .left) else { return }
    down.setIntegerValueField(.mouseEventClickState, value: clickCount)
    up.setIntegerValueField(.mouseEventClickState, value: clickCount)
    down.post(tap: .cghidEventTap)
    usleep(50_000)
    up.post(tap: .cghidEventTap)
}

let args = CommandLine.arguments
guard args.count > 1 else { print("usage: ui <command>"); exit(2) }

switch args[1] {
case "activate":
    activate(args.count > 2 ? args[2] : "BleedSuite")
    usleep(400_000)
case "window":
    if let r = windowRect() { print("\(r.id) \(r.x) \(r.y) \(r.w) \(r.h)") } else { print("-1"); }
case "click":
    guard args.count > 3, let x = Double(args[2]), let y = Double(args[3]) else { exit(2) }
    post(.leftMouseDown, x, y)
    post(.leftMouseUp, x, y)
case "double":
    guard args.count > 3, let x = Double(args[2]), let y = Double(args[3]) else { exit(2) }
    post(.leftMouseDown, x, y, clickCount: 1)
    post(.leftMouseDown, x, y, clickCount: 2)
case "move":
    guard args.count > 3, let x = Double(args[2]), let y = Double(args[3]) else { exit(2) }
    post(.mouseMoved, x, y)
default:
    print("unknown command")
    exit(2)
}
exit(0)