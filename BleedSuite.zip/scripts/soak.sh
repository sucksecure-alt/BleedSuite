#!/bin/bash
# Load soak: N rounds of parallel requests through the running proxy, reporting
# thread count, latency failures and whether the process survived.
cd ~/Downloads/BleedSuite || exit 1
ROUNDS=${1:-8}
PER=${2:-10}
PORT=${3:-8080}

pkill -9 -f "\.build/debug/BleedSuite" 2>/dev/null
sleep 1
nohup ./.build/debug/BleedSuite > /tmp/bleed-soak.log 2>&1 < /dev/null &
disown 2>/dev/null || true
sleep 9

PID=$(pgrep -f "\.build/debug/BleedSuite" | head -1)
if [ -z "$PID" ]; then echo "app failed to start"; exit 1; fi
echo "pid=$PID start_threads=$(ps -M "$PID" | wc -l)"

fail=0
for i in $(seq 1 "$ROUNDS"); do
    pids=""
    for n in $(seq 1 "$PER"); do
        (
            code=$(curl -sk -x "http://127.0.0.1:$PORT" -m 12 -o /dev/null -w "%{http_code}" \
                "https://example.com/p$i-$n")
            [ "$code" = "200" ] || echo "bad $code https example.com/p$i-$n"
        ) &
        pids="$pids $!"
        (
            code=$(curl -sk -x "http://127.0.0.1:$PORT" -m 12 -o /dev/null -w "%{http_code}" \
                "https://www.iana.org/h?q$i$n")
            [ "$code" = "200" ] || echo "bad $code https iana.org/h?q$i$n"
        ) &
        pids="$pids $!"
    done
    # Never let a stuck worker hold the whole soak hostage.
    ( sleep 40; kill -9 $pids 2>/dev/null ) &
    killer=$!
    for p in $pids; do wait "$p" 2>/dev/null || fail=$((fail+1)); done
    kill -9 "$killer" 2>/dev/null
    alive=$(pgrep -f "\.build/debug/BleedSuite" | head -1)
    if [ -z "$alive" ]; then
        echo "t=$i PROCESS GONE"
        break
    fi
    echo "t=$i threads=$(ps -M "$alive" | wc -l) rssMB=$(( $(ps -o rss= -p "$alive") / 1024 ))"
done

alive=$(pgrep -f "\.build/debug/BleedSuite" | head -1)
if [ -n "$alive" ]; then
    echo "SURVIVED threads=$(ps -M "$alive" | wc -l) rssMB=$(( $(ps -o rss= -p "$alive") / 1024 ))"
else
    echo "DIED"
fi
echo "handshake_failed=$(grep -c 'handshake failed' /tmp/bleed-soak.log)"
echo "opaque=$(grep -c 'Opaque tunnel' /tmp/bleed-soak.log)"
echo "keygen_failed=$(grep -c 'Key generation failed' /tmp/bleed-soak.log)"
echo "tls_terminated=$(grep -c 'TLS terminated' /tmp/bleed-soak.log)"
pkill -9 -f "\.build/debug/BleedSuite" 2>/dev/null
exit 0