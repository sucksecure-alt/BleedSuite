#!/bin/bash
# Fetches the same pages directly and through the proxy and compares status, byte count
# and wall time. A proxy that "shows requests" but breaks the page shows up here as a
# mismatched body length or a timeout.
cd ~/Downloads/BleedSuite || exit 1

pkill -9 -f "\.build/debug/BleedSuite" 2>/dev/null
sleep 1
nohup ./.build/debug/BleedSuite > /tmp/bleed-real.log 2>&1 &
sleep 9

nc -z 127.0.0.1 8080 || { echo "proxy is not listening"; exit 1; }

pages=(
    "https://example.com/"
    "https://www.iana.org/"
    "https://en.wikipedia.org/wiki/Main_Page"
    "https://www.rfc-editor.org/rfc/rfc9110.html"
    "https://news.ycombinator.com/"
)

printf '%-46s %-14s %-14s %s\n' "page" "direct" "proxied" "verdict"
for u in "${pages[@]}"; do
    d=$(curl -sk -m 25 -o /tmp/d.html -w '%{http_code}/%{size_download}' "$u")
    p=$(curl -sk -m 25 -x http://127.0.0.1:8080 -o /tmp/p.html -w '%{http_code}/%{size_download}' "$u")

    dcode=${d%%/*}; pcode=${p%%/*}
    dsize=${d##*/}; psize=${p##*/}
    verdict="ok"
    [ "$dcode" != "$pcode" ] && verdict="STATUS MISMATCH"
    [ "$dsize" != "$psize" ] && verdict="SIZE MISMATCH ($dsize vs $psize)"
    [ "$pcode" = "000" ] && verdict="PROXY FAILED"
    printf '%-46s %-14s %-14s %s\n' "$u" "$d" "$p" "$verdict"
done

echo
echo "=== asset fan-out (one page, every subresource) ==="
curl -sk -m 30 -x http://127.0.0.1:8080 -o /tmp/page.html "https://en.wikipedia.org/wiki/Main_Page"
count=$(grep -oE 'href="/wiki/[^"#]+"' /tmp/page.html | sed 's/href="//; s/"$//' | sort -u | head -12)
n=0; bad=0
while read -r p; do
    [ -z "$p" ] && continue
    n=$((n+1))
    code=$(curl -sk -m 20 -x http://127.0.0.1:8080 -o /dev/null -w '%{http_code}' "https://en.wikipedia.org$p")
    if [ "$code" = "000" ]; then bad=$((bad+1)); echo "  FAILED $code $p"; fi
done <<< "$count"
echo "subresources: $n fetched, $bad failed"

echo
echo "=== proxy log summary ==="
echo "upstream errors : $(grep -c 'upstream error' /tmp/bleed-real.log)"
echo "timeouts        : $(grep -c 'Timed out' /tmp/bleed-real.log)"
echo "tls terminated  : $(grep -c 'TLS terminated' /tmp/bleed-real.log)"
echo "opaque tunnels  : $(grep -c 'Opaque tunnel' /tmp/bleed-real.log)"
grep -iE "upstream error|Timed out" /tmp/bleed-real.log | sort | uniq -c | sort -rn | head -5

pkill -9 -f "\.build/debug/BleedSuite" 2>/dev/null
exit 0